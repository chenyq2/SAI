/****************************************************************************
* $Id$
*  some util function
*
* (C) Copyright Centec Networks Inc.  All rights reserved.
*
* Modify History:
* Revision      : R0.01
* Author        : Alexander
* Date          : 2014-10-30 11:14
* Reason        : First Create.
****************************************************************************/

/****************************************************************************
 *
* Header Files
* 
****************************************************************************/

/****************************************************************************
 *
* Defines and Macros
* 
****************************************************************************/

/****************************************************************************
 *
* Global and Declaration
* 
****************************************************************************/

/****************************************************************************
 *
* Function
* 
****************************************************************************/

int sal_cmd_exec(char *pszRetBuf, size_t nBufSize, const char *pszCmdFmt, ...)
{
    /* unimplementted */
    return -1;
}

int sal_cmd_exec_file(char *pszDestFile, const char *pszCmdFmt, ...)
{
    /* unimplementted */
    return -1;
}

int sal_cmd_get_token(char *pszBuf, char *pszToken, char *pszValue, size_t nValueSize)
{
    return -1;
}



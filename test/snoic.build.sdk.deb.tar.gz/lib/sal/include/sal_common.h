#ifndef __SAL_COMMON_H__
#define __SAL_COMMON_H__
#include "sal.h"
#endif /* !__SAL_COMMON_H__ */

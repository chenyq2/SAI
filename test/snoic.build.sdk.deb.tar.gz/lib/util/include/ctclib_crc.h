#ifndef _CTCLIB_CRC_H
#define _CTCLIB_CRC_H


uint32 ctclib_gen_crc32(uint32 crc, char *buf, size_t len);



#endif


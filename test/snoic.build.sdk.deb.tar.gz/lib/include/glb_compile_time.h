/* Auto generated file, please don't modify!!! */
#ifndef _COMPILE_TIME_H
#define _COMPILE_TIME_H

#define COMPILE_TIME 1509366069
#define COMPILE_TIME_STR "Oct 30 20:21:09 2017"

#endif

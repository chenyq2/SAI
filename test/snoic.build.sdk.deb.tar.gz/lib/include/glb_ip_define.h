#ifndef __GLB_IP_DEFINE_H__
#define __GLB_IP_DEFINE_H__

#define GLB_SSH_PORT_DEF        22
#define GLB_TELNET_PORT_DEF     23
#define GLB_HTTP_PORT_DEF       80

typedef uint32 in4_addr;
typedef struct sal_in4_addr addr_ipv4_t;
typedef struct in6_addr addr_ipv6_t;

#define GLB_IPV4_MAX_PREFIXLEN 32
#define GLB_IPV4_STR_LEN 16   


#define GLB_MAX_NH_ECMP_NUM   8
#define GLB_MAX_IPV4_MASK_LEN 32
#define GLB_MAX_IPV6_MASK_LEN 128
/*added by ychen in 2012-04-05 for ecmp*/
#define GLB_MAX_ECMP_GROUPS   256/*(2 ^GLB_MAX_NH_ECMP_NUM)*/

#define GLB_INVALID_IPV4_ADDR 0x00000000

#define GLB_ARP_DEFAULT_RETRANS_TIME 1
#define GLB_ARP_DEFAULT_TIMEOUT      3600
#define GLB_IPV6_ADDR_IS_LINKLOCAL(ip) \
    (((ip[0]) & 0xFFC00000) == 0xFE800000)

/* support vrrp modified by liwh for bug 45215, 2017-09-17 */
#define     GLB_VRRP_VERSION_V2            2
#define     GLB_VRRP_VERSION_V3            3

#define     GLB_VRRP_ADVT_INT_DFLT         1

#define     GLB_VRRP_SECONDS_MODE          0
#define     GLB_VRRP_MILLI_SECONDS_MODE    1

#define     GLB_VRRP_PREEMPT_DELAY_DFLT    0

#define     GLB_VRRP_DEFAULT_NON_IP_OWNER_PRIORITY  100

#define     GLB_VRRP_ADVT_MSEC_MIN         100

#define     GLB_VRRP_MAC_VALID             0
#define     GLB_VRRP_MAC_INVALID           1
#define     GLB_VRRP_MAC_INTERFACE         2

/*reference to SYS_ROUTER_MAC_ENTRY_NUM, reserve 1 for global*/
#define     GLB_VRRP_MAX_SESSION           31 
/* liwh end */

enum glb_ip_ver_e
{
    GLB_IP_VER_4,
    GLB_IP_VER_6,
    GLB_IP_VER_MAX,
};
typedef enum glb_ip_ver_e glb_ip_ver_t;

typedef enum
{
    GLB_IPUC_REMOTE,        /* Nexthop is remote */    
    GLB_IPUC_LOCAL,         /* Nexthop is directly attached */
    GLB_IPUC_BLACKHOLE,     /* Drop */
    GLB_IPUC_FTN,           /* Nexthop is a FTN */
    GLB_IPUC_TYPE_MAX
} glb_ipuc_nexthop_type_t;

enum glb_ipuc_flag_e
{
    GLB_IPUC_FLAG_RPF_CHECK     = 0x01,      /**< This route will do RPF check */
    GLB_IPUC_FLAG_TTL_CHECK     = 0x02,      /**< This route will do ttl check */
    GLB_IPUC_FLAG_ICMP_CHECK    = 0x04,      /**< This route will do icmp redirect check */
    GLB_IPUC_FLAG_CPU           = 0x08,      /**< Packets hitting this route will be copied to CPU */
    GLB_IPUC_FLAG_VRF           = 0x10,      /**< Packets hitting this route will be copied to CPU */
    GLB_IPUC_FLAG_NEIGHBOR      = 0x20,      /**< This is a ARP entry, only set when mask length is 32 on IPv4 or 128 on IPv6 */
    GLB_IPUC_FLAG_CONNECT       = 0x40,      /**< This is a CONNECT entry */
    GLB_IPUC_FLAG_SELF_ADDRESS  = 0x80,    /**< [GB]Indicate it is a PTP or OAM entry */
    GLB_MAX_IPUC_FLAG           = 0xFF
};
typedef enum glb_ipuc_flag_e glb_ipuc_flag_t;

enum glb_parser_ecmp_hash_key_e
{
    GLB_ECMP_HASH_KEY_IPSA      = 1 << 0,
    GLB_ECMP_HASH_KEY_IPDA      = 1 << 1,
    GLB_ECMP_HASH_KEY_IPPRO     = 1 << 2,
    GLB_ECMP_HASH_KEY_DSCP      = 1 << 3,
    GLB_ECMP_HASH_KEY_SRC_PORT  = 1 << 4,
    GLB_ECMP_HASH_KEY_DST_PORT  = 1 << 5,
    GLB_ECMP_HASH_KEY_MACSA     = 1 << 6,
    GLB_ECMP_HASH_KEY_MACDA     = 1 << 7,
    GLB_ECMP_HASH_KEY_ETHERTYPE = 1 << 8,

    GLB_ECMP_HASH_KEY_ALL      = GLB_ECMP_HASH_KEY_IPSA      |
                                 GLB_ECMP_HASH_KEY_IPDA      |
                                 GLB_ECMP_HASH_KEY_IPPRO     |
                                 GLB_ECMP_HASH_KEY_SRC_PORT  |
                                 GLB_ECMP_HASH_KEY_DST_PORT  |
                                 GLB_ECMP_HASH_KEY_MACSA     |
                                 GLB_ECMP_HASH_KEY_MACDA     |
                                 GLB_ECMP_HASH_KEY_ETHERTYPE
};
typedef enum adpt_parser_ecmp_hash_key_e adpt_parser_ecmp_hash_key_t;

#endif /*__GLB_IP_DEFINE_H__*/


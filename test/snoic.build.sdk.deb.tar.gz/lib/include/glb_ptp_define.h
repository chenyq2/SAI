/****************************************************************************
 * $Id$
 *  Centec PTP related global MACRO, ENUM, Date Structure defines file
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Kun Cao
 * Date          : 2010-07-15 16:00
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __GLB_PTP_DEFINE_H__
#define __GLB_PTP_DEFINE_H__

#define GLB_PTP_NS_PER_SEC 1000000000
#define GLB_PTP_NNS_PER_NS 1000000000
#define GLB_PTP_UNKNOWN_CLK_ACC 0xFE

/****************************************************************************
 * clause 5 - Data types and on-the-wire formats in a PTP system
 ****************************************************************************/

/* refer to 5.3 Derived data type specifications  */
struct glb_ptp_uint48_s
{
    uint32 lsb;
    uint16 msb;
};
typedef struct glb_ptp_uint48_s glb_ptp_uint48_t;

/* refer to 5.3.2 TimeInterval */
union glb_ptp_timeinterval_u
{
    int64 v;
#if _GLB_HOST_IS_LE
    struct
    {
        uint32 lsb;
        int32 msb;
    } s;
#else
    struct
    {
        int32 msb;
        uint32 lsb;
    } s;
#endif
};
typedef union glb_ptp_timeinterval_u glb_ptp_timeinterval_t;

/* used for internal calculation for convenience */
union glb_ptp_timeinternal_s
{
    int64 v;
#if _GLB_HOST_IS_LE
    struct
    {
        int32 lsb;
        int32 msb;
    } s;
#else
    struct
    {
        int32 msb;
        int32 lsb;
    } s;
#endif
};
typedef union glb_ptp_timeinternal_s glb_ptp_timeinternal_t;

struct glb_ptp_timestamp_s
{
    glb_ptp_uint48_t sec;
    uint32 ns;
};
typedef struct glb_ptp_timestamp_s glb_ptp_timestamp_t;

#define GLB_PTP_CLOCK_ID_LEN  8
#define GLB_PTP_PORT_ID_LEN   10
typedef uint8 glb_ptp_clock_id_t[GLB_PTP_CLOCK_ID_LEN];

struct glb_ptp_port_id_s
{
    glb_ptp_clock_id_t clock_id;
    uint16 port_num;
};
typedef struct glb_ptp_port_id_s glb_ptp_port_id_t;

#define GLB_PTP_MAX_PORT_ADDR_LEN 16
struct glb_ptp_port_address_s
{
    uint16 protocol;
    uint16 length;
    union {
        uint8 pad[GLB_PTP_MAX_PORT_ADDR_LEN];
        mac_addr_t mac_addr;
        ip_addr_t ip_addr;
        ipv6_addr_t ipv6_addr;
    } field;
};
typedef struct glb_ptp_port_address_s glb_ptp_port_address_t;

struct glb_ptp_clock_quality_s
{
    uint8 clk_class;
    uint8 clk_accuracy;
    uint16 offset_scaled_log_variance;
};
typedef struct glb_ptp_clock_quality_s glb_ptp_clock_quality_t;

struct glb_ptp_tlv_s
{
    uint16 type;
    uint16 length;
    uint8* value;
};
typedef struct glb_ptp_tlv_s glb_ptp_tlv_t;

struct glb_ptp_text_s
{
    uint16 length;
    uint8* text;
};
typedef struct glb_ptp_text_s glb_ptp_text_t;

/****************************************************************************
 * clause Annex D - Transport of PTP over User Datagram Protocol over
 * Internet Protocol Version 4
 ****************************************************************************/
#define GLB_PTP_IPV4_ETYPE                  0x0800
#define GLB_PTP_IPV6_ETYPE                  0x86DD

/* refer to D.2 UDP port numbers */
#define GLB_PTP_UDP_EVENT_PORT              319
#define GLB_PTP_UDP_GENERAL_PORT            320

/* refer to D.3 IPv4 multicast addresses */
/*"224.0.1.129"*/
#define GLB_PTP_IPV4_ADDRESS_PRIMARY        0xE0000181
/*"224.0.0.107"*/
#define GLB_PTP_IPV4_ADDRESS_PDELAY         0xE000006B

#define GLB_PTP_IP_MAC_ADDRESS_PRIMARY      {0x01, 0x00, 0x5e, 0x00, 0x01, 0x81}
#define GLB_PTP_IP_MAC_ADDRESS_PDELAY       {0x01, 0x00, 0x5e, 0x00, 0x00, 0x6b}

/****************************************************************************
 * clause Annex F - Transport of PTP over IEEE 802.3 /Ethernet
 ****************************************************************************/
/* refer to F.2 Ethertype */
#define GLB_PTP_1588_ETYPE                  0x88F7

/* refer to F.3 Multicast MAC Addresses */
#define GLB_PTP_MAC_ADDRESS_DEFAULT         {0x01, 0x1B, 0x19, 0x00, 0x00, 0x00}
#define GLB_PTP_MAC_ADDRESS_PDELAY          {0x01, 0x80, 0xC2, 0x00, 0x00, 0x0E}

#endif /*!__GLB_PTP_DEFINE_H__*/

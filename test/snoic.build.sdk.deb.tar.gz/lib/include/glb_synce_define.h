/****************************************************************************
 * $Id$
 *  Centec SyncE related global MACRO, ENUM, Date Structure defines file
 *
 * (C) Copyright Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision      : R0.01
 * Author        : Zhen Jiang
 * Date          : 2011-03-05 16:00
 * Reason        : First Create.
 ****************************************************************************/
#ifndef __GLB_SYNCE_DEFINE_H__
#define __GLB_SYNCE_DEFINE_H__

/****************************************************************************
 *
 * Header Files
 *
 ****************************************************************************/
#define GLB_SYNCE_SERDES_MIN 0x0
#define GLB_SYNCE_SERDES_MAX 0xF

#define GLB_SYNCE_DIVIDER_MIN 0x0
#define GLB_SYNCE_DIVIDER_MAX 0x3F

enum glb_synce_type_e
{
    GLB_SYNCE_PRIMARY,
    GLB_SYNCE_SECONDARY,
};
typedef enum glb_synce_type_e glb_synce_type_t;

/****************************************************************************
 *
 * Defines and Macros
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Global and Declaration
 *
 ****************************************************************************/

/****************************************************************************
 *
 * Functions
 *
 ****************************************************************************/

#endif /*!__GLB_SYNCE_DEFINE_H__*/

#!/bin/sh

/sw/pub/bin/asn1c -Werror -fnative-types -funnamed-unions \
../lcm.asn1 \
../lcm_debug.asn1 \
2>&1| grep -v "contents unchanged" | grep -v "Cannot read file-dependencies"

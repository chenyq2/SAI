function check_verficode(c_name)
{
    if (document.cookie.length > 0)
    {
        c_start = document.cookie.indexOf(c_name + '=')
        if (c_start != -1)
        {
            c_start = c_start + c_name.length + 1
            c_end = document.cookie.indexOf(";",c_start)
            if(c_end == -1)
                c_end = document.cookie.length
            return unescape(document.cookie.substring(c_start, c_end))
        }
    }

    return ""
}

;Public.app.controller('ctlLogin', ['$scope', '$http', '$rootScope', '$location', '$translate', function($scope, $http, $rootScope, $location, $translate) {

    $scope.isSubmit = false;

    $scope.verficode_cnt = 0;
    $scope.verficode_display = 0;
    
    $scope.form = {
        username: '',
        password: '',
        verficode_id: '',
    };

    $scope.getverficode = function(){
        setTimeout(function(){
            $scope.$apply(function(){
                $scope.verficode_rand = 'auth_code/auth_code.jpg?d=' + Math.random();
            });
        },100);
    };

    $scope.submit = function() {
    
        /* Forbidden repeated submit */
        if (isSubmit == true) {
          return;
        }

        var verficode = check_verficode('verficode_id')

        if($rootScope.Sysinfo.product != 'CNOS')
        {
            if($scope.verficode_cnt >= 3)
            {
                if(verficode != $scope.form.verficode_id)
                {
                    $rootScope.authErrorFlag = true;
                    $rootScope.authErrorReason = 'Verifcode Error'
                    return;
                }
            }
        }
        
        isSubmit = true;
        $http({
            url: '/api/token/',
            method: 'POST',
            data: {
                username: $scope.form.username,
                password: $scope.form.password,
            },
        })
        .then(function(resp) {
            if(resp.status == 200 && !resp.data.error) {
                time = parseInt((new Date().getTime()) / 1000);

                // refresh user infomation
                localStorage.setItem('username', $scope.form.username);
                localStorage.setItem('token', resp.data.token);
                localStorage.setItem('time', time);

                // clear error flag
                $rootScope.authErrorFlag = false;

                // login successful
                $rootScope.UserInfo = {
                    username: $scope.form.username,
                    token: resp.data.token,
                    time: time,
                };

                $location.path('/'); 
            }
            else {
                $rootScope.authErrorFlag = true;
                $rootScope.authErrorReason = resp.data['err_reason'];
                
                isSubmit = false;

                if($rootScope.Sysinfo.product != 'CNOS')
                {
                    $scope.verficode_cnt++;
                    if($scope.verficode_cnt >= 3)
                    {
                        $scope.verficode_display = 1;
                        $scope.verficode_rand = 'auth_code/auth_code.jpg?d=' + Math.random();
                    }
                }
            }
        }, function() { // ajax error
            $rootScope.authErrorFlag = true;
            $rootScope.authErrorReason = 'ajax request error';
        });
    }; 

    isSubmit = false;
}]);

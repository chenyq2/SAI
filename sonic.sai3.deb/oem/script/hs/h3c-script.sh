#!/bin/sh
#set -o errexit
#
#echo "scrpit h3c-script processing, please wait..."
#
#if [ "y" = "$IS_UML" ] ; then
#    echo "uml"
#    cd $UML_IMAGE_DIR/osp/etc/cmd
#else
#    echo "board"
#    cd $BLD_DIR/etc/cmd
#fi
#
#find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show running-config\"/<COMMAND name=\"display current-configuration\"/g"
#find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show\"/<COMMAND name=\"display\"/g"
#find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show /<COMMAND name=\"display /g"
#
#cd -

function do_xml()
{
    if [ "y" = "$IS_UML" ] ; then
        echo "uml"
        cd $UML_IMAGE_DIR/osp/etc/cmd
    else
        echo "board"
        cd $BLD_DIR/etc/cmd
    fi
    
    find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show running-config\"/<COMMAND name=\"display current-configuration\"/g"
    find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show\"/<COMMAND name=\"display\"/g"
    find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"show /<COMMAND name=\"display /g"
    find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"no\"/<COMMAND name=\"undo\"/g"
    find . -type f -name '*.xml' | xargs sed -i "s/<COMMAND name=\"no /<COMMAND name=\"undo /g"
    find . -type f -name '*.xml' | xargs sed -i "s/hostname\/Switch/hostname\/H3C/g"
    find . -type f -name '*.xml' | xargs sed -i "s/delete\/cdb\/app\/clock\/timezone/delete\/cdb\/app\/clock\/timezone\/Beijing\/add\/8\/none\/none/g"
    
    cd -
}

function do_web()
{
	cp $TOP_DIR/oem/script/hs/web/.    $TMP_DIR/web/ -rf
	sed -i "s/});/ 'Copyright @ 2004-2017 New H3C Technologies Co., Ltd. All rights Reserved' :'版权 @ 2004-2017 新华三技术有限公司 版权所有，保留一切权利', });/g" $TMP_DIR/web/static/switch/js/i18n/zh_CN/zh_CN.js
}

function do_build_files()
{	
	cd $TMP_DIR
	find . -type f -name 'rc.sysinit' | xargs sed -i "s/hostname\/Switch/hostname\/H3C/g"
	cd -
}

echo "scrpit h3c-script processing, please wait..."

case "$1" in
    xml)
        do_xml
        ;;
	web)
		do_web
		;;
	build_files)
		do_build_files
		;;
    *)
        echo $"Usage: $0 {xml|}"
esac

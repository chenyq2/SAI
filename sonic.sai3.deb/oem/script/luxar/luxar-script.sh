#!/bin/sh

function do_xml()
{
    if [ "y" = "$IS_UML" ] ; then
        echo "uml"
        cd $UML_IMAGE_DIR/osp/etc/cmd
    else
        echo "board"
        cd $BLD_DIR/etc/cmd
    fi
    
    cd -
}

function do_web()
{
	cp $TOP_DIR/oem/script/luxar/web/.    $TMP_DIR/web/ -rf
}

function do_build_files()
{	
	cd $TMP_DIR
	cd -
}

echo "scrpit luxar-script processing, please wait..."

case "$1" in
    xml)
        do_xml
        ;;
	web)
		do_web
		;;
	build_files)
		do_build_files
		;;
    *)
        echo $"Usage: $0 {xml|web|build_files}"
esac

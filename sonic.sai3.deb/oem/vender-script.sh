#!/bin/sh
set -o errexit

product=$PRODUCT
board=$BOARD
rootfs_dir=$BUILD_ROOTFS_DIR
CROSS_COMPILER=$CROSS_COMPILE
etc_dir=$PLAT_TOP_DIR/build_svc/etc
ctc_build_dir=$BLD_DIR
kbuild_dir=$KDIR
top_dir=$TOP_DIR
klish_dir=$TOP_DIR/klish
ver=$VER
vender=$VENDER


function do_xml()
{
    if [ 'tap' = "$product" ] ; then
        if [ "hs" = "$vender" ] ; then
            $SCRIPT_DIR/script/$VENDER/h3c-script.sh xml
        fi
        if [ "luxar" = "$vender" ] ; then
            $SCRIPT_DIR/script/$VENDER/luxar-script.sh xml
        fi
    fi
}

function do_web()
{	
	if [ 'tap' = "$product" ] ; then
		if [ "hs" = "$vender" ] ; then
			$SCRIPT_DIR/script/$VENDER/h3c-script.sh web
		fi
		if [ "luxar" = "$vender" ] ; then
			$SCRIPT_DIR/script/$VENDER/luxar-script.sh web
		fi
	fi
}

function do_build_files()
{	
	if [ 'tap' = "$product" ] ; then
		if [ "hs" = "$vender" ] ; then
			$SCRIPT_DIR/script/$VENDER/h3c-script.sh build_files
		fi
		if [ "luxar" = "$vender" ] ; then
			$SCRIPT_DIR/script/$VENDER/luxar-script.sh build_files
		fi
	fi
}

echo "Package vender binaries, please wait..."

case "$1" in
    xml)
        do_xml
        ;;
	web)
		do_web
		;;	
	build_files)
		do_build_files
		;;
    *)
        echo $"Usage: $0 {xml|web|build_files}"
esac

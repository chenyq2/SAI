#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "sal.h"
#include "ctc_hw.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "detect.h"


int main(int argc, char *argv[])
{    
    int ret = 0;
    char mgtmac[6];
    uint32 ipaddr[4];
    uint8 board_type = 0;

    ret = i2c_open_dev0();
    if (ret < 0)
    {
        printf("Open i2c bus 0 device failed!\n");
        return -1;
    }
#ifndef _CTC_ARM_HI3535_
    ret = i2c_open_dev1();
    if (ret < 0)
    {
        printf("Open i2c bus 1 device failed!\n");
        return -1;
    }
#endif
    if(!sal_strncmp("mgtmac", argv[1], 6))
    {
        sal_memset(mgtmac, 0, 6);
        ret = ctc_get_ethaddr(mgtmac, 6);
        if(ret < 0)
        {
            printf("Can't get managment mac address!\n");
            return -1;
        }

        printf("%x:%x:%x:%x:%x:%x\n", mgtmac[0], mgtmac[1], mgtmac[2], mgtmac[3], mgtmac[4], mgtmac[5]);
    }
    else if(!sal_strncmp("selfip", argv[1], 6))
    {
        memset(ipaddr, 0, 4 * sizeof(uint32));
        ret = ctc_get_ipaddr(ipaddr, 4);
        if(ret < 0)
        {
            printf("Can't get managment ip address!\n");
            return -1;
        }

        printf("%x.%x.%x.%x\n", ipaddr[0], ipaddr[1], ipaddr[2], ipaddr[3]);
    }
    else if(!sal_strncmp("board_type", argv[1], 10))
    {
        ret = ctc_get_board_info(&board_type);
        if(ret < 0)
        {
            printf("Can't get board type!\n");
            return -1;
        }
        
        printf("%d\n", board_type);
    }
   
    return 0;
}



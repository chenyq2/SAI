#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "ctc_hw.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "detect.h"

/* 
 * According to new EEPROM allocation specification, there will be TWO EEPROMs(I2C addr: 0x56, 0x57)
 * on board, CPU both on motherboard and daughter card MUST obey the agreement!
 * 
 * ########################  CPU on daughter card  ############################
 * EEPROM0(I2C addr: 0x56) stores CPU-subsystem-related information:
 *    1) CPU exist on daughter card or on mother board   (offset: 0x1[7])
 *    2) NOR Flash type register                   (offset: 0x4)
 *    3) NAND Flash type register                  (offset: 0x5)
 *    4) DDR type register                         (offset: 0x6)
 *    5) CPU daughter card version                 (offset: 0x7)
 *    6) CPU daughter card serial number           (offset: 0x1220~0x122C)
 *
 * EEPROM1(I2C addr: 0x57) stores Product-related information:
 *    1) Product series register                   (offset: 0x1011)
 *    2) Board type register                       (offset: 0x1012)
 *    3) Board version register                    (offset: 0x1013)
 *    4) Management MAC address                    (offset: 0x1000~0x1005)
 *    5) Board serial number                       (offset: 0x1220~0x122C)
 *    6) System MAC addresses                      (offset: 0x1240~0x1247)
 * 
 *
 * ########################  CPU on mother board  ############################
 * EEPROM0(I2C addr: 0x56) stores CPU-subsystem-related information:
 *    1) CPU exist on daughter card or on mother board   (offset: 0x1[7])
 *    2) Product series register                   (offset: 0x1[6:0])
 *    3) Board type register                       (offset: 0x2)
 *    4) Board version register                    (offset: 0x3)
 *    5) NOR Flash type register                   (offset: 0x4)
 *    6) NAND Flash type register                  (offset: 0x5)
 *    7) DDR type register                         (offset: 0x6)
 *
 * EEPROM1(I2C addr: 0x57) stores Product-related information:
 *    1) Management MAC address                    (offset: 0x1000~0x1005)
 *    2) Board serial number                       (offset: 0x1220~0x122C)
 *    3) System MAC addresses                      (offset: 0x1240~0x1247)
 * 
 * 
 */
/*Every GB board infomation get from EEPROM 0x56 or 0x57. jqiu modify 2013-08-10
  First check EEPROM 0x56, board info at address 0x0-0x6
  If 0x56 is not exist, then check EEPROM 0x57, board info at address 0x1284-0x128a
  If 0x57 is not exist, then default as GB demo board.
*/
static int
ctc_get_normal_board_type(FILE *fp, uint8 *board_type)
{
    uint8 cpu_location;           /* CPU location: 1 means on daugther card */
    uint8 product_series;           /*board series*/
    uint8 hw_ver;                 /*board version*/
    uint8 nor_flash_type;              /*nor flash type*/    uint8 nand_flash_type;              /*nor flash type*/
    uint8 dram_type;                /*ddr type*/
    uint8 sysmac[6];
    int32 ret = 0;
    
    if(g_eeprom_info[0] == 0)
    {
        
    }
    else if(g_eeprom_info[0] == 1)
    {
        ret += i2c_read(GLB_I2C_IDX_0, g_eeprom_info[1], GB_EEPROM1_BOARD_SERIES_OFFSET, 2, &product_series, 1);
        ret += i2c_read(GLB_I2C_IDX_0, g_eeprom_info[1], GB_EEPROM1_BOARD_TYPE_OFFSET, 2, board_type, 1);
        ret += i2c_read(GLB_I2C_IDX_0, g_eeprom_info[1], GB_EEPROM1_BOARD_VER_OFFSET, 2, &hw_ver, 1);  
        if (ret < 0)
        {
            printf("i2c_read failed!\n");
        }
        if(product_series == GLB_SERIES_E350)
        {
            if(*board_type == GLB_BOARD_E350_PEGATRON)
            {
                nand_flash_type = 1;
                dram_type = 0;
            }
        }
        ret += i2c_read(GLB_I2C_IDX_0, g_eeprom_info[1], GB_NORMAL_SYSMAC_ADDR, 2, sysmac, 6);
    }
    else if(g_eeprom_info[0] == 2)
    {
        /* Step 1: check CPU on motherboard or daughter card */
        ret = i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_SERIES_OFFSET, 2, &cpu_location, 1);

        /* Step 3: check CPU location */
        if (cpu_location & 0x80)   /* CPU on daughter card, board info store in EEPROM1 */
        {
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM1_ADDR, GB_EEPROM1_BOARD_SERIES_OFFSET, 2, &product_series, 1);
            /* When read EEPROM 0x56, offset 0x1[7] if the flag of CPU location */
            product_series &= 0x7f;
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM1_ADDR, GB_EEPROM1_BOARD_TYPE_OFFSET, 2, board_type, 1);
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM1_ADDR, GB_EEPROM1_BOARD_VER_OFFSET, 2, &hw_ver, 1);
        }
        else   /* CPU on motherboard, board info store in EEPROM0 */
        {
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_SERIES_OFFSET, 2, &product_series, 1);
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_TYPE_OFFSET, 2, board_type, 1);
            ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_VER_OFFSET, 2, &hw_ver, 1);       
        }

        /* 
         * No matther CPU on daughter card or motherboard, Nor Flash/Nand Flash/DDR 
         * info store in the same location(EEPROM0)
         */
        ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_NOR_FLASH_OFFSET, 2, &nor_flash_type, 1);
        ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_NAND_FLASH_OFFSET, 2, &nand_flash_type, 1);
        ret += i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_BOARD_DDR_TYPE_OFFSET, 2, &dram_type, 1); 
        if (ret < 0)
        {
            printf("i2c_read failed!\n");
        }
        ret += i2c_read(GLB_I2C_IDX_0, g_eeprom_info[2], GB_NORMAL_SYSMAC_ADDR, 2, sysmac, 6);
    }
    
    g_product_series = product_series;
    g_board_type     = *board_type;
    
    fprintf(fp, GLB_PRODUCT_SERIES_STRING "  %x\n", product_series);
    fprintf(fp, GLB_BOARD_TYPE_STRING "  %x\n", *board_type);
    fprintf(fp, GLB_HW_VERSION_STRING "  %x\n", hw_ver);
    fprintf(fp, GLB_HW_FLASH_SIZE "  %x\n", ctc_flash_size_array[nand_flash_type]);
    fprintf(fp, GLB_HW_DRAM_SIZE  "  %x\n", ctc_dram_size_array[dram_type]);
    fprintf(fp, GLB_ROOT_MAC " %02X:%02X:%02X:%02X:%02X:%02X\n", 
        sysmac[0], sysmac[1], sysmac[2], sysmac[3], sysmac[4], sysmac[5]);
    fprintf(fp, GLB_SYS_MAC " %02X:%02X:%02X:%02X:%02X:%02X\n", 
        sysmac[0], sysmac[1], sysmac[2], sysmac[3], sysmac[4], sysmac[5]);
    fprintf(fp, GLB_PLATFORM_TYPE  "  %x\n", g_platform_type);
   
    return 0;
}

void
ctc_get_normal_bootromver(FILE *fp)
{
    char bootrom_ver[32];
    char ary_tmp[256];
    char *chr_p = NULL;
    FILE * fd_proc;
    char cur_tmp[256] = {'\0'};

    sal_memset(bootrom_ver, 0, 32);
    fd_proc = sal_fopen("/proc/cmdline", "r");
    if(!fd_proc)
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
        return ;
    }
    sal_fgets(ary_tmp, 256, fd_proc);

    chr_p = sal_strstr(ary_tmp, "U-Boot ");

    if(chr_p != NULL)
    {
        chr_p += sal_strlen("U-Boot ");
        sal_strncpy(cur_tmp, chr_p, 256);
        chr_p = cur_tmp;
        if((chr_p = strchr(chr_p, ' ')) != NULL)
            *chr_p = '\0';

        sal_strncpy(bootrom_ver, cur_tmp, MAX_BOOTROM_VER_LEN);
    }
    else
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
    }
    sal_fclose(fd_proc);
    
    sal_fprintf(fp, "bootrom %s\n", bootrom_ver);
    
}

int
ctc_get_normal_board_info(uint8 *board_type)
{
    FILE *fp;

    fp = sal_fopen(GLB_BOARD_INFO_FILE, "w+");
    if(fp == NULL)
    {
       printf("open global board file failed\n");
       return 0;
    }

    ctc_get_normal_board_type(fp, board_type);
    ctc_get_common_epld_info(fp);
    ctc_get_common_mgt_info(fp);
    ctc_get_normal_bootromver(fp);
    
    if(fp)
    {
        sal_fclose(fp);
    }

    return 0;
}


#ifndef __CTC_EPLD_INFO_H__
#define __CTC_EPLD_INFO_H__

#define EPLD_ADDR                        0x58
#define EPLD_VER       0x01
#define EPLD_CENTURY   0xf0
#define EPLD_YEAR      0xf1
#define EPLD_MONTH     0xf2
#define EPLD_DAY       0xf3
#define EPLD_HOUR      0xf4
#define EPLD_MINUTE    0xf5


int ctc_get_epld_info(FILE *fp);

#endif

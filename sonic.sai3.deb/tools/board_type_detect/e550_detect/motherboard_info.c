#include "detect.h"

static int ctc_get_board_type(FILE *fp)
{
    int ret = 0;
    unsigned char product_series = 0; 
    unsigned char board_type = 0; 
    unsigned char board_ver = 0; 
    
    ret = i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_PRODUCT_SERIES, 2, &product_series, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_BOARD_TYPE, 2, &board_type, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_BOARD_VER, 2, &board_ver, 1);

    printf("%d\n", board_type);

    fprintf(fp, GLB_PRODUCT_SERIES_STRING "  %x\n", product_series);
    fprintf(fp, GLB_BOARD_TYPE_STRING "  %x\n", board_type);   
    fprintf(fp, GLB_HW_VERSION_STRING "  %x\n", board_ver);  

    return board_type;
}

static int ctc_get_mac_addr(FILE *fp)
{
    int ret = 0;
    uint8 sysmac[6]; 
    
    ret += i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_MAC_ADDRESS, 2, sysmac, 6);

    fprintf(fp, "rmac %02X:%02X:%02X:%02X:%02X:%02X\n", 
            sysmac[0], sysmac[1], sysmac[2], sysmac[3], sysmac[4], sysmac[5]);
    fprintf(fp, "sysmac %02X:%02X:%02X:%02X:%02X:%02X\n", 
            sysmac[0], sysmac[1], sysmac[2], sysmac[3], sysmac[4], sysmac[5]);
    
    return ret;

}

static int ctc_get_board_material(FILE *fp)
{
    int ret;
    uint8 bm;
    
    ret = i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_BOARD_MATERIAL_OFFSET, 2, &bm, 1);

    fprintf(fp, GLB_BOARD_MATERIAL_STRING "  %x\n", bm);

    return ret;
}

static int ctc_get_board_speed_mode(FILE *fp)
{
    int ret;
    uint8 speed_mode;

    ret = i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_SPEED_MODE_OFFSET, 2, &speed_mode, 1);

    fprintf(fp, GLB_SPEED_MODE_STRING "  %x\n", speed_mode);

    return ret;
}

int ctc_get_matherboard_info(FILE *fp)
{    
    int ret = 0;
    ret =  ctc_get_board_type(fp);
    ret += ctc_get_mac_addr(fp);
    ret += ctc_get_board_material(fp);
    ret += ctc_get_board_speed_mode(fp);

    return ret;
}


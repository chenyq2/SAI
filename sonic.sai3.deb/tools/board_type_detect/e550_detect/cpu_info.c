#include "detect.h"

int ctc_flash_size_array[CTC_FLASH_MAX_TYPES] =
{
    CTC_MEMORY_SIZE_1G,
    CTC_MEMORY_SIZE_2G,
    CTC_MEMORY_SIZE_512,
    CTC_MEMORY_SIZE_4G,
    CTC_MEMORY_SIZE_32,
    CTC_MEMORY_SIZE_8G,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
};

int ctc_get_cpu_info(FILE *fp)
{
    int ret = 0;
    unsigned char nand_type = 0, ddr_type = 0; 
    
    ret += i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_NAND_TYPE, 2, &nand_type, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_DDR_TYPE, 2, &ddr_type, 1);

    fprintf(fp, GLB_HW_FLASH_SIZE "  %x\n", ctc_flash_size_array[nand_type]);
    fprintf(fp, GLB_HW_DRAM_SIZE "  %x\n", ctc_flash_size_array[ddr_type]);   

    return 0;
}

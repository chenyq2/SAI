#ifndef __CTC_BOOTROM_VER_H__
#define __CTC_BOOTROM_VER_H__

void ctc_get_bootromver(FILE *fp);

#endif

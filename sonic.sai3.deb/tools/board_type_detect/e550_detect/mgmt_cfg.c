#include "detect.h"

int ctc_get_mgt_info(FILE *fp)
{
    uint8 mgmtcfg[24];
    unsigned char mgmtuser[9];
    unsigned char mgmtpin[9];
    struct in_addr addr;
    int ret;
    int i;

    ret = i2c_read(GLB_I2C_IDX_0, EEPROM1_ADDR, EEPROM1_MGMT_CFG_OFFSET, 2, mgmtcfg, sizeof(mgmtcfg));
    
    if (0xFF == mgmtcfg[0] && 0xFF == mgmtcfg[23]) {
        /* EEPROM for MGMT CFG uninitialized */
        memset(mgmtcfg, 0x00, sizeof(mgmtcfg));     
        memcpy(mgmtcfg, "admin", strlen("admin"));
        memcpy(mgmtcfg + 8, "admin", strlen("admin"));
        inet_aton("192.168.0.100", &addr);
        memcpy(mgmtcfg + 16, &addr, sizeof(addr));
    }
    
    memset(mgmtuser, 0x00, sizeof(mgmtuser));
    memset(mgmtpin, 0x00, sizeof(mgmtpin));
    for (i = 0; i < 8; i++) {
        if ('\0' == mgmtcfg[i]) {
            break;
        }

        mgmtuser[i] = mgmtcfg[i];
    }
    mgmtuser[i] = '\0';

    for (i = 0; i < 8; i++) {
        if ('\0' == mgmtcfg[i + 8]) {
            break;
        }

        mgmtpin[i] = mgmtcfg[i + 8];
    }
    mgmtpin[i] = '\0';
    memcpy(&addr, mgmtcfg + 16, sizeof(addr));

    fprintf(fp, "mgmtuser %s\n", mgmtuser);
    fprintf(fp, "mgmtpin \"%s\"\n", mgmtpin);
    fprintf(fp, "mgmtip %s\n", inet_ntoa(addr)); 

    return 0;
}



#ifndef __CTC_CPU_INFO_H__
#define __CTC_CPU_INFO_H__

/* Flash/Dram can has at most 16 kinds of types */
#define CTC_MEMORY_SIZE_32   32
#define CTC_MEMORY_SIZE_64   64
#define CTC_MEMORY_SIZE_128  128
#define CTC_MEMORY_SIZE_256  256
#define CTC_MEMORY_SIZE_512  512
#define CTC_MEMORY_SIZE_1G   1024
#define CTC_MEMORY_SIZE_2G   2048
#define CTC_MEMORY_SIZE_4G   4096
#define CTC_MEMORY_SIZE_8G   8192
#define CTC_MEMORY_SIZE_16   16
#define CTC_MEMORY_RESERVE   0
#define CTC_FLASH_MAX_TYPES 16
#define CTC_DRAM_MAX_TYPES 8

int ctc_get_cpu_info(FILE *fp);

#endif

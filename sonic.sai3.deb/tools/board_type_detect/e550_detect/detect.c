#include "detect.h"

int main(int argc, char *argv[])
{    
    FILE *fp;
    
    fp = sal_fopen(GLB_BOARD_INFO_FILE, "w+");
    if(fp == NULL)
    {
       printf("open global board file failed\n");
       return 0;
    }
    
    ctc_i2c_drv_init();
    ctc_get_matherboard_info(fp);
    ctc_get_cpu_info(fp);
    ctc_get_epld_info(fp);
    ctc_get_mgt_info(fp);
    ctc_get_bootromver(fp);

    if(fp)
    {
        sal_fclose(fp);
    }

    return 0;
}



#ifndef __DETECT_H__
#define __DETECT_H__

#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sal_common.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"

#include "i2c_drv.h"
#include "epld_info.h"
#include "mgmt_cfg.h"
#include "cpu_info.h"
#include "motherboard_info.h"
#include "bootrom_ver.h"

#define EEPROM1_ADDR                        0x57
#define EEPROM1_PRODUCT_SERIES              0x1621
#define EEPROM1_BOARD_TYPE                  0x1622
#define EEPROM1_BOARD_VER                   0x1623
#define EEPROM1_MAC_ADDRESS                 0x1636
#define EEPROM1_MGMT_CFG_OFFSET             0x1100

#define EEPROM1_NOR_TYPE                     0x1600
#define EEPROM1_NAND_TYPE                    0x1601
#define EEPROM1_DDR_TYPE                     0x1602

#define EEPROM1_BOARD_MATERIAL_OFFSET    0x1008
#define EEPROM1_SPEED_MODE_OFFSET        0x1009

#endif /* !__RMT_H__ */

#include "detect.h"

void ctc_get_bootromver(FILE *fp)
{
    char bootrom_ver[32];
    char ary_tmp[256];
    char *chr_p = NULL;
    FILE * fd_proc;
    char cur_tmp[256] = {'\0'};

    sal_memset(bootrom_ver, 0, 32);
    fd_proc = sal_fopen("/proc/cmdline", "r");
    if(!fd_proc)
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
        return ;
    }
    sal_fgets(ary_tmp, 256, fd_proc);

    chr_p = sal_strstr(ary_tmp, "U-Boot ");

    if(chr_p != NULL)
    {
        chr_p += sal_strlen("U-Boot ");
        sal_strncpy(cur_tmp, chr_p, 256);
        chr_p = cur_tmp;
        if((chr_p = strchr(chr_p, ' ')) != NULL)
            *chr_p = '\0';

        sal_strncpy(bootrom_ver, cur_tmp, MAX_BOOTROM_VER_LEN);
    }
    else
    {
        sal_strncpy(bootrom_ver, "UNKNOWN", MAX_BOOTROM_VER_LEN);
    }
    sal_fclose(fd_proc);
    
    sal_fprintf(fp, "bootrom %s\n", bootrom_ver);
    
}

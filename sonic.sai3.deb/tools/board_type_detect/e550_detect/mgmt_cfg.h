#ifndef __CTC_MGMT_CFG_H__
#define __CTC_MGMT_CFG_H__

int ctc_get_mgt_info(FILE *fp);

#endif

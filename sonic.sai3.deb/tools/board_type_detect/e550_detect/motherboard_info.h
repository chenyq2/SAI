#ifndef __CTC_MATHERBOARD_INFO_H__
#define __CTC_MATHERBOARD_INFO_H__

int ctc_get_matherboard_info(FILE *fp);

#endif

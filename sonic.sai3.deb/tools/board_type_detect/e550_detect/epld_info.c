#include "detect.h"

int ctc_get_epld_info(FILE *fp)
{
    int ret = 0;
    unsigned char epld_ver = 0;
    unsigned char century = 0, year = 0, month = 0, day = 0, hour = 0, minute = 0;
    unsigned short epld_time = 0;
    unsigned int epld_date = 0;
    
    ret = i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_VER, 1, &epld_ver, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_CENTURY, 1, &century, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_YEAR, 1, &year, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_MONTH, 1, &month, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_DAY, 1, &day, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_HOUR, 1, &hour, 1);
    ret += i2c_read(GLB_I2C_IDX_0, EPLD_ADDR, EPLD_MINUTE, 1, &minute, 1);

    epld_date = century << 24 | year << 16 | month << 8 | day;
    epld_time = hour << 8 | minute;

    fprintf(fp, GLB_EPLD_VERSION_STRING "  %x\n", epld_ver);
    fprintf(fp, GLB_EPLD_DATE_STRING "  %x\n", epld_date);
    fprintf(fp, GLB_EPLD_TIME_STRING "  %x\n", epld_time);

    return ret;
}


#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "ctc_hw.h"
#include "glb_hw_define.h"
#include "glb_tempfile_define.h"
#include "detect.h"

#define I2C_WRITE_OP    0
#define I2C_READ_OP     1
#define I2C_RDWR        0x0707  /* Combined R/W transfer (one stop only)*/

#define CTC_HW_GET_PLATFORM_TYPE _IO(CTC_HW_DEV_MAJOR, 16)

int ctc_flash_size_array[CTC_FLASH_MAX_TYPES] =
{
    CTC_MEMORY_SIZE_1G,
    CTC_MEMORY_SIZE_2G,
    CTC_MEMORY_SIZE_512,
    CTC_MEMORY_SIZE_4G,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
};

int ctc_dram_size_array[CTC_DRAM_MAX_TYPES] =
{
    CTC_MEMORY_SIZE_1G,
    CTC_MEMORY_SIZE_2G,
    CTC_MEMORY_SIZE_512,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
    CTC_MEMORY_RESERVE,
};

uint8 g_eeprom_info[3]; /* eeprom_num:eeprom1addr:eeprom2addr */
int g_platform_type;
uint8 g_product_series;           /*board series*/
uint8 g_board_type;           /*board series*/
static int32 i2c_dev0_fd = -1;
static int32 i2c_dev1_fd = -1;

int
i2c_open_dev0(void)
{
    if (i2c_dev0_fd < 0)
    {
        i2c_dev0_fd = open("/dev/i2c-0", O_RDWR);
        if (i2c_dev0_fd < 0)
        {
            return -1;
        }
    }
    return 0;
}

int
i2c_open_dev1(void)
{
    if (i2c_dev1_fd < 0)
    {
        i2c_dev1_fd = open("/dev/i2c-1", O_RDWR);
        if (i2c_dev1_fd < 0)
        {
            return -1;
        }
    }
    return 0;
}

int32
i2c_switch_msg(struct ctc_i2c_msg* msg, uint16 addr,
                         uint8* p_buf, uint16 flag, int32 len)
{
    if(NULL == msg)
    {
        return -1;
    }

    msg->addr = addr;
    msg->buf = p_buf;
    msg->flags = flag;
    msg->len = len;
    return 0;
}

int32
i2c_transfer(uint8 i2c_bus_idx, struct i2c_rdwr_ioctl_data* msgset)
{
    int32 ret=0;
    if (NULL == msgset)
    {
        return -1;
    }
    if (GLB_I2C_IDX_0 == i2c_bus_idx)
    {
        ret = ioctl(i2c_dev0_fd, I2C_RDWR, msgset);    
    }
    else if (GLB_I2C_IDX_1 == i2c_bus_idx)
    {
        ret = ioctl(i2c_dev1_fd, I2C_RDWR, msgset);    
    }
    
    return ret;
}


/*Below cmd just used for diag*/
int32 i2c_read(uint8 i2c_bus_idx, uint16 addr, uint32 offset, uint8 alen, uint8* buf, uint8 len)
{
    int32 ret;
    struct i2c_rdwr_ioctl_data msgset;
    struct ctc_i2c_msg msgs[2];
    uint8 offset_buf[4];

    /*fix bug20012,cr5438, change high and low address position, liangf, 2012-07-30*/
    if(alen == 1)
    {
        offset_buf[0] = (uint8)(offset&0xff);
    }
    else if(alen == 2)
    {
        offset_buf[0] = (uint8)((offset>>8)&0xff);
        offset_buf[1] = (uint8)(offset&0xff);
    }
    else if(alen == 3)
    {
        offset_buf[0] = (uint8)((offset>>16)&0xff);
        offset_buf[1] = (uint8)((offset>>8)&0xff);
        offset_buf[2] = (uint8)(offset&0xff);
    }
    else if(alen == 4)
    {
        offset_buf[0] = (uint8)((offset>>24)&0xff);
        offset_buf[1] = (uint8)((offset>>16)&0xff);
        offset_buf[2] = (uint8)((offset>>8)&0xff);
        offset_buf[3] = (uint8)(offset&0xff);
    }
    i2c_switch_msg(msgs, addr, offset_buf, I2C_WRITE_OP, alen);
    i2c_switch_msg(msgs+1, addr, buf, I2C_READ_OP, len);

    msgset.msgs = msgs;
    msgset.nmsgs = 2;
    ret = i2c_transfer(i2c_bus_idx, &msgset);
    return ret;
}

/*bootargsline : input parser line
**log_path : store parser result
**len : the max path length*/
int
parser_bootargs_ethaddr(char* bootargsline, char* ethaddr, int len)
{
    char* ptr;
    int i=0;
    uint32 tmp;

    ptr = strstr(bootargsline, "ethaddr=");
    if(ptr == NULL)
    {
        return -1;
    }
    ptr = ptr + 8;
    if(len <= i)
        return -1;

    while(*ptr != '\0' && *ptr != ' ')
    {
        if(*ptr == ':')
        {
            ptr++;
            continue;
        }
        tmp = 0;
        sal_sscanf(ptr, "%x" , &tmp);
        ethaddr[i] = tmp&0xff;
        ptr += 2;
        i++;

        if(len < i)
            return -1;
    }

    return 0;
}

/*bootargsline : input parser line
**ipaddr : store parser result
**len : the max ip length*/
int
_parser_bootargs_ipaddr(char* bootargsline, uint32* ipaddr, int len)
{
    char* ptr;
    int i=0;
    uint32 tmp;

    ptr = strstr(bootargsline, "selfip=");
    if(ptr == NULL)
    {
        return -1;
    }
    ptr = ptr + 7;
    if(len <= i)
        return -1;

    while(*ptr != '\0' && *ptr != ' ')
    {
        if(*ptr == '.')
        {
            ptr++;
            continue;
        }
        tmp = 0;
        sal_sscanf(ptr, "%x" , &tmp);
        ipaddr[i] = tmp;
        if(i < 3)
        {
          ptr = strstr(ptr, ".");
            i++;
        }
        else
        {
            break;
        }
        if(len < i)
            return -1;
    }

    return 0;
}

int
ctc_get_common_epld_info(FILE *fp)
{
    int mem_fd;
    unsigned char *local_bus_base;
    unsigned char epld_ver = 0;
    unsigned short epld_time = 0;
    unsigned int epld_date = 0;

#ifdef _CTC_ARM_HI3535_
    unsigned char value;

    /* get epld version */
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_VER, 1, &epld_ver, 1);

    /* get epld data */
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_DATA_OFFSET, 1, &value, 1);
    epld_date = value;
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_DATA_OFFSET+1, 1, &value, 1);
    epld_date <<= 8;
    epld_date |= value;
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_DATA_OFFSET+2, 1, &value, 1);
    epld_date <<= 8;
    epld_date |= value;
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_DATA_OFFSET+3, 1, &value, 1);
    epld_date <<= 8;
    epld_date |= value;

    /* get epld time */
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_TIME_OFFSET, 1, &value, 1);
    epld_time = value;
    i2c_read(GLB_I2C_IDX_0, EPLD_ADDRESS, EPLD_TIME_OFFSET+1, 1, &value, 1);
    epld_time <<= 8;
    epld_time |= value;
#else
    mem_fd = open("/dev/mem", O_RDWR | O_SYNC);
    if(mem_fd < 0) {
        printf("open /dev/mem failed");
        return -1;
    }
    local_bus_base = (unsigned char*)mmap(NULL, 0x1000, PROT_READ|PROT_WRITE,
            MAP_SHARED, mem_fd, GB_NORMAL_EPLD_LOCAL_BUS_ADDR);/* IO for EPLD */
    if(local_bus_base < 0)
    {
        printf("Mmap epld error\n");
        close(mem_fd);
        return -1;
    }

    epld_ver = *(local_bus_base + 0x1);
    epld_date = *(local_bus_base + 0xf0);
    epld_date <<= 8;
    epld_date |= *(local_bus_base + 0xf1);
    epld_date <<= 8;
    epld_date |= *(local_bus_base + 0xf2);
    epld_date <<= 8;
    epld_date |= *(local_bus_base + 0xf3);
    epld_time = *(local_bus_base + 0xf4);
    epld_time <<= 8;
    epld_time |= *(local_bus_base + 0xf5);
    munmap(local_bus_base, 0x1000);
#endif
    fprintf(fp, GLB_EPLD_VERSION_STRING "  %x\n", epld_ver);
    fprintf(fp, GLB_EPLD_DATE_STRING "  %x\n", epld_date);
    fprintf(fp, GLB_EPLD_TIME_STRING "  %x\n", epld_time);

    return 0;
}

int
ctc_get_common_mgt_info(FILE *fp)
{
    uint8 mgmtcfg[24];
    unsigned char mgmtuser[9];
    unsigned char mgmtpin[9];
    struct in_addr addr;
    int ret;
    int i;
    ret = i2c_open_dev0();
    if (ret < 0)
    {
        printf("Open i2c bus 0 device failed!\n");
        return -1;
    }
    if(g_platform_type)
    {
        ret = i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, GB_EEPROM0_MGMT_CFG_OFFSET, 2, mgmtcfg, sizeof(mgmtcfg));
    }
    else
    {
        ret = i2c_read(GLB_I2C_IDX_0, GB_EEPROM1_ADDR, GB_EEPROM1_MGMT_CFG_OFFSET, 2, mgmtcfg, sizeof(mgmtcfg));
    }
    

    if (0xFF == mgmtcfg[0] && 0xFF == mgmtcfg[23]) {
        /* EEPROM for MGMT CFG uninitialized */
        memset(mgmtcfg, 0x00, sizeof(mgmtcfg));   
        /* for bug 37280 modified by liuyang 2016-2-26*/
        if (g_product_series == GLB_SERIES_P580)  
        {
            /*modified by liuyang 2016-2-18*/
            memcpy(mgmtcfg, "admin", strlen("admin"));
            memcpy(mgmtcfg + 8, "admin", strlen("admin"));
            inet_aton("192.168.0.100", &addr);
            memcpy(mgmtcfg + 16, &addr, sizeof(addr));
        }
    }

    memset(mgmtuser, 0x00, sizeof(mgmtuser));
    memset(mgmtpin, 0x00, sizeof(mgmtpin));
    for (i = 0; i < 8; i++) {
        if ('\0' == mgmtcfg[i]) {
            break;
        }

        mgmtuser[i] = mgmtcfg[i];
    }
    mgmtuser[i] = '\0';

    for (i = 0; i < 8; i++) {
        if ('\0' == mgmtcfg[i + 8]) {
            break;
        }

        mgmtpin[i] = mgmtcfg[i + 8];
    }
    mgmtpin[i] = '\0';
    memcpy(&addr, mgmtcfg + 16, sizeof(addr));

    fprintf(fp, "mgmtuser %s\n", mgmtuser);
    fprintf(fp, "mgmtpin \"%s\"\n", mgmtpin);
    fprintf(fp, "mgmtip %s\n", inet_ntoa(addr)); 

    return 0;
}

int
ctc_get_ethaddr(char* ethaddr, int len)
{

    return 0;
}

int
ctc_get_ipaddr(uint32* ipaddr, int len)
{

    return 0;
}

int
ctc_get_platform_type()
{
    int fd;

    fd = open("/dev/ctc_hw", O_RDWR);
    ioctl(fd, CTC_HW_GET_PLATFORM_TYPE, &g_platform_type);
    close(fd);
    
    return g_platform_type;
}

int
ctc_eeprom_detect()
{
    int ret;
    uint8 val;
    uint8 num=0;
    
    ret = i2c_read(GLB_I2C_IDX_0, GB_EEPROM0_ADDR, 0, 2, &val, 1);
    if(ret>=0)
    {
        num++;
        g_eeprom_info[num] = GB_EEPROM0_ADDR;
    }
    ret = i2c_read(GLB_I2C_IDX_0, GB_EEPROM1_ADDR, 0, 2, &val, 1);
    if(ret>=0)
    {
        num++;
        g_eeprom_info[num] = GB_EEPROM1_ADDR;
    }
    g_eeprom_info[0] = num;

    return 0;
}

int ctc_get_board_info(uint8* board_type)
{
    ctc_eeprom_detect();
    
    if(ctc_get_platform_type())
    {
        ctc_get_onie_board_info(board_type);
    }
    else
    {
        ctc_get_normal_board_info(board_type);
    }
    return 0;
}


tbl_acl_worm_filter_t*
tbl_acl_worm_filter_get_by_name(char *name);

tbl_acl_worm_filter_t*
tbl_acl_worm_filter_get_by_seq(uint32 seq_num);

int32
tbl_acl_worm_filter_get_range_count();

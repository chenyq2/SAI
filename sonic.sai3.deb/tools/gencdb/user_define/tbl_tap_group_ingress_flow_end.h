int32
tbl_tap_group_ingress_flow_get_if_exist(const char* tap_grp, const char* if_name);

int32
tbl_tap_group_ingress_flow_get_group_if_exist(const char* tap_grp, const char* if_name);

int32
tbl_tap_group_ingress_flow_get_if_flow_exist(const char* if_name, const char* flow_name);


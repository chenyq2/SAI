uint32
tbl_chip_get_type();

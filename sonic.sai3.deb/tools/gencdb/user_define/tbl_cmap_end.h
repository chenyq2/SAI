tbl_cmap_t*
tbl_cmap_get_cmap_by_name(char *name);

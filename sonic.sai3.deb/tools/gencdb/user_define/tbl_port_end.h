tbl_port_t*
tbl_port_get_port_by_slot_port(uint8 slot_no, uint8 port_no, uint8 sub_port_no);

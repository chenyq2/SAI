bool
tbl_qos_global_get_phb_enable();

bool
tbl_qos_global_get_qos_enable();

bool
tbl_qos_global_get_port_policer_first_enable();

bool
tbl_qos_global_get_policer_stats_enable();

int32
tbl_qos_global_get_cur_cpu_rate();

int32
tbl_qos_global_get_def_cpu_rate();

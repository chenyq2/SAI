typedef void (*TIME_RANGE_CB)(void* arg, bool invalid);

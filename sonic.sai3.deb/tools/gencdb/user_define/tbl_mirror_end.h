extern tbl_mirror_t*
mirror_get_session(uint32 sessionid);

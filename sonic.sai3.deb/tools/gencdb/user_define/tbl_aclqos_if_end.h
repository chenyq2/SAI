tbl_aclqos_if_t*
tbl_aclqos_if_get_aclqos_if_by_name(const char* ifname);
int32
tbl_qos_domain_get_qos_domain_field(uint8 domain_id, tbl_qos_domain_field_id_t field_id, tbl_qos_domain_t *p_qos_domain);

tbl_qos_domain_t*
tbl_qos_domain_get_qos_domain_by_id(uint8 domain_id);

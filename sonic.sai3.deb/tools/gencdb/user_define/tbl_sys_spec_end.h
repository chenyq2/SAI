tbl_sys_spec_t*
tbl_sys_spec_get_sys_spec_by_type(uint32 type);

uint32
tbl_sys_spec_get_sys_spec_field_by_type(uint32 type, int32 field_id);

typedef struct
{
    tbl_route_node_t     *top;
    uint32               count;
} tbl_route_table_t;

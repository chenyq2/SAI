int32
tbl_ace_config_get_ace_config_count();

tbl_ace_config_t*
tbl_ace_config_get_ace_config_by_name(const char* acl_name, const uint32 seq_no);


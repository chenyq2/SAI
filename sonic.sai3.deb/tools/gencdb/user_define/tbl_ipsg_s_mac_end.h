
tbl_ipsg_s_mac_t*
tbl_ipsg_s_mac_get_ipsg_s_mac_by_macaddr(mac_addr_t mac);


#include "mirror_define.h"

const char *mirror_dest_type_strs[MIRROR_DEST_TYPE_MAX] =
{
    "MIRROR_DEST_NONE",
    "MIRROR_DEST_VLAN",
    "MIRROR_DEST_PORT",
    "MIRROR_DEST_GROUP",
    "MIRROR_DEST_MAX",
};


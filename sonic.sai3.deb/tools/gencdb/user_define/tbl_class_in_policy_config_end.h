

tbl_class_in_policy_config_t*
tbl_class_in_policy_config_get_class_in_policy_config_by_name(const char* policy_map_name, const char* class_map_name);

tbl_class_in_policy_config_t*
tbl_class_in_policy_config_get_class_in_policy_config_by_class_priority(const uint64 class_priority);

ds_pmap_class_t*
ds_pmap_class_get_pmap_class_by_name(tbl_pmap_t *p_pmap, char *name);

int32
ds_pmap_class_add_pmap_class_by_name(tbl_pmap_t *p_pmap, char* name);

int32
ds_pmap_class_del_pmap_class_by_name(tbl_pmap_t *p_pmap, char* name);

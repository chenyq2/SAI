typedef CTCLIB_TAILQ_HEAD(fea_fdb_tailq_head_s, tbl_fea_fdb_s) fea_fdb_tailq_head_t;

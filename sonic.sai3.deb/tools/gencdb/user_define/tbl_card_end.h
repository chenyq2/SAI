tbl_card_t*
tbl_card_get_default_card();

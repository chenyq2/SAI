int32
tbl_policy_map_config_get_policy_map_config_count();

tbl_policy_map_config_t*
tbl_policy_map_config_get_policy_map_config_by_name(const char* policy_map_name);


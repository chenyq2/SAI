tbl_acl_t*
tbl_acl_get_acl_by_name(char *name);

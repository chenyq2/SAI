
tbl_class_map_action_config_t*
tbl_class_map_action_config_get_class_map_action_config_by_name(const char* policy_map_name, const char* class_map_name);



tbl_ipsg_s_ip_t*
tbl_ipsg_s_ip_get_ipsg_s_ip_by_ipaddr(prefix_t *preifx);


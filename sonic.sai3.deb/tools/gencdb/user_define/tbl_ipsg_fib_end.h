
tbl_ipsg_fib_t*
tbl_ipsg_fib_get_ipsg_fib_by_ifname(char *ifname);

uint32
tbl_chip_get_type()
{
    return _g_p_tbl_chip->type;
}

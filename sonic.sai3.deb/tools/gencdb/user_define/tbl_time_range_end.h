tbl_time_range_t*
tbl_time_range_get_time_range_by_name(char *name);

int32
tbl_time_range_get_time_range_count();


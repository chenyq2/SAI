int32
tbl_tap_group_get_truncation_rcs(tbl_tap_group_t *p_tap_grp, tbl_iter_args_t *pargs);


int32
tbl_tap_group_get_truncation_count();


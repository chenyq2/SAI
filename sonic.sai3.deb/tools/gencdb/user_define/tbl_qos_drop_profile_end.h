tbl_qos_drop_profile_t*
tbl_qos_drop_profile_get_profile_by_name(char *name);

int32
tbl_qos_drop_profile_alloc_profile_id(uint32 *p_id);

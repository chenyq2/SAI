

tbl_acl_in_class_config_t*
tbl_acl_in_class_config_get_acl_in_class_config_by_name(const char* class_map_name, const char* acl_name);

tbl_acl_in_class_config_t*
tbl_acl_in_class_config_get_acl_in_class_config_by_acl_priority(const uint64 acl_priority);
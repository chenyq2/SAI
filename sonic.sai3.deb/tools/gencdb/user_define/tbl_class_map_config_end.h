
int32
tbl_class_map_config_get_class_map_config_count();

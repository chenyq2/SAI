int32
tbl_acl_config_get_acl_config_count();

int32
tbl_acl_config_get_l4port_one(tbl_acl_config_t *p_acl_config, tbl_iter_args_t *pargs);

int32
tbl_acl_config_get_l4port_config_count();

int32
tbl_acl_config_get_tcp_flags_one(tbl_acl_config_t *p_acl_config, tbl_iter_args_t *pargs);

int32
tbl_acl_config_get_tcp_flags_config_count();


#define l_left   link[0]
#define l_right  link[1]

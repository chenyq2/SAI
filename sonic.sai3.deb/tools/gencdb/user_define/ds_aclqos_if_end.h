int32
ds_aclqos_if_get_aclqos_if_field(tbl_interface_t *p_db_if, ds_aclqos_if_field_id_t field_id, void* field_value);

tbl_pmap_t*
tbl_pmap_get_pmap_by_name(char *name);
int32
tbl_pmap_add_pmap_by_name(char *name);
int32
tbl_pmap_del_pmap_by_name(char *name);

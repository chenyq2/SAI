
#include "proto.h"
#include "pb_cdb_inc.h"
#include "tbl.pb-c.h"
#include "pb_tbl.h"
#include "pb_common.h"

/* pb functions for TBL_INTERFACE */
int32
pb_tbl_interface_to_pb(uint32 only_key, tbl_interface_t *p_if, Cdb__TblInterface *p_pb_if)
{
    p_pb_if->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->key.name)+1);
    sal_strcpy(p_pb_if->key->name, p_if->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_if->has_ifindex = TRUE;
    p_pb_if->ifindex = p_if->ifindex;
    p_pb_if->has_portid = TRUE;
    p_pb_if->portid = p_if->portid;
    p_pb_if->has_hostifid = TRUE;
    p_pb_if->hostifid = p_if->hostifid;
    p_pb_if->desc = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->desc)+1);
    sal_strcpy(p_pb_if->desc, p_if->desc);
    p_pb_if->has_speed = TRUE;
    p_pb_if->speed = p_if->speed;
    p_pb_if->has_duplex = TRUE;
    p_pb_if->duplex = p_if->duplex;
    p_pb_if->has_unidir = TRUE;
    p_pb_if->unidir = p_if->unidir;
    p_pb_if->has_flowcontrol_send = TRUE;
    p_pb_if->flowcontrol_send = GLB_FLAG_ISSET(p_if->flowcontrol, GLB_IF_FLOW_CONTROL_SEND) ? TRUE : FALSE;
    p_pb_if->has_flowcontrol_receive = TRUE;
    p_pb_if->flowcontrol_receive = GLB_FLAG_ISSET(p_if->flowcontrol, GLB_IF_FLOW_CONTROL_RECEIVE) ? TRUE : FALSE;
    p_pb_if->has_flowcontrol_oper_send = TRUE;
    p_pb_if->flowcontrol_oper_send = GLB_FLAG_ISSET(p_if->flowcontrol, GLB_IF_FLOW_OPER_CONTROL_SEND) ? TRUE : FALSE;
    p_pb_if->has_flowcontrol_oper_receive = TRUE;
    p_pb_if->flowcontrol_oper_receive = GLB_FLAG_ISSET(p_if->flowcontrol, GLB_IF_FLOW_OPER_CONTROL_RECEIVE) ? TRUE : FALSE;
    p_pb_if->has_fec = TRUE;
    p_pb_if->fec = p_if->fec;
    p_pb_if->has_pfc_admin = TRUE;
    p_pb_if->pfc_admin = p_if->pfc_admin;
    p_pb_if->has_pfc_oper = TRUE;
    p_pb_if->pfc_oper = p_if->pfc_oper;
    p_pb_if->has_pfc_priority = TRUE;
    p_pb_if->pfc_priority = p_if->pfc_priority;
    p_pb_if->has_jumboframe_en = TRUE;
    p_pb_if->jumboframe_en = p_if->jumboframe_en;
    p_pb_if->has_isolate_group_id = TRUE;
    p_pb_if->isolate_group_id = p_if->isolate_group_id;
    p_pb_if->has_dhcp_snooping_trust = TRUE;
    p_pb_if->dhcp_snooping_trust = p_if->dhcp_snooping_trust;
    p_pb_if->has_phy_status = TRUE;
    p_pb_if->phy_status = p_if->phy_status;
    p_pb_if->has_phy_loopback_mode = TRUE;
    p_pb_if->phy_loopback_mode = p_if->phy_loopback_mode;
    p_pb_if->has_internal_lp_ifindex = TRUE;
    p_pb_if->internal_lp_ifindex = p_if->internal_lp_ifindex;
    p_pb_if->has_pvlan_type = TRUE;
    p_pb_if->pvlan_type = p_if->pvlan_type;
    p_pb_if->has_private_vlan = TRUE;
    p_pb_if->private_vlan = p_if->private_vlan;
    p_pb_if->has_community_vlan = TRUE;
    p_pb_if->community_vlan = p_if->community_vlan;
    p_pb_if->has_ntp_disable = TRUE;
    p_pb_if->ntp_disable = p_if->ntp_disable;
    p_pb_if->has_ntp_broadcast_client = TRUE;
    p_pb_if->ntp_broadcast_client = p_if->ntp_broadcast_client;
    p_pb_if->has_pvlan_group_id = TRUE;
    p_pb_if->pvlan_group_id = p_if->pvlan_group_id;
    p_pb_if->has_support_speed = TRUE;
    p_pb_if->support_speed = p_if->support_speed;
    p_pb_if->has_mode = TRUE;
    p_pb_if->mode = p_if->mode;
    p_pb_if->has_vlan_type = TRUE;
    p_pb_if->vlan_type = p_if->vlan_type;
    p_pb_if->has_up = TRUE;
    p_pb_if->up = GLB_FLAG_ISSET(p_if->flags, GLB_IFF_UP) ? TRUE : FALSE;
    p_pb_if->has_running = TRUE;
    p_pb_if->running = GLB_FLAG_ISSET(p_if->flags, GLB_IFF_RUNNING) ? TRUE : FALSE;
    p_pb_if->has_mtu = TRUE;
    p_pb_if->mtu = p_if->mtu;
    p_pb_if->has_oper_speed = TRUE;
    p_pb_if->oper_speed = p_if->oper_speed;
    p_pb_if->has_oper_duplex = TRUE;
    p_pb_if->oper_duplex = p_if->oper_duplex;
    p_pb_if->has_oper_unidir = TRUE;
    p_pb_if->oper_unidir = p_if->oper_unidir;
    p_pb_if->has_oper_fec = TRUE;
    p_pb_if->oper_fec = p_if->oper_fec;
    p_pb_if->has_oper_loopback = TRUE;
    p_pb_if->oper_loopback = p_if->oper_loopback;
    p_pb_if->has_bandwidth = TRUE;
    p_pb_if->bandwidth = p_if->bandwidth;
    p_pb_if->has_tap_used = TRUE;
    p_pb_if->tap_used = p_if->tap_used;
    p_pb_if->has_tap_ingress_enable = TRUE;
    p_pb_if->tap_ingress_enable = p_if->tap_ingress_enable;
    p_pb_if->tap = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->tap)+1);
    sal_strcpy(p_pb_if->tap, p_if->tap);
    p_pb_if->has_tap_mark_vlan = TRUE;
    p_pb_if->tap_mark_vlan = p_if->tap_mark_vlan;
    p_pb_if->has_mirror_enable = TRUE;
    p_pb_if->mirror_enable = p_if->mirror_enable;
    p_pb_if->has_mirror_igs_id = TRUE;
    p_pb_if->mirror_igs_id = p_if->mirror_igs_id;
    p_pb_if->has_mirror_egs_id = TRUE;
    p_pb_if->mirror_egs_id = p_if->mirror_egs_id;
    p_pb_if->has_mirror_dest_id = TRUE;
    p_pb_if->mirror_dest_id = p_if->mirror_dest_id;
    p_pb_if->has_admin_up = TRUE;
    p_pb_if->admin_up = p_if->admin_up;
    p_pb_if->has_ip_source_en = TRUE;
    p_pb_if->ip_source_en = p_if->ip_source_en;
    p_pb_if->has_ip_source_type = TRUE;
    p_pb_if->ip_source_type = p_if->ip_source_type;
    p_pb_if->has_ip_source_item_number = TRUE;
    p_pb_if->ip_source_item_number = p_if->ip_source_item_number;
    p_pb_if->has_unicast_rpf_en = TRUE;
    p_pb_if->unicast_rpf_en = p_if->unicast_rpf_en;
    p_pb_if->has_oper_bandwidth = TRUE;
    p_pb_if->oper_bandwidth = p_if->oper_bandwidth;
    p_pb_if->has_errdisable_reason = TRUE;
    p_pb_if->errdisable_reason = p_if->errdisable_reason;
    p_pb_if->has_fdb_loop_occur = TRUE;
    p_pb_if->fdb_loop_occur = p_if->fdb_loop_occur;
    p_pb_if->has_link_flap_cnt = TRUE;
    p_pb_if->link_flap_cnt = p_if->link_flap_cnt;
    p_pb_if->has_static_security_num = TRUE;
    p_pb_if->static_security_num = p_if->static_security_num;
    p_pb_if->has_sflow_flow_en = TRUE;
    p_pb_if->sflow_flow_en = p_if->sflow_flow_en;
    p_pb_if->has_sflow_flow_ingress = TRUE;
    p_pb_if->sflow_flow_ingress = p_if->sflow_flow_ingress;
    p_pb_if->has_sflow_flow_egress = TRUE;
    p_pb_if->sflow_flow_egress = p_if->sflow_flow_egress;
    p_pb_if->has_sflow_counter_en = TRUE;
    p_pb_if->sflow_counter_en = p_if->sflow_counter_en;
    p_pb_if->has_sflow_rate = TRUE;
    p_pb_if->sflow_rate = p_if->sflow_rate;
    p_pb_if->has_sflow_sequence = TRUE;
    p_pb_if->sflow_sequence = p_if->sflow_sequence;
    p_pb_if->has_sflow_sample_pool = TRUE;
    p_pb_if->sflow_sample_pool = p_if->sflow_sample_pool;
    pb_compose_mac_addr_t_to_pb(p_if->mac_addr, p_pb_if->mac_addr);
    pb_compose_mac_addr_t_to_pb(p_if->hw_mac_addr, p_pb_if->hw_mac_addr);
    p_pb_if->has_hw_type = TRUE;
    p_pb_if->hw_type = p_if->hw_type;
    p_pb_if->has_phy_type = TRUE;
    p_pb_if->phy_type = p_if->phy_type;
    p_pb_if->has_media = TRUE;
    p_pb_if->media = p_if->media;
    p_pb_if->has_phyport_combo = TRUE;
    p_pb_if->phyport_combo = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_COMBO) ? TRUE : FALSE;
    p_pb_if->has_phyport_loopback = TRUE;
    p_pb_if->phyport_loopback = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_LOOPBACK) ? TRUE : FALSE;
    p_pb_if->has_phyport_eee = TRUE;
    p_pb_if->phyport_eee = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_EEE) ? TRUE : FALSE;
    p_pb_if->has_phyport_poe = TRUE;
    p_pb_if->phyport_poe = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_POE) ? TRUE : FALSE;
    p_pb_if->has_phyport_master = TRUE;
    p_pb_if->phyport_master = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_MASTER) ? TRUE : FALSE;
    p_pb_if->has_phyport_slave = TRUE;
    p_pb_if->phyport_slave = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_SLAVE) ? TRUE : FALSE;
    p_pb_if->has_phyport_unidir = TRUE;
    p_pb_if->phyport_unidir = GLB_FLAG_ISSET(p_if->phyport_flag, GLB_PHYPORT_FLAG_UNIDIR) ? TRUE : FALSE;
    p_pb_if->has_support_100m = TRUE;
    p_pb_if->support_100m = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_100M) ? TRUE : FALSE;
    p_pb_if->has_support_1g = TRUE;
    p_pb_if->support_1g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_1G) ? TRUE : FALSE;
    p_pb_if->has_support_10g = TRUE;
    p_pb_if->support_10g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_10G) ? TRUE : FALSE;
    p_pb_if->has_support_40g = TRUE;
    p_pb_if->support_40g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_40G) ? TRUE : FALSE;
    p_pb_if->has_support_100g = TRUE;
    p_pb_if->support_100g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_100G) ? TRUE : FALSE;
    p_pb_if->has_support_2_5g = TRUE;
    p_pb_if->support_2_5g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_2_5G) ? TRUE : FALSE;
    p_pb_if->has_support_5g = TRUE;
    p_pb_if->support_5g = GLB_FLAG_ISSET(p_if->support_speed_flag, GLB_SUPPORT_SPEED_5G) ? TRUE : FALSE;
    p_pb_if->igs_acl = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->igs_acl)+1);
    sal_strcpy(p_pb_if->igs_acl, p_if->igs_acl);
    p_pb_if->egs_acl = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->egs_acl)+1);
    sal_strcpy(p_pb_if->egs_acl, p_if->egs_acl);
    p_pb_if->igs_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->igs_policy_map)+1);
    sal_strcpy(p_pb_if->igs_policy_map, p_if->igs_policy_map);
    p_pb_if->egs_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->egs_policy_map)+1);
    sal_strcpy(p_pb_if->egs_policy_map, p_if->egs_policy_map);
    p_pb_if->has_crc_error_check_en = TRUE;
    p_pb_if->crc_error_check_en = p_if->crc_error_check_en;
    p_pb_if->has_mlag_id = TRUE;
    p_pb_if->mlag_id = p_if->mlag_id;
    p_pb_if->has_erps_enable = TRUE;
    p_pb_if->erps_enable = p_if->erps_enable;
    p_pb_if->has_erps_pdu_action = TRUE;
    p_pb_if->erps_pdu_action = p_if->erps_pdu_action;
    p_pb_if->has_dot1x_enable = TRUE;
    p_pb_if->dot1x_enable = p_if->dot1x_enable;
    p_pb_if->has_dot1x_unauthorized = TRUE;
    p_pb_if->dot1x_unauthorized = GLB_FLAG_ISSET(p_if->dot1x_flag, GLB_IF_DOT1X_UNAUTHED) ? TRUE : FALSE;
    p_pb_if->has_dot1x_dir_in = TRUE;
    p_pb_if->dot1x_dir_in = GLB_FLAG_ISSET(p_if->dot1x_flag, GLB_IF_DOT1X_DIR_IN) ? TRUE : FALSE;
    p_pb_if->has_dot1x_dir_out = TRUE;
    p_pb_if->dot1x_dir_out = GLB_FLAG_ISSET(p_if->dot1x_flag, GLB_IF_DOT1X_DIR_OUT) ? TRUE : FALSE;
    p_pb_if->has_dot1x_mode_mac = TRUE;
    p_pb_if->dot1x_mode_mac = GLB_FLAG_ISSET(p_if->dot1x_flag, GLB_IF_DOT1X_MODE_MAC) ? TRUE : FALSE;
    p_pb_if->has_dot1x_guest_vlan = TRUE;
    p_pb_if->dot1x_guest_vlan = p_if->dot1x_guest_vlan;
    p_pb_if->has_vlanclass_group_id = TRUE;
    p_pb_if->vlanclass_group_id = p_if->vlanclass_group_id;
    p_pb_if->has_vlanclass_active_type = TRUE;
    p_pb_if->vlanclass_active_type = p_if->vlanclass_active_type;
    p_pb_if->has_vlanclass_default_action = TRUE;
    p_pb_if->vlanclass_default_action = p_if->vlanclass_default_action;
    p_pb_if->has_dot1x_cfg_guest_vlan = TRUE;
    p_pb_if->dot1x_cfg_guest_vlan = p_if->dot1x_cfg_guest_vlan;
    p_pb_if->has_egs_acl_en = TRUE;
    p_pb_if->egs_acl_en = p_if->egs_acl_en;
    p_pb_if->has_tap_group_igs_ref_cnt = TRUE;
    p_pb_if->tap_group_igs_ref_cnt = p_if->tap_group_igs_ref_cnt;
    p_pb_if->has_tap_group_egs_ref_cnt = TRUE;
    p_pb_if->tap_group_egs_ref_cnt = p_if->tap_group_egs_ref_cnt;
    p_pb_if->has_arpinsp_trust_enable = TRUE;
    p_pb_if->arpinsp_trust_enable = p_if->arpinsp_trust_enable;
    p_pb_if->has_arp_numberlimit_enable = TRUE;
    p_pb_if->arp_numberlimit_enable = p_if->arp_numberlimit_enable;
    p_pb_if->has_arp_numberlimit_number = TRUE;
    p_pb_if->arp_numberlimit_number = p_if->arp_numberlimit_number;
    p_pb_if->has_arp_numberlimit_violate = TRUE;
    p_pb_if->arp_numberlimit_violate = p_if->arp_numberlimit_violate;
    p_pb_if->has_arp_numberlimit_occur = TRUE;
    p_pb_if->arp_numberlimit_occur = p_if->arp_numberlimit_occur;
    p_pb_if->has_arp_rate_limit_errdisable_occur = TRUE;
    p_pb_if->arp_rate_limit_errdisable_occur = p_if->arp_rate_limit_errdisable_occur;
    p_pb_if->has_inband_snat_type = TRUE;
    p_pb_if->inband_snat_type = p_if->inband_snat_type;

    return PM_E_NONE;
}

int32
pb_tbl_interface_to_pb_free_packed(Cdb__TblInterface *p_pb_if)
{
    if (p_pb_if->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->key->name);
        p_pb_if->key->name = NULL;
    }

    if (p_pb_if->desc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->desc);
        p_pb_if->desc = NULL;
    }

    if (p_pb_if->tap)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->tap);
        p_pb_if->tap = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_if->mac_addr);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_if->hw_mac_addr);
    if (p_pb_if->igs_acl)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->igs_acl);
        p_pb_if->igs_acl = NULL;
    }

    if (p_pb_if->egs_acl)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->egs_acl);
        p_pb_if->egs_acl = NULL;
    }

    if (p_pb_if->igs_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->igs_policy_map);
        p_pb_if->igs_policy_map = NULL;
    }

    if (p_pb_if->egs_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->egs_policy_map);
        p_pb_if->egs_policy_map = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_interface_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__TblInterface pb_if = CDB__TBL_INTERFACE__INIT;
    tbl_interface_t *p_if = (tbl_interface_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT hw_mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_if.key = &pb_if_key;
    pb_if.mac_addr = &mac_addr;
    pb_if.hw_mac_addr = &hw_mac_addr;
    pb_tbl_interface_to_pb(only_key, p_if, &pb_if);
    len = cdb__tbl_interface__pack(&pb_if, buf);
    pb_tbl_interface_to_pb_free_packed(&pb_if);

    return len;
}

int32
pb_tbl_interface_dump(Cdb__TblInterface *p_pb_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_if->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_if->ifindex);
    offset += sal_sprintf(out + offset, "/portid=%llu", p_pb_if->portid);
    offset += sal_sprintf(out + offset, "/hostifid=%llu", p_pb_if->hostifid);
    offset += sal_sprintf(out + offset, "/desc=%s", p_pb_if->desc);
    offset += sal_sprintf(out + offset, "/speed=%u", p_pb_if->speed);
    offset += sal_sprintf(out + offset, "/duplex=%u", p_pb_if->duplex);
    offset += sal_sprintf(out + offset, "/unidir=%u", p_pb_if->unidir);
    offset += sal_sprintf(out + offset, "/flowcontrol_send=%u", p_pb_if->flowcontrol_send);
    offset += sal_sprintf(out + offset, "/flowcontrol_receive=%u", p_pb_if->flowcontrol_receive);
    offset += sal_sprintf(out + offset, "/flowcontrol_oper_send=%u", p_pb_if->flowcontrol_oper_send);
    offset += sal_sprintf(out + offset, "/flowcontrol_oper_receive=%u", p_pb_if->flowcontrol_oper_receive);
    offset += sal_sprintf(out + offset, "/fec=%u", p_pb_if->fec);
    offset += sal_sprintf(out + offset, "/pfc_admin=%u", p_pb_if->pfc_admin);
    offset += sal_sprintf(out + offset, "/pfc_oper=%u", p_pb_if->pfc_oper);
    offset += sal_sprintf(out + offset, "/pfc_priority=%u", p_pb_if->pfc_priority);
    offset += sal_sprintf(out + offset, "/jumboframe_en=%u", p_pb_if->jumboframe_en);
    offset += sal_sprintf(out + offset, "/isolate_group_id=%u", p_pb_if->isolate_group_id);
    offset += sal_sprintf(out + offset, "/dhcp_snooping_trust=%u", p_pb_if->dhcp_snooping_trust);
    offset += sal_sprintf(out + offset, "/phy_status=%u", p_pb_if->phy_status);
    offset += sal_sprintf(out + offset, "/phy_loopback_mode=%u", p_pb_if->phy_loopback_mode);
    offset += sal_sprintf(out + offset, "/internal_lp_ifindex=%u", p_pb_if->internal_lp_ifindex);
    offset += sal_sprintf(out + offset, "/pvlan_type=%u", p_pb_if->pvlan_type);
    offset += sal_sprintf(out + offset, "/private_vlan=%u", p_pb_if->private_vlan);
    offset += sal_sprintf(out + offset, "/community_vlan=%u", p_pb_if->community_vlan);
    offset += sal_sprintf(out + offset, "/ntp_disable=%u", p_pb_if->ntp_disable);
    offset += sal_sprintf(out + offset, "/ntp_broadcast_client=%u", p_pb_if->ntp_broadcast_client);
    offset += sal_sprintf(out + offset, "/pvlan_group_id=%u", p_pb_if->pvlan_group_id);
    offset += sal_sprintf(out + offset, "/support_speed=%u", p_pb_if->support_speed);
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_if->mode);
    offset += sal_sprintf(out + offset, "/vlan_type=%u", p_pb_if->vlan_type);
    offset += sal_sprintf(out + offset, "/up=%u", p_pb_if->up);
    offset += sal_sprintf(out + offset, "/running=%u", p_pb_if->running);
    offset += sal_sprintf(out + offset, "/mtu=%u", p_pb_if->mtu);
    offset += sal_sprintf(out + offset, "/oper_speed=%u", p_pb_if->oper_speed);
    offset += sal_sprintf(out + offset, "/oper_duplex=%u", p_pb_if->oper_duplex);
    offset += sal_sprintf(out + offset, "/oper_unidir=%u", p_pb_if->oper_unidir);
    offset += sal_sprintf(out + offset, "/oper_fec=%u", p_pb_if->oper_fec);
    offset += sal_sprintf(out + offset, "/oper_loopback=%u", p_pb_if->oper_loopback);
    offset += sal_sprintf(out + offset, "/bandwidth=%u", p_pb_if->bandwidth);
    offset += sal_sprintf(out + offset, "/tap_used=%u", p_pb_if->tap_used);
    offset += sal_sprintf(out + offset, "/tap_ingress_enable=%u", p_pb_if->tap_ingress_enable);
    offset += sal_sprintf(out + offset, "/tap=%s", p_pb_if->tap);
    offset += sal_sprintf(out + offset, "/tap_mark_vlan=%u", p_pb_if->tap_mark_vlan);
    offset += sal_sprintf(out + offset, "/mirror_enable=%u", p_pb_if->mirror_enable);
    offset += sal_sprintf(out + offset, "/mirror_igs_id=%u", p_pb_if->mirror_igs_id);
    offset += sal_sprintf(out + offset, "/mirror_egs_id=%u", p_pb_if->mirror_egs_id);
    offset += sal_sprintf(out + offset, "/mirror_dest_id=%u", p_pb_if->mirror_dest_id);
    offset += sal_sprintf(out + offset, "/admin_up=%u", p_pb_if->admin_up);
    offset += sal_sprintf(out + offset, "/ip_source_en=%u", p_pb_if->ip_source_en);
    offset += sal_sprintf(out + offset, "/ip_source_type=%u", p_pb_if->ip_source_type);
    offset += sal_sprintf(out + offset, "/ip_source_item_number=%u", p_pb_if->ip_source_item_number);
    offset += sal_sprintf(out + offset, "/unicast_rpf_en=%u", p_pb_if->unicast_rpf_en);
    offset += sal_sprintf(out + offset, "/oper_bandwidth=%u", p_pb_if->oper_bandwidth);
    offset += sal_sprintf(out + offset, "/errdisable_reason=%u", p_pb_if->errdisable_reason);
    offset += sal_sprintf(out + offset, "/fdb_loop_occur=%u", p_pb_if->fdb_loop_occur);
    offset += sal_sprintf(out + offset, "/link_flap_cnt=%u", p_pb_if->link_flap_cnt);
    offset += sal_sprintf(out + offset, "/static_security_num=%u", p_pb_if->static_security_num);
    offset += sal_sprintf(out + offset, "/sflow_flow_en=%u", p_pb_if->sflow_flow_en);
    offset += sal_sprintf(out + offset, "/sflow_flow_ingress=%u", p_pb_if->sflow_flow_ingress);
    offset += sal_sprintf(out + offset, "/sflow_flow_egress=%u", p_pb_if->sflow_flow_egress);
    offset += sal_sprintf(out + offset, "/sflow_counter_en=%u", p_pb_if->sflow_counter_en);
    offset += sal_sprintf(out + offset, "/sflow_rate=%u", p_pb_if->sflow_rate);
    offset += sal_sprintf(out + offset, "/sflow_sequence=%u", p_pb_if->sflow_sequence);
    offset += sal_sprintf(out + offset, "/sflow_sample_pool=%u", p_pb_if->sflow_sample_pool);
    offset += pb_compose_mac_addr_t_dump(p_pb_if->mac_addr, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_if->hw_mac_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/hw_type=%u", p_pb_if->hw_type);
    offset += sal_sprintf(out + offset, "/phy_type=%u", p_pb_if->phy_type);
    offset += sal_sprintf(out + offset, "/media=%u", p_pb_if->media);
    offset += sal_sprintf(out + offset, "/phyport_combo=%u", p_pb_if->phyport_combo);
    offset += sal_sprintf(out + offset, "/phyport_loopback=%u", p_pb_if->phyport_loopback);
    offset += sal_sprintf(out + offset, "/phyport_eee=%u", p_pb_if->phyport_eee);
    offset += sal_sprintf(out + offset, "/phyport_poe=%u", p_pb_if->phyport_poe);
    offset += sal_sprintf(out + offset, "/phyport_master=%u", p_pb_if->phyport_master);
    offset += sal_sprintf(out + offset, "/phyport_slave=%u", p_pb_if->phyport_slave);
    offset += sal_sprintf(out + offset, "/phyport_unidir=%u", p_pb_if->phyport_unidir);
    offset += sal_sprintf(out + offset, "/support_100m=%u", p_pb_if->support_100m);
    offset += sal_sprintf(out + offset, "/support_1g=%u", p_pb_if->support_1g);
    offset += sal_sprintf(out + offset, "/support_10g=%u", p_pb_if->support_10g);
    offset += sal_sprintf(out + offset, "/support_40g=%u", p_pb_if->support_40g);
    offset += sal_sprintf(out + offset, "/support_100g=%u", p_pb_if->support_100g);
    offset += sal_sprintf(out + offset, "/support_2_5g=%u", p_pb_if->support_2_5g);
    offset += sal_sprintf(out + offset, "/support_5g=%u", p_pb_if->support_5g);
    offset += sal_sprintf(out + offset, "/igs_acl=%s", p_pb_if->igs_acl);
    offset += sal_sprintf(out + offset, "/egs_acl=%s", p_pb_if->egs_acl);
    offset += sal_sprintf(out + offset, "/igs_policy_map=%s", p_pb_if->igs_policy_map);
    offset += sal_sprintf(out + offset, "/egs_policy_map=%s", p_pb_if->egs_policy_map);
    offset += sal_sprintf(out + offset, "/crc_error_check_en=%u", p_pb_if->crc_error_check_en);
    offset += sal_sprintf(out + offset, "/mlag_id=%u", p_pb_if->mlag_id);
    offset += sal_sprintf(out + offset, "/erps_enable=%u", p_pb_if->erps_enable);
    offset += sal_sprintf(out + offset, "/erps_pdu_action=%u", p_pb_if->erps_pdu_action);
    offset += sal_sprintf(out + offset, "/dot1x_enable=%u", p_pb_if->dot1x_enable);
    offset += sal_sprintf(out + offset, "/dot1x_unauthorized=%u", p_pb_if->dot1x_unauthorized);
    offset += sal_sprintf(out + offset, "/dot1x_dir_in=%u", p_pb_if->dot1x_dir_in);
    offset += sal_sprintf(out + offset, "/dot1x_dir_out=%u", p_pb_if->dot1x_dir_out);
    offset += sal_sprintf(out + offset, "/dot1x_mode_mac=%u", p_pb_if->dot1x_mode_mac);
    offset += sal_sprintf(out + offset, "/dot1x_guest_vlan=%u", p_pb_if->dot1x_guest_vlan);
    offset += sal_sprintf(out + offset, "/vlanclass_group_id=%u", p_pb_if->vlanclass_group_id);
    offset += sal_sprintf(out + offset, "/vlanclass_active_type=%u", p_pb_if->vlanclass_active_type);
    offset += sal_sprintf(out + offset, "/vlanclass_default_action=%u", p_pb_if->vlanclass_default_action);
    offset += sal_sprintf(out + offset, "/dot1x_cfg_guest_vlan=%u", p_pb_if->dot1x_cfg_guest_vlan);
    offset += sal_sprintf(out + offset, "/egs_acl_en=%u", p_pb_if->egs_acl_en);
    offset += sal_sprintf(out + offset, "/tap_group_igs_ref_cnt=%u", p_pb_if->tap_group_igs_ref_cnt);
    offset += sal_sprintf(out + offset, "/tap_group_egs_ref_cnt=%u", p_pb_if->tap_group_egs_ref_cnt);
    offset += sal_sprintf(out + offset, "/arpinsp_trust_enable=%u", p_pb_if->arpinsp_trust_enable);
    offset += sal_sprintf(out + offset, "/arp_numberlimit_enable=%u", p_pb_if->arp_numberlimit_enable);
    offset += sal_sprintf(out + offset, "/arp_numberlimit_number=%u", p_pb_if->arp_numberlimit_number);
    offset += sal_sprintf(out + offset, "/arp_numberlimit_violate=%u", p_pb_if->arp_numberlimit_violate);
    offset += sal_sprintf(out + offset, "/arp_numberlimit_occur=%u", p_pb_if->arp_numberlimit_occur);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_errdisable_occur=%u", p_pb_if->arp_rate_limit_errdisable_occur);
    offset += sal_sprintf(out + offset, "/inband_snat_type=%u", p_pb_if->inband_snat_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ROUTE_IF */
int32
pb_tbl_route_if_to_pb(uint32 only_key, tbl_route_if_t *p_rtif, Cdb__TblRouteIf *p_pb_rtif)
{
    p_pb_rtif->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif->key.name)+1);
    sal_strcpy(p_pb_rtif->key->name, p_rtif->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rtif->has_mtu = TRUE;
    p_pb_rtif->mtu = p_rtif->mtu;
    pb_compose_mac_addr_t_to_pb(p_rtif->mac, p_pb_rtif->mac);
    p_pb_rtif->has_ipv4_enable = TRUE;
    p_pb_rtif->ipv4_enable = p_rtif->ipv4_enable;
    p_pb_rtif->has_ipv6_enable = TRUE;
    p_pb_rtif->ipv6_enable = p_rtif->ipv6_enable;
    p_pb_rtif->has_arp_retrans_time = TRUE;
    p_pb_rtif->arp_retrans_time = p_rtif->arp_retrans_time;
    p_pb_rtif->has_arp_timeout = TRUE;
    p_pb_rtif->arp_timeout = p_rtif->arp_timeout;
    p_pb_rtif->has_ifindex = TRUE;
    p_pb_rtif->ifindex = p_rtif->ifindex;
    p_pb_rtif->has_kernel_ifindex = TRUE;
    p_pb_rtif->kernel_ifindex = p_rtif->kernel_ifindex;
    p_pb_rtif->has_arp_retry_timeout = TRUE;
    p_pb_rtif->arp_retry_timeout = p_rtif->arp_retry_timeout;
    p_pb_rtif->has_ospf_cost = TRUE;
    p_pb_rtif->ospf_cost = p_rtif->ospf_cost;
    p_pb_rtif->has_ospf_mtu_ignore = TRUE;
    p_pb_rtif->ospf_mtu_ignore = p_rtif->ospf_mtu_ignore;
    p_pb_rtif->has_ospf_timer_hello = TRUE;
    p_pb_rtif->ospf_timer_hello = p_rtif->ospf_timer_hello;
    p_pb_rtif->has_ospf_timer_dead = TRUE;
    p_pb_rtif->ospf_timer_dead = p_rtif->ospf_timer_dead;
    p_pb_rtif->has_ospf_auth_type = TRUE;
    p_pb_rtif->ospf_auth_type = p_rtif->ospf_auth_type;
    p_pb_rtif->ospf_auth_key = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif->ospf_auth_key)+1);
    sal_strcpy(p_pb_rtif->ospf_auth_key, p_rtif->ospf_auth_key);
    p_pb_rtif->has_arp_proxy_en = TRUE;
    p_pb_rtif->arp_proxy_en = p_rtif->arp_proxy_en;
    p_pb_rtif->has_local_arp_proxy_en = TRUE;
    p_pb_rtif->local_arp_proxy_en = p_rtif->local_arp_proxy_en;
    p_pb_rtif->has_unicast_rpf_en = TRUE;
    p_pb_rtif->unicast_rpf_en = p_rtif->unicast_rpf_en;
    p_pb_rtif->has_ip_unreachable_en = TRUE;
    p_pb_rtif->ip_unreachable_en = p_rtif->ip_unreachable_en;
    p_pb_rtif->has_ip_redirects_en = TRUE;
    p_pb_rtif->ip_redirects_en = p_rtif->ip_redirects_en;
    p_pb_rtif->has_dhcp_relay_option_trust = TRUE;
    p_pb_rtif->dhcp_relay_option_trust = p_rtif->dhcp_relay_option_trust;
    p_pb_rtif->has_dhcp_server_group = TRUE;
    p_pb_rtif->dhcp_server_group = p_rtif->dhcp_server_group;
    p_pb_rtif->has_dhcp_pdu_enabled = TRUE;
    p_pb_rtif->dhcp_pdu_enabled = p_rtif->dhcp_pdu_enabled;
    p_pb_rtif->has_dhcp_client_enable = TRUE;
    p_pb_rtif->dhcp_client_enable = p_rtif->dhcp_client_enable;
    p_pb_rtif->dhcp_client_ipv4 = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif->dhcp_client_ipv4)+1);
    sal_strcpy(p_pb_rtif->dhcp_client_ipv4, p_rtif->dhcp_client_ipv4);
    p_pb_rtif->dhcp_client_ipv4_mask = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif->dhcp_client_ipv4_mask)+1);
    sal_strcpy(p_pb_rtif->dhcp_client_ipv4_mask, p_rtif->dhcp_client_ipv4_mask);
    p_pb_rtif->has_arp_curr_dynamic = TRUE;
    p_pb_rtif->arp_curr_dynamic = p_rtif->arp_curr_dynamic;
    p_pb_rtif->has_arp_attack_number = TRUE;
    p_pb_rtif->arp_attack_number = p_rtif->arp_attack_number;
    p_pb_rtif->has_arp_rate_limit_en = TRUE;
    p_pb_rtif->arp_rate_limit_en = p_rtif->arp_rate_limit_en;
    p_pb_rtif->has_arp_rate_limit_pkt_max = TRUE;
    p_pb_rtif->arp_rate_limit_pkt_max = p_rtif->arp_rate_limit_pkt_max;
    p_pb_rtif->has_arp_rate_limit_violation = TRUE;
    p_pb_rtif->arp_rate_limit_violation = p_rtif->arp_rate_limit_violation;
    p_pb_rtif->has_arp_rate_limit_pkt_curr = TRUE;
    p_pb_rtif->arp_rate_limit_pkt_curr = p_rtif->arp_rate_limit_pkt_curr;
    p_pb_rtif->has_arp_rate_limit_port_abnormal_flag = TRUE;
    p_pb_rtif->arp_rate_limit_port_abnormal_flag = p_rtif->arp_rate_limit_port_abnormal_flag;

    return PM_E_NONE;
}

int32
pb_tbl_route_if_to_pb_free_packed(Cdb__TblRouteIf *p_pb_rtif)
{
    if (p_pb_rtif->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rtif->key->name);
        p_pb_rtif->key->name = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_rtif->mac);
    if (p_pb_rtif->ospf_auth_key)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rtif->ospf_auth_key);
        p_pb_rtif->ospf_auth_key = NULL;
    }

    if (p_pb_rtif->dhcp_client_ipv4)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rtif->dhcp_client_ipv4);
        p_pb_rtif->dhcp_client_ipv4 = NULL;
    }

    if (p_pb_rtif->dhcp_client_ipv4_mask)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rtif->dhcp_client_ipv4_mask);
        p_pb_rtif->dhcp_client_ipv4_mask = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_route_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRouteIfKey pb_rtif_key = CDB__TBL_ROUTE_IF_KEY__INIT;
    Cdb__TblRouteIf pb_rtif = CDB__TBL_ROUTE_IF__INIT;
    tbl_route_if_t *p_rtif = (tbl_route_if_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_rtif.key = &pb_rtif_key;
    pb_rtif.mac = &mac;
    pb_tbl_route_if_to_pb(only_key, p_rtif, &pb_rtif);
    len = cdb__tbl_route_if__pack(&pb_rtif, buf);
    pb_tbl_route_if_to_pb_free_packed(&pb_rtif);

    return len;
}

int32
pb_tbl_route_if_dump(Cdb__TblRouteIf *p_pb_rtif, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_rtif->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/mtu=%u", p_pb_rtif->mtu);
    offset += pb_compose_mac_addr_t_dump(p_pb_rtif->mac, (out + offset));
    offset += sal_sprintf(out + offset, "/ipv4_enable=%u", p_pb_rtif->ipv4_enable);
    offset += sal_sprintf(out + offset, "/ipv6_enable=%u", p_pb_rtif->ipv6_enable);
    offset += sal_sprintf(out + offset, "/arp_retrans_time=%u", p_pb_rtif->arp_retrans_time);
    offset += sal_sprintf(out + offset, "/arp_timeout=%u", p_pb_rtif->arp_timeout);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_rtif->ifindex);
    offset += sal_sprintf(out + offset, "/kernel_ifindex=%u", p_pb_rtif->kernel_ifindex);
    offset += sal_sprintf(out + offset, "/arp_retry_timeout=%u", p_pb_rtif->arp_retry_timeout);
    offset += sal_sprintf(out + offset, "/ospf_cost=%u", p_pb_rtif->ospf_cost);
    offset += sal_sprintf(out + offset, "/ospf_mtu_ignore=%u", p_pb_rtif->ospf_mtu_ignore);
    offset += sal_sprintf(out + offset, "/ospf_timer_hello=%u", p_pb_rtif->ospf_timer_hello);
    offset += sal_sprintf(out + offset, "/ospf_timer_dead=%u", p_pb_rtif->ospf_timer_dead);
    offset += sal_sprintf(out + offset, "/ospf_auth_type=%u", p_pb_rtif->ospf_auth_type);
    offset += sal_sprintf(out + offset, "/ospf_auth_key=%s", p_pb_rtif->ospf_auth_key);
    offset += sal_sprintf(out + offset, "/arp_proxy_en=%u", p_pb_rtif->arp_proxy_en);
    offset += sal_sprintf(out + offset, "/local_arp_proxy_en=%u", p_pb_rtif->local_arp_proxy_en);
    offset += sal_sprintf(out + offset, "/unicast_rpf_en=%u", p_pb_rtif->unicast_rpf_en);
    offset += sal_sprintf(out + offset, "/ip_unreachable_en=%u", p_pb_rtif->ip_unreachable_en);
    offset += sal_sprintf(out + offset, "/ip_redirects_en=%u", p_pb_rtif->ip_redirects_en);
    offset += sal_sprintf(out + offset, "/dhcp_relay_option_trust=%u", p_pb_rtif->dhcp_relay_option_trust);
    offset += sal_sprintf(out + offset, "/dhcp_server_group=%u", p_pb_rtif->dhcp_server_group);
    offset += sal_sprintf(out + offset, "/dhcp_pdu_enabled=%u", p_pb_rtif->dhcp_pdu_enabled);
    offset += sal_sprintf(out + offset, "/dhcp_client_enable=%u", p_pb_rtif->dhcp_client_enable);
    offset += sal_sprintf(out + offset, "/dhcp_client_ipv4=%s", p_pb_rtif->dhcp_client_ipv4);
    offset += sal_sprintf(out + offset, "/dhcp_client_ipv4_mask=%s", p_pb_rtif->dhcp_client_ipv4_mask);
    offset += sal_sprintf(out + offset, "/arp_curr_dynamic=%u", p_pb_rtif->arp_curr_dynamic);
    offset += sal_sprintf(out + offset, "/arp_attack_number=%llu", p_pb_rtif->arp_attack_number);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_en=%u", p_pb_rtif->arp_rate_limit_en);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_pkt_max=%u", p_pb_rtif->arp_rate_limit_pkt_max);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_violation=%u", p_pb_rtif->arp_rate_limit_violation);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_pkt_curr=%u", p_pb_rtif->arp_rate_limit_pkt_curr);
    offset += sal_sprintf(out + offset, "/arp_rate_limit_port_abnormal_flag=%u", p_pb_rtif->arp_rate_limit_port_abnormal_flag);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_KERNEL_IF */
int32
pb_tbl_kernel_if_to_pb(uint32 only_key, tbl_kernel_if_t *p_kernel_if, Cdb__TblKernelIf *p_pb_kernel_if)
{
    p_pb_kernel_if->key->ifindex = p_kernel_if->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_kernel_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_kernel_if->name)+1);
    sal_strcpy(p_pb_kernel_if->name, p_kernel_if->name);
    pb_compose_addr_ipv4_t_to_pb(&p_kernel_if->ip_addr, p_pb_kernel_if->ip_addr);
    p_pb_kernel_if->has_masklen = TRUE;
    p_pb_kernel_if->masklen = p_kernel_if->masklen;
    p_pb_kernel_if->has_vrf_id = TRUE;
    p_pb_kernel_if->vrf_id = p_kernel_if->vrf_id;

    return PM_E_NONE;
}

int32
pb_tbl_kernel_if_to_pb_free_packed(Cdb__TblKernelIf *p_pb_kernel_if)
{
    if (p_pb_kernel_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_kernel_if->name);
        p_pb_kernel_if->name = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_kernel_if->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_kernel_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblKernelIfKey pb_kernel_if_key = CDB__TBL_KERNEL_IF_KEY__INIT;
    Cdb__TblKernelIf pb_kernel_if = CDB__TBL_KERNEL_IF__INIT;
    tbl_kernel_if_t *p_kernel_if = (tbl_kernel_if_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T ip_addr = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_kernel_if.key = &pb_kernel_if_key;
    pb_kernel_if.ip_addr = &ip_addr;
    pb_tbl_kernel_if_to_pb(only_key, p_kernel_if, &pb_kernel_if);
    len = cdb__tbl_kernel_if__pack(&pb_kernel_if, buf);
    pb_tbl_kernel_if_to_pb_free_packed(&pb_kernel_if);

    return len;
}

int32
pb_tbl_kernel_if_dump(Cdb__TblKernelIf *p_pb_kernel_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_kernel_if->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_kernel_if->name);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_kernel_if->ip_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/masklen=%u", p_pb_kernel_if->masklen);
    offset += sal_sprintf(out + offset, "/vrf_id=%u", p_pb_kernel_if->vrf_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_PORT_IF */
int32
pb_tbl_fea_port_if_to_pb(uint32 only_key, tbl_fea_port_if_t *p_portif, Cdb__TblFeaPortIf *p_pb_portif)
{
    p_pb_portif->key->portid = p_portif->key.portid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_portif->has_ifindex = TRUE;
    p_pb_portif->ifindex = p_portif->ifindex;
    p_pb_portif->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_portif->name)+1);
    sal_strcpy(p_pb_portif->name, p_portif->name);
    p_pb_portif->has_lag_member = TRUE;
    p_pb_portif->lag_member = p_portif->lag_member;

    return PM_E_NONE;
}

int32
pb_tbl_fea_port_if_to_pb_free_packed(Cdb__TblFeaPortIf *p_pb_portif)
{
    if (p_pb_portif->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_portif->name);
        p_pb_portif->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fea_port_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaPortIfKey pb_portif_key = CDB__TBL_FEA_PORT_IF_KEY__INIT;
    Cdb__TblFeaPortIf pb_portif = CDB__TBL_FEA_PORT_IF__INIT;
    tbl_fea_port_if_t *p_portif = (tbl_fea_port_if_t*)p_tbl;
    int32 len = 0;

    pb_portif.key = &pb_portif_key;
    pb_tbl_fea_port_if_to_pb(only_key, p_portif, &pb_portif);
    len = cdb__tbl_fea_port_if__pack(&pb_portif, buf);
    pb_tbl_fea_port_if_to_pb_free_packed(&pb_portif);

    return len;
}

int32
pb_tbl_fea_port_if_dump(Cdb__TblFeaPortIf *p_pb_portif, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->portid=%llu", p_pb_portif->key->portid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_portif->ifindex);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_portif->name);
    offset += sal_sprintf(out + offset, "/lag_member=%llu", p_pb_portif->lag_member);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_VLAN */
int32
pb_tbl_vlan_to_pb(uint32 only_key, tbl_vlan_t *p_vlan, Cdb__TblVlan *p_pb_vlan)
{
    p_pb_vlan->key->vid = p_vlan->key.vid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_vlan->has_max_mac_count = TRUE;
    p_pb_vlan->max_mac_count = p_vlan->max_mac_count;
    p_pb_vlan->has_cur_mac_count = TRUE;
    p_pb_vlan->cur_mac_count = p_vlan->cur_mac_count;
    p_pb_vlan->has_instance = TRUE;
    p_pb_vlan->instance = p_vlan->instance;
    p_pb_vlan->has_dhcsnooping = TRUE;
    p_pb_vlan->dhcsnooping = p_vlan->dhcsnooping;
    p_pb_vlan->has_arpsnooping = TRUE;
    p_pb_vlan->arpsnooping = p_vlan->arpsnooping;
    p_pb_vlan->has_security_action = TRUE;
    p_pb_vlan->security_action = p_vlan->security_action;
    p_pb_vlan->has_enable = TRUE;
    p_pb_vlan->enable = p_vlan->enable;
    p_pb_vlan->has_mac_learning_en = TRUE;
    p_pb_vlan->mac_learning_en = p_vlan->mac_learning_en;
    p_pb_vlan->has_op_ifindex = TRUE;
    p_pb_vlan->op_ifindex = p_vlan->op_ifindex;
    p_pb_vlan->has_member_port = TRUE;
    p_pb_vlan->member_port.len = sizeof(p_vlan->member_port);
    p_pb_vlan->member_port.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_vlan->member_port));
    sal_memcpy(p_pb_vlan->member_port.data, p_vlan->member_port, sizeof(p_vlan->member_port));
    p_pb_vlan->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vlan->name)+1);
    sal_strcpy(p_pb_vlan->name, p_vlan->name);
    p_pb_vlan->has_erps_domain_id = TRUE;
    p_pb_vlan->erps_domain_id = p_vlan->erps_domain_id;
    p_pb_vlan->has_dot1x_guest_vlan_num = TRUE;
    p_pb_vlan->dot1x_guest_vlan_num = p_vlan->dot1x_guest_vlan_num;

    return PM_E_NONE;
}

int32
pb_tbl_vlan_to_pb_free_packed(Cdb__TblVlan *p_pb_vlan)
{
    if (p_pb_vlan->member_port.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vlan->member_port.data);
        p_pb_vlan->member_port.data = NULL;
    }

    if (p_pb_vlan->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vlan->name);
        p_pb_vlan->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_vlan_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblVlanKey pb_vlan_key = CDB__TBL_VLAN_KEY__INIT;
    Cdb__TblVlan pb_vlan = CDB__TBL_VLAN__INIT;
    tbl_vlan_t *p_vlan = (tbl_vlan_t*)p_tbl;
    int32 len = 0;

    pb_vlan.key = &pb_vlan_key;
    pb_tbl_vlan_to_pb(only_key, p_vlan, &pb_vlan);
    len = cdb__tbl_vlan__pack(&pb_vlan, buf);
    pb_tbl_vlan_to_pb_free_packed(&pb_vlan);

    return len;
}

int32
pb_tbl_vlan_dump(Cdb__TblVlan *p_pb_vlan, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->vid=%u", p_pb_vlan->key->vid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/max_mac_count=%u", p_pb_vlan->max_mac_count);
    offset += sal_sprintf(out + offset, "/cur_mac_count=%u", p_pb_vlan->cur_mac_count);
    offset += sal_sprintf(out + offset, "/instance=%u", p_pb_vlan->instance);
    offset += sal_sprintf(out + offset, "/dhcsnooping=%u", p_pb_vlan->dhcsnooping);
    offset += sal_sprintf(out + offset, "/arpsnooping=%u", p_pb_vlan->arpsnooping);
    offset += sal_sprintf(out + offset, "/security_action=%u", p_pb_vlan->security_action);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_vlan->enable);
    offset += sal_sprintf(out + offset, "/mac_learning_en=%u", p_pb_vlan->mac_learning_en);
    offset += sal_sprintf(out + offset, "/op_ifindex=%llu", p_pb_vlan->op_ifindex);
    offset += sal_sprintf(out + offset, "/member_port=");
    offset += pb_bitmap_array_dump(p_pb_vlan->member_port.data, p_pb_vlan->member_port.len, (out + offset));
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_vlan->name);
    offset += sal_sprintf(out + offset, "/erps_domain_id=%u", p_pb_vlan->erps_domain_id);
    offset += sal_sprintf(out + offset, "/dot1x_guest_vlan_num=%u", p_pb_vlan->dot1x_guest_vlan_num);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PVLAN */
int32
pb_tbl_pvlan_to_pb(uint32 only_key, tbl_pvlan_t *p_pvlan, Cdb__TblPvlan *p_pb_pvlan)
{
    p_pb_pvlan->key->primary_vid = p_pvlan->key.primary_vid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_pvlan->has_community_group_id = TRUE;
    p_pb_pvlan->community_group_id.len = sizeof(p_pvlan->community_group_id);
    p_pb_pvlan->community_group_id.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_pvlan->community_group_id));
    sal_memcpy(p_pb_pvlan->community_group_id.data, p_pvlan->community_group_id, sizeof(p_pvlan->community_group_id));

    return PM_E_NONE;
}

int32
pb_tbl_pvlan_to_pb_free_packed(Cdb__TblPvlan *p_pb_pvlan)
{
    if (p_pb_pvlan->community_group_id.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pvlan->community_group_id.data);
        p_pb_pvlan->community_group_id.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_pvlan_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPvlanKey pb_pvlan_key = CDB__TBL_PVLAN_KEY__INIT;
    Cdb__TblPvlan pb_pvlan = CDB__TBL_PVLAN__INIT;
    tbl_pvlan_t *p_pvlan = (tbl_pvlan_t*)p_tbl;
    int32 len = 0;

    pb_pvlan.key = &pb_pvlan_key;
    pb_tbl_pvlan_to_pb(only_key, p_pvlan, &pb_pvlan);
    len = cdb__tbl_pvlan__pack(&pb_pvlan, buf);
    pb_tbl_pvlan_to_pb_free_packed(&pb_pvlan);

    return len;
}

int32
pb_tbl_pvlan_dump(Cdb__TblPvlan *p_pb_pvlan, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->primary_vid=%u", p_pb_pvlan->key->primary_vid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/community_group_id=");
    offset += pb_bitmap_array_dump(p_pb_pvlan->community_group_id.data, p_pb_pvlan->community_group_id.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FDB */
int32
pb_tbl_fdb_to_pb(uint32 only_key, tbl_fdb_t *p_fdb, Cdb__TblFdb *p_pb_fdb)
{
    pb_compose_fdb_key_t_to_pb(&p_fdb->key, p_pb_fdb->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fdb->has_ifindex = TRUE;
    p_pb_fdb->ifindex = p_fdb->ifindex;
    p_pb_fdb->has_static_ = TRUE;
    p_pb_fdb->static_ = GLB_FLAG_ISSET(p_fdb->flags, GLB_FDB_FLAG_STATIC) ? TRUE : FALSE;
    p_pb_fdb->has_security = TRUE;
    p_pb_fdb->security = GLB_FLAG_ISSET(p_fdb->flags, GLB_FDB_FLAG_MAC_SECURITY_EN) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_fdb_to_pb_free_packed(Cdb__TblFdb *p_pb_fdb)
{
    pb_compose_fdb_key_t_to_pb_free_packed(p_pb_fdb->key);
    return PM_E_NONE;
}

int32
pb_tbl_fdb_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFdbKey pb_fdb_key = CDB__TBL_FDB_KEY__INIT;
    Cdb__TblFdb pb_fdb = CDB__TBL_FDB__INIT;
    tbl_fdb_t *p_fdb = (tbl_fdb_t*)p_tbl;
    int32 len = 0;

    pb_fdb.key = &pb_fdb_key;
    pb_tbl_fdb_to_pb(only_key, p_fdb, &pb_fdb);
    len = cdb__tbl_fdb__pack(&pb_fdb, buf);
    pb_tbl_fdb_to_pb_free_packed(&pb_fdb);

    return len;
}

int32
pb_tbl_fdb_dump(Cdb__TblFdb *p_pb_fdb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_fdb_key_t_dump(p_pb_fdb->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_fdb->ifindex);
    offset += sal_sprintf(out + offset, "/static_=%u", p_pb_fdb->static_);
    offset += sal_sprintf(out + offset, "/security=%u", p_pb_fdb->security);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MCFDB */
int32
pb_tbl_mcfdb_to_pb(uint32 only_key, tbl_mcfdb_t *p_mcfdb, Cdb__TblMcfdb *p_pb_mcfdb)
{
    pb_compose_fdb_key_t_to_pb(&p_mcfdb->key, p_pb_mcfdb->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_mcfdb->has_l2mc_port = TRUE;
    p_pb_mcfdb->l2mc_port.len = sizeof(p_mcfdb->l2mc_port);
    p_pb_mcfdb->l2mc_port.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mcfdb->l2mc_port));
    sal_memcpy(p_pb_mcfdb->l2mc_port.data, p_mcfdb->l2mc_port, sizeof(p_mcfdb->l2mc_port));
    p_pb_mcfdb->has_action_ifindex = TRUE;
    p_pb_mcfdb->action_ifindex = p_mcfdb->action_ifindex;
    p_pb_mcfdb->has_manual = TRUE;
    p_pb_mcfdb->manual = p_mcfdb->manual;

    return PM_E_NONE;
}

int32
pb_tbl_mcfdb_to_pb_free_packed(Cdb__TblMcfdb *p_pb_mcfdb)
{
    pb_compose_fdb_key_t_to_pb_free_packed(p_pb_mcfdb->key);
    if (p_pb_mcfdb->l2mc_port.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mcfdb->l2mc_port.data);
        p_pb_mcfdb->l2mc_port.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_mcfdb_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMcfdbKey pb_mcfdb_key = CDB__TBL_MCFDB_KEY__INIT;
    Cdb__TblMcfdb pb_mcfdb = CDB__TBL_MCFDB__INIT;
    tbl_mcfdb_t *p_mcfdb = (tbl_mcfdb_t*)p_tbl;
    int32 len = 0;

    pb_mcfdb.key = &pb_mcfdb_key;
    pb_tbl_mcfdb_to_pb(only_key, p_mcfdb, &pb_mcfdb);
    len = cdb__tbl_mcfdb__pack(&pb_mcfdb, buf);
    pb_tbl_mcfdb_to_pb_free_packed(&pb_mcfdb);

    return len;
}

int32
pb_tbl_mcfdb_dump(Cdb__TblMcfdb *p_pb_mcfdb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_fdb_key_t_dump(p_pb_mcfdb->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/l2mc_port=");
    offset += pb_bitmap_array_dump(p_pb_mcfdb->l2mc_port.data, p_pb_mcfdb->l2mc_port.len, (out + offset));
    offset += sal_sprintf(out + offset, "/action_ifindex=%u", p_pb_mcfdb->action_ifindex);
    offset += sal_sprintf(out + offset, "/manual=%u", p_pb_mcfdb->manual);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MACFILTER */
int32
pb_tbl_macfilter_to_pb(uint32 only_key, tbl_macfilter_t *p_macflt, Cdb__TblMacfilter *p_pb_macflt)
{
    pb_compose_mac_addr_t_to_pb(p_macflt->key.mac, p_pb_macflt->key->mac);

    if (only_key)
    {
        return PM_E_NONE;
    }


    return PM_E_NONE;
}

int32
pb_tbl_macfilter_to_pb_free_packed(Cdb__TblMacfilter *p_pb_macflt)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_macflt->key->mac);
    return PM_E_NONE;
}

int32
pb_tbl_macfilter_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__TblMacfilterKey pb_macflt_key = CDB__TBL_MACFILTER_KEY__INIT;
    Cdb__TblMacfilter pb_macflt = CDB__TBL_MACFILTER__INIT;
    tbl_macfilter_t *p_macflt = (tbl_macfilter_t*)p_tbl;
    int32 len = 0;

    pb_macflt_key.mac = &mac;
    pb_macflt.key = &pb_macflt_key;
    pb_tbl_macfilter_to_pb(only_key, p_macflt, &pb_macflt);
    len = cdb__tbl_macfilter__pack(&pb_macflt, buf);
    pb_tbl_macfilter_to_pb_free_packed(&pb_macflt);

    return len;
}

int32
pb_tbl_macfilter_dump(Cdb__TblMacfilter *p_pb_macflt, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_mac_addr_t_dump(p_pb_macflt->key->mac, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PSFDB */
int32
pb_tbl_psfdb_to_pb(uint32 only_key, tbl_psfdb_t *p_psfdb, Cdb__TblPsfdb *p_pb_psfdb)
{
    pb_compose_fdb_key_t_to_pb(&p_psfdb->key, p_pb_psfdb->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_psfdb->has_ifindex = TRUE;
    p_pb_psfdb->ifindex = p_psfdb->ifindex;
    p_pb_psfdb->has_port_security = TRUE;
    p_pb_psfdb->port_security = GLB_FLAG_ISSET(p_psfdb->flags, GLB_FDB_FLAG_MAC_SECURITY_EN) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_psfdb_to_pb_free_packed(Cdb__TblPsfdb *p_pb_psfdb)
{
    pb_compose_fdb_key_t_to_pb_free_packed(p_pb_psfdb->key);
    return PM_E_NONE;
}

int32
pb_tbl_psfdb_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPsfdbKey pb_psfdb_key = CDB__TBL_PSFDB_KEY__INIT;
    Cdb__TblPsfdb pb_psfdb = CDB__TBL_PSFDB__INIT;
    tbl_psfdb_t *p_psfdb = (tbl_psfdb_t*)p_tbl;
    int32 len = 0;

    pb_psfdb.key = &pb_psfdb_key;
    pb_tbl_psfdb_to_pb(only_key, p_psfdb, &pb_psfdb);
    len = cdb__tbl_psfdb__pack(&pb_psfdb, buf);
    pb_tbl_psfdb_to_pb_free_packed(&pb_psfdb);

    return len;
}

int32
pb_tbl_psfdb_dump(Cdb__TblPsfdb *p_pb_psfdb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_fdb_key_t_dump(p_pb_psfdb->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_psfdb->ifindex);
    offset += sal_sprintf(out + offset, "/port_security=%u", p_pb_psfdb->port_security);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IPSG_S_IP */
int32
pb_tbl_ipsg_s_ip_to_pb(uint32 only_key, tbl_ipsg_s_ip_t *p_ipsg_s_ip, Cdb__TblIpsgSIp *p_pb_ipsg_s_ip)
{
    pb_compose_prefix_t_to_pb(&p_ipsg_s_ip->key.ip, p_pb_ipsg_s_ip->key->ip);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ipsg_s_ip->has_vid = TRUE;
    p_pb_ipsg_s_ip->vid = p_ipsg_s_ip->vid;
    p_pb_ipsg_s_ip->has_ifindex = TRUE;
    p_pb_ipsg_s_ip->ifindex = p_ipsg_s_ip->ifindex;
    p_pb_ipsg_s_ip->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ipsg_s_ip->ifname)+1);
    sal_strcpy(p_pb_ipsg_s_ip->ifname, p_ipsg_s_ip->ifname);
    pb_compose_mac_addr_t_to_pb(p_ipsg_s_ip->mac_addr, p_pb_ipsg_s_ip->mac_addr);
    pb_compose_prefix_t_to_pb(&p_ipsg_s_ip->ip_addr, p_pb_ipsg_s_ip->ip_addr);

    return PM_E_NONE;
}

int32
pb_tbl_ipsg_s_ip_to_pb_free_packed(Cdb__TblIpsgSIp *p_pb_ipsg_s_ip)
{
    pb_compose_prefix_t_to_pb_free_packed(p_pb_ipsg_s_ip->key->ip);
    if (p_pb_ipsg_s_ip->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ipsg_s_ip->ifname);
        p_pb_ipsg_s_ip->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ipsg_s_ip->mac_addr);
    pb_compose_prefix_t_to_pb_free_packed(p_pb_ipsg_s_ip->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_ipsg_s_ip_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposePrefixT ip = CDB__COMPOSE_PREFIX_T__INIT;
    Cdb__TblIpsgSIpKey pb_ipsg_s_ip_key = CDB__TBL_IPSG_S_IP_KEY__INIT;
    Cdb__TblIpsgSIp pb_ipsg_s_ip = CDB__TBL_IPSG_S_IP__INIT;
    tbl_ipsg_s_ip_t *p_ipsg_s_ip = (tbl_ipsg_s_ip_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposePrefixT ip_addr = CDB__COMPOSE_PREFIX_T__INIT;

    pb_ipsg_s_ip_key.ip = &ip;
    pb_ipsg_s_ip.key = &pb_ipsg_s_ip_key;
    pb_ipsg_s_ip.mac_addr = &mac_addr;
    pb_ipsg_s_ip.ip_addr = &ip_addr;
    pb_tbl_ipsg_s_ip_to_pb(only_key, p_ipsg_s_ip, &pb_ipsg_s_ip);
    len = cdb__tbl_ipsg_s_ip__pack(&pb_ipsg_s_ip, buf);
    pb_tbl_ipsg_s_ip_to_pb_free_packed(&pb_ipsg_s_ip);

    return len;
}

int32
pb_tbl_ipsg_s_ip_dump(Cdb__TblIpsgSIp *p_pb_ipsg_s_ip, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_prefix_t_dump(p_pb_ipsg_s_ip->key->ip, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_ipsg_s_ip->vid);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_ipsg_s_ip->ifindex);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_ipsg_s_ip->ifname);
    offset += pb_compose_mac_addr_t_dump(p_pb_ipsg_s_ip->mac_addr, (out + offset));
    offset += pb_compose_prefix_t_dump(p_pb_ipsg_s_ip->ip_addr, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IPSG_S_MAC */
int32
pb_tbl_ipsg_s_mac_to_pb(uint32 only_key, tbl_ipsg_s_mac_t *p_ipsg_s_mac, Cdb__TblIpsgSMac *p_pb_ipsg_s_mac)
{
    pb_compose_mac_addr_t_to_pb(p_ipsg_s_mac->key.mac, p_pb_ipsg_s_mac->key->mac);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ipsg_s_mac->has_vid = TRUE;
    p_pb_ipsg_s_mac->vid = p_ipsg_s_mac->vid;
    p_pb_ipsg_s_mac->has_ifindex = TRUE;
    p_pb_ipsg_s_mac->ifindex = p_ipsg_s_mac->ifindex;
    p_pb_ipsg_s_mac->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ipsg_s_mac->ifname)+1);
    sal_strcpy(p_pb_ipsg_s_mac->ifname, p_ipsg_s_mac->ifname);
    pb_compose_mac_addr_t_to_pb(p_ipsg_s_mac->mac_addr, p_pb_ipsg_s_mac->mac_addr);
    pb_compose_prefix_t_to_pb(&p_ipsg_s_mac->ip_addr, p_pb_ipsg_s_mac->ip_addr);

    return PM_E_NONE;
}

int32
pb_tbl_ipsg_s_mac_to_pb_free_packed(Cdb__TblIpsgSMac *p_pb_ipsg_s_mac)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ipsg_s_mac->key->mac);
    if (p_pb_ipsg_s_mac->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ipsg_s_mac->ifname);
        p_pb_ipsg_s_mac->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ipsg_s_mac->mac_addr);
    pb_compose_prefix_t_to_pb_free_packed(p_pb_ipsg_s_mac->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_ipsg_s_mac_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__TblIpsgSMacKey pb_ipsg_s_mac_key = CDB__TBL_IPSG_S_MAC_KEY__INIT;
    Cdb__TblIpsgSMac pb_ipsg_s_mac = CDB__TBL_IPSG_S_MAC__INIT;
    tbl_ipsg_s_mac_t *p_ipsg_s_mac = (tbl_ipsg_s_mac_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposePrefixT ip_addr = CDB__COMPOSE_PREFIX_T__INIT;

    pb_ipsg_s_mac_key.mac = &mac;
    pb_ipsg_s_mac.key = &pb_ipsg_s_mac_key;
    pb_ipsg_s_mac.mac_addr = &mac_addr;
    pb_ipsg_s_mac.ip_addr = &ip_addr;
    pb_tbl_ipsg_s_mac_to_pb(only_key, p_ipsg_s_mac, &pb_ipsg_s_mac);
    len = cdb__tbl_ipsg_s_mac__pack(&pb_ipsg_s_mac, buf);
    pb_tbl_ipsg_s_mac_to_pb_free_packed(&pb_ipsg_s_mac);

    return len;
}

int32
pb_tbl_ipsg_s_mac_dump(Cdb__TblIpsgSMac *p_pb_ipsg_s_mac, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_mac_addr_t_dump(p_pb_ipsg_s_mac->key->mac, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_ipsg_s_mac->vid);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_ipsg_s_mac->ifindex);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_ipsg_s_mac->ifname);
    offset += pb_compose_mac_addr_t_dump(p_pb_ipsg_s_mac->mac_addr, (out + offset));
    offset += pb_compose_prefix_t_dump(p_pb_ipsg_s_mac->ip_addr, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IPSG_FIB */
int32
pb_tbl_ipsg_fib_to_pb(uint32 only_key, tbl_ipsg_fib_t *p_ipsg_fib, Cdb__TblIpsgFib *p_pb_ipsg_fib)
{
    pb_compose_fdb_key_t_to_pb(&p_ipsg_fib->key, p_pb_ipsg_fib->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ipsg_fib->has_vid = TRUE;
    p_pb_ipsg_fib->vid = p_ipsg_fib->vid;
    p_pb_ipsg_fib->has_ifindex = TRUE;
    p_pb_ipsg_fib->ifindex = p_ipsg_fib->ifindex;
    p_pb_ipsg_fib->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ipsg_fib->ifname)+1);
    sal_strcpy(p_pb_ipsg_fib->ifname, p_ipsg_fib->ifname);
    pb_compose_mac_addr_t_to_pb(p_ipsg_fib->mac_addr, p_pb_ipsg_fib->mac_addr);
    pb_compose_prefix_t_to_pb(&p_ipsg_fib->ip_addr, p_pb_ipsg_fib->ip_addr);
    p_pb_ipsg_fib->has_ipsg_type = TRUE;
    p_pb_ipsg_fib->ipsg_type = p_ipsg_fib->ipsg_type;

    return PM_E_NONE;
}

int32
pb_tbl_ipsg_fib_to_pb_free_packed(Cdb__TblIpsgFib *p_pb_ipsg_fib)
{
    pb_compose_fdb_key_t_to_pb_free_packed(p_pb_ipsg_fib->key);
    if (p_pb_ipsg_fib->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ipsg_fib->ifname);
        p_pb_ipsg_fib->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ipsg_fib->mac_addr);
    pb_compose_prefix_t_to_pb_free_packed(p_pb_ipsg_fib->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_ipsg_fib_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIpsgFibKey pb_ipsg_fib_key = CDB__TBL_IPSG_FIB_KEY__INIT;
    Cdb__TblIpsgFib pb_ipsg_fib = CDB__TBL_IPSG_FIB__INIT;
    tbl_ipsg_fib_t *p_ipsg_fib = (tbl_ipsg_fib_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposePrefixT ip_addr = CDB__COMPOSE_PREFIX_T__INIT;

    pb_ipsg_fib.key = &pb_ipsg_fib_key;
    pb_ipsg_fib.mac_addr = &mac_addr;
    pb_ipsg_fib.ip_addr = &ip_addr;
    pb_tbl_ipsg_fib_to_pb(only_key, p_ipsg_fib, &pb_ipsg_fib);
    len = cdb__tbl_ipsg_fib__pack(&pb_ipsg_fib, buf);
    pb_tbl_ipsg_fib_to_pb_free_packed(&pb_ipsg_fib);

    return len;
}

int32
pb_tbl_ipsg_fib_dump(Cdb__TblIpsgFib *p_pb_ipsg_fib, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_fdb_key_t_dump(p_pb_ipsg_fib->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_ipsg_fib->vid);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_ipsg_fib->ifindex);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_ipsg_fib->ifname);
    offset += pb_compose_mac_addr_t_dump(p_pb_ipsg_fib->mac_addr, (out + offset));
    offset += pb_compose_prefix_t_dump(p_pb_ipsg_fib->ip_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/ipsg_type=%u", p_pb_ipsg_fib->ipsg_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_BRG_GLOBAL */
int32
pb_tbl_brg_global_to_pb(uint32 only_key, tbl_brg_global_t *p_brg_glb, Cdb__TblBrgGlobal *p_pb_brg_glb)
{
    p_pb_brg_glb->has_max_static_fdb = TRUE;
    p_pb_brg_glb->max_static_fdb = p_brg_glb->max_static_fdb;
    p_pb_brg_glb->has_max_l2mcast_fdb = TRUE;
    p_pb_brg_glb->max_l2mcast_fdb = p_brg_glb->max_l2mcast_fdb;
    p_pb_brg_glb->has_fdb_aging_time = TRUE;
    p_pb_brg_glb->fdb_aging_time = p_brg_glb->fdb_aging_time;
    p_pb_brg_glb->has_oper_fdb_aging_time = TRUE;
    p_pb_brg_glb->oper_fdb_aging_time = p_brg_glb->oper_fdb_aging_time;
    p_pb_brg_glb->has_hw_learning_enable = TRUE;
    p_pb_brg_glb->hw_learning_enable = p_brg_glb->hw_learning_enable;
    p_pb_brg_glb->has_ipsg_max_port_binding = TRUE;
    p_pb_brg_glb->ipsg_max_port_binding = p_brg_glb->ipsg_max_port_binding;
    p_pb_brg_glb->has_cur_ipv4_source_guard = TRUE;
    p_pb_brg_glb->cur_ipv4_source_guard = p_brg_glb->cur_ipv4_source_guard;
    p_pb_brg_glb->has_port_isolate_mode = TRUE;
    p_pb_brg_glb->port_isolate_mode = p_brg_glb->port_isolate_mode;
    p_pb_brg_glb->has_instance = TRUE;
    p_pb_brg_glb->instance.len = sizeof(p_brg_glb->instance);
    p_pb_brg_glb->instance.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_brg_glb->instance));
    sal_memcpy(p_pb_brg_glb->instance.data, p_brg_glb->instance, sizeof(p_brg_glb->instance));
    p_pb_brg_glb->has_pvlan_isolate_id = TRUE;
    p_pb_brg_glb->pvlan_isolate_id.len = sizeof(p_brg_glb->pvlan_isolate_id);
    p_pb_brg_glb->pvlan_isolate_id.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_brg_glb->pvlan_isolate_id));
    sal_memcpy(p_pb_brg_glb->pvlan_isolate_id.data, p_brg_glb->pvlan_isolate_id, sizeof(p_brg_glb->pvlan_isolate_id));
    p_pb_brg_glb->has_max_instance = TRUE;
    p_pb_brg_glb->max_instance = p_brg_glb->max_instance;
    p_pb_brg_glb->has_max_pvlan_isolate_id = TRUE;
    p_pb_brg_glb->max_pvlan_isolate_id = p_brg_glb->max_pvlan_isolate_id;
    p_pb_brg_glb->has_fdb_loop_errdis_en = TRUE;
    p_pb_brg_glb->fdb_loop_errdis_en = p_brg_glb->fdb_loop_errdis_en;
    p_pb_brg_glb->has_fdb_loop_max_size = TRUE;
    p_pb_brg_glb->fdb_loop_max_size = p_brg_glb->fdb_loop_max_size;
    p_pb_brg_glb->has_fdb_loop_add_rate = TRUE;
    p_pb_brg_glb->fdb_loop_add_rate = p_brg_glb->fdb_loop_add_rate;
    p_pb_brg_glb->has_fdb_loop_disc_cnt = TRUE;
    p_pb_brg_glb->fdb_loop_disc_cnt = p_brg_glb->fdb_loop_disc_cnt;
    p_pb_brg_glb->has_fdb_loop_curr_size = TRUE;
    p_pb_brg_glb->fdb_loop_curr_size = p_brg_glb->fdb_loop_curr_size;
    p_pb_brg_glb->has_trap_delay_up = TRUE;
    p_pb_brg_glb->trap_delay_up = p_brg_glb->trap_delay_up;
    p_pb_brg_glb->has_trap_delay_down = TRUE;
    p_pb_brg_glb->trap_delay_down = p_brg_glb->trap_delay_down;
    p_pb_brg_glb->has_fdb_all_flushing = TRUE;
    p_pb_brg_glb->fdb_all_flushing = p_brg_glb->fdb_all_flushing;
    p_pb_brg_glb->has_mac_based_vlan_class = TRUE;
    p_pb_brg_glb->mac_based_vlan_class = p_brg_glb->mac_based_vlan_class;
    p_pb_brg_glb->has_ipv4_based_vlan_class = TRUE;
    p_pb_brg_glb->ipv4_based_vlan_class = p_brg_glb->ipv4_based_vlan_class;
    p_pb_brg_glb->has_ipv6_based_vlan_class = TRUE;
    p_pb_brg_glb->ipv6_based_vlan_class = p_brg_glb->ipv6_based_vlan_class;
    p_pb_brg_glb->has_max_mirror_mac_escape = TRUE;
    p_pb_brg_glb->max_mirror_mac_escape = p_brg_glb->max_mirror_mac_escape;

    return PM_E_NONE;
}

int32
pb_tbl_brg_global_to_pb_free_packed(Cdb__TblBrgGlobal *p_pb_brg_glb)
{
    if (p_pb_brg_glb->instance.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_brg_glb->instance.data);
        p_pb_brg_glb->instance.data = NULL;
    }

    if (p_pb_brg_glb->pvlan_isolate_id.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_brg_glb->pvlan_isolate_id.data);
        p_pb_brg_glb->pvlan_isolate_id.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_brg_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblBrgGlobal pb_brg_glb = CDB__TBL_BRG_GLOBAL__INIT;
    tbl_brg_global_t *p_brg_glb = (tbl_brg_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_brg_global_to_pb(only_key, p_brg_glb, &pb_brg_glb);
    len = cdb__tbl_brg_global__pack(&pb_brg_glb, buf);
    pb_tbl_brg_global_to_pb_free_packed(&pb_brg_glb);

    return len;
}

int32
pb_tbl_brg_global_dump(Cdb__TblBrgGlobal *p_pb_brg_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/max_static_fdb=%u", p_pb_brg_glb->max_static_fdb);
    offset += sal_sprintf(out + offset, "/max_l2mcast_fdb=%u", p_pb_brg_glb->max_l2mcast_fdb);
    offset += sal_sprintf(out + offset, "/fdb_aging_time=%u", p_pb_brg_glb->fdb_aging_time);
    offset += sal_sprintf(out + offset, "/oper_fdb_aging_time=%u", p_pb_brg_glb->oper_fdb_aging_time);
    offset += sal_sprintf(out + offset, "/hw_learning_enable=%u", p_pb_brg_glb->hw_learning_enable);
    offset += sal_sprintf(out + offset, "/ipsg_max_port_binding=%u", p_pb_brg_glb->ipsg_max_port_binding);
    offset += sal_sprintf(out + offset, "/cur_ipv4_source_guard=%u", p_pb_brg_glb->cur_ipv4_source_guard);
    offset += sal_sprintf(out + offset, "/port_isolate_mode=%u", p_pb_brg_glb->port_isolate_mode);
    offset += sal_sprintf(out + offset, "/instance=");
    offset += pb_bitmap_array_dump(p_pb_brg_glb->instance.data, p_pb_brg_glb->instance.len, (out + offset));
    offset += sal_sprintf(out + offset, "/pvlan_isolate_id=");
    offset += pb_bitmap_array_dump(p_pb_brg_glb->pvlan_isolate_id.data, p_pb_brg_glb->pvlan_isolate_id.len, (out + offset));
    offset += sal_sprintf(out + offset, "/max_instance=%u", p_pb_brg_glb->max_instance);
    offset += sal_sprintf(out + offset, "/max_pvlan_isolate_id=%u", p_pb_brg_glb->max_pvlan_isolate_id);
    offset += sal_sprintf(out + offset, "/fdb_loop_errdis_en=%u", p_pb_brg_glb->fdb_loop_errdis_en);
    offset += sal_sprintf(out + offset, "/fdb_loop_max_size=%u", p_pb_brg_glb->fdb_loop_max_size);
    offset += sal_sprintf(out + offset, "/fdb_loop_add_rate=%u", p_pb_brg_glb->fdb_loop_add_rate);
    offset += sal_sprintf(out + offset, "/fdb_loop_disc_cnt=%u", p_pb_brg_glb->fdb_loop_disc_cnt);
    offset += sal_sprintf(out + offset, "/fdb_loop_curr_size=%u", p_pb_brg_glb->fdb_loop_curr_size);
    offset += sal_sprintf(out + offset, "/trap_delay_up=%u", p_pb_brg_glb->trap_delay_up);
    offset += sal_sprintf(out + offset, "/trap_delay_down=%u", p_pb_brg_glb->trap_delay_down);
    offset += sal_sprintf(out + offset, "/fdb_all_flushing=%u", p_pb_brg_glb->fdb_all_flushing);
    offset += sal_sprintf(out + offset, "/mac_based_vlan_class=%u", p_pb_brg_glb->mac_based_vlan_class);
    offset += sal_sprintf(out + offset, "/ipv4_based_vlan_class=%u", p_pb_brg_glb->ipv4_based_vlan_class);
    offset += sal_sprintf(out + offset, "/ipv6_based_vlan_class=%u", p_pb_brg_glb->ipv6_based_vlan_class);
    offset += sal_sprintf(out + offset, "/max_mirror_mac_escape=%u", p_pb_brg_glb->max_mirror_mac_escape);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MSTP_PORT */
int32
pb_tbl_mstp_port_to_pb(uint32 only_key, tbl_mstp_port_t *p_mstp_port, Cdb__TblMstpPort *p_pb_mstp_port)
{
    p_pb_mstp_port->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_mstp_port->key.name)+1);
    sal_strcpy(p_pb_mstp_port->key->name, p_mstp_port->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_mstp_port->has_ifindex = TRUE;
    p_pb_mstp_port->ifindex = p_mstp_port->ifindex;
    p_pb_mstp_port->has_adminportpathcost = TRUE;
    p_pb_mstp_port->adminportpathcost = p_mstp_port->adminPortPathCost;
    p_pb_mstp_port->has_portpathcost = TRUE;
    p_pb_mstp_port->portpathcost = p_mstp_port->portPathCost;
    p_pb_mstp_port->has_forward_transitions = TRUE;
    p_pb_mstp_port->forward_transitions = p_mstp_port->forward_transitions;
    p_pb_mstp_port->has_tx_bpdu_count = TRUE;
    p_pb_mstp_port->tx_bpdu_count = p_mstp_port->tx_bpdu_count;
    p_pb_mstp_port->has_tx_error_count = TRUE;
    p_pb_mstp_port->tx_error_count = p_mstp_port->tx_error_count;
    p_pb_mstp_port->has_rx_bpdu_count = TRUE;
    p_pb_mstp_port->rx_bpdu_count = p_mstp_port->rx_bpdu_count;
    p_pb_mstp_port->has_rx_error_count = TRUE;
    p_pb_mstp_port->rx_error_count = p_mstp_port->rx_error_count;
    p_pb_mstp_port->has_port_enable = TRUE;
    p_pb_mstp_port->port_enable = p_mstp_port->port_enable;
    p_pb_mstp_port->has_bpdu_loop_count = TRUE;
    p_pb_mstp_port->bpdu_loop_count = p_mstp_port->bpdu_loop_count;
    p_pb_mstp_port->has_restricted_role = TRUE;
    p_pb_mstp_port->restricted_role = p_mstp_port->restricted_role;
    p_pb_mstp_port->has_restricted_tcn = TRUE;
    p_pb_mstp_port->restricted_tcn = p_mstp_port->restricted_tcn;
    p_pb_mstp_port->has_admin_bpduguard = TRUE;
    p_pb_mstp_port->admin_bpduguard = p_mstp_port->admin_bpduguard;
    p_pb_mstp_port->has_oper_bpduguard = TRUE;
    p_pb_mstp_port->oper_bpduguard = p_mstp_port->oper_bpduguard;
    p_pb_mstp_port->has_admin_bpdufilter = TRUE;
    p_pb_mstp_port->admin_bpdufilter = p_mstp_port->admin_bpdufilter;
    p_pb_mstp_port->has_oper_bpdufilter = TRUE;
    p_pb_mstp_port->oper_bpdufilter = p_mstp_port->oper_bpdufilter;
    p_pb_mstp_port->has_admin_rootguard = TRUE;
    p_pb_mstp_port->admin_rootguard = p_mstp_port->admin_rootguard;
    p_pb_mstp_port->has_oper_rootguard = TRUE;
    p_pb_mstp_port->oper_rootguard = p_mstp_port->oper_rootguard;
    p_pb_mstp_port->has_admin_loopguard = TRUE;
    p_pb_mstp_port->admin_loopguard = p_mstp_port->admin_loopguard;
    p_pb_mstp_port->has_oper_loopguard = TRUE;
    p_pb_mstp_port->oper_loopguard = p_mstp_port->oper_loopguard;
    p_pb_mstp_port->has_cisco_cfg_format_id = TRUE;
    p_pb_mstp_port->cisco_cfg_format_id = p_mstp_port->cisco_cfg_format_id;
    p_pb_mstp_port->has_adminp2pmac = TRUE;
    p_pb_mstp_port->adminp2pmac = p_mstp_port->adminP2PMac;
    p_pb_mstp_port->has_operp2pmac = TRUE;
    p_pb_mstp_port->operp2pmac = p_mstp_port->operP2PMac;
    p_pb_mstp_port->has_agree = TRUE;
    p_pb_mstp_port->agree = p_mstp_port->agree;
    p_pb_mstp_port->has_agreed = TRUE;
    p_pb_mstp_port->agreed = p_mstp_port->agreed;
    p_pb_mstp_port->has_adminforceversion = TRUE;
    p_pb_mstp_port->adminforceversion = p_mstp_port->adminForceVersion;
    p_pb_mstp_port->has_forceversion = TRUE;
    p_pb_mstp_port->forceversion = p_mstp_port->forceVersion;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->designated_rootId, p_pb_mstp_port->designated_rootid);
    p_pb_mstp_port->has_designated_rootpathcost = TRUE;
    p_pb_mstp_port->designated_rootpathcost = p_mstp_port->designated_rootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->designated_regionRootId, p_pb_mstp_port->designated_regionrootid);
    p_pb_mstp_port->has_designated_introotpathcost = TRUE;
    p_pb_mstp_port->designated_introotpathcost = p_mstp_port->designated_intRootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->designated_designatedBridgeId, p_pb_mstp_port->designated_designatedbridgeid);
    p_pb_mstp_port->has_designated_designatedportid = TRUE;
    p_pb_mstp_port->designated_designatedportid = p_mstp_port->designated_designatedPortId;
    p_pb_mstp_port->has_designated_bridgeportid = TRUE;
    p_pb_mstp_port->designated_bridgeportid = p_mstp_port->designated_bridgePortId;
    p_pb_mstp_port->has_designated_messageage = TRUE;
    p_pb_mstp_port->designated_messageage = p_mstp_port->designated_messageAge;
    p_pb_mstp_port->has_designated_fwddelay = TRUE;
    p_pb_mstp_port->designated_fwddelay = p_mstp_port->designated_fwdDelay;
    p_pb_mstp_port->has_designated_hellotime = TRUE;
    p_pb_mstp_port->designated_hellotime = p_mstp_port->designated_helloTime;
    p_pb_mstp_port->has_designated_maxage = TRUE;
    p_pb_mstp_port->designated_maxage = p_mstp_port->designated_maxAge;
    p_pb_mstp_port->has_disputed = TRUE;
    p_pb_mstp_port->disputed = p_mstp_port->disputed;
    p_pb_mstp_port->has_fdbflush = TRUE;
    p_pb_mstp_port->fdbflush = p_mstp_port->fdbFlush;
    p_pb_mstp_port->has_forward = TRUE;
    p_pb_mstp_port->forward = p_mstp_port->forward;
    p_pb_mstp_port->has_forwarding = TRUE;
    p_pb_mstp_port->forwarding = p_mstp_port->forwarding;
    p_pb_mstp_port->has_infois = TRUE;
    p_pb_mstp_port->infois = p_mstp_port->infoIs;
    p_pb_mstp_port->has_learn = TRUE;
    p_pb_mstp_port->learn = p_mstp_port->learn;
    p_pb_mstp_port->has_learning = TRUE;
    p_pb_mstp_port->learning = p_mstp_port->learning;
    p_pb_mstp_port->has_mcheck = TRUE;
    p_pb_mstp_port->mcheck = p_mstp_port->mcheck;
    p_pb_mstp_port->has_newinfo = TRUE;
    p_pb_mstp_port->newinfo = p_mstp_port->newInfo;
    p_pb_mstp_port->has_newinfomsti = TRUE;
    p_pb_mstp_port->newinfomsti = p_mstp_port->newInfoMsti;
    p_pb_mstp_port->has_adminedge = TRUE;
    p_pb_mstp_port->adminedge = p_mstp_port->adminEdge;
    p_pb_mstp_port->has_operedge = TRUE;
    p_pb_mstp_port->operedge = p_mstp_port->operEdge;
    p_pb_mstp_port->has_portenabled = TRUE;
    p_pb_mstp_port->portenabled = p_mstp_port->portEnabled;
    p_pb_mstp_port->has_portid = TRUE;
    p_pb_mstp_port->portid = p_mstp_port->portId;
    p_pb_mstp_port->has_priority = TRUE;
    p_pb_mstp_port->priority = p_mstp_port->priority;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->port_rootId, p_pb_mstp_port->port_rootid);
    p_pb_mstp_port->has_port_rootpathcost = TRUE;
    p_pb_mstp_port->port_rootpathcost = p_mstp_port->port_rootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->port_regionRootId, p_pb_mstp_port->port_regionrootid);
    p_pb_mstp_port->has_port_introotpathcost = TRUE;
    p_pb_mstp_port->port_introotpathcost = p_mstp_port->port_intRootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_port->port_designatedBridgeId, p_pb_mstp_port->port_designatedbridgeid);
    p_pb_mstp_port->has_port_designatedportid = TRUE;
    p_pb_mstp_port->port_designatedportid = p_mstp_port->port_designatedPortId;
    p_pb_mstp_port->has_port_bridgeportid = TRUE;
    p_pb_mstp_port->port_bridgeportid = p_mstp_port->port_bridgePortId;
    p_pb_mstp_port->has_port_messageage = TRUE;
    p_pb_mstp_port->port_messageage = p_mstp_port->port_messageAge;
    p_pb_mstp_port->has_port_fwddelay = TRUE;
    p_pb_mstp_port->port_fwddelay = p_mstp_port->port_fwdDelay;
    p_pb_mstp_port->has_port_hellotime = TRUE;
    p_pb_mstp_port->port_hellotime = p_mstp_port->port_helloTime;
    p_pb_mstp_port->has_port_maxage = TRUE;
    p_pb_mstp_port->port_maxage = p_mstp_port->port_maxAge;
    p_pb_mstp_port->has_proposed = TRUE;
    p_pb_mstp_port->proposed = p_mstp_port->proposed;
    p_pb_mstp_port->has_proposing = TRUE;
    p_pb_mstp_port->proposing = p_mstp_port->proposing;
    p_pb_mstp_port->has_rcvdbpdu = TRUE;
    p_pb_mstp_port->rcvdbpdu = p_mstp_port->rcvdBpdu;
    p_pb_mstp_port->has_rcvdinfo = TRUE;
    p_pb_mstp_port->rcvdinfo = p_mstp_port->rcvdInfo;
    p_pb_mstp_port->has_rcvdmsg = TRUE;
    p_pb_mstp_port->rcvdmsg = p_mstp_port->rcvdMsg;
    p_pb_mstp_port->has_rcvdmstp = TRUE;
    p_pb_mstp_port->rcvdmstp = p_mstp_port->rcvdMSTP;
    p_pb_mstp_port->has_rcvdrstp = TRUE;
    p_pb_mstp_port->rcvdrstp = p_mstp_port->rcvdRSTP;
    p_pb_mstp_port->has_rcvdstp = TRUE;
    p_pb_mstp_port->rcvdstp = p_mstp_port->rcvdSTP;
    p_pb_mstp_port->has_rcvdtc = TRUE;
    p_pb_mstp_port->rcvdtc = p_mstp_port->rcvdTc;
    p_pb_mstp_port->has_rcvdtcack = TRUE;
    p_pb_mstp_port->rcvdtcack = p_mstp_port->rcvdTcAck;
    p_pb_mstp_port->has_rcvdtcn = TRUE;
    p_pb_mstp_port->rcvdtcn = p_mstp_port->rcvdTcn;
    p_pb_mstp_port->has_reroot = TRUE;
    p_pb_mstp_port->reroot = p_mstp_port->reRoot;
    p_pb_mstp_port->has_reselect = TRUE;
    p_pb_mstp_port->reselect = p_mstp_port->reselect;
    p_pb_mstp_port->has_role = TRUE;
    p_pb_mstp_port->role = p_mstp_port->role;
    p_pb_mstp_port->has_selected = TRUE;
    p_pb_mstp_port->selected = p_mstp_port->selected;
    p_pb_mstp_port->has_selectedrole = TRUE;
    p_pb_mstp_port->selectedrole = p_mstp_port->selectedRole;
    p_pb_mstp_port->has_sendrstp = TRUE;
    p_pb_mstp_port->sendrstp = p_mstp_port->sendRstp;
    p_pb_mstp_port->has_sync = TRUE;
    p_pb_mstp_port->sync = p_mstp_port->sync;
    p_pb_mstp_port->has_synced = TRUE;
    p_pb_mstp_port->synced = p_mstp_port->synced;
    p_pb_mstp_port->has_tcack = TRUE;
    p_pb_mstp_port->tcack = p_mstp_port->tcAck;
    p_pb_mstp_port->has_tcprop = TRUE;
    p_pb_mstp_port->tcprop = p_mstp_port->tcProp;
    p_pb_mstp_port->has_txcount = TRUE;
    p_pb_mstp_port->txcount = p_mstp_port->txCount;
    p_pb_mstp_port->has_updtinfo = TRUE;
    p_pb_mstp_port->updtinfo = p_mstp_port->updtInfo;
    p_pb_mstp_port->has_rerooted = TRUE;
    p_pb_mstp_port->rerooted = p_mstp_port->reRooted;
    p_pb_mstp_port->has_rstpversion = TRUE;
    p_pb_mstp_port->rstpversion = p_mstp_port->rstpVersion;
    p_pb_mstp_port->has_stpversion = TRUE;
    p_pb_mstp_port->stpversion = p_mstp_port->stpVersion;
    p_pb_mstp_port->has_rcvdinternal = TRUE;
    p_pb_mstp_port->rcvdinternal = p_mstp_port->rcvdInternal;
    p_pb_mstp_port->has_rcvdinternalchange = TRUE;
    p_pb_mstp_port->rcvdinternalchange = p_mstp_port->rcvdInternalChange;
    p_pb_mstp_port->has_hopcount = TRUE;
    p_pb_mstp_port->hopcount = p_mstp_port->hopCount;
    p_pb_mstp_port->has_prx_state = TRUE;
    p_pb_mstp_port->prx_state = p_mstp_port->prx_state;
    p_pb_mstp_port->has_ppm_state = TRUE;
    p_pb_mstp_port->ppm_state = p_mstp_port->ppm_state;
    p_pb_mstp_port->has_bdm_state = TRUE;
    p_pb_mstp_port->bdm_state = p_mstp_port->bdm_state;
    p_pb_mstp_port->has_ptx_state = TRUE;
    p_pb_mstp_port->ptx_state = p_mstp_port->ptx_state;
    p_pb_mstp_port->has_pim_state = TRUE;
    p_pb_mstp_port->pim_state = p_mstp_port->pim_state;
    p_pb_mstp_port->has_prt_state = TRUE;
    p_pb_mstp_port->prt_state = p_mstp_port->prt_state;
    p_pb_mstp_port->has_pst_state = TRUE;
    p_pb_mstp_port->pst_state = p_mstp_port->pst_state;
    p_pb_mstp_port->has_tcm_state = TRUE;
    p_pb_mstp_port->tcm_state = p_mstp_port->tcm_state;
    p_pb_mstp_port->has_fea_state = TRUE;
    p_pb_mstp_port->fea_state = p_mstp_port->fea_state;

    return PM_E_NONE;
}

int32
pb_tbl_mstp_port_to_pb_free_packed(Cdb__TblMstpPort *p_pb_mstp_port)
{
    if (p_pb_mstp_port->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mstp_port->key->name);
        p_pb_mstp_port->key->name = NULL;
    }

    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->designated_rootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->designated_regionrootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->designated_designatedbridgeid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->port_rootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->port_regionrootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_port->port_designatedbridgeid);
    return PM_E_NONE;
}

int32
pb_tbl_mstp_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMstpPortKey pb_mstp_port_key = CDB__TBL_MSTP_PORT_KEY__INIT;
    Cdb__TblMstpPort pb_mstp_port = CDB__TBL_MSTP_PORT__INIT;
    tbl_mstp_port_t *p_mstp_port = (tbl_mstp_port_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMstpBrgIdT designated_rootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT designated_regionrootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT designated_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT port_rootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT port_regionrootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT port_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;

    pb_mstp_port.key = &pb_mstp_port_key;
    pb_mstp_port.designated_rootid = &designated_rootid;
    pb_mstp_port.designated_regionrootid = &designated_regionrootid;
    pb_mstp_port.designated_designatedbridgeid = &designated_designatedbridgeid;
    pb_mstp_port.port_rootid = &port_rootid;
    pb_mstp_port.port_regionrootid = &port_regionrootid;
    pb_mstp_port.port_designatedbridgeid = &port_designatedbridgeid;
    pb_tbl_mstp_port_to_pb(only_key, p_mstp_port, &pb_mstp_port);
    len = cdb__tbl_mstp_port__pack(&pb_mstp_port, buf);
    pb_tbl_mstp_port_to_pb_free_packed(&pb_mstp_port);

    return len;
}

int32
pb_tbl_mstp_port_dump(Cdb__TblMstpPort *p_pb_mstp_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_mstp_port->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_mstp_port->ifindex);
    offset += sal_sprintf(out + offset, "/adminPortPathCost=%u", p_pb_mstp_port->adminportpathcost);
    offset += sal_sprintf(out + offset, "/portPathCost=%u", p_pb_mstp_port->portpathcost);
    offset += sal_sprintf(out + offset, "/forward_transitions=%u", p_pb_mstp_port->forward_transitions);
    offset += sal_sprintf(out + offset, "/tx_bpdu_count=%u", p_pb_mstp_port->tx_bpdu_count);
    offset += sal_sprintf(out + offset, "/tx_error_count=%u", p_pb_mstp_port->tx_error_count);
    offset += sal_sprintf(out + offset, "/rx_bpdu_count=%u", p_pb_mstp_port->rx_bpdu_count);
    offset += sal_sprintf(out + offset, "/rx_error_count=%u", p_pb_mstp_port->rx_error_count);
    offset += sal_sprintf(out + offset, "/port_enable=%u", p_pb_mstp_port->port_enable);
    offset += sal_sprintf(out + offset, "/bpdu_loop_count=%u", p_pb_mstp_port->bpdu_loop_count);
    offset += sal_sprintf(out + offset, "/restricted_role=%u", p_pb_mstp_port->restricted_role);
    offset += sal_sprintf(out + offset, "/restricted_tcn=%u", p_pb_mstp_port->restricted_tcn);
    offset += sal_sprintf(out + offset, "/admin_bpduguard=%u", p_pb_mstp_port->admin_bpduguard);
    offset += sal_sprintf(out + offset, "/oper_bpduguard=%u", p_pb_mstp_port->oper_bpduguard);
    offset += sal_sprintf(out + offset, "/admin_bpdufilter=%u", p_pb_mstp_port->admin_bpdufilter);
    offset += sal_sprintf(out + offset, "/oper_bpdufilter=%u", p_pb_mstp_port->oper_bpdufilter);
    offset += sal_sprintf(out + offset, "/admin_rootguard=%u", p_pb_mstp_port->admin_rootguard);
    offset += sal_sprintf(out + offset, "/oper_rootguard=%u", p_pb_mstp_port->oper_rootguard);
    offset += sal_sprintf(out + offset, "/admin_loopguard=%u", p_pb_mstp_port->admin_loopguard);
    offset += sal_sprintf(out + offset, "/oper_loopguard=%u", p_pb_mstp_port->oper_loopguard);
    offset += sal_sprintf(out + offset, "/cisco_cfg_format_id=%u", p_pb_mstp_port->cisco_cfg_format_id);
    offset += sal_sprintf(out + offset, "/adminP2PMac=%u", p_pb_mstp_port->adminp2pmac);
    offset += sal_sprintf(out + offset, "/operP2PMac=%u", p_pb_mstp_port->operp2pmac);
    offset += sal_sprintf(out + offset, "/agree=%u", p_pb_mstp_port->agree);
    offset += sal_sprintf(out + offset, "/agreed=%u", p_pb_mstp_port->agreed);
    offset += sal_sprintf(out + offset, "/adminForceVersion=%u", p_pb_mstp_port->adminforceversion);
    offset += sal_sprintf(out + offset, "/forceVersion=%u", p_pb_mstp_port->forceversion);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->designated_rootid, (out + offset));
    offset += sal_sprintf(out + offset, "/designated_rootPathCost=%u", p_pb_mstp_port->designated_rootpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->designated_regionrootid, (out + offset));
    offset += sal_sprintf(out + offset, "/designated_intRootPathCost=%u", p_pb_mstp_port->designated_introotpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->designated_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/designated_designatedPortId=%u", p_pb_mstp_port->designated_designatedportid);
    offset += sal_sprintf(out + offset, "/designated_bridgePortId=%u", p_pb_mstp_port->designated_bridgeportid);
    offset += sal_sprintf(out + offset, "/designated_messageAge=%u", p_pb_mstp_port->designated_messageage);
    offset += sal_sprintf(out + offset, "/designated_fwdDelay=%u", p_pb_mstp_port->designated_fwddelay);
    offset += sal_sprintf(out + offset, "/designated_helloTime=%u", p_pb_mstp_port->designated_hellotime);
    offset += sal_sprintf(out + offset, "/designated_maxAge=%u", p_pb_mstp_port->designated_maxage);
    offset += sal_sprintf(out + offset, "/disputed=%u", p_pb_mstp_port->disputed);
    offset += sal_sprintf(out + offset, "/fdbFlush=%u", p_pb_mstp_port->fdbflush);
    offset += sal_sprintf(out + offset, "/forward=%u", p_pb_mstp_port->forward);
    offset += sal_sprintf(out + offset, "/forwarding=%u", p_pb_mstp_port->forwarding);
    offset += sal_sprintf(out + offset, "/infoIs=%u", p_pb_mstp_port->infois);
    offset += sal_sprintf(out + offset, "/learn=%u", p_pb_mstp_port->learn);
    offset += sal_sprintf(out + offset, "/learning=%u", p_pb_mstp_port->learning);
    offset += sal_sprintf(out + offset, "/mcheck=%u", p_pb_mstp_port->mcheck);
    offset += sal_sprintf(out + offset, "/newInfo=%u", p_pb_mstp_port->newinfo);
    offset += sal_sprintf(out + offset, "/newInfoMsti=%u", p_pb_mstp_port->newinfomsti);
    offset += sal_sprintf(out + offset, "/adminEdge=%u", p_pb_mstp_port->adminedge);
    offset += sal_sprintf(out + offset, "/operEdge=%u", p_pb_mstp_port->operedge);
    offset += sal_sprintf(out + offset, "/portEnabled=%u", p_pb_mstp_port->portenabled);
    offset += sal_sprintf(out + offset, "/portId=%u", p_pb_mstp_port->portid);
    offset += sal_sprintf(out + offset, "/priority=%u", p_pb_mstp_port->priority);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->port_rootid, (out + offset));
    offset += sal_sprintf(out + offset, "/port_rootPathCost=%u", p_pb_mstp_port->port_rootpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->port_regionrootid, (out + offset));
    offset += sal_sprintf(out + offset, "/port_intRootPathCost=%u", p_pb_mstp_port->port_introotpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_port->port_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/port_designatedPortId=%u", p_pb_mstp_port->port_designatedportid);
    offset += sal_sprintf(out + offset, "/port_bridgePortId=%u", p_pb_mstp_port->port_bridgeportid);
    offset += sal_sprintf(out + offset, "/port_messageAge=%u", p_pb_mstp_port->port_messageage);
    offset += sal_sprintf(out + offset, "/port_fwdDelay=%u", p_pb_mstp_port->port_fwddelay);
    offset += sal_sprintf(out + offset, "/port_helloTime=%u", p_pb_mstp_port->port_hellotime);
    offset += sal_sprintf(out + offset, "/port_maxAge=%u", p_pb_mstp_port->port_maxage);
    offset += sal_sprintf(out + offset, "/proposed=%u", p_pb_mstp_port->proposed);
    offset += sal_sprintf(out + offset, "/proposing=%u", p_pb_mstp_port->proposing);
    offset += sal_sprintf(out + offset, "/rcvdBpdu=%u", p_pb_mstp_port->rcvdbpdu);
    offset += sal_sprintf(out + offset, "/rcvdInfo=%u", p_pb_mstp_port->rcvdinfo);
    offset += sal_sprintf(out + offset, "/rcvdMsg=%u", p_pb_mstp_port->rcvdmsg);
    offset += sal_sprintf(out + offset, "/rcvdMSTP=%u", p_pb_mstp_port->rcvdmstp);
    offset += sal_sprintf(out + offset, "/rcvdRSTP=%u", p_pb_mstp_port->rcvdrstp);
    offset += sal_sprintf(out + offset, "/rcvdSTP=%u", p_pb_mstp_port->rcvdstp);
    offset += sal_sprintf(out + offset, "/rcvdTc=%u", p_pb_mstp_port->rcvdtc);
    offset += sal_sprintf(out + offset, "/rcvdTcAck=%u", p_pb_mstp_port->rcvdtcack);
    offset += sal_sprintf(out + offset, "/rcvdTcn=%u", p_pb_mstp_port->rcvdtcn);
    offset += sal_sprintf(out + offset, "/reRoot=%u", p_pb_mstp_port->reroot);
    offset += sal_sprintf(out + offset, "/reselect=%u", p_pb_mstp_port->reselect);
    offset += sal_sprintf(out + offset, "/role=%u", p_pb_mstp_port->role);
    offset += sal_sprintf(out + offset, "/selected=%u", p_pb_mstp_port->selected);
    offset += sal_sprintf(out + offset, "/selectedRole=%u", p_pb_mstp_port->selectedrole);
    offset += sal_sprintf(out + offset, "/sendRstp=%u", p_pb_mstp_port->sendrstp);
    offset += sal_sprintf(out + offset, "/sync=%u", p_pb_mstp_port->sync);
    offset += sal_sprintf(out + offset, "/synced=%u", p_pb_mstp_port->synced);
    offset += sal_sprintf(out + offset, "/tcAck=%u", p_pb_mstp_port->tcack);
    offset += sal_sprintf(out + offset, "/tcProp=%u", p_pb_mstp_port->tcprop);
    offset += sal_sprintf(out + offset, "/txCount=%u", p_pb_mstp_port->txcount);
    offset += sal_sprintf(out + offset, "/updtInfo=%u", p_pb_mstp_port->updtinfo);
    offset += sal_sprintf(out + offset, "/reRooted=%u", p_pb_mstp_port->rerooted);
    offset += sal_sprintf(out + offset, "/rstpVersion=%u", p_pb_mstp_port->rstpversion);
    offset += sal_sprintf(out + offset, "/stpVersion=%u", p_pb_mstp_port->stpversion);
    offset += sal_sprintf(out + offset, "/rcvdInternal=%u", p_pb_mstp_port->rcvdinternal);
    offset += sal_sprintf(out + offset, "/rcvdInternalChange=%u", p_pb_mstp_port->rcvdinternalchange);
    offset += sal_sprintf(out + offset, "/hopCount=%u", p_pb_mstp_port->hopcount);
    offset += sal_sprintf(out + offset, "/prx_state=%u", p_pb_mstp_port->prx_state);
    offset += sal_sprintf(out + offset, "/ppm_state=%u", p_pb_mstp_port->ppm_state);
    offset += sal_sprintf(out + offset, "/bdm_state=%u", p_pb_mstp_port->bdm_state);
    offset += sal_sprintf(out + offset, "/ptx_state=%u", p_pb_mstp_port->ptx_state);
    offset += sal_sprintf(out + offset, "/pim_state=%u", p_pb_mstp_port->pim_state);
    offset += sal_sprintf(out + offset, "/prt_state=%u", p_pb_mstp_port->prt_state);
    offset += sal_sprintf(out + offset, "/pst_state=%u", p_pb_mstp_port->pst_state);
    offset += sal_sprintf(out + offset, "/tcm_state=%u", p_pb_mstp_port->tcm_state);
    offset += sal_sprintf(out + offset, "/fea_state=%u", p_pb_mstp_port->fea_state);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MSTI_PORT */
int32
pb_tbl_msti_port_to_pb(uint32 only_key, tbl_msti_port_t *p_msti_port, Cdb__TblMstiPort *p_pb_msti_port)
{
    pb_compose_msti_port_key_t_to_pb(&p_msti_port->key, p_pb_msti_port->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_msti_port->has_ifindex = TRUE;
    p_pb_msti_port->ifindex = p_msti_port->ifindex;
    p_pb_msti_port->has_adminportpathcost = TRUE;
    p_pb_msti_port->adminportpathcost = p_msti_port->adminPortPathCost;
    p_pb_msti_port->has_portpathcost = TRUE;
    p_pb_msti_port->portpathcost = p_msti_port->portPathCost;
    p_pb_msti_port->has_forward_transitions = TRUE;
    p_pb_msti_port->forward_transitions = p_msti_port->forward_transitions;
    p_pb_msti_port->has_newinfomsti = TRUE;
    p_pb_msti_port->newinfomsti = p_msti_port->newInfoMsti;
    p_pb_msti_port->has_bpdu_loop_count = TRUE;
    p_pb_msti_port->bpdu_loop_count = p_msti_port->bpdu_loop_count;
    p_pb_msti_port->has_restricted_role = TRUE;
    p_pb_msti_port->restricted_role = p_msti_port->restricted_role;
    p_pb_msti_port->has_restricted_tcn = TRUE;
    p_pb_msti_port->restricted_tcn = p_msti_port->restricted_tcn;
    p_pb_msti_port->has_oper_rootguard = TRUE;
    p_pb_msti_port->oper_rootguard = p_msti_port->oper_rootguard;
    p_pb_msti_port->has_oper_loopguard = TRUE;
    p_pb_msti_port->oper_loopguard = p_msti_port->oper_loopguard;
    p_pb_msti_port->has_agree = TRUE;
    p_pb_msti_port->agree = p_msti_port->agree;
    p_pb_msti_port->has_agreed = TRUE;
    p_pb_msti_port->agreed = p_msti_port->agreed;
    p_pb_msti_port->has_adminforceversion = TRUE;
    p_pb_msti_port->adminforceversion = p_msti_port->adminForceVersion;
    pb_compose_mstp_brg_id_t_to_pb(&p_msti_port->designated_regionRootId, p_pb_msti_port->designated_regionrootid);
    p_pb_msti_port->has_designated_introotpathcost = TRUE;
    p_pb_msti_port->designated_introotpathcost = p_msti_port->designated_intRootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_msti_port->designated_designatedBridgeId, p_pb_msti_port->designated_designatedbridgeid);
    p_pb_msti_port->has_designated_designatedportid = TRUE;
    p_pb_msti_port->designated_designatedportid = p_msti_port->designated_designatedPortId;
    p_pb_msti_port->has_designated_bridgeportid = TRUE;
    p_pb_msti_port->designated_bridgeportid = p_msti_port->designated_bridgePortId;
    p_pb_msti_port->has_designated_messageage = TRUE;
    p_pb_msti_port->designated_messageage = p_msti_port->designated_messageAge;
    p_pb_msti_port->has_designated_fwddelay = TRUE;
    p_pb_msti_port->designated_fwddelay = p_msti_port->designated_fwdDelay;
    p_pb_msti_port->has_designated_hellotime = TRUE;
    p_pb_msti_port->designated_hellotime = p_msti_port->designated_helloTime;
    p_pb_msti_port->has_designated_maxage = TRUE;
    p_pb_msti_port->designated_maxage = p_msti_port->designated_maxAge;
    p_pb_msti_port->has_disputed = TRUE;
    p_pb_msti_port->disputed = p_msti_port->disputed;
    p_pb_msti_port->has_fdbflush = TRUE;
    p_pb_msti_port->fdbflush = p_msti_port->fdbFlush;
    p_pb_msti_port->has_forward = TRUE;
    p_pb_msti_port->forward = p_msti_port->forward;
    p_pb_msti_port->has_forwarding = TRUE;
    p_pb_msti_port->forwarding = p_msti_port->forwarding;
    p_pb_msti_port->has_infois = TRUE;
    p_pb_msti_port->infois = p_msti_port->infoIs;
    p_pb_msti_port->has_learn = TRUE;
    p_pb_msti_port->learn = p_msti_port->learn;
    p_pb_msti_port->has_learning = TRUE;
    p_pb_msti_port->learning = p_msti_port->learning;
    p_pb_msti_port->has_newinfo = TRUE;
    p_pb_msti_port->newinfo = p_msti_port->newInfo;
    p_pb_msti_port->has_portid = TRUE;
    p_pb_msti_port->portid = p_msti_port->portId;
    p_pb_msti_port->has_priority = TRUE;
    p_pb_msti_port->priority = p_msti_port->priority;
    pb_compose_mstp_brg_id_t_to_pb(&p_msti_port->port_rootId, p_pb_msti_port->port_rootid);
    p_pb_msti_port->has_port_rootpathcost = TRUE;
    p_pb_msti_port->port_rootpathcost = p_msti_port->port_rootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_msti_port->port_designatedBridgeId, p_pb_msti_port->port_designatedbridgeid);
    p_pb_msti_port->has_port_designatedportid = TRUE;
    p_pb_msti_port->port_designatedportid = p_msti_port->port_designatedPortId;
    p_pb_msti_port->has_port_bridgeportid = TRUE;
    p_pb_msti_port->port_bridgeportid = p_msti_port->port_bridgePortId;
    p_pb_msti_port->has_port_messageage = TRUE;
    p_pb_msti_port->port_messageage = p_msti_port->port_messageAge;
    p_pb_msti_port->has_port_fwddelay = TRUE;
    p_pb_msti_port->port_fwddelay = p_msti_port->port_fwdDelay;
    p_pb_msti_port->has_port_hellotime = TRUE;
    p_pb_msti_port->port_hellotime = p_msti_port->port_helloTime;
    p_pb_msti_port->has_port_maxage = TRUE;
    p_pb_msti_port->port_maxage = p_msti_port->port_maxAge;
    p_pb_msti_port->has_proposed = TRUE;
    p_pb_msti_port->proposed = p_msti_port->proposed;
    p_pb_msti_port->has_proposing = TRUE;
    p_pb_msti_port->proposing = p_msti_port->proposing;
    p_pb_msti_port->has_rcvdbpdu = TRUE;
    p_pb_msti_port->rcvdbpdu = p_msti_port->rcvdBpdu;
    p_pb_msti_port->has_rcvdinfo = TRUE;
    p_pb_msti_port->rcvdinfo = p_msti_port->rcvdInfo;
    p_pb_msti_port->has_rcvdmsg = TRUE;
    p_pb_msti_port->rcvdmsg = p_msti_port->rcvdMsg;
    p_pb_msti_port->has_rcvdrstp = TRUE;
    p_pb_msti_port->rcvdrstp = p_msti_port->rcvdRSTP;
    p_pb_msti_port->has_rcvdstp = TRUE;
    p_pb_msti_port->rcvdstp = p_msti_port->rcvdSTP;
    p_pb_msti_port->has_rcvdtc = TRUE;
    p_pb_msti_port->rcvdtc = p_msti_port->rcvdTc;
    p_pb_msti_port->has_rcvdtcack = TRUE;
    p_pb_msti_port->rcvdtcack = p_msti_port->rcvdTcAck;
    p_pb_msti_port->has_rcvdtcn = TRUE;
    p_pb_msti_port->rcvdtcn = p_msti_port->rcvdTcn;
    p_pb_msti_port->has_reroot = TRUE;
    p_pb_msti_port->reroot = p_msti_port->reRoot;
    p_pb_msti_port->has_reselect = TRUE;
    p_pb_msti_port->reselect = p_msti_port->reselect;
    p_pb_msti_port->has_role = TRUE;
    p_pb_msti_port->role = p_msti_port->role;
    p_pb_msti_port->has_selected = TRUE;
    p_pb_msti_port->selected = p_msti_port->selected;
    p_pb_msti_port->has_selectedrole = TRUE;
    p_pb_msti_port->selectedrole = p_msti_port->selectedRole;
    p_pb_msti_port->has_sync = TRUE;
    p_pb_msti_port->sync = p_msti_port->sync;
    p_pb_msti_port->has_synced = TRUE;
    p_pb_msti_port->synced = p_msti_port->synced;
    p_pb_msti_port->has_tcack = TRUE;
    p_pb_msti_port->tcack = p_msti_port->tcAck;
    p_pb_msti_port->has_tcprop = TRUE;
    p_pb_msti_port->tcprop = p_msti_port->tcProp;
    p_pb_msti_port->has_txcount = TRUE;
    p_pb_msti_port->txcount = p_msti_port->txCount;
    p_pb_msti_port->has_updtinfo = TRUE;
    p_pb_msti_port->updtinfo = p_msti_port->updtInfo;
    p_pb_msti_port->has_rerooted = TRUE;
    p_pb_msti_port->rerooted = p_msti_port->reRooted;
    p_pb_msti_port->has_hopcount = TRUE;
    p_pb_msti_port->hopcount = p_msti_port->hopCount;
    p_pb_msti_port->has_ppm_state = TRUE;
    p_pb_msti_port->ppm_state = p_msti_port->ppm_state;
    p_pb_msti_port->has_pim_state = TRUE;
    p_pb_msti_port->pim_state = p_msti_port->pim_state;
    p_pb_msti_port->has_prt_state = TRUE;
    p_pb_msti_port->prt_state = p_msti_port->prt_state;
    p_pb_msti_port->has_pst_state = TRUE;
    p_pb_msti_port->pst_state = p_msti_port->pst_state;
    p_pb_msti_port->has_tcm_state = TRUE;
    p_pb_msti_port->tcm_state = p_msti_port->tcm_state;
    p_pb_msti_port->has_fea_state = TRUE;
    p_pb_msti_port->fea_state = p_msti_port->fea_state;

    return PM_E_NONE;
}

int32
pb_tbl_msti_port_to_pb_free_packed(Cdb__TblMstiPort *p_pb_msti_port)
{
    pb_compose_msti_port_key_t_to_pb_free_packed(p_pb_msti_port->key);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_msti_port->designated_regionrootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_msti_port->designated_designatedbridgeid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_msti_port->port_rootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_msti_port->port_designatedbridgeid);
    return PM_E_NONE;
}

int32
pb_tbl_msti_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMstiPortKey pb_msti_port_key = CDB__TBL_MSTI_PORT_KEY__INIT;
    Cdb__TblMstiPort pb_msti_port = CDB__TBL_MSTI_PORT__INIT;
    tbl_msti_port_t *p_msti_port = (tbl_msti_port_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMstpBrgIdT designated_regionrootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT designated_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT port_rootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT port_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;

    pb_msti_port.key = &pb_msti_port_key;
    pb_msti_port.designated_regionrootid = &designated_regionrootid;
    pb_msti_port.designated_designatedbridgeid = &designated_designatedbridgeid;
    pb_msti_port.port_rootid = &port_rootid;
    pb_msti_port.port_designatedbridgeid = &port_designatedbridgeid;
    pb_tbl_msti_port_to_pb(only_key, p_msti_port, &pb_msti_port);
    len = cdb__tbl_msti_port__pack(&pb_msti_port, buf);
    pb_tbl_msti_port_to_pb_free_packed(&pb_msti_port);

    return len;
}

int32
pb_tbl_msti_port_dump(Cdb__TblMstiPort *p_pb_msti_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_msti_port_key_t_dump(p_pb_msti_port->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_msti_port->ifindex);
    offset += sal_sprintf(out + offset, "/adminPortPathCost=%u", p_pb_msti_port->adminportpathcost);
    offset += sal_sprintf(out + offset, "/portPathCost=%u", p_pb_msti_port->portpathcost);
    offset += sal_sprintf(out + offset, "/forward_transitions=%u", p_pb_msti_port->forward_transitions);
    offset += sal_sprintf(out + offset, "/newInfoMsti=%u", p_pb_msti_port->newinfomsti);
    offset += sal_sprintf(out + offset, "/bpdu_loop_count=%u", p_pb_msti_port->bpdu_loop_count);
    offset += sal_sprintf(out + offset, "/restricted_role=%u", p_pb_msti_port->restricted_role);
    offset += sal_sprintf(out + offset, "/restricted_tcn=%u", p_pb_msti_port->restricted_tcn);
    offset += sal_sprintf(out + offset, "/oper_rootguard=%u", p_pb_msti_port->oper_rootguard);
    offset += sal_sprintf(out + offset, "/oper_loopguard=%u", p_pb_msti_port->oper_loopguard);
    offset += sal_sprintf(out + offset, "/agree=%u", p_pb_msti_port->agree);
    offset += sal_sprintf(out + offset, "/agreed=%u", p_pb_msti_port->agreed);
    offset += sal_sprintf(out + offset, "/adminForceVersion=%u", p_pb_msti_port->adminforceversion);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_msti_port->designated_regionrootid, (out + offset));
    offset += sal_sprintf(out + offset, "/designated_intRootPathCost=%u", p_pb_msti_port->designated_introotpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_msti_port->designated_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/designated_designatedPortId=%u", p_pb_msti_port->designated_designatedportid);
    offset += sal_sprintf(out + offset, "/designated_bridgePortId=%u", p_pb_msti_port->designated_bridgeportid);
    offset += sal_sprintf(out + offset, "/designated_messageAge=%u", p_pb_msti_port->designated_messageage);
    offset += sal_sprintf(out + offset, "/designated_fwdDelay=%u", p_pb_msti_port->designated_fwddelay);
    offset += sal_sprintf(out + offset, "/designated_helloTime=%u", p_pb_msti_port->designated_hellotime);
    offset += sal_sprintf(out + offset, "/designated_maxAge=%u", p_pb_msti_port->designated_maxage);
    offset += sal_sprintf(out + offset, "/disputed=%u", p_pb_msti_port->disputed);
    offset += sal_sprintf(out + offset, "/fdbFlush=%u", p_pb_msti_port->fdbflush);
    offset += sal_sprintf(out + offset, "/forward=%u", p_pb_msti_port->forward);
    offset += sal_sprintf(out + offset, "/forwarding=%u", p_pb_msti_port->forwarding);
    offset += sal_sprintf(out + offset, "/infoIs=%u", p_pb_msti_port->infois);
    offset += sal_sprintf(out + offset, "/learn=%u", p_pb_msti_port->learn);
    offset += sal_sprintf(out + offset, "/learning=%u", p_pb_msti_port->learning);
    offset += sal_sprintf(out + offset, "/newInfo=%u", p_pb_msti_port->newinfo);
    offset += sal_sprintf(out + offset, "/portId=%u", p_pb_msti_port->portid);
    offset += sal_sprintf(out + offset, "/priority=%u", p_pb_msti_port->priority);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_msti_port->port_rootid, (out + offset));
    offset += sal_sprintf(out + offset, "/port_rootPathCost=%u", p_pb_msti_port->port_rootpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_msti_port->port_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/port_designatedPortId=%u", p_pb_msti_port->port_designatedportid);
    offset += sal_sprintf(out + offset, "/port_bridgePortId=%u", p_pb_msti_port->port_bridgeportid);
    offset += sal_sprintf(out + offset, "/port_messageAge=%u", p_pb_msti_port->port_messageage);
    offset += sal_sprintf(out + offset, "/port_fwdDelay=%u", p_pb_msti_port->port_fwddelay);
    offset += sal_sprintf(out + offset, "/port_helloTime=%u", p_pb_msti_port->port_hellotime);
    offset += sal_sprintf(out + offset, "/port_maxAge=%u", p_pb_msti_port->port_maxage);
    offset += sal_sprintf(out + offset, "/proposed=%u", p_pb_msti_port->proposed);
    offset += sal_sprintf(out + offset, "/proposing=%u", p_pb_msti_port->proposing);
    offset += sal_sprintf(out + offset, "/rcvdBpdu=%u", p_pb_msti_port->rcvdbpdu);
    offset += sal_sprintf(out + offset, "/rcvdInfo=%u", p_pb_msti_port->rcvdinfo);
    offset += sal_sprintf(out + offset, "/rcvdMsg=%u", p_pb_msti_port->rcvdmsg);
    offset += sal_sprintf(out + offset, "/rcvdRSTP=%u", p_pb_msti_port->rcvdrstp);
    offset += sal_sprintf(out + offset, "/rcvdSTP=%u", p_pb_msti_port->rcvdstp);
    offset += sal_sprintf(out + offset, "/rcvdTc=%u", p_pb_msti_port->rcvdtc);
    offset += sal_sprintf(out + offset, "/rcvdTcAck=%u", p_pb_msti_port->rcvdtcack);
    offset += sal_sprintf(out + offset, "/rcvdTcn=%u", p_pb_msti_port->rcvdtcn);
    offset += sal_sprintf(out + offset, "/reRoot=%u", p_pb_msti_port->reroot);
    offset += sal_sprintf(out + offset, "/reselect=%u", p_pb_msti_port->reselect);
    offset += sal_sprintf(out + offset, "/role=%u", p_pb_msti_port->role);
    offset += sal_sprintf(out + offset, "/selected=%u", p_pb_msti_port->selected);
    offset += sal_sprintf(out + offset, "/selectedRole=%u", p_pb_msti_port->selectedrole);
    offset += sal_sprintf(out + offset, "/sync=%u", p_pb_msti_port->sync);
    offset += sal_sprintf(out + offset, "/synced=%u", p_pb_msti_port->synced);
    offset += sal_sprintf(out + offset, "/tcAck=%u", p_pb_msti_port->tcack);
    offset += sal_sprintf(out + offset, "/tcProp=%u", p_pb_msti_port->tcprop);
    offset += sal_sprintf(out + offset, "/txCount=%u", p_pb_msti_port->txcount);
    offset += sal_sprintf(out + offset, "/updtInfo=%u", p_pb_msti_port->updtinfo);
    offset += sal_sprintf(out + offset, "/reRooted=%u", p_pb_msti_port->rerooted);
    offset += sal_sprintf(out + offset, "/hopCount=%u", p_pb_msti_port->hopcount);
    offset += sal_sprintf(out + offset, "/ppm_state=%u", p_pb_msti_port->ppm_state);
    offset += sal_sprintf(out + offset, "/pim_state=%u", p_pb_msti_port->pim_state);
    offset += sal_sprintf(out + offset, "/prt_state=%u", p_pb_msti_port->prt_state);
    offset += sal_sprintf(out + offset, "/pst_state=%u", p_pb_msti_port->pst_state);
    offset += sal_sprintf(out + offset, "/tcm_state=%u", p_pb_msti_port->tcm_state);
    offset += sal_sprintf(out + offset, "/fea_state=%u", p_pb_msti_port->fea_state);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MSTP_INSTANCE */
int32
pb_tbl_mstp_instance_to_pb(uint32 only_key, tbl_mstp_instance_t *p_inst, Cdb__TblMstpInstance *p_pb_inst)
{
    p_pb_inst->key->instance = p_inst->key.instance;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_inst->has_instance_oid = TRUE;
    p_pb_inst->instance_oid = p_inst->instance_oid;
    p_pb_inst->has_vlan = TRUE;
    p_pb_inst->vlan.len = sizeof(p_inst->vlan);
    p_pb_inst->vlan.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_inst->vlan));
    sal_memcpy(p_pb_inst->vlan.data, p_inst->vlan, sizeof(p_inst->vlan));
    p_pb_inst->has_bridge_priority = TRUE;
    p_pb_inst->bridge_priority = p_inst->bridge_priority;
    pb_compose_mstp_brg_id_t_to_pb(&p_inst->bridge_id, p_pb_inst->bridge_id);
    p_pb_inst->has_root_portid = TRUE;
    p_pb_inst->root_portid = p_inst->root_portId;
    pb_compose_mstp_brg_id_t_to_pb(&p_inst->root_rootId, p_pb_inst->root_rootid);
    p_pb_inst->has_root_rootpathcost = TRUE;
    p_pb_inst->root_rootpathcost = p_inst->root_rootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_inst->root_designatedBridgeId, p_pb_inst->root_designatedbridgeid);
    p_pb_inst->has_root_designatedportid = TRUE;
    p_pb_inst->root_designatedportid = p_inst->root_designatedPortId;
    p_pb_inst->has_root_bridgeportid = TRUE;
    p_pb_inst->root_bridgeportid = p_inst->root_bridgePortId;
    p_pb_inst->has_root_messageage = TRUE;
    p_pb_inst->root_messageage = p_inst->root_messageAge;
    p_pb_inst->has_root_fwddelay = TRUE;
    p_pb_inst->root_fwddelay = p_inst->root_fwdDelay;
    p_pb_inst->has_root_hellotime = TRUE;
    p_pb_inst->root_hellotime = p_inst->root_helloTime;
    p_pb_inst->has_root_maxage = TRUE;
    p_pb_inst->root_maxage = p_inst->root_maxAge;
    p_pb_inst->has_prs_state = TRUE;
    p_pb_inst->prs_state = p_inst->prs_state;
    p_pb_inst->has_hopcount = TRUE;
    p_pb_inst->hopcount = p_inst->hopCount;

    return PM_E_NONE;
}

int32
pb_tbl_mstp_instance_to_pb_free_packed(Cdb__TblMstpInstance *p_pb_inst)
{
    if (p_pb_inst->vlan.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_inst->vlan.data);
        p_pb_inst->vlan.data = NULL;
    }

    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_inst->bridge_id);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_inst->root_rootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_inst->root_designatedbridgeid);
    return PM_E_NONE;
}

int32
pb_tbl_mstp_instance_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMstpInstanceKey pb_inst_key = CDB__TBL_MSTP_INSTANCE_KEY__INIT;
    Cdb__TblMstpInstance pb_inst = CDB__TBL_MSTP_INSTANCE__INIT;
    tbl_mstp_instance_t *p_inst = (tbl_mstp_instance_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMstpBrgIdT bridge_id = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT root_rootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT root_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;

    pb_inst.key = &pb_inst_key;
    pb_inst.bridge_id = &bridge_id;
    pb_inst.root_rootid = &root_rootid;
    pb_inst.root_designatedbridgeid = &root_designatedbridgeid;
    pb_tbl_mstp_instance_to_pb(only_key, p_inst, &pb_inst);
    len = cdb__tbl_mstp_instance__pack(&pb_inst, buf);
    pb_tbl_mstp_instance_to_pb_free_packed(&pb_inst);

    return len;
}

int32
pb_tbl_mstp_instance_dump(Cdb__TblMstpInstance *p_pb_inst, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->instance=%u", p_pb_inst->key->instance);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/instance_oid=%llu", p_pb_inst->instance_oid);
    offset += sal_sprintf(out + offset, "/vlan=");
    offset += pb_bitmap_array_dump(p_pb_inst->vlan.data, p_pb_inst->vlan.len, (out + offset));
    offset += sal_sprintf(out + offset, "/bridge_priority=%u", p_pb_inst->bridge_priority);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_inst->bridge_id, (out + offset));
    offset += sal_sprintf(out + offset, "/root_portId=%u", p_pb_inst->root_portid);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_inst->root_rootid, (out + offset));
    offset += sal_sprintf(out + offset, "/root_rootPathCost=%u", p_pb_inst->root_rootpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_inst->root_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/root_designatedPortId=%u", p_pb_inst->root_designatedportid);
    offset += sal_sprintf(out + offset, "/root_bridgePortId=%u", p_pb_inst->root_bridgeportid);
    offset += sal_sprintf(out + offset, "/root_messageAge=%u", p_pb_inst->root_messageage);
    offset += sal_sprintf(out + offset, "/root_fwdDelay=%u", p_pb_inst->root_fwddelay);
    offset += sal_sprintf(out + offset, "/root_helloTime=%u", p_pb_inst->root_hellotime);
    offset += sal_sprintf(out + offset, "/root_maxAge=%u", p_pb_inst->root_maxage);
    offset += sal_sprintf(out + offset, "/prs_state=%u", p_pb_inst->prs_state);
    offset += sal_sprintf(out + offset, "/hopCount=%u", p_pb_inst->hopcount);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MSTP_GLOBAL */
int32
pb_tbl_mstp_global_to_pb(uint32 only_key, tbl_mstp_global_t *p_mstp_glb, Cdb__TblMstpGlobal *p_pb_mstp_glb)
{
    p_pb_mstp_glb->has_type = TRUE;
    p_pb_mstp_glb->type = p_mstp_glb->type;
    p_pb_mstp_glb->has_no_mst_config = TRUE;
    p_pb_mstp_glb->no_mst_config = p_mstp_glb->no_mst_config;
    p_pb_mstp_glb->has_external_root_path_cost = TRUE;
    p_pb_mstp_glb->external_root_path_cost = p_mstp_glb->external_root_path_cost;
    p_pb_mstp_glb->has_internal_root_path_cost = TRUE;
    p_pb_mstp_glb->internal_root_path_cost = p_mstp_glb->internal_root_path_cost;
    p_pb_mstp_glb->has_root_portid = TRUE;
    p_pb_mstp_glb->root_portid = p_mstp_glb->root_portId;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_glb->root_rootId, p_pb_mstp_glb->root_rootid);
    p_pb_mstp_glb->has_root_rootpathcost = TRUE;
    p_pb_mstp_glb->root_rootpathcost = p_mstp_glb->root_rootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_glb->root_regionRootId, p_pb_mstp_glb->root_regionrootid);
    p_pb_mstp_glb->has_root_introotpathcost = TRUE;
    p_pb_mstp_glb->root_introotpathcost = p_mstp_glb->root_intRootPathCost;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_glb->root_designatedBridgeId, p_pb_mstp_glb->root_designatedbridgeid);
    p_pb_mstp_glb->has_root_designatedportid = TRUE;
    p_pb_mstp_glb->root_designatedportid = p_mstp_glb->root_designatedPortId;
    p_pb_mstp_glb->has_root_bridgeportid = TRUE;
    p_pb_mstp_glb->root_bridgeportid = p_mstp_glb->root_bridgePortId;
    p_pb_mstp_glb->has_root_messageage = TRUE;
    p_pb_mstp_glb->root_messageage = p_mstp_glb->root_messageAge;
    p_pb_mstp_glb->has_root_fwddelay = TRUE;
    p_pb_mstp_glb->root_fwddelay = p_mstp_glb->root_fwdDelay;
    p_pb_mstp_glb->has_root_hellotime = TRUE;
    p_pb_mstp_glb->root_hellotime = p_mstp_glb->root_helloTime;
    p_pb_mstp_glb->has_root_maxage = TRUE;
    p_pb_mstp_glb->root_maxage = p_mstp_glb->root_maxAge;
    p_pb_mstp_glb->has_bridge_fwddelay = TRUE;
    p_pb_mstp_glb->bridge_fwddelay = p_mstp_glb->bridge_fwdDelay;
    p_pb_mstp_glb->has_bridge_hellotime = TRUE;
    p_pb_mstp_glb->bridge_hellotime = p_mstp_glb->bridge_helloTime;
    p_pb_mstp_glb->has_bridge_maxage = TRUE;
    p_pb_mstp_glb->bridge_maxage = p_mstp_glb->bridge_maxAge;
    p_pb_mstp_glb->has_bridge_maxhops = TRUE;
    p_pb_mstp_glb->bridge_maxhops = p_mstp_glb->bridge_maxHops;
    p_pb_mstp_glb->has_bridge_priority = TRUE;
    p_pb_mstp_glb->bridge_priority = p_mstp_glb->bridge_priority;
    pb_compose_mstp_brg_id_t_to_pb(&p_mstp_glb->bridge_id, p_pb_mstp_glb->bridge_id);
    pb_compose_sal_time_t_to_pb(&p_mstp_glb->last_tc_time, p_pb_mstp_glb->last_tc_time);
    p_pb_mstp_glb->has_num_topo_changes = TRUE;
    p_pb_mstp_glb->num_topo_changes = p_mstp_glb->num_topo_changes;
    p_pb_mstp_glb->has_mlag_role = TRUE;
    p_pb_mstp_glb->mlag_role = p_mstp_glb->mlag_role;
    p_pb_mstp_glb->has_mlag_enable = TRUE;
    p_pb_mstp_glb->mlag_enable = p_mstp_glb->mlag_enable;
    p_pb_mstp_glb->has_enable = TRUE;
    p_pb_mstp_glb->enable = p_mstp_glb->enable;
    p_pb_mstp_glb->has_topology_change_detected = TRUE;
    p_pb_mstp_glb->topology_change_detected = p_mstp_glb->topology_change_detected;
    p_pb_mstp_glb->has_bpduguard = TRUE;
    p_pb_mstp_glb->bpduguard = p_mstp_glb->bpduguard;
    p_pb_mstp_glb->has_bpdufilter = TRUE;
    p_pb_mstp_glb->bpdufilter = p_mstp_glb->bpdufilter;
    p_pb_mstp_glb->has_admin_cisco = TRUE;
    p_pb_mstp_glb->admin_cisco = p_mstp_glb->admin_cisco;
    p_pb_mstp_glb->has_oper_cisco = TRUE;
    p_pb_mstp_glb->oper_cisco = p_mstp_glb->oper_cisco;
    p_pb_mstp_glb->has_txholdcount = TRUE;
    p_pb_mstp_glb->txholdcount = p_mstp_glb->txHoldCount;
    p_pb_mstp_glb->has_pathcost_standard = TRUE;
    p_pb_mstp_glb->pathcost_standard = p_mstp_glb->pathcost_standard;
    p_pb_mstp_glb->has_tc_protection = TRUE;
    p_pb_mstp_glb->tc_protection = p_mstp_glb->tc_protection;
    p_pb_mstp_glb->has_hopcount = TRUE;
    p_pb_mstp_glb->hopcount = p_mstp_glb->hopCount;
    p_pb_mstp_glb->has_recv_tcn_threshold = TRUE;
    p_pb_mstp_glb->recv_tcn_threshold = p_mstp_glb->recv_tcn_threshold;
    p_pb_mstp_glb->has_recv_tcn_number = TRUE;
    p_pb_mstp_glb->recv_tcn_number = p_mstp_glb->recv_tcn_number;
    p_pb_mstp_glb->has_root_port_ifindex = TRUE;
    p_pb_mstp_glb->root_port_ifindex = p_mstp_glb->root_port_ifindex;
    p_pb_mstp_glb->has_alternate_port_ifndex = TRUE;
    p_pb_mstp_glb->alternate_port_ifndex = p_mstp_glb->alternate_port_ifndex;
    p_pb_mstp_glb->has_prs_state = TRUE;
    p_pb_mstp_glb->prs_state = p_mstp_glb->prs_state;
    p_pb_mstp_glb->has_mstp_format_id = TRUE;
    p_pb_mstp_glb->mstp_format_id = p_mstp_glb->mstp_format_id;
    p_pb_mstp_glb->has_mstp_revision_level = TRUE;
    p_pb_mstp_glb->mstp_revision_level = p_mstp_glb->mstp_revision_level;
    p_pb_mstp_glb->mstp_region_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_mstp_glb->mstp_region_name)+1);
    sal_strcpy(p_pb_mstp_glb->mstp_region_name, p_mstp_glb->mstp_region_name);
    pb_compose_mstp_digest_t_to_pb(&p_mstp_glb->mstp_digest, p_pb_mstp_glb->mstp_digest);

    return PM_E_NONE;
}

int32
pb_tbl_mstp_global_to_pb_free_packed(Cdb__TblMstpGlobal *p_pb_mstp_glb)
{
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_glb->root_rootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_glb->root_regionrootid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_glb->root_designatedbridgeid);
    pb_compose_mstp_brg_id_t_to_pb_free_packed(p_pb_mstp_glb->bridge_id);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_mstp_glb->last_tc_time);
    if (p_pb_mstp_glb->mstp_region_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mstp_glb->mstp_region_name);
        p_pb_mstp_glb->mstp_region_name = NULL;
    }

    pb_compose_mstp_digest_t_to_pb_free_packed(p_pb_mstp_glb->mstp_digest);
    return PM_E_NONE;
}

int32
pb_tbl_mstp_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMstpGlobal pb_mstp_glb = CDB__TBL_MSTP_GLOBAL__INIT;
    tbl_mstp_global_t *p_mstp_glb = (tbl_mstp_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMstpBrgIdT root_rootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT root_regionrootid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT root_designatedbridgeid = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeMstpBrgIdT bridge_id = CDB__COMPOSE_MSTP_BRG_ID_T__INIT;
    Cdb__ComposeSalTimeT last_tc_time = CDB__COMPOSE_SAL_TIME_T__INIT;
    Cdb__ComposeMstpDigestT mstp_digest = CDB__COMPOSE_MSTP_DIGEST_T__INIT;

    pb_mstp_glb.root_rootid = &root_rootid;
    pb_mstp_glb.root_regionrootid = &root_regionrootid;
    pb_mstp_glb.root_designatedbridgeid = &root_designatedbridgeid;
    pb_mstp_glb.bridge_id = &bridge_id;
    pb_mstp_glb.last_tc_time = &last_tc_time;
    pb_mstp_glb.mstp_digest = &mstp_digest;
    pb_tbl_mstp_global_to_pb(only_key, p_mstp_glb, &pb_mstp_glb);
    len = cdb__tbl_mstp_global__pack(&pb_mstp_glb, buf);
    pb_tbl_mstp_global_to_pb_free_packed(&pb_mstp_glb);

    return len;
}

int32
pb_tbl_mstp_global_dump(Cdb__TblMstpGlobal *p_pb_mstp_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_mstp_glb->type);
    offset += sal_sprintf(out + offset, "/no_mst_config=%u", p_pb_mstp_glb->no_mst_config);
    offset += sal_sprintf(out + offset, "/external_root_path_cost=%u", p_pb_mstp_glb->external_root_path_cost);
    offset += sal_sprintf(out + offset, "/internal_root_path_cost=%u", p_pb_mstp_glb->internal_root_path_cost);
    offset += sal_sprintf(out + offset, "/root_portId=%u", p_pb_mstp_glb->root_portid);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_glb->root_rootid, (out + offset));
    offset += sal_sprintf(out + offset, "/root_rootPathCost=%u", p_pb_mstp_glb->root_rootpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_glb->root_regionrootid, (out + offset));
    offset += sal_sprintf(out + offset, "/root_intRootPathCost=%u", p_pb_mstp_glb->root_introotpathcost);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_glb->root_designatedbridgeid, (out + offset));
    offset += sal_sprintf(out + offset, "/root_designatedPortId=%u", p_pb_mstp_glb->root_designatedportid);
    offset += sal_sprintf(out + offset, "/root_bridgePortId=%u", p_pb_mstp_glb->root_bridgeportid);
    offset += sal_sprintf(out + offset, "/root_messageAge=%u", p_pb_mstp_glb->root_messageage);
    offset += sal_sprintf(out + offset, "/root_fwdDelay=%u", p_pb_mstp_glb->root_fwddelay);
    offset += sal_sprintf(out + offset, "/root_helloTime=%u", p_pb_mstp_glb->root_hellotime);
    offset += sal_sprintf(out + offset, "/root_maxAge=%u", p_pb_mstp_glb->root_maxage);
    offset += sal_sprintf(out + offset, "/bridge_fwdDelay=%u", p_pb_mstp_glb->bridge_fwddelay);
    offset += sal_sprintf(out + offset, "/bridge_helloTime=%u", p_pb_mstp_glb->bridge_hellotime);
    offset += sal_sprintf(out + offset, "/bridge_maxAge=%u", p_pb_mstp_glb->bridge_maxage);
    offset += sal_sprintf(out + offset, "/bridge_maxHops=%u", p_pb_mstp_glb->bridge_maxhops);
    offset += sal_sprintf(out + offset, "/bridge_priority=%u", p_pb_mstp_glb->bridge_priority);
    offset += pb_compose_mstp_brg_id_t_dump(p_pb_mstp_glb->bridge_id, (out + offset));
    offset += pb_compose_sal_time_t_dump(p_pb_mstp_glb->last_tc_time, (out + offset));
    offset += sal_sprintf(out + offset, "/num_topo_changes=%u", p_pb_mstp_glb->num_topo_changes);
    offset += sal_sprintf(out + offset, "/mlag_role=%u", p_pb_mstp_glb->mlag_role);
    offset += sal_sprintf(out + offset, "/mlag_enable=%u", p_pb_mstp_glb->mlag_enable);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_mstp_glb->enable);
    offset += sal_sprintf(out + offset, "/topology_change_detected=%u", p_pb_mstp_glb->topology_change_detected);
    offset += sal_sprintf(out + offset, "/bpduguard=%u", p_pb_mstp_glb->bpduguard);
    offset += sal_sprintf(out + offset, "/bpdufilter=%u", p_pb_mstp_glb->bpdufilter);
    offset += sal_sprintf(out + offset, "/admin_cisco=%u", p_pb_mstp_glb->admin_cisco);
    offset += sal_sprintf(out + offset, "/oper_cisco=%u", p_pb_mstp_glb->oper_cisco);
    offset += sal_sprintf(out + offset, "/txHoldCount=%u", p_pb_mstp_glb->txholdcount);
    offset += sal_sprintf(out + offset, "/pathcost_standard=%u", p_pb_mstp_glb->pathcost_standard);
    offset += sal_sprintf(out + offset, "/tc_protection=%u", p_pb_mstp_glb->tc_protection);
    offset += sal_sprintf(out + offset, "/hopCount=%u", p_pb_mstp_glb->hopcount);
    offset += sal_sprintf(out + offset, "/recv_tcn_threshold=%u", p_pb_mstp_glb->recv_tcn_threshold);
    offset += sal_sprintf(out + offset, "/recv_tcn_number=%u", p_pb_mstp_glb->recv_tcn_number);
    offset += sal_sprintf(out + offset, "/root_port_ifindex=%u", p_pb_mstp_glb->root_port_ifindex);
    offset += sal_sprintf(out + offset, "/alternate_port_ifndex=%u", p_pb_mstp_glb->alternate_port_ifndex);
    offset += sal_sprintf(out + offset, "/prs_state=%u", p_pb_mstp_glb->prs_state);
    offset += sal_sprintf(out + offset, "/mstp_format_id=%u", p_pb_mstp_glb->mstp_format_id);
    offset += sal_sprintf(out + offset, "/mstp_revision_level=%u", p_pb_mstp_glb->mstp_revision_level);
    offset += sal_sprintf(out + offset, "/mstp_region_name=%s", p_pb_mstp_glb->mstp_region_name);
    offset += pb_compose_mstp_digest_t_dump(p_pb_mstp_glb->mstp_digest, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LLDP_GLOBAL */
int32
pb_tbl_lldp_global_to_pb(uint32 only_key, tbl_lldp_global_t *p_lldp_glb, Cdb__TblLldpGlobal *p_pb_lldp_glb)
{
    p_pb_lldp_glb->has_enable = TRUE;
    p_pb_lldp_glb->enable = p_lldp_glb->enable;
    p_pb_lldp_glb->has_system_mac_en = TRUE;
    p_pb_lldp_glb->system_mac_en = p_lldp_glb->system_mac_en;
    p_pb_lldp_glb->has_config_flag = TRUE;
    p_pb_lldp_glb->config_flag = p_lldp_glb->config_flag;
    pb_compose_mac_addr_t_to_pb(p_lldp_glb->system_mac, p_pb_lldp_glb->system_mac);
    pb_compose_addr_t_to_pb(&p_lldp_glb->management_ip, p_pb_lldp_glb->management_ip);
    p_pb_lldp_glb->has_tx_hold = TRUE;
    p_pb_lldp_glb->tx_hold = p_lldp_glb->tx_hold;
    p_pb_lldp_glb->has_tx_interval = TRUE;
    p_pb_lldp_glb->tx_interval = p_lldp_glb->tx_interval;
    p_pb_lldp_glb->has_tx_delay = TRUE;
    p_pb_lldp_glb->tx_delay = p_lldp_glb->tx_delay;
    p_pb_lldp_glb->has_reinit_delay = TRUE;
    p_pb_lldp_glb->reinit_delay = p_lldp_glb->reinit_delay;
    p_pb_lldp_glb->has_system_capability = TRUE;
    p_pb_lldp_glb->system_capability = p_lldp_glb->system_capability;
    p_pb_lldp_glb->system_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_glb->system_name)+1);
    sal_strcpy(p_pb_lldp_glb->system_name, p_lldp_glb->system_name);
    p_pb_lldp_glb->system_desc = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_glb->system_desc)+1);
    sal_strcpy(p_pb_lldp_glb->system_desc, p_lldp_glb->system_desc);
    p_pb_lldp_glb->system_desc_default = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_glb->system_desc_default)+1);
    sal_strcpy(p_pb_lldp_glb->system_desc_default, p_lldp_glb->system_desc_default);

    return PM_E_NONE;
}

int32
pb_tbl_lldp_global_to_pb_free_packed(Cdb__TblLldpGlobal *p_pb_lldp_glb)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_lldp_glb->system_mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_lldp_glb->management_ip);
    if (p_pb_lldp_glb->system_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_glb->system_name);
        p_pb_lldp_glb->system_name = NULL;
    }

    if (p_pb_lldp_glb->system_desc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_glb->system_desc);
        p_pb_lldp_glb->system_desc = NULL;
    }

    if (p_pb_lldp_glb->system_desc_default)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_glb->system_desc_default);
        p_pb_lldp_glb->system_desc_default = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_lldp_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLldpGlobal pb_lldp_glb = CDB__TBL_LLDP_GLOBAL__INIT;
    tbl_lldp_global_t *p_lldp_glb = (tbl_lldp_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT system_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT management_ip = CDB__COMPOSE_ADDR_T__INIT;

    pb_lldp_glb.system_mac = &system_mac;
    pb_lldp_glb.management_ip = &management_ip;
    pb_tbl_lldp_global_to_pb(only_key, p_lldp_glb, &pb_lldp_glb);
    len = cdb__tbl_lldp_global__pack(&pb_lldp_glb, buf);
    pb_tbl_lldp_global_to_pb_free_packed(&pb_lldp_glb);

    return len;
}

int32
pb_tbl_lldp_global_dump(Cdb__TblLldpGlobal *p_pb_lldp_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_lldp_glb->enable);
    offset += sal_sprintf(out + offset, "/system_mac_en=%u", p_pb_lldp_glb->system_mac_en);
    offset += sal_sprintf(out + offset, "/config_flag=%u", p_pb_lldp_glb->config_flag);
    offset += pb_compose_mac_addr_t_dump(p_pb_lldp_glb->system_mac, (out + offset));
    offset += pb_compose_addr_t_dump(p_pb_lldp_glb->management_ip, (out + offset));
    offset += sal_sprintf(out + offset, "/tx_hold=%u", p_pb_lldp_glb->tx_hold);
    offset += sal_sprintf(out + offset, "/tx_interval=%u", p_pb_lldp_glb->tx_interval);
    offset += sal_sprintf(out + offset, "/tx_delay=%u", p_pb_lldp_glb->tx_delay);
    offset += sal_sprintf(out + offset, "/reinit_delay=%u", p_pb_lldp_glb->reinit_delay);
    offset += sal_sprintf(out + offset, "/system_capability=%u", p_pb_lldp_glb->system_capability);
    offset += sal_sprintf(out + offset, "/system_name=%s", p_pb_lldp_glb->system_name);
    offset += sal_sprintf(out + offset, "/system_desc=%s", p_pb_lldp_glb->system_desc);
    offset += sal_sprintf(out + offset, "/system_desc_default=%s", p_pb_lldp_glb->system_desc_default);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LLDP_IF */
int32
pb_tbl_lldp_if_to_pb(uint32 only_key, tbl_lldp_if_t *p_lldp_if, Cdb__TblLldpIf *p_pb_lldp_if)
{
    p_pb_lldp_if->key->ifindex = p_lldp_if->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_lldp_if->has_mode = TRUE;
    p_pb_lldp_if->mode = p_lldp_if->mode;
    p_pb_lldp_if->has_tx_ttl = TRUE;
    p_pb_lldp_if->tx_ttl = p_lldp_if->tx_ttl;
    p_pb_lldp_if->has_tx_count = TRUE;
    p_pb_lldp_if->tx_count = p_lldp_if->tx_count;
    p_pb_lldp_if->has_rx_count = TRUE;
    p_pb_lldp_if->rx_count = p_lldp_if->rx_count;
    p_pb_lldp_if->has_rx_error_count = TRUE;
    p_pb_lldp_if->rx_error_count = p_lldp_if->rx_error_count;
    p_pb_lldp_if->has_rx_discard_count = TRUE;
    p_pb_lldp_if->rx_discard_count = p_lldp_if->rx_discard_count;
    p_pb_lldp_if->has_tlv_discard_count = TRUE;
    p_pb_lldp_if->tlv_discard_count = p_lldp_if->tlv_discard_count;
    p_pb_lldp_if->has_tlv_unrecognized_count = TRUE;
    p_pb_lldp_if->tlv_unrecognized_count = p_lldp_if->tlv_unrecognized_count;
    p_pb_lldp_if->has_aged_count = TRUE;
    p_pb_lldp_if->aged_count = p_lldp_if->aged_count;
    p_pb_lldp_if->has_tlv_enable_basic = TRUE;
    p_pb_lldp_if->tlv_enable_basic = p_lldp_if->tlv_enable_basic;
    p_pb_lldp_if->has_tlv_enable_8021 = TRUE;
    p_pb_lldp_if->tlv_enable_8021 = p_lldp_if->tlv_enable_8021;
    p_pb_lldp_if->has_tlv_enable_8023 = TRUE;
    p_pb_lldp_if->tlv_enable_8023 = p_lldp_if->tlv_enable_8023;
    p_pb_lldp_if->has_tlv_enable_med = TRUE;
    p_pb_lldp_if->tlv_enable_med = p_lldp_if->tlv_enable_med;
    p_pb_lldp_if->has_ppvid_flag = TRUE;
    p_pb_lldp_if->ppvid_flag = p_lldp_if->ppvid_flag;
    p_pb_lldp_if->has_ppvid = TRUE;
    p_pb_lldp_if->ppvid = p_lldp_if->ppvid;
    p_pb_lldp_if->has_protocol_id = TRUE;
    p_pb_lldp_if->protocol_id = p_lldp_if->protocol_id;
    p_pb_lldp_if->vlan_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_if->vlan_name)+1);
    sal_strcpy(p_pb_lldp_if->vlan_name, p_lldp_if->vlan_name);
    p_pb_lldp_if->has_vlan_name_id = TRUE;
    p_pb_lldp_if->vlan_name_id = p_lldp_if->vlan_name_id;
    p_pb_lldp_if->has_mdi_support = TRUE;
    p_pb_lldp_if->mdi_support = p_lldp_if->mdi_support;
    p_pb_lldp_if->has_pse_power_pair = TRUE;
    p_pb_lldp_if->pse_power_pair = p_lldp_if->pse_power_pair;
    p_pb_lldp_if->has_power_class = TRUE;
    p_pb_lldp_if->power_class = p_lldp_if->power_class;
    p_pb_lldp_if->has_med_capbility = TRUE;
    p_pb_lldp_if->med_capbility = p_lldp_if->med_capbility;
    p_pb_lldp_if->has_med_dev_type = TRUE;
    p_pb_lldp_if->med_dev_type = p_lldp_if->med_dev_type;
    p_pb_lldp_if->has_med_power_flag = TRUE;
    p_pb_lldp_if->med_power_flag = p_lldp_if->med_power_flag;
    p_pb_lldp_if->has_med_power_value = TRUE;
    p_pb_lldp_if->med_power_value = p_lldp_if->med_power_value;
    p_pb_lldp_if->has_med_policy_flag = TRUE;
    p_pb_lldp_if->med_policy_flag = p_lldp_if->med_policy_flag;
    p_pb_lldp_if->has_med_lci_format = TRUE;
    p_pb_lldp_if->med_lci_format = p_lldp_if->med_lci_format;
    p_pb_lldp_if->med_lci_coordinate = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_if->med_lci_coordinate)+1);
    sal_strcpy(p_pb_lldp_if->med_lci_coordinate, p_lldp_if->med_lci_coordinate);
    p_pb_lldp_if->med_lci_elin = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_lldp_if->med_lci_elin)+1);
    sal_strcpy(p_pb_lldp_if->med_lci_elin, p_lldp_if->med_lci_elin);
    pb_compose_lldp_civic_address_t_to_pb(&p_lldp_if->med_lci_civic, p_pb_lldp_if->med_lci_civic);

    return PM_E_NONE;
}

int32
pb_tbl_lldp_if_to_pb_free_packed(Cdb__TblLldpIf *p_pb_lldp_if)
{
    if (p_pb_lldp_if->vlan_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_if->vlan_name);
        p_pb_lldp_if->vlan_name = NULL;
    }

    if (p_pb_lldp_if->med_lci_coordinate)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_if->med_lci_coordinate);
        p_pb_lldp_if->med_lci_coordinate = NULL;
    }

    if (p_pb_lldp_if->med_lci_elin)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lldp_if->med_lci_elin);
        p_pb_lldp_if->med_lci_elin = NULL;
    }

    pb_compose_lldp_civic_address_t_to_pb_free_packed(p_pb_lldp_if->med_lci_civic);
    return PM_E_NONE;
}

int32
pb_tbl_lldp_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLldpIfKey pb_lldp_if_key = CDB__TBL_LLDP_IF_KEY__INIT;
    Cdb__TblLldpIf pb_lldp_if = CDB__TBL_LLDP_IF__INIT;
    tbl_lldp_if_t *p_lldp_if = (tbl_lldp_if_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeLldpCivicAddressT med_lci_civic = CDB__COMPOSE_LLDP_CIVIC_ADDRESS_T__INIT;

    pb_lldp_if.key = &pb_lldp_if_key;
    pb_lldp_if.med_lci_civic = &med_lci_civic;
    pb_tbl_lldp_if_to_pb(only_key, p_lldp_if, &pb_lldp_if);
    len = cdb__tbl_lldp_if__pack(&pb_lldp_if, buf);
    pb_tbl_lldp_if_to_pb_free_packed(&pb_lldp_if);

    return len;
}

int32
pb_tbl_lldp_if_dump(Cdb__TblLldpIf *p_pb_lldp_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_lldp_if->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_lldp_if->mode);
    offset += sal_sprintf(out + offset, "/tx_ttl=%u", p_pb_lldp_if->tx_ttl);
    offset += sal_sprintf(out + offset, "/tx_count=%u", p_pb_lldp_if->tx_count);
    offset += sal_sprintf(out + offset, "/rx_count=%u", p_pb_lldp_if->rx_count);
    offset += sal_sprintf(out + offset, "/rx_error_count=%u", p_pb_lldp_if->rx_error_count);
    offset += sal_sprintf(out + offset, "/rx_discard_count=%u", p_pb_lldp_if->rx_discard_count);
    offset += sal_sprintf(out + offset, "/tlv_discard_count=%u", p_pb_lldp_if->tlv_discard_count);
    offset += sal_sprintf(out + offset, "/tlv_unrecognized_count=%u", p_pb_lldp_if->tlv_unrecognized_count);
    offset += sal_sprintf(out + offset, "/aged_count=%u", p_pb_lldp_if->aged_count);
    offset += sal_sprintf(out + offset, "/tlv_enable_basic=%u", p_pb_lldp_if->tlv_enable_basic);
    offset += sal_sprintf(out + offset, "/tlv_enable_8021=%u", p_pb_lldp_if->tlv_enable_8021);
    offset += sal_sprintf(out + offset, "/tlv_enable_8023=%u", p_pb_lldp_if->tlv_enable_8023);
    offset += sal_sprintf(out + offset, "/tlv_enable_med=%u", p_pb_lldp_if->tlv_enable_med);
    offset += sal_sprintf(out + offset, "/ppvid_flag=%u", p_pb_lldp_if->ppvid_flag);
    offset += sal_sprintf(out + offset, "/ppvid=%u", p_pb_lldp_if->ppvid);
    offset += sal_sprintf(out + offset, "/protocol_id=%u", p_pb_lldp_if->protocol_id);
    offset += sal_sprintf(out + offset, "/vlan_name=%s", p_pb_lldp_if->vlan_name);
    offset += sal_sprintf(out + offset, "/vlan_name_id=%u", p_pb_lldp_if->vlan_name_id);
    offset += sal_sprintf(out + offset, "/mdi_support=%u", p_pb_lldp_if->mdi_support);
    offset += sal_sprintf(out + offset, "/pse_power_pair=%u", p_pb_lldp_if->pse_power_pair);
    offset += sal_sprintf(out + offset, "/power_class=%u", p_pb_lldp_if->power_class);
    offset += sal_sprintf(out + offset, "/med_capbility=%u", p_pb_lldp_if->med_capbility);
    offset += sal_sprintf(out + offset, "/med_dev_type=%u", p_pb_lldp_if->med_dev_type);
    offset += sal_sprintf(out + offset, "/med_power_flag=%u", p_pb_lldp_if->med_power_flag);
    offset += sal_sprintf(out + offset, "/med_power_value=%u", p_pb_lldp_if->med_power_value);
    offset += sal_sprintf(out + offset, "/med_policy_flag=%u", p_pb_lldp_if->med_policy_flag);
    offset += sal_sprintf(out + offset, "/med_lci_format=%u", p_pb_lldp_if->med_lci_format);
    offset += sal_sprintf(out + offset, "/med_lci_coordinate=%s", p_pb_lldp_if->med_lci_coordinate);
    offset += sal_sprintf(out + offset, "/med_lci_elin=%s", p_pb_lldp_if->med_lci_elin);
    offset += pb_compose_lldp_civic_address_t_dump(p_pb_lldp_if->med_lci_civic, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MLAG */
int32
pb_tbl_mlag_to_pb(uint32 only_key, tbl_mlag_t *p_mlag, Cdb__TblMlag *p_pb_mlag)
{
    p_pb_mlag->has_enable = TRUE;
    p_pb_mlag->enable = p_mlag->enable;
    pb_compose_addr_t_to_pb(&p_mlag->local_addr, p_pb_mlag->local_addr);
    p_pb_mlag->has_reload_delay_interval = TRUE;
    p_pb_mlag->reload_delay_interval = p_mlag->reload_delay_interval;
    p_pb_mlag->has_role = TRUE;
    p_pb_mlag->role = p_mlag->role;
    pb_compose_mac_addr_t_to_pb(p_mlag->local_sysid, p_pb_mlag->local_sysid);
    pb_compose_mac_addr_t_to_pb(p_mlag->remote_sysid, p_pb_mlag->remote_sysid);
    pb_compose_mac_addr_t_to_pb(p_mlag->mlag_sysid, p_pb_mlag->mlag_sysid);
    pb_compose_mac_addr_t_to_pb(p_mlag->peer_routemac, p_pb_mlag->peer_routemac);
    p_pb_mlag->has_local_syspri = TRUE;
    p_pb_mlag->local_syspri = p_mlag->local_syspri;
    p_pb_mlag->has_remote_syspri = TRUE;
    p_pb_mlag->remote_syspri = p_mlag->remote_syspri;
    p_pb_mlag->has_mlag_syspri = TRUE;
    p_pb_mlag->mlag_syspri = p_mlag->mlag_syspri;
    p_pb_mlag->has_peer_vlanif_bmp = TRUE;
    p_pb_mlag->peer_vlanif_bmp.len = sizeof(p_mlag->peer_vlanif_bmp);
    p_pb_mlag->peer_vlanif_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mlag->peer_vlanif_bmp));
    sal_memcpy(p_pb_mlag->peer_vlanif_bmp.data, p_mlag->peer_vlanif_bmp, sizeof(p_mlag->peer_vlanif_bmp));
    p_pb_mlag->has_peer_fdb_bmp = TRUE;
    p_pb_mlag->peer_fdb_bmp.len = sizeof(p_mlag->peer_fdb_bmp);
    p_pb_mlag->peer_fdb_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mlag->peer_fdb_bmp));
    sal_memcpy(p_pb_mlag->peer_fdb_bmp.data, p_mlag->peer_fdb_bmp, sizeof(p_mlag->peer_fdb_bmp));
    p_pb_mlag->has_peer_link_ifindex = TRUE;
    p_pb_mlag->peer_link_ifindex = p_mlag->peer_link_ifindex;
    p_pb_mlag->has_flush_fdb_mi = TRUE;
    p_pb_mlag->flush_fdb_mi = p_mlag->flush_fdb_mi;

    return PM_E_NONE;
}

int32
pb_tbl_mlag_to_pb_free_packed(Cdb__TblMlag *p_pb_mlag)
{
    pb_compose_addr_t_to_pb_free_packed(p_pb_mlag->local_addr);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mlag->local_sysid);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mlag->remote_sysid);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mlag->mlag_sysid);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mlag->peer_routemac);
    if (p_pb_mlag->peer_vlanif_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mlag->peer_vlanif_bmp.data);
        p_pb_mlag->peer_vlanif_bmp.data = NULL;
    }

    if (p_pb_mlag->peer_fdb_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mlag->peer_fdb_bmp.data);
        p_pb_mlag->peer_fdb_bmp.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_mlag_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMlag pb_mlag = CDB__TBL_MLAG__INIT;
    tbl_mlag_t *p_mlag = (tbl_mlag_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrT local_addr = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__ComposeMacAddrT local_sysid = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT remote_sysid = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT mlag_sysid = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT peer_routemac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_mlag.local_addr = &local_addr;
    pb_mlag.local_sysid = &local_sysid;
    pb_mlag.remote_sysid = &remote_sysid;
    pb_mlag.mlag_sysid = &mlag_sysid;
    pb_mlag.peer_routemac = &peer_routemac;
    pb_tbl_mlag_to_pb(only_key, p_mlag, &pb_mlag);
    len = cdb__tbl_mlag__pack(&pb_mlag, buf);
    pb_tbl_mlag_to_pb_free_packed(&pb_mlag);

    return len;
}

int32
pb_tbl_mlag_dump(Cdb__TblMlag *p_pb_mlag, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_mlag->enable);
    offset += pb_compose_addr_t_dump(p_pb_mlag->local_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/reload_delay_interval=%u", p_pb_mlag->reload_delay_interval);
    offset += sal_sprintf(out + offset, "/role=%u", p_pb_mlag->role);
    offset += pb_compose_mac_addr_t_dump(p_pb_mlag->local_sysid, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mlag->remote_sysid, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mlag->mlag_sysid, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mlag->peer_routemac, (out + offset));
    offset += sal_sprintf(out + offset, "/local_syspri=%u", p_pb_mlag->local_syspri);
    offset += sal_sprintf(out + offset, "/remote_syspri=%u", p_pb_mlag->remote_syspri);
    offset += sal_sprintf(out + offset, "/mlag_syspri=%u", p_pb_mlag->mlag_syspri);
    offset += sal_sprintf(out + offset, "/peer_vlanif_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mlag->peer_vlanif_bmp.data, p_pb_mlag->peer_vlanif_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/peer_fdb_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mlag->peer_fdb_bmp.data, p_pb_mlag->peer_fdb_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/peer_link_ifindex=%u", p_pb_mlag->peer_link_ifindex);
    offset += sal_sprintf(out + offset, "/flush_fdb_mi=%u", p_pb_mlag->flush_fdb_mi);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MLAG_PEER */
int32
pb_tbl_mlag_peer_to_pb(uint32 only_key, tbl_mlag_peer_t *p_peer, Cdb__TblMlagPeer *p_pb_peer)
{
    pb_compose_addr_t_to_pb(&p_peer->peer_addr, p_pb_peer->peer_addr);
    p_pb_peer->has_set_timers = TRUE;
    p_pb_peer->set_timers = p_peer->set_timers;
    p_pb_peer->has_holdtime = TRUE;
    p_pb_peer->holdtime = p_peer->holdtime;
    p_pb_peer->has_keepalive = TRUE;
    p_pb_peer->keepalive = p_peer->keepalive;
    p_pb_peer->has_server_sock = TRUE;
    p_pb_peer->server_sock = p_peer->server_sock;
    p_pb_peer->has_client_sock = TRUE;
    p_pb_peer->client_sock = p_peer->client_sock;
    p_pb_peer->has_v_auto_start = TRUE;
    p_pb_peer->v_auto_start = p_peer->v_auto_start;
    p_pb_peer->has_v_connect = TRUE;
    p_pb_peer->v_connect = p_peer->v_connect;
    p_pb_peer->has_v_holdtime = TRUE;
    p_pb_peer->v_holdtime = p_peer->v_holdtime;
    p_pb_peer->has_v_keepalive = TRUE;
    p_pb_peer->v_keepalive = p_peer->v_keepalive;
    p_pb_peer->has_open_in = TRUE;
    p_pb_peer->open_in = p_peer->open_in;
    p_pb_peer->has_open_out = TRUE;
    p_pb_peer->open_out = p_peer->open_out;
    p_pb_peer->has_keepalive_in = TRUE;
    p_pb_peer->keepalive_in = p_peer->keepalive_in;
    p_pb_peer->has_keepalive_out = TRUE;
    p_pb_peer->keepalive_out = p_peer->keepalive_out;
    p_pb_peer->has_fdbsync_in = TRUE;
    p_pb_peer->fdbsync_in = p_peer->fdbsync_in;
    p_pb_peer->has_fdbsync_out = TRUE;
    p_pb_peer->fdbsync_out = p_peer->fdbsync_out;
    p_pb_peer->has_failover_in = TRUE;
    p_pb_peer->failover_in = p_peer->failover_in;
    p_pb_peer->has_failover_out = TRUE;
    p_pb_peer->failover_out = p_peer->failover_out;
    p_pb_peer->has_conf_in = TRUE;
    p_pb_peer->conf_in = p_peer->conf_in;
    p_pb_peer->has_conf_out = TRUE;
    p_pb_peer->conf_out = p_peer->conf_out;
    p_pb_peer->has_syspri_in = TRUE;
    p_pb_peer->syspri_in = p_peer->syspri_in;
    p_pb_peer->has_syspri_out = TRUE;
    p_pb_peer->syspri_out = p_peer->syspri_out;
    p_pb_peer->has_peer_fdb_in = TRUE;
    p_pb_peer->peer_fdb_in = p_peer->peer_fdb_in;
    p_pb_peer->has_peer_fdb_out = TRUE;
    p_pb_peer->peer_fdb_out = p_peer->peer_fdb_out;
    p_pb_peer->has_stp_in = TRUE;
    p_pb_peer->stp_in = p_peer->stp_in;
    p_pb_peer->has_stp_out = TRUE;
    p_pb_peer->stp_out = p_peer->stp_out;
    p_pb_peer->has_stp_global_in = TRUE;
    p_pb_peer->stp_global_in = p_peer->stp_global_in;
    p_pb_peer->has_stp_global_out = TRUE;
    p_pb_peer->stp_global_out = p_peer->stp_global_out;
    p_pb_peer->has_stp_port_in = TRUE;
    p_pb_peer->stp_port_in = p_peer->stp_port_in;
    p_pb_peer->has_stp_port_out = TRUE;
    p_pb_peer->stp_port_out = p_peer->stp_port_out;
    p_pb_peer->has_stp_packet_in = TRUE;
    p_pb_peer->stp_packet_in = p_peer->stp_packet_in;
    p_pb_peer->has_stp_packet_out = TRUE;
    p_pb_peer->stp_packet_out = p_peer->stp_packet_out;
    p_pb_peer->has_stp_instance_in = TRUE;
    p_pb_peer->stp_instance_in = p_peer->stp_instance_in;
    p_pb_peer->has_stp_instance_out = TRUE;
    p_pb_peer->stp_instance_out = p_peer->stp_instance_out;
    p_pb_peer->has_stp_state_in = TRUE;
    p_pb_peer->stp_state_in = p_peer->stp_state_in;
    p_pb_peer->has_stp_state_out = TRUE;
    p_pb_peer->stp_state_out = p_peer->stp_state_out;
    p_pb_peer->has_established = TRUE;
    p_pb_peer->established = p_peer->established;
    p_pb_peer->has_dropped = TRUE;
    p_pb_peer->dropped = p_peer->dropped;
    p_pb_peer->has_ttl = TRUE;
    p_pb_peer->ttl = p_peer->ttl;
    pb_compose_sal_time_t_to_pb(&p_peer->uptime, p_pb_peer->uptime);
    pb_compose_sal_time_t_to_pb(&p_peer->lastread, p_pb_peer->lastread);
    p_pb_peer->has_mpf_state = TRUE;
    p_pb_peer->mpf_state = p_peer->mpf_state;

    return PM_E_NONE;
}

int32
pb_tbl_mlag_peer_to_pb_free_packed(Cdb__TblMlagPeer *p_pb_peer)
{
    pb_compose_addr_t_to_pb_free_packed(p_pb_peer->peer_addr);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_peer->uptime);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_peer->lastread);
    return PM_E_NONE;
}

int32
pb_tbl_mlag_peer_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMlagPeer pb_peer = CDB__TBL_MLAG_PEER__INIT;
    tbl_mlag_peer_t *p_peer = (tbl_mlag_peer_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrT peer_addr = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__ComposeSalTimeT uptime = CDB__COMPOSE_SAL_TIME_T__INIT;
    Cdb__ComposeSalTimeT lastread = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_peer.peer_addr = &peer_addr;
    pb_peer.uptime = &uptime;
    pb_peer.lastread = &lastread;
    pb_tbl_mlag_peer_to_pb(only_key, p_peer, &pb_peer);
    len = cdb__tbl_mlag_peer__pack(&pb_peer, buf);
    pb_tbl_mlag_peer_to_pb_free_packed(&pb_peer);

    return len;
}

int32
pb_tbl_mlag_peer_dump(Cdb__TblMlagPeer *p_pb_peer, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_addr_t_dump(p_pb_peer->peer_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/set_timers=%u", p_pb_peer->set_timers);
    offset += sal_sprintf(out + offset, "/holdtime=%u", p_pb_peer->holdtime);
    offset += sal_sprintf(out + offset, "/keepalive=%u", p_pb_peer->keepalive);
    offset += sal_sprintf(out + offset, "/server_sock=%d", p_pb_peer->server_sock);
    offset += sal_sprintf(out + offset, "/client_sock=%d", p_pb_peer->client_sock);
    offset += sal_sprintf(out + offset, "/v_auto_start=%u", p_pb_peer->v_auto_start);
    offset += sal_sprintf(out + offset, "/v_connect=%u", p_pb_peer->v_connect);
    offset += sal_sprintf(out + offset, "/v_holdtime=%u", p_pb_peer->v_holdtime);
    offset += sal_sprintf(out + offset, "/v_keepalive=%u", p_pb_peer->v_keepalive);
    offset += sal_sprintf(out + offset, "/open_in=%u", p_pb_peer->open_in);
    offset += sal_sprintf(out + offset, "/open_out=%u", p_pb_peer->open_out);
    offset += sal_sprintf(out + offset, "/keepalive_in=%u", p_pb_peer->keepalive_in);
    offset += sal_sprintf(out + offset, "/keepalive_out=%u", p_pb_peer->keepalive_out);
    offset += sal_sprintf(out + offset, "/fdbsync_in=%u", p_pb_peer->fdbsync_in);
    offset += sal_sprintf(out + offset, "/fdbsync_out=%u", p_pb_peer->fdbsync_out);
    offset += sal_sprintf(out + offset, "/failover_in=%u", p_pb_peer->failover_in);
    offset += sal_sprintf(out + offset, "/failover_out=%u", p_pb_peer->failover_out);
    offset += sal_sprintf(out + offset, "/conf_in=%u", p_pb_peer->conf_in);
    offset += sal_sprintf(out + offset, "/conf_out=%u", p_pb_peer->conf_out);
    offset += sal_sprintf(out + offset, "/syspri_in=%u", p_pb_peer->syspri_in);
    offset += sal_sprintf(out + offset, "/syspri_out=%u", p_pb_peer->syspri_out);
    offset += sal_sprintf(out + offset, "/peer_fdb_in=%u", p_pb_peer->peer_fdb_in);
    offset += sal_sprintf(out + offset, "/peer_fdb_out=%u", p_pb_peer->peer_fdb_out);
    offset += sal_sprintf(out + offset, "/stp_in=%u", p_pb_peer->stp_in);
    offset += sal_sprintf(out + offset, "/stp_out=%u", p_pb_peer->stp_out);
    offset += sal_sprintf(out + offset, "/stp_global_in=%u", p_pb_peer->stp_global_in);
    offset += sal_sprintf(out + offset, "/stp_global_out=%u", p_pb_peer->stp_global_out);
    offset += sal_sprintf(out + offset, "/stp_port_in=%u", p_pb_peer->stp_port_in);
    offset += sal_sprintf(out + offset, "/stp_port_out=%u", p_pb_peer->stp_port_out);
    offset += sal_sprintf(out + offset, "/stp_packet_in=%u", p_pb_peer->stp_packet_in);
    offset += sal_sprintf(out + offset, "/stp_packet_out=%u", p_pb_peer->stp_packet_out);
    offset += sal_sprintf(out + offset, "/stp_instance_in=%u", p_pb_peer->stp_instance_in);
    offset += sal_sprintf(out + offset, "/stp_instance_out=%u", p_pb_peer->stp_instance_out);
    offset += sal_sprintf(out + offset, "/stp_state_in=%u", p_pb_peer->stp_state_in);
    offset += sal_sprintf(out + offset, "/stp_state_out=%u", p_pb_peer->stp_state_out);
    offset += sal_sprintf(out + offset, "/established=%u", p_pb_peer->established);
    offset += sal_sprintf(out + offset, "/dropped=%u", p_pb_peer->dropped);
    offset += sal_sprintf(out + offset, "/ttl=%u", p_pb_peer->ttl);
    offset += pb_compose_sal_time_t_dump(p_pb_peer->uptime, (out + offset));
    offset += pb_compose_sal_time_t_dump(p_pb_peer->lastread, (out + offset));
    offset += sal_sprintf(out + offset, "/mpf_state=%u", p_pb_peer->mpf_state);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MLAG_PORT */
int32
pb_tbl_mlag_port_to_pb(uint32 only_key, tbl_mlag_port_t *p_port, Cdb__TblMlagPort *p_pb_port)
{
    p_pb_port->key->id = p_port->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_port->has_peer_conf = TRUE;
    p_pb_port->peer_conf = p_port->peer_conf;
    p_pb_port->has_peer_if_up = TRUE;
    p_pb_port->peer_if_up = p_port->peer_if_up;
    p_pb_port->has_stp_port_enable = TRUE;
    p_pb_port->stp_port_enable = p_port->stp_port_enable;
    p_pb_port->has_ifindex = TRUE;
    p_pb_port->ifindex = p_port->ifindex;
    p_pb_port->has_protect_en = TRUE;
    p_pb_port->protect_en = p_port->protect_en;

    return PM_E_NONE;
}

int32
pb_tbl_mlag_port_to_pb_free_packed(Cdb__TblMlagPort *p_pb_port)
{
    return PM_E_NONE;
}

int32
pb_tbl_mlag_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMlagPortKey pb_port_key = CDB__TBL_MLAG_PORT_KEY__INIT;
    Cdb__TblMlagPort pb_port = CDB__TBL_MLAG_PORT__INIT;
    tbl_mlag_port_t *p_port = (tbl_mlag_port_t*)p_tbl;
    int32 len = 0;

    pb_port.key = &pb_port_key;
    pb_tbl_mlag_port_to_pb(only_key, p_port, &pb_port);
    len = cdb__tbl_mlag_port__pack(&pb_port, buf);
    pb_tbl_mlag_port_to_pb_free_packed(&pb_port);

    return len;
}

int32
pb_tbl_mlag_port_dump(Cdb__TblMlagPort *p_pb_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_port->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/peer_conf=%u", p_pb_port->peer_conf);
    offset += sal_sprintf(out + offset, "/peer_if_up=%u", p_pb_port->peer_if_up);
    offset += sal_sprintf(out + offset, "/stp_port_enable=%u", p_pb_port->stp_port_enable);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_port->ifindex);
    offset += sal_sprintf(out + offset, "/protect_en=%u", p_pb_port->protect_en);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ISOLATION */
int32
pb_tbl_isolation_to_pb(uint32 only_key, tbl_isolation_t *p_iso, Cdb__TblIsolation *p_pb_iso)
{
    p_pb_iso->key->isolation_id = p_iso->key.isolation_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_iso->has_isolation_oid = TRUE;
    p_pb_iso->isolation_oid = p_iso->isolation_oid;

    return PM_E_NONE;
}

int32
pb_tbl_isolation_to_pb_free_packed(Cdb__TblIsolation *p_pb_iso)
{
    return PM_E_NONE;
}

int32
pb_tbl_isolation_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIsolationKey pb_iso_key = CDB__TBL_ISOLATION_KEY__INIT;
    Cdb__TblIsolation pb_iso = CDB__TBL_ISOLATION__INIT;
    tbl_isolation_t *p_iso = (tbl_isolation_t*)p_tbl;
    int32 len = 0;

    pb_iso.key = &pb_iso_key;
    pb_tbl_isolation_to_pb(only_key, p_iso, &pb_iso);
    len = cdb__tbl_isolation__pack(&pb_iso, buf);
    pb_tbl_isolation_to_pb_free_packed(&pb_iso);

    return len;
}

int32
pb_tbl_isolation_dump(Cdb__TblIsolation *p_pb_iso, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->isolation_id=%u", p_pb_iso->key->isolation_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/isolation_oid=%llu", p_pb_iso->isolation_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ROUTE_GLOBAL */
int32
pb_tbl_route_global_to_pb(uint32 only_key, tbl_route_global_t *p_rt_glb, Cdb__TblRouteGlobal *p_pb_rt_glb)
{
    p_pb_rt_glb->has_gratuitous_arp_learn_en = TRUE;
    p_pb_rt_glb->gratuitous_arp_learn_en = p_rt_glb->gratuitous_arp_learn_en;
    p_pb_rt_glb->has_arp_pkt_rx_count = TRUE;
    p_pb_rt_glb->arp_pkt_rx_count = p_rt_glb->arp_pkt_rx_count;
    p_pb_rt_glb->has_arp_pkt_tx_count = TRUE;
    p_pb_rt_glb->arp_pkt_tx_count = p_rt_glb->arp_pkt_tx_count;
    p_pb_rt_glb->has_arp_pkt_discard_count = TRUE;
    p_pb_rt_glb->arp_pkt_discard_count = p_rt_glb->arp_pkt_discard_count;
    p_pb_rt_glb->has_arp_count = TRUE;
    p_pb_rt_glb->arp_count = p_rt_glb->arp_count;
    p_pb_rt_glb->has_multipath_num = TRUE;
    p_pb_rt_glb->multipath_num = p_rt_glb->multipath_num;
    p_pb_rt_glb->has_max_static = TRUE;
    p_pb_rt_glb->max_static = p_rt_glb->max_static;
    p_pb_rt_glb->has_icmp_error_ratelimit = TRUE;
    p_pb_rt_glb->icmp_error_ratelimit = p_rt_glb->icmp_error_ratelimit;
    p_pb_rt_glb->has_current_static_routes = TRUE;
    p_pb_rt_glb->current_static_routes = p_rt_glb->current_static_routes;
    p_pb_rt_glb->has_current_ecmp_routes = TRUE;
    p_pb_rt_glb->current_ecmp_routes = p_rt_glb->current_ecmp_routes;
    p_pb_rt_glb->has_current_remote_routes = TRUE;
    p_pb_rt_glb->current_remote_routes = p_rt_glb->current_remote_routes;
    p_pb_rt_glb->has_current_host_routes = TRUE;
    p_pb_rt_glb->current_host_routes = p_rt_glb->current_host_routes;
    p_pb_rt_glb->has_active_local = TRUE;
    p_pb_rt_glb->active_local = p_rt_glb->active_local;
    p_pb_rt_glb->has_active_static = TRUE;
    p_pb_rt_glb->active_static = p_rt_glb->active_static;
    p_pb_rt_glb->has_active_connected = TRUE;
    p_pb_rt_glb->active_connected = p_rt_glb->active_connected;
    p_pb_rt_glb->has_active_rip = TRUE;
    p_pb_rt_glb->active_rip = p_rt_glb->active_rip;
    p_pb_rt_glb->has_active_ospf = TRUE;
    p_pb_rt_glb->active_ospf = p_rt_glb->active_ospf;
    p_pb_rt_glb->has_active_bgp = TRUE;
    p_pb_rt_glb->active_bgp = p_rt_glb->active_bgp;
    p_pb_rt_glb->has_arpinsp_logbuf_entrynum = TRUE;
    p_pb_rt_glb->arpinsp_logbuf_entrynum = p_rt_glb->arpinsp_logbuf_entrynum;
    p_pb_rt_glb->has_arpinsp_logbuf_curnum = TRUE;
    p_pb_rt_glb->arpinsp_logbuf_curnum = p_rt_glb->arpinsp_logbuf_curnum;
    p_pb_rt_glb->has_arpinsp_logbuf_lognum = TRUE;
    p_pb_rt_glb->arpinsp_logbuf_lognum = p_rt_glb->arpinsp_logbuf_lognum;
    p_pb_rt_glb->has_arpinsp_logbuf_logsec = TRUE;
    p_pb_rt_glb->arpinsp_logbuf_logsec = p_rt_glb->arpinsp_logbuf_logsec;
    p_pb_rt_glb->has_arpinsp_validate_flag = TRUE;
    p_pb_rt_glb->arpinsp_validate_flag = p_rt_glb->arpinsp_validate_flag;
    p_pb_rt_glb->has_fib_full = TRUE;
    p_pb_rt_glb->fib_full = p_rt_glb->fib_full;

    return PM_E_NONE;
}

int32
pb_tbl_route_global_to_pb_free_packed(Cdb__TblRouteGlobal *p_pb_rt_glb)
{
    return PM_E_NONE;
}

int32
pb_tbl_route_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRouteGlobal pb_rt_glb = CDB__TBL_ROUTE_GLOBAL__INIT;
    tbl_route_global_t *p_rt_glb = (tbl_route_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_route_global_to_pb(only_key, p_rt_glb, &pb_rt_glb);
    len = cdb__tbl_route_global__pack(&pb_rt_glb, buf);
    pb_tbl_route_global_to_pb_free_packed(&pb_rt_glb);

    return len;
}

int32
pb_tbl_route_global_dump(Cdb__TblRouteGlobal *p_pb_rt_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/gratuitous_arp_learn_en=%u", p_pb_rt_glb->gratuitous_arp_learn_en);
    offset += sal_sprintf(out + offset, "/arp_pkt_rx_count=%u", p_pb_rt_glb->arp_pkt_rx_count);
    offset += sal_sprintf(out + offset, "/arp_pkt_tx_count=%u", p_pb_rt_glb->arp_pkt_tx_count);
    offset += sal_sprintf(out + offset, "/arp_pkt_discard_count=%u", p_pb_rt_glb->arp_pkt_discard_count);
    offset += sal_sprintf(out + offset, "/arp_count=%u", p_pb_rt_glb->arp_count);
    offset += sal_sprintf(out + offset, "/multipath_num=%u", p_pb_rt_glb->multipath_num);
    offset += sal_sprintf(out + offset, "/max_static=%u", p_pb_rt_glb->max_static);
    offset += sal_sprintf(out + offset, "/icmp_error_ratelimit=%u", p_pb_rt_glb->icmp_error_ratelimit);
    offset += sal_sprintf(out + offset, "/current_static_routes=%u", p_pb_rt_glb->current_static_routes);
    offset += sal_sprintf(out + offset, "/current_ecmp_routes=%u", p_pb_rt_glb->current_ecmp_routes);
    offset += sal_sprintf(out + offset, "/current_remote_routes=%u", p_pb_rt_glb->current_remote_routes);
    offset += sal_sprintf(out + offset, "/current_host_routes=%u", p_pb_rt_glb->current_host_routes);
    offset += sal_sprintf(out + offset, "/active_local=%u", p_pb_rt_glb->active_local);
    offset += sal_sprintf(out + offset, "/active_static=%u", p_pb_rt_glb->active_static);
    offset += sal_sprintf(out + offset, "/active_connected=%u", p_pb_rt_glb->active_connected);
    offset += sal_sprintf(out + offset, "/active_rip=%u", p_pb_rt_glb->active_rip);
    offset += sal_sprintf(out + offset, "/active_ospf=%u", p_pb_rt_glb->active_ospf);
    offset += sal_sprintf(out + offset, "/active_bgp=%u", p_pb_rt_glb->active_bgp);
    offset += sal_sprintf(out + offset, "/arpinsp_logbuf_entrynum=%u", p_pb_rt_glb->arpinsp_logbuf_entrynum);
    offset += sal_sprintf(out + offset, "/arpinsp_logbuf_curnum=%u", p_pb_rt_glb->arpinsp_logbuf_curnum);
    offset += sal_sprintf(out + offset, "/arpinsp_logbuf_lognum=%u", p_pb_rt_glb->arpinsp_logbuf_lognum);
    offset += sal_sprintf(out + offset, "/arpinsp_logbuf_logsec=%u", p_pb_rt_glb->arpinsp_logbuf_logsec);
    offset += sal_sprintf(out + offset, "/arpinsp_validate_flag=%u", p_pb_rt_glb->arpinsp_validate_flag);
    offset += sal_sprintf(out + offset, "/fib_full=%u", p_pb_rt_glb->fib_full);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OSPF */
int32
pb_tbl_ospf_to_pb(uint32 only_key, tbl_ospf_t *p_ospf, Cdb__TblOspf *p_pb_ospf)
{
    p_pb_ospf->key->id = p_ospf->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_addr_ipv4_t_to_pb(&p_ospf->router_id, p_pb_ospf->router_id);
    p_pb_ospf->has_default_originate = TRUE;
    p_pb_ospf->default_originate = p_ospf->default_originate;
    p_pb_ospf->has_redistribute = TRUE;
    p_pb_ospf->redistribute = p_ospf->redistribute;

    return PM_E_NONE;
}

int32
pb_tbl_ospf_to_pb_free_packed(Cdb__TblOspf *p_pb_ospf)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ospf->router_id);
    return PM_E_NONE;
}

int32
pb_tbl_ospf_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOspfKey pb_ospf_key = CDB__TBL_OSPF_KEY__INIT;
    Cdb__TblOspf pb_ospf = CDB__TBL_OSPF__INIT;
    tbl_ospf_t *p_ospf = (tbl_ospf_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T router_id = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_ospf.key = &pb_ospf_key;
    pb_ospf.router_id = &router_id;
    pb_tbl_ospf_to_pb(only_key, p_ospf, &pb_ospf);
    len = cdb__tbl_ospf__pack(&pb_ospf, buf);
    pb_tbl_ospf_to_pb_free_packed(&pb_ospf);

    return len;
}

int32
pb_tbl_ospf_dump(Cdb__TblOspf *p_pb_ospf, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_ospf->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ospf->router_id, (out + offset));
    offset += sal_sprintf(out + offset, "/default_originate=%u", p_pb_ospf->default_originate);
    offset += sal_sprintf(out + offset, "/redistribute=%u", p_pb_ospf->redistribute);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OSPF_NETWORK */
int32
pb_tbl_ospf_network_to_pb(uint32 only_key, tbl_ospf_network_t *p_ospf_network, Cdb__TblOspfNetwork *p_pb_ospf_network)
{
    pb_compose_prefix_t_to_pb(&p_ospf_network->key, p_pb_ospf_network->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ospf_network->has_area_id = TRUE;
    p_pb_ospf_network->area_id = p_ospf_network->area_id;

    return PM_E_NONE;
}

int32
pb_tbl_ospf_network_to_pb_free_packed(Cdb__TblOspfNetwork *p_pb_ospf_network)
{
    pb_compose_prefix_t_to_pb_free_packed(p_pb_ospf_network->key);
    return PM_E_NONE;
}

int32
pb_tbl_ospf_network_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOspfNetworkKey pb_ospf_network_key = CDB__TBL_OSPF_NETWORK_KEY__INIT;
    Cdb__TblOspfNetwork pb_ospf_network = CDB__TBL_OSPF_NETWORK__INIT;
    tbl_ospf_network_t *p_ospf_network = (tbl_ospf_network_t*)p_tbl;
    int32 len = 0;

    pb_ospf_network.key = &pb_ospf_network_key;
    pb_tbl_ospf_network_to_pb(only_key, p_ospf_network, &pb_ospf_network);
    len = cdb__tbl_ospf_network__pack(&pb_ospf_network, buf);
    pb_tbl_ospf_network_to_pb_free_packed(&pb_ospf_network);

    return len;
}

int32
pb_tbl_ospf_network_dump(Cdb__TblOspfNetwork *p_pb_ospf_network, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_prefix_t_dump(p_pb_ospf_network->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/area_id=%u", p_pb_ospf_network->area_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OSPF_AREA_AUTH */
int32
pb_tbl_ospf_area_auth_to_pb(uint32 only_key, tbl_ospf_area_auth_t *p_ospf_area_auth, Cdb__TblOspfAreaAuth *p_pb_ospf_area_auth)
{
    p_pb_ospf_area_auth->key->areaid = p_ospf_area_auth->key.areaid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ospf_area_auth->has_auth_type = TRUE;
    p_pb_ospf_area_auth->auth_type = p_ospf_area_auth->auth_type;

    return PM_E_NONE;
}

int32
pb_tbl_ospf_area_auth_to_pb_free_packed(Cdb__TblOspfAreaAuth *p_pb_ospf_area_auth)
{
    return PM_E_NONE;
}

int32
pb_tbl_ospf_area_auth_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOspfAreaAuthKey pb_ospf_area_auth_key = CDB__TBL_OSPF_AREA_AUTH_KEY__INIT;
    Cdb__TblOspfAreaAuth pb_ospf_area_auth = CDB__TBL_OSPF_AREA_AUTH__INIT;
    tbl_ospf_area_auth_t *p_ospf_area_auth = (tbl_ospf_area_auth_t*)p_tbl;
    int32 len = 0;

    pb_ospf_area_auth.key = &pb_ospf_area_auth_key;
    pb_tbl_ospf_area_auth_to_pb(only_key, p_ospf_area_auth, &pb_ospf_area_auth);
    len = cdb__tbl_ospf_area_auth__pack(&pb_ospf_area_auth, buf);
    pb_tbl_ospf_area_auth_to_pb_free_packed(&pb_ospf_area_auth);

    return len;
}

int32
pb_tbl_ospf_area_auth_dump(Cdb__TblOspfAreaAuth *p_pb_ospf_area_auth, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->areaid=%u", p_pb_ospf_area_auth->key->areaid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/auth_type=%u", p_pb_ospf_area_auth->auth_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IPROUTE_NODE */
int32
pb_tbl_iproute_node_to_pb(uint32 only_key, tbl_iproute_node_t *p_rn, Cdb__TblIprouteNode *p_pb_rn)
{
    pb_compose_route_node_key_t_to_pb(&p_rn->key, p_pb_rn->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rn->has_distance = TRUE;
    p_pb_rn->distance = p_rn->distance;
    p_pb_rn->has_multipath = TRUE;
    p_pb_rn->multipath = p_rn->multipath;
    pb_compose_nexthop_key_t_to_pb(&p_rn->nh_key, p_pb_rn->nh_key);
    pb_compose_nexthop_ecmp_t_to_pb(&p_rn->nh_group, p_pb_rn->nh_group);

    return PM_E_NONE;
}

int32
pb_tbl_iproute_node_to_pb_free_packed(Cdb__TblIprouteNode *p_pb_rn)
{
    pb_compose_route_node_key_t_to_pb_free_packed(p_pb_rn->key);
    pb_compose_nexthop_key_t_to_pb_free_packed(p_pb_rn->nh_key);
    pb_compose_nexthop_ecmp_t_to_pb_free_packed(p_pb_rn->nh_group);
    return PM_E_NONE;
}

int32
pb_tbl_iproute_node_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIprouteNodeKey pb_rn_key = CDB__TBL_IPROUTE_NODE_KEY__INIT;
    Cdb__TblIprouteNode pb_rn = CDB__TBL_IPROUTE_NODE__INIT;
    tbl_iproute_node_t *p_rn = (tbl_iproute_node_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeNexthopKeyT nh_key = CDB__COMPOSE_NEXTHOP_KEY_T__INIT;
    Cdb__ComposeNexthopEcmpT nh_group = CDB__COMPOSE_NEXTHOP_ECMP_T__INIT;

    pb_rn.key = &pb_rn_key;
    pb_rn.nh_key = &nh_key;
    pb_rn.nh_group = &nh_group;
    pb_tbl_iproute_node_to_pb(only_key, p_rn, &pb_rn);
    len = cdb__tbl_iproute_node__pack(&pb_rn, buf);
    pb_tbl_iproute_node_to_pb_free_packed(&pb_rn);

    return len;
}

int32
pb_tbl_iproute_node_dump(Cdb__TblIprouteNode *p_pb_rn, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_route_node_key_t_dump(p_pb_rn->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/distance=%u", p_pb_rn->distance);
    offset += sal_sprintf(out + offset, "/multipath=%u", p_pb_rn->multipath);
    offset += pb_compose_nexthop_key_t_dump(p_pb_rn->nh_key, (out + offset));
    offset += pb_compose_nexthop_ecmp_t_dump(p_pb_rn->nh_group, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_STATIC_ROUTE_CFG */
int32
pb_tbl_static_route_cfg_to_pb(uint32 only_key, tbl_static_route_cfg_t *p_rst_cfg, Cdb__TblStaticRouteCfg *p_pb_rst_cfg)
{
    pb_compose_route_node_key_t_to_pb(&p_rst_cfg->key, p_pb_rst_cfg->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rst_cfg->has_distance = TRUE;
    p_pb_rst_cfg->distance = p_rst_cfg->distance;

    return PM_E_NONE;
}

int32
pb_tbl_static_route_cfg_to_pb_free_packed(Cdb__TblStaticRouteCfg *p_pb_rst_cfg)
{
    pb_compose_route_node_key_t_to_pb_free_packed(p_pb_rst_cfg->key);
    return PM_E_NONE;
}

int32
pb_tbl_static_route_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblStaticRouteCfgKey pb_rst_cfg_key = CDB__TBL_STATIC_ROUTE_CFG_KEY__INIT;
    Cdb__TblStaticRouteCfg pb_rst_cfg = CDB__TBL_STATIC_ROUTE_CFG__INIT;
    tbl_static_route_cfg_t *p_rst_cfg = (tbl_static_route_cfg_t*)p_tbl;
    int32 len = 0;

    pb_rst_cfg.key = &pb_rst_cfg_key;
    pb_tbl_static_route_cfg_to_pb(only_key, p_rst_cfg, &pb_rst_cfg);
    len = cdb__tbl_static_route_cfg__pack(&pb_rst_cfg, buf);
    pb_tbl_static_route_cfg_to_pb_free_packed(&pb_rst_cfg);

    return len;
}

int32
pb_tbl_static_route_cfg_dump(Cdb__TblStaticRouteCfg *p_pb_rst_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_route_node_key_t_dump(p_pb_rst_cfg->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/distance=%u", p_pb_rst_cfg->distance);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_STATIC_RT_CNT */
int32
pb_tbl_static_rt_cnt_to_pb(uint32 only_key, tbl_static_rt_cnt_t *p_rt_cnt, Cdb__TblStaticRtCnt *p_pb_rt_cnt)
{
    pb_compose_route_node_key_t_to_pb(&p_rt_cnt->key, p_pb_rt_cnt->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rt_cnt->has_refer_cnt = TRUE;
    p_pb_rt_cnt->refer_cnt = p_rt_cnt->refer_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_static_rt_cnt_to_pb_free_packed(Cdb__TblStaticRtCnt *p_pb_rt_cnt)
{
    pb_compose_route_node_key_t_to_pb_free_packed(p_pb_rt_cnt->key);
    return PM_E_NONE;
}

int32
pb_tbl_static_rt_cnt_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblStaticRtCntKey pb_rt_cnt_key = CDB__TBL_STATIC_RT_CNT_KEY__INIT;
    Cdb__TblStaticRtCnt pb_rt_cnt = CDB__TBL_STATIC_RT_CNT__INIT;
    tbl_static_rt_cnt_t *p_rt_cnt = (tbl_static_rt_cnt_t*)p_tbl;
    int32 len = 0;

    pb_rt_cnt.key = &pb_rt_cnt_key;
    pb_tbl_static_rt_cnt_to_pb(only_key, p_rt_cnt, &pb_rt_cnt);
    len = cdb__tbl_static_rt_cnt__pack(&pb_rt_cnt, buf);
    pb_tbl_static_rt_cnt_to_pb_free_packed(&pb_rt_cnt);

    return len;
}

int32
pb_tbl_static_rt_cnt_dump(Cdb__TblStaticRtCnt *p_pb_rt_cnt, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_route_node_key_t_dump(p_pb_rt_cnt->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/refer_cnt=%u", p_pb_rt_cnt->refer_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ARP_FIB */
int32
pb_tbl_arp_fib_to_pb(uint32 only_key, tbl_arp_fib_t *p_arp_fib, Cdb__TblArpFib *p_pb_arp_fib)
{
    pb_compose_addr_ipv4_t_to_pb(&p_arp_fib->key.ip, p_pb_arp_fib->key->ip);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_arp_fib->has_ifindex = TRUE;
    p_pb_arp_fib->ifindex = p_arp_fib->ifindex;
    p_pb_arp_fib->has_type = TRUE;
    p_pb_arp_fib->type = p_arp_fib->type;
    p_pb_arp_fib->has_vrf_id = TRUE;
    p_pb_arp_fib->vrf_id = p_arp_fib->vrf_id;
    p_pb_arp_fib->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_arp_fib->ifname)+1);
    sal_strcpy(p_pb_arp_fib->ifname, p_arp_fib->ifname);
    p_pb_arp_fib->has_flags = TRUE;
    p_pb_arp_fib->flags = p_arp_fib->flags;
    pb_compose_mac_addr_t_to_pb(p_arp_fib->mac_addr, p_pb_arp_fib->mac_addr);
    p_pb_arp_fib->has_is_router = TRUE;
    p_pb_arp_fib->is_router = p_arp_fib->is_router;
    p_pb_arp_fib->has_route_ref = TRUE;
    p_pb_arp_fib->route_ref = p_arp_fib->route_ref;

    return PM_E_NONE;
}

int32
pb_tbl_arp_fib_to_pb_free_packed(Cdb__TblArpFib *p_pb_arp_fib)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_arp_fib->key->ip);
    if (p_pb_arp_fib->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_arp_fib->ifname);
        p_pb_arp_fib->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_arp_fib->mac_addr);
    return PM_E_NONE;
}

int32
pb_tbl_arp_fib_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__TblArpFibKey pb_arp_fib_key = CDB__TBL_ARP_FIB_KEY__INIT;
    Cdb__TblArpFib pb_arp_fib = CDB__TBL_ARP_FIB__INIT;
    tbl_arp_fib_t *p_arp_fib = (tbl_arp_fib_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_arp_fib_key.ip = &ip;
    pb_arp_fib.key = &pb_arp_fib_key;
    pb_arp_fib.mac_addr = &mac_addr;
    pb_tbl_arp_fib_to_pb(only_key, p_arp_fib, &pb_arp_fib);
    len = cdb__tbl_arp_fib__pack(&pb_arp_fib, buf);
    pb_tbl_arp_fib_to_pb_free_packed(&pb_arp_fib);

    return len;
}

int32
pb_tbl_arp_fib_dump(Cdb__TblArpFib *p_pb_arp_fib, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_addr_ipv4_t_dump(p_pb_arp_fib->key->ip, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_arp_fib->ifindex);
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_arp_fib->type);
    offset += sal_sprintf(out + offset, "/vrf_id=%u", p_pb_arp_fib->vrf_id);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_arp_fib->ifname);
    offset += sal_sprintf(out + offset, "/flags=%u", p_pb_arp_fib->flags);
    offset += pb_compose_mac_addr_t_dump(p_pb_arp_fib->mac_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/is_router=%u", p_pb_arp_fib->is_router);
    offset += sal_sprintf(out + offset, "/route_ref=%u", p_pb_arp_fib->route_ref);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ARP */
int32
pb_tbl_arp_to_pb(uint32 only_key, tbl_arp_t *p_arp, Cdb__TblArp *p_pb_arp)
{
    pb_compose_addr_ipv4_t_to_pb(&p_arp->key.ip, p_pb_arp->key->ip);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_arp->has_type = TRUE;
    p_pb_arp->type = p_arp->type;
    p_pb_arp->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_arp->ifname)+1);
    sal_strcpy(p_pb_arp->ifname, p_arp->ifname);
    p_pb_arp->has_vrf_id = TRUE;
    p_pb_arp->vrf_id = p_arp->vrf_id;
    pb_compose_mac_addr_t_to_pb(p_arp->mac_addr, p_pb_arp->mac_addr);
    p_pb_arp->has_rif_id = TRUE;
    p_pb_arp->rif_id = p_arp->rif_id;
    p_pb_arp->has_ifindex = TRUE;
    p_pb_arp->ifindex = p_arp->ifindex;
    p_pb_arp->has_flags = TRUE;
    p_pb_arp->flags = p_arp->flags;
    p_pb_arp->has_status = TRUE;
    p_pb_arp->status = p_arp->status;
    p_pb_arp->has_route_ref = TRUE;
    p_pb_arp->route_ref = p_arp->route_ref;
    pb_compose_sal_time_t_to_pb(&p_arp->uptime, p_pb_arp->uptime);
    p_pb_arp->has_aging_delay = TRUE;
    p_pb_arp->aging_delay = p_arp->aging_delay;
    p_pb_arp->has_is_gratuitous = TRUE;
    p_pb_arp->is_gratuitous = p_arp->is_gratuitous;
    p_pb_arp->has_is_proxy = TRUE;
    p_pb_arp->is_proxy = p_arp->is_proxy;
    p_pb_arp->has_is_router = TRUE;
    p_pb_arp->is_router = p_arp->is_router;
    p_pb_arp->has_retry_count = TRUE;
    p_pb_arp->retry_count = p_arp->retry_count;
    p_pb_arp->has_is_bfd_ref = TRUE;
    p_pb_arp->is_bfd_ref = p_arp->is_bfd_ref;

    return PM_E_NONE;
}

int32
pb_tbl_arp_to_pb_free_packed(Cdb__TblArp *p_pb_arp)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_arp->key->ip);
    if (p_pb_arp->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_arp->ifname);
        p_pb_arp->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_arp->mac_addr);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_arp->uptime);
    return PM_E_NONE;
}

int32
pb_tbl_arp_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__TblArpKey pb_arp_key = CDB__TBL_ARP_KEY__INIT;
    Cdb__TblArp pb_arp = CDB__TBL_ARP__INIT;
    tbl_arp_t *p_arp = (tbl_arp_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeSalTimeT uptime = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_arp_key.ip = &ip;
    pb_arp.key = &pb_arp_key;
    pb_arp.mac_addr = &mac_addr;
    pb_arp.uptime = &uptime;
    pb_tbl_arp_to_pb(only_key, p_arp, &pb_arp);
    len = cdb__tbl_arp__pack(&pb_arp, buf);
    pb_tbl_arp_to_pb_free_packed(&pb_arp);

    return len;
}

int32
pb_tbl_arp_dump(Cdb__TblArp *p_pb_arp, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_addr_ipv4_t_dump(p_pb_arp->key->ip, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_arp->type);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_arp->ifname);
    offset += sal_sprintf(out + offset, "/vrf_id=%u", p_pb_arp->vrf_id);
    offset += pb_compose_mac_addr_t_dump(p_pb_arp->mac_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/rif_id=%llu", p_pb_arp->rif_id);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_arp->ifindex);
    offset += sal_sprintf(out + offset, "/flags=%u", p_pb_arp->flags);
    offset += sal_sprintf(out + offset, "/status=%u", p_pb_arp->status);
    offset += sal_sprintf(out + offset, "/route_ref=%u", p_pb_arp->route_ref);
    offset += pb_compose_sal_time_t_dump(p_pb_arp->uptime, (out + offset));
    offset += sal_sprintf(out + offset, "/aging_delay=%u", p_pb_arp->aging_delay);
    offset += sal_sprintf(out + offset, "/is_gratuitous=%u", p_pb_arp->is_gratuitous);
    offset += sal_sprintf(out + offset, "/is_proxy=%u", p_pb_arp->is_proxy);
    offset += sal_sprintf(out + offset, "/is_router=%u", p_pb_arp->is_router);
    offset += sal_sprintf(out + offset, "/retry_count=%u", p_pb_arp->retry_count);
    offset += sal_sprintf(out + offset, "/is_bfd_ref=%u", p_pb_arp->is_bfd_ref);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NEXTHOP */
int32
pb_tbl_nexthop_to_pb(uint32 only_key, tbl_nexthop_t *p_nh, Cdb__TblNexthop *p_pb_nh)
{
    pb_compose_nexthop_key_t_to_pb(&p_nh->key, p_pb_nh->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_nh->has_refcnt = TRUE;
    p_pb_nh->refcnt = p_nh->refcnt;

    return PM_E_NONE;
}

int32
pb_tbl_nexthop_to_pb_free_packed(Cdb__TblNexthop *p_pb_nh)
{
    pb_compose_nexthop_key_t_to_pb_free_packed(p_pb_nh->key);
    return PM_E_NONE;
}

int32
pb_tbl_nexthop_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNexthopKey pb_nh_key = CDB__TBL_NEXTHOP_KEY__INIT;
    Cdb__TblNexthop pb_nh = CDB__TBL_NEXTHOP__INIT;
    tbl_nexthop_t *p_nh = (tbl_nexthop_t*)p_tbl;
    int32 len = 0;

    pb_nh.key = &pb_nh_key;
    pb_tbl_nexthop_to_pb(only_key, p_nh, &pb_nh);
    len = cdb__tbl_nexthop__pack(&pb_nh, buf);
    pb_tbl_nexthop_to_pb_free_packed(&pb_nh);

    return len;
}

int32
pb_tbl_nexthop_dump(Cdb__TblNexthop *p_pb_nh, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_nexthop_key_t_dump(p_pb_nh->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/refcnt=%u", p_pb_nh->refcnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NEXTHOP_GROUP */
int32
pb_tbl_nexthop_group_to_pb(uint32 only_key, tbl_nexthop_group_t *p_nhg, Cdb__TblNexthopGroup *p_pb_nhg)
{
    pb_compose_nexthop_ecmp_t_to_pb(&p_nhg->key, p_pb_nhg->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_nexthop_ecmp_t_to_pb(&p_nhg->nh_group, p_pb_nhg->nh_group);
    p_pb_nhg->has_nhg_oid = TRUE;
    p_pb_nhg->nhg_oid = p_nhg->nhg_oid;
    p_pb_nhg->has_ref_cnt = TRUE;
    p_pb_nhg->ref_cnt = p_nhg->ref_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_nexthop_group_to_pb_free_packed(Cdb__TblNexthopGroup *p_pb_nhg)
{
    pb_compose_nexthop_ecmp_t_to_pb_free_packed(p_pb_nhg->key);
    pb_compose_nexthop_ecmp_t_to_pb_free_packed(p_pb_nhg->nh_group);
    return PM_E_NONE;
}

int32
pb_tbl_nexthop_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNexthopGroupKey pb_nhg_key = CDB__TBL_NEXTHOP_GROUP_KEY__INIT;
    Cdb__TblNexthopGroup pb_nhg = CDB__TBL_NEXTHOP_GROUP__INIT;
    tbl_nexthop_group_t *p_nhg = (tbl_nexthop_group_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeNexthopEcmpT nh_group = CDB__COMPOSE_NEXTHOP_ECMP_T__INIT;

    pb_nhg.key = &pb_nhg_key;
    pb_nhg.nh_group = &nh_group;
    pb_tbl_nexthop_group_to_pb(only_key, p_nhg, &pb_nhg);
    len = cdb__tbl_nexthop_group__pack(&pb_nhg, buf);
    pb_tbl_nexthop_group_to_pb_free_packed(&pb_nhg);

    return len;
}

int32
pb_tbl_nexthop_group_dump(Cdb__TblNexthopGroup *p_pb_nhg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_nexthop_ecmp_t_dump(p_pb_nhg->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_nexthop_ecmp_t_dump(p_pb_nhg->nh_group, (out + offset));
    offset += sal_sprintf(out + offset, "/nhg_oid=%llu", p_pb_nhg->nhg_oid);
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_nhg->ref_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_NEXTHOP */
int32
pb_tbl_fea_nexthop_to_pb(uint32 only_key, tbl_fea_nexthop_t *p_nh, Cdb__TblFeaNexthop *p_pb_nh)
{
    pb_compose_nexthop_key_t_to_pb(&p_nh->key, p_pb_nh->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_nh->has_nhid = TRUE;
    p_pb_nh->nhid = p_nh->nhid;

    return PM_E_NONE;
}

int32
pb_tbl_fea_nexthop_to_pb_free_packed(Cdb__TblFeaNexthop *p_pb_nh)
{
    pb_compose_nexthop_key_t_to_pb_free_packed(p_pb_nh->key);
    return PM_E_NONE;
}

int32
pb_tbl_fea_nexthop_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaNexthopKey pb_nh_key = CDB__TBL_FEA_NEXTHOP_KEY__INIT;
    Cdb__TblFeaNexthop pb_nh = CDB__TBL_FEA_NEXTHOP__INIT;
    tbl_fea_nexthop_t *p_nh = (tbl_fea_nexthop_t*)p_tbl;
    int32 len = 0;

    pb_nh.key = &pb_nh_key;
    pb_tbl_fea_nexthop_to_pb(only_key, p_nh, &pb_nh);
    len = cdb__tbl_fea_nexthop__pack(&pb_nh, buf);
    pb_tbl_fea_nexthop_to_pb_free_packed(&pb_nh);

    return len;
}

int32
pb_tbl_fea_nexthop_dump(Cdb__TblFeaNexthop *p_pb_nh, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_nexthop_key_t_dump(p_pb_nh->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/nhid=%llu", p_pb_nh->nhid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SYS_GLOBAL */
int32
pb_tbl_sys_global_to_pb(uint32 only_key, tbl_sys_global_t *p_sys_glb, Cdb__TblSysGlobal *p_pb_sys_glb)
{
    p_pb_sys_glb->hostname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_sys_glb->hostname)+1);
    sal_strcpy(p_pb_sys_glb->hostname, p_sys_glb->hostname);
    pb_compose_mac_addr_t_to_pb(p_sys_glb->route_mac, p_pb_sys_glb->route_mac);
    p_pb_sys_glb->has_mac_num = TRUE;
    p_pb_sys_glb->mac_num = p_sys_glb->mac_num;
    p_pb_sys_glb->has_curr_vlanif_count = TRUE;
    p_pb_sys_glb->curr_vlanif_count = p_sys_glb->curr_vlanif_count;
    p_pb_sys_glb->has_init_done = TRUE;
    p_pb_sys_glb->init_done = p_sys_glb->init_done;
    p_pb_sys_glb->has_startup_done = TRUE;
    p_pb_sys_glb->startup_done = p_sys_glb->startup_done;
    p_pb_sys_glb->has_max_frame_size = TRUE;
    p_pb_sys_glb->max_frame_size = p_sys_glb->max_frame_size;
    p_pb_sys_glb->has_jumbo_frame_size = TRUE;
    p_pb_sys_glb->jumbo_frame_size = p_sys_glb->jumbo_frame_size;
    p_pb_sys_glb->has_reboot_type = TRUE;
    p_pb_sys_glb->reboot_type = p_sys_glb->reboot_type;
    p_pb_sys_glb->has_ipg_shaping_enable = TRUE;
    p_pb_sys_glb->ipg_shaping_enable = p_sys_glb->ipg_shaping_enable;
    p_pb_sys_glb->has_ipg_policing_enable = TRUE;
    p_pb_sys_glb->ipg_policing_enable = p_sys_glb->ipg_policing_enable;
    p_pb_sys_glb->has_ipg_storm_control_enable = TRUE;
    p_pb_sys_glb->ipg_storm_control_enable = p_sys_glb->ipg_storm_control_enable;
    p_pb_sys_glb->has_aaa_new_model = TRUE;
    p_pb_sys_glb->aaa_new_model = p_sys_glb->aaa_new_model;
    p_pb_sys_glb->has_service_password_encryption = TRUE;
    p_pb_sys_glb->service_password_encryption = p_sys_glb->service_password_encryption;
    p_pb_sys_glb->has_max_vty = TRUE;
    p_pb_sys_glb->max_vty = p_sys_glb->max_vty;
    p_pb_sys_glb->has_aaa_privilege1 = TRUE;
    p_pb_sys_glb->aaa_privilege1 = p_sys_glb->aaa_privilege1;
    p_pb_sys_glb->has_aaa_privilege2 = TRUE;
    p_pb_sys_glb->aaa_privilege2 = p_sys_glb->aaa_privilege2;
    p_pb_sys_glb->has_aaa_privilege3 = TRUE;
    p_pb_sys_glb->aaa_privilege3 = p_sys_glb->aaa_privilege3;
    p_pb_sys_glb->has_dhcp_service_enable = TRUE;
    p_pb_sys_glb->dhcp_service_enable = p_sys_glb->dhcp_service_enable;
    p_pb_sys_glb->has_dhcp_relay_enable = TRUE;
    p_pb_sys_glb->dhcp_relay_enable = p_sys_glb->dhcp_relay_enable;
    p_pb_sys_glb->has_dhcp_snooping_enable = TRUE;
    p_pb_sys_glb->dhcp_snooping_enable = p_sys_glb->dhcp_snooping_enable;
    p_pb_sys_glb->has_http_service_enable = TRUE;
    p_pb_sys_glb->http_service_enable = p_sys_glb->http_service_enable;
    p_pb_sys_glb->http_image_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_sys_glb->http_image_name)+1);
    sal_strcpy(p_pb_sys_glb->http_image_name, p_sys_glb->http_image_name);
    p_pb_sys_glb->has_errdisable_interval = TRUE;
    p_pb_sys_glb->errdisable_interval = p_sys_glb->errdisable_interval;
    p_pb_sys_glb->has_rpc_http_port = TRUE;
    p_pb_sys_glb->rpc_http_port = p_sys_glb->rpc_http_port;
    p_pb_sys_glb->has_trunction_length = TRUE;
    p_pb_sys_glb->trunction_length = p_sys_glb->trunction_length;
    pb_compose_mac_addr_t_to_pb(p_sys_glb->tap_ts_macda, p_pb_sys_glb->tap_ts_macda);
    pb_compose_mac_addr_t_to_pb(p_sys_glb->tap_ts_macsa, p_pb_sys_glb->tap_ts_macsa);
    p_pb_sys_glb->has_ether_type = TRUE;
    p_pb_sys_glb->ether_type = p_sys_glb->ether_type;
    p_pb_sys_glb->has_ptf_port = TRUE;
    p_pb_sys_glb->ptf_port = p_sys_glb->ptf_port;
    p_pb_sys_glb->has_telnet_disable = TRUE;
    p_pb_sys_glb->telnet_disable = p_sys_glb->telnet_disable;
    p_pb_sys_glb->has_http_disable = TRUE;
    p_pb_sys_glb->http_disable = p_sys_glb->http_disable;
    p_pb_sys_glb->has_http_port = TRUE;
    p_pb_sys_glb->http_port = p_sys_glb->http_port;
    p_pb_sys_glb->has_cut_through_enable = TRUE;
    p_pb_sys_glb->cut_through_enable = p_sys_glb->cut_through_enable;
    p_pb_sys_glb->has_protected_vlan_cnt = TRUE;
    p_pb_sys_glb->protected_vlan_cnt = p_sys_glb->protected_vlan_cnt;
    p_pb_sys_glb->has_mib_port_stats_read_num = TRUE;
    p_pb_sys_glb->mib_port_stats_read_num = p_sys_glb->mib_port_stats_read_num;
    p_pb_sys_glb->has_mib_flow_stats_read_num = TRUE;
    p_pb_sys_glb->mib_flow_stats_read_num = p_sys_glb->mib_flow_stats_read_num;
    p_pb_sys_glb->has_memory_threshold1 = TRUE;
    p_pb_sys_glb->memory_threshold1 = p_sys_glb->memory_threshold1;
    p_pb_sys_glb->has_memory_threshold2 = TRUE;
    p_pb_sys_glb->memory_threshold2 = p_sys_glb->memory_threshold2;
    p_pb_sys_glb->has_memory_threshold3 = TRUE;
    p_pb_sys_glb->memory_threshold3 = p_sys_glb->memory_threshold3;
    p_pb_sys_glb->has_system_memchk_state = TRUE;
    p_pb_sys_glb->system_memchk_state = p_sys_glb->system_memchk_state;
    p_pb_sys_glb->has_mgmt_if_running = TRUE;
    p_pb_sys_glb->mgmt_if_running = p_sys_glb->mgmt_if_running;

    return PM_E_NONE;
}

int32
pb_tbl_sys_global_to_pb_free_packed(Cdb__TblSysGlobal *p_pb_sys_glb)
{
    if (p_pb_sys_glb->hostname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sys_glb->hostname);
        p_pb_sys_glb->hostname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_sys_glb->route_mac);
    if (p_pb_sys_glb->http_image_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sys_glb->http_image_name);
        p_pb_sys_glb->http_image_name = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_sys_glb->tap_ts_macda);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_sys_glb->tap_ts_macsa);
    return PM_E_NONE;
}

int32
pb_tbl_sys_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSysGlobal pb_sys_glb = CDB__TBL_SYS_GLOBAL__INIT;
    tbl_sys_global_t *p_sys_glb = (tbl_sys_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT route_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT tap_ts_macda = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT tap_ts_macsa = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_sys_glb.route_mac = &route_mac;
    pb_sys_glb.tap_ts_macda = &tap_ts_macda;
    pb_sys_glb.tap_ts_macsa = &tap_ts_macsa;
    pb_tbl_sys_global_to_pb(only_key, p_sys_glb, &pb_sys_glb);
    len = cdb__tbl_sys_global__pack(&pb_sys_glb, buf);
    pb_tbl_sys_global_to_pb_free_packed(&pb_sys_glb);

    return len;
}

int32
pb_tbl_sys_global_dump(Cdb__TblSysGlobal *p_pb_sys_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/hostname=%s", p_pb_sys_glb->hostname);
    offset += pb_compose_mac_addr_t_dump(p_pb_sys_glb->route_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/mac_num=%u", p_pb_sys_glb->mac_num);
    offset += sal_sprintf(out + offset, "/curr_vlanif_count=%d", p_pb_sys_glb->curr_vlanif_count);
    offset += sal_sprintf(out + offset, "/init_done=%u", p_pb_sys_glb->init_done);
    offset += sal_sprintf(out + offset, "/startup_done=%u", p_pb_sys_glb->startup_done);
    offset += sal_sprintf(out + offset, "/max_frame_size=%u", p_pb_sys_glb->max_frame_size);
    offset += sal_sprintf(out + offset, "/jumbo_frame_size=%u", p_pb_sys_glb->jumbo_frame_size);
    offset += sal_sprintf(out + offset, "/reboot_type=%u", p_pb_sys_glb->reboot_type);
    offset += sal_sprintf(out + offset, "/ipg_shaping_enable=%u", p_pb_sys_glb->ipg_shaping_enable);
    offset += sal_sprintf(out + offset, "/ipg_policing_enable=%u", p_pb_sys_glb->ipg_policing_enable);
    offset += sal_sprintf(out + offset, "/ipg_storm_control_enable=%u", p_pb_sys_glb->ipg_storm_control_enable);
    offset += sal_sprintf(out + offset, "/aaa_new_model=%u", p_pb_sys_glb->aaa_new_model);
    offset += sal_sprintf(out + offset, "/service_password_encryption=%u", p_pb_sys_glb->service_password_encryption);
    offset += sal_sprintf(out + offset, "/max_vty=%u", p_pb_sys_glb->max_vty);
    offset += sal_sprintf(out + offset, "/aaa_privilege1=%u", p_pb_sys_glb->aaa_privilege1);
    offset += sal_sprintf(out + offset, "/aaa_privilege2=%u", p_pb_sys_glb->aaa_privilege2);
    offset += sal_sprintf(out + offset, "/aaa_privilege3=%u", p_pb_sys_glb->aaa_privilege3);
    offset += sal_sprintf(out + offset, "/dhcp_service_enable=%u", p_pb_sys_glb->dhcp_service_enable);
    offset += sal_sprintf(out + offset, "/dhcp_relay_enable=%u", p_pb_sys_glb->dhcp_relay_enable);
    offset += sal_sprintf(out + offset, "/dhcp_snooping_enable=%u", p_pb_sys_glb->dhcp_snooping_enable);
    offset += sal_sprintf(out + offset, "/http_service_enable=%u", p_pb_sys_glb->http_service_enable);
    offset += sal_sprintf(out + offset, "/http_image_name=%s", p_pb_sys_glb->http_image_name);
    offset += sal_sprintf(out + offset, "/errdisable_interval=%u", p_pb_sys_glb->errdisable_interval);
    offset += sal_sprintf(out + offset, "/rpc_http_port=%u", p_pb_sys_glb->rpc_http_port);
    offset += sal_sprintf(out + offset, "/trunction_length=%u", p_pb_sys_glb->trunction_length);
    offset += pb_compose_mac_addr_t_dump(p_pb_sys_glb->tap_ts_macda, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_sys_glb->tap_ts_macsa, (out + offset));
    offset += sal_sprintf(out + offset, "/ether_type=%u", p_pb_sys_glb->ether_type);
    offset += sal_sprintf(out + offset, "/ptf_port=%u", p_pb_sys_glb->ptf_port);
    offset += sal_sprintf(out + offset, "/telnet_disable=%u", p_pb_sys_glb->telnet_disable);
    offset += sal_sprintf(out + offset, "/http_disable=%u", p_pb_sys_glb->http_disable);
    offset += sal_sprintf(out + offset, "/http_port=%u", p_pb_sys_glb->http_port);
    offset += sal_sprintf(out + offset, "/cut_through_enable=%u", p_pb_sys_glb->cut_through_enable);
    offset += sal_sprintf(out + offset, "/protected_vlan_cnt=%u", p_pb_sys_glb->protected_vlan_cnt);
    offset += sal_sprintf(out + offset, "/mib_port_stats_read_num=%u", p_pb_sys_glb->mib_port_stats_read_num);
    offset += sal_sprintf(out + offset, "/mib_flow_stats_read_num=%u", p_pb_sys_glb->mib_flow_stats_read_num);
    offset += sal_sprintf(out + offset, "/memory_threshold1=%u", p_pb_sys_glb->memory_threshold1);
    offset += sal_sprintf(out + offset, "/memory_threshold2=%u", p_pb_sys_glb->memory_threshold2);
    offset += sal_sprintf(out + offset, "/memory_threshold3=%u", p_pb_sys_glb->memory_threshold3);
    offset += sal_sprintf(out + offset, "/system_memchk_state=%u", p_pb_sys_glb->system_memchk_state);
    offset += sal_sprintf(out + offset, "/mgmt_if_running=%u", p_pb_sys_glb->mgmt_if_running);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LAG_GLOBAL */
int32
pb_tbl_lag_global_to_pb(uint32 only_key, tbl_lag_global_t *p_lag_glb, Cdb__TblLagGlobal *p_pb_lag_glb)
{
    p_pb_lag_glb->has_system_priority = TRUE;
    p_pb_lag_glb->system_priority = p_lag_glb->system_priority;
    pb_compose_mac_addr_t_to_pb(p_lag_glb->system_id, p_pb_lag_glb->system_id);
    p_pb_lag_glb->has_mlag_system_priority = TRUE;
    p_pb_lag_glb->mlag_system_priority = p_lag_glb->mlag_system_priority;
    pb_compose_mac_addr_t_to_pb(p_lag_glb->mlag_system_id, p_pb_lag_glb->mlag_system_id);
    p_pb_lag_glb->has_load_balance = TRUE;
    p_pb_lag_glb->load_balance = p_lag_glb->load_balance;
    p_pb_lag_glb->has_load_balance_inner_field_en = TRUE;
    p_pb_lag_glb->load_balance_inner_field_en = p_lag_glb->load_balance_inner_field_en;
    p_pb_lag_glb->has_hash_arithmetic = TRUE;
    p_pb_lag_glb->hash_arithmetic = p_lag_glb->hash_arithmetic;
    p_pb_lag_glb->has_load_balance_mode = TRUE;
    p_pb_lag_glb->load_balance_mode.len = sizeof(p_lag_glb->load_balance_mode);
    p_pb_lag_glb->load_balance_mode.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_lag_glb->load_balance_mode));
    sal_memcpy(p_pb_lag_glb->load_balance_mode.data, p_lag_glb->load_balance_mode, sizeof(p_lag_glb->load_balance_mode));

    return PM_E_NONE;
}

int32
pb_tbl_lag_global_to_pb_free_packed(Cdb__TblLagGlobal *p_pb_lag_glb)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_lag_glb->system_id);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_lag_glb->mlag_system_id);
    if (p_pb_lag_glb->load_balance_mode.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lag_glb->load_balance_mode.data);
        p_pb_lag_glb->load_balance_mode.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_lag_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLagGlobal pb_lag_glb = CDB__TBL_LAG_GLOBAL__INIT;
    tbl_lag_global_t *p_lag_glb = (tbl_lag_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT system_id = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT mlag_system_id = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_lag_glb.system_id = &system_id;
    pb_lag_glb.mlag_system_id = &mlag_system_id;
    pb_tbl_lag_global_to_pb(only_key, p_lag_glb, &pb_lag_glb);
    len = cdb__tbl_lag_global__pack(&pb_lag_glb, buf);
    pb_tbl_lag_global_to_pb_free_packed(&pb_lag_glb);

    return len;
}

int32
pb_tbl_lag_global_dump(Cdb__TblLagGlobal *p_pb_lag_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/system_priority=%u", p_pb_lag_glb->system_priority);
    offset += pb_compose_mac_addr_t_dump(p_pb_lag_glb->system_id, (out + offset));
    offset += sal_sprintf(out + offset, "/mlag_system_priority=%u", p_pb_lag_glb->mlag_system_priority);
    offset += pb_compose_mac_addr_t_dump(p_pb_lag_glb->mlag_system_id, (out + offset));
    offset += sal_sprintf(out + offset, "/load_balance=%u", p_pb_lag_glb->load_balance);
    offset += sal_sprintf(out + offset, "/load_balance_inner_field_en=%u", p_pb_lag_glb->load_balance_inner_field_en);
    offset += sal_sprintf(out + offset, "/hash_arithmetic=%u", p_pb_lag_glb->hash_arithmetic);
    offset += sal_sprintf(out + offset, "/load_balance_mode=");
    offset += pb_uint8_array_dump(p_pb_lag_glb->load_balance_mode.data, p_pb_lag_glb->load_balance_mode.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MEM_SUMMARY */
int32
pb_tbl_mem_summary_to_pb(uint32 only_key, tbl_mem_summary_t *p_mem_info, Cdb__TblMemSummary *p_pb_mem_info)
{
    p_pb_mem_info->has_total = TRUE;
    p_pb_mem_info->total = p_mem_info->total;
    p_pb_mem_info->has_used = TRUE;
    p_pb_mem_info->used = p_mem_info->used;
    p_pb_mem_info->has_free = TRUE;
    p_pb_mem_info->free = p_mem_info->free;
    p_pb_mem_info->has_buffer = TRUE;
    p_pb_mem_info->buffer = p_mem_info->buffer;
    p_pb_mem_info->has_cahed = TRUE;
    p_pb_mem_info->cahed = p_mem_info->cahed;

    return PM_E_NONE;
}

int32
pb_tbl_mem_summary_to_pb_free_packed(Cdb__TblMemSummary *p_pb_mem_info)
{
    return PM_E_NONE;
}

int32
pb_tbl_mem_summary_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMemSummary pb_mem_info = CDB__TBL_MEM_SUMMARY__INIT;
    tbl_mem_summary_t *p_mem_info = (tbl_mem_summary_t*)p_tbl;
    int32 len = 0;

    pb_tbl_mem_summary_to_pb(only_key, p_mem_info, &pb_mem_info);
    len = cdb__tbl_mem_summary__pack(&pb_mem_info, buf);
    pb_tbl_mem_summary_to_pb_free_packed(&pb_mem_info);

    return len;
}

int32
pb_tbl_mem_summary_dump(Cdb__TblMemSummary *p_pb_mem_info, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/total=%u", p_pb_mem_info->total);
    offset += sal_sprintf(out + offset, "/used=%u", p_pb_mem_info->used);
    offset += sal_sprintf(out + offset, "/free=%u", p_pb_mem_info->free);
    offset += sal_sprintf(out + offset, "/buffer=%u", p_pb_mem_info->buffer);
    offset += sal_sprintf(out + offset, "/cahed=%u", p_pb_mem_info->cahed);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CHSM_DEBUG */
int32
pb_tbl_chsm_debug_to_pb(uint32 only_key, tbl_chsm_debug_t *p_chsmdbg, Cdb__TblChsmDebug *p_pb_chsmdbg)
{
    p_pb_chsmdbg->has_chsm_chassis = TRUE;
    p_pb_chsmdbg->chsm_chassis = GLB_FLAG_ISSET(p_chsmdbg->chsm, CHSMDBG_FLAG_CHSM_CHASSIS) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_chsm_debug_to_pb_free_packed(Cdb__TblChsmDebug *p_pb_chsmdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_chsm_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblChsmDebug pb_chsmdbg = CDB__TBL_CHSM_DEBUG__INIT;
    tbl_chsm_debug_t *p_chsmdbg = (tbl_chsm_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_chsm_debug_to_pb(only_key, p_chsmdbg, &pb_chsmdbg);
    len = cdb__tbl_chsm_debug__pack(&pb_chsmdbg, buf);
    pb_tbl_chsm_debug_to_pb_free_packed(&pb_chsmdbg);

    return len;
}

int32
pb_tbl_chsm_debug_dump(Cdb__TblChsmDebug *p_pb_chsmdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/chsm_chassis=%u", p_pb_chsmdbg->chsm_chassis);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SWITCH_DEBUG */
int32
pb_tbl_switch_debug_to_pb(uint32 only_key, tbl_switch_debug_t *p_swthdbg, Cdb__TblSwitchDebug *p_pb_swthdbg)
{
    p_pb_swthdbg->has_stp_event = TRUE;
    p_pb_swthdbg->stp_event = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_stp_packet_tx = TRUE;
    p_pb_swthdbg->stp_packet_tx = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_PACKET_TX) ? TRUE : FALSE;
    p_pb_swthdbg->has_stp_packet_rx = TRUE;
    p_pb_swthdbg->stp_packet_rx = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_PACKET_RX) ? TRUE : FALSE;
    p_pb_swthdbg->has_stp_protocol_cist = TRUE;
    p_pb_swthdbg->stp_protocol_cist = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_PROTO_CIST) ? TRUE : FALSE;
    p_pb_swthdbg->has_stp_protocol_msti = TRUE;
    p_pb_swthdbg->stp_protocol_msti = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_PROTO_MSTI) ? TRUE : FALSE;
    p_pb_swthdbg->has_stp_timer = TRUE;
    p_pb_swthdbg->stp_timer = GLB_FLAG_ISSET(p_swthdbg->stp, SWTHDBG_FLAG_STP_TIMER) ? TRUE : FALSE;
    p_pb_swthdbg->has_mlag_event = TRUE;
    p_pb_swthdbg->mlag_event = GLB_FLAG_ISSET(p_swthdbg->mlag, SWTHDBG_FLAG_MLAG_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_mlag_packet = TRUE;
    p_pb_swthdbg->mlag_packet = GLB_FLAG_ISSET(p_swthdbg->mlag, SWTHDBG_FLAG_MLAG_PACKET) ? TRUE : FALSE;
    p_pb_swthdbg->has_mlag_protocol = TRUE;
    p_pb_swthdbg->mlag_protocol = GLB_FLAG_ISSET(p_swthdbg->mlag, SWTHDBG_FLAG_MLAG_PROTO) ? TRUE : FALSE;
    p_pb_swthdbg->has_mlag_timer = TRUE;
    p_pb_swthdbg->mlag_timer = GLB_FLAG_ISSET(p_swthdbg->mlag, SWTHDBG_FLAG_MLAG_TIMER) ? TRUE : FALSE;
    p_pb_swthdbg->has_lacp_event = TRUE;
    p_pb_swthdbg->lacp_event = GLB_FLAG_ISSET(p_swthdbg->lacp, SWTHDBG_FLAG_LACP_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_lacp_packet = TRUE;
    p_pb_swthdbg->lacp_packet = GLB_FLAG_ISSET(p_swthdbg->lacp, SWTHDBG_FLAG_LACP_PACKET) ? TRUE : FALSE;
    p_pb_swthdbg->has_lacp_protocol = TRUE;
    p_pb_swthdbg->lacp_protocol = GLB_FLAG_ISSET(p_swthdbg->lacp, SWTHDBG_FLAG_LACP_PROTO) ? TRUE : FALSE;
    p_pb_swthdbg->has_lacp_timer = TRUE;
    p_pb_swthdbg->lacp_timer = GLB_FLAG_ISSET(p_swthdbg->lacp, SWTHDBG_FLAG_LACP_TIMER) ? TRUE : FALSE;
    p_pb_swthdbg->has_igsp_event = TRUE;
    p_pb_swthdbg->igsp_event = GLB_FLAG_ISSET(p_swthdbg->igsp, SWTHDBG_FLAG_IGSP_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_igsp_packet_tx = TRUE;
    p_pb_swthdbg->igsp_packet_tx = GLB_FLAG_ISSET(p_swthdbg->igsp, SWTHDBG_FLAG_IGSP_PACKET_TX) ? TRUE : FALSE;
    p_pb_swthdbg->has_igsp_packet_rx = TRUE;
    p_pb_swthdbg->igsp_packet_rx = GLB_FLAG_ISSET(p_swthdbg->igsp, SWTHDBG_FLAG_IGSP_PACKET_RX) ? TRUE : FALSE;
    p_pb_swthdbg->has_igsp_protocol = TRUE;
    p_pb_swthdbg->igsp_protocol = GLB_FLAG_ISSET(p_swthdbg->igsp, SWTHDBG_FLAG_IGSP_PROTO) ? TRUE : FALSE;
    p_pb_swthdbg->has_igsp_timer = TRUE;
    p_pb_swthdbg->igsp_timer = GLB_FLAG_ISSET(p_swthdbg->igsp, SWTHDBG_FLAG_IGSP_TIMER) ? TRUE : FALSE;
    p_pb_swthdbg->has_ipsg_event = TRUE;
    p_pb_swthdbg->ipsg_event = GLB_FLAG_ISSET(p_swthdbg->ipsg, SWTHDBG_FLAG_IPSG_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_ipsg_error = TRUE;
    p_pb_swthdbg->ipsg_error = GLB_FLAG_ISSET(p_swthdbg->ipsg, SWTHDBG_FLAG_IPSG_ERROR) ? TRUE : FALSE;
    p_pb_swthdbg->has_lldp_event = TRUE;
    p_pb_swthdbg->lldp_event = GLB_FLAG_ISSET(p_swthdbg->lldp, SWTHDBG_FLAG_LLDP_EVENT) ? TRUE : FALSE;
    p_pb_swthdbg->has_lldp_packet_tx = TRUE;
    p_pb_swthdbg->lldp_packet_tx = GLB_FLAG_ISSET(p_swthdbg->lldp, SWTHDBG_FLAG_LLDP_PACKET_TX) ? TRUE : FALSE;
    p_pb_swthdbg->has_lldp_packet_rx = TRUE;
    p_pb_swthdbg->lldp_packet_rx = GLB_FLAG_ISSET(p_swthdbg->lldp, SWTHDBG_FLAG_LLDP_PACKET_RX) ? TRUE : FALSE;
    p_pb_swthdbg->has_lldp_protocol = TRUE;
    p_pb_swthdbg->lldp_protocol = GLB_FLAG_ISSET(p_swthdbg->lldp, SWTHDBG_FLAG_LLDP_PROTO) ? TRUE : FALSE;
    p_pb_swthdbg->has_lldp_timer = TRUE;
    p_pb_swthdbg->lldp_timer = GLB_FLAG_ISSET(p_swthdbg->lldp, SWTHDBG_FLAG_LLDP_TIMER) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_switch_debug_to_pb_free_packed(Cdb__TblSwitchDebug *p_pb_swthdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_switch_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSwitchDebug pb_swthdbg = CDB__TBL_SWITCH_DEBUG__INIT;
    tbl_switch_debug_t *p_swthdbg = (tbl_switch_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_switch_debug_to_pb(only_key, p_swthdbg, &pb_swthdbg);
    len = cdb__tbl_switch_debug__pack(&pb_swthdbg, buf);
    pb_tbl_switch_debug_to_pb_free_packed(&pb_swthdbg);

    return len;
}

int32
pb_tbl_switch_debug_dump(Cdb__TblSwitchDebug *p_pb_swthdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/stp_event=%u", p_pb_swthdbg->stp_event);
    offset += sal_sprintf(out + offset, "/stp_packet_tx=%u", p_pb_swthdbg->stp_packet_tx);
    offset += sal_sprintf(out + offset, "/stp_packet_rx=%u", p_pb_swthdbg->stp_packet_rx);
    offset += sal_sprintf(out + offset, "/stp_protocol_cist=%u", p_pb_swthdbg->stp_protocol_cist);
    offset += sal_sprintf(out + offset, "/stp_protocol_msti=%u", p_pb_swthdbg->stp_protocol_msti);
    offset += sal_sprintf(out + offset, "/stp_timer=%u", p_pb_swthdbg->stp_timer);
    offset += sal_sprintf(out + offset, "/mlag_event=%u", p_pb_swthdbg->mlag_event);
    offset += sal_sprintf(out + offset, "/mlag_packet=%u", p_pb_swthdbg->mlag_packet);
    offset += sal_sprintf(out + offset, "/mlag_protocol=%u", p_pb_swthdbg->mlag_protocol);
    offset += sal_sprintf(out + offset, "/mlag_timer=%u", p_pb_swthdbg->mlag_timer);
    offset += sal_sprintf(out + offset, "/lacp_event=%u", p_pb_swthdbg->lacp_event);
    offset += sal_sprintf(out + offset, "/lacp_packet=%u", p_pb_swthdbg->lacp_packet);
    offset += sal_sprintf(out + offset, "/lacp_protocol=%u", p_pb_swthdbg->lacp_protocol);
    offset += sal_sprintf(out + offset, "/lacp_timer=%u", p_pb_swthdbg->lacp_timer);
    offset += sal_sprintf(out + offset, "/igsp_event=%u", p_pb_swthdbg->igsp_event);
    offset += sal_sprintf(out + offset, "/igsp_packet_tx=%u", p_pb_swthdbg->igsp_packet_tx);
    offset += sal_sprintf(out + offset, "/igsp_packet_rx=%u", p_pb_swthdbg->igsp_packet_rx);
    offset += sal_sprintf(out + offset, "/igsp_protocol=%u", p_pb_swthdbg->igsp_protocol);
    offset += sal_sprintf(out + offset, "/igsp_timer=%u", p_pb_swthdbg->igsp_timer);
    offset += sal_sprintf(out + offset, "/ipsg_event=%u", p_pb_swthdbg->ipsg_event);
    offset += sal_sprintf(out + offset, "/ipsg_error=%u", p_pb_swthdbg->ipsg_error);
    offset += sal_sprintf(out + offset, "/lldp_event=%u", p_pb_swthdbg->lldp_event);
    offset += sal_sprintf(out + offset, "/lldp_packet_tx=%u", p_pb_swthdbg->lldp_packet_tx);
    offset += sal_sprintf(out + offset, "/lldp_packet_rx=%u", p_pb_swthdbg->lldp_packet_rx);
    offset += sal_sprintf(out + offset, "/lldp_protocol=%u", p_pb_swthdbg->lldp_protocol);
    offset += sal_sprintf(out + offset, "/lldp_timer=%u", p_pb_swthdbg->lldp_timer);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ROUTE_DEBUG */
int32
pb_tbl_route_debug_to_pb(uint32 only_key, tbl_route_debug_t *p_rtdbg, Cdb__TblRouteDebug *p_pb_rtdbg)
{
    p_pb_rtdbg->has_route_event = TRUE;
    p_pb_rtdbg->route_event = GLB_FLAG_ISSET(p_rtdbg->route, RTDBG_FLAG_ROUTE_EVENT) ? TRUE : FALSE;
    p_pb_rtdbg->has_arp_event = TRUE;
    p_pb_rtdbg->arp_event = GLB_FLAG_ISSET(p_rtdbg->arp, RTDBG_FLAG_ARP_EVENT) ? TRUE : FALSE;
    p_pb_rtdbg->has_arp_packet = TRUE;
    p_pb_rtdbg->arp_packet = GLB_FLAG_ISSET(p_rtdbg->arp, RTDBG_FLAG_ARP_PACKET) ? TRUE : FALSE;
    p_pb_rtdbg->has_arp_protocol = TRUE;
    p_pb_rtdbg->arp_protocol = GLB_FLAG_ISSET(p_rtdbg->arp, RTDBG_FLAG_ARP_PROTO) ? TRUE : FALSE;
    p_pb_rtdbg->has_arp_timer = TRUE;
    p_pb_rtdbg->arp_timer = GLB_FLAG_ISSET(p_rtdbg->arp, RTDBG_FLAG_ARP_TIMER) ? TRUE : FALSE;
    p_pb_rtdbg->has_arpinspection_event = TRUE;
    p_pb_rtdbg->arpinspection_event = GLB_FLAG_ISSET(p_rtdbg->arpinspection, RTDBG_FLAG_ARPINSPECTION_EVENT) ? TRUE : FALSE;
    p_pb_rtdbg->has_arpinspection_packet = TRUE;
    p_pb_rtdbg->arpinspection_packet = GLB_FLAG_ISSET(p_rtdbg->arpinspection, RTDBG_FLAG_ARPINSPECTION_PACKET) ? TRUE : FALSE;
    p_pb_rtdbg->has_arpinspection_protocol = TRUE;
    p_pb_rtdbg->arpinspection_protocol = GLB_FLAG_ISSET(p_rtdbg->arpinspection, RTDBG_FLAG_ARPINSPECTION_PROTO) ? TRUE : FALSE;
    p_pb_rtdbg->has_arpinspection_timer = TRUE;
    p_pb_rtdbg->arpinspection_timer = GLB_FLAG_ISSET(p_rtdbg->arpinspection, RTDBG_FLAG_ARPINSPECTION_TIMER) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_route_debug_to_pb_free_packed(Cdb__TblRouteDebug *p_pb_rtdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_route_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRouteDebug pb_rtdbg = CDB__TBL_ROUTE_DEBUG__INIT;
    tbl_route_debug_t *p_rtdbg = (tbl_route_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_route_debug_to_pb(only_key, p_rtdbg, &pb_rtdbg);
    len = cdb__tbl_route_debug__pack(&pb_rtdbg, buf);
    pb_tbl_route_debug_to_pb_free_packed(&pb_rtdbg);

    return len;
}

int32
pb_tbl_route_debug_dump(Cdb__TblRouteDebug *p_pb_rtdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/route_event=%u", p_pb_rtdbg->route_event);
    offset += sal_sprintf(out + offset, "/arp_event=%u", p_pb_rtdbg->arp_event);
    offset += sal_sprintf(out + offset, "/arp_packet=%u", p_pb_rtdbg->arp_packet);
    offset += sal_sprintf(out + offset, "/arp_protocol=%u", p_pb_rtdbg->arp_protocol);
    offset += sal_sprintf(out + offset, "/arp_timer=%u", p_pb_rtdbg->arp_timer);
    offset += sal_sprintf(out + offset, "/arpinspection_event=%u", p_pb_rtdbg->arpinspection_event);
    offset += sal_sprintf(out + offset, "/arpinspection_packet=%u", p_pb_rtdbg->arpinspection_packet);
    offset += sal_sprintf(out + offset, "/arpinspection_protocol=%u", p_pb_rtdbg->arpinspection_protocol);
    offset += sal_sprintf(out + offset, "/arpinspection_timer=%u", p_pb_rtdbg->arpinspection_timer);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QUAGGA_DEBUG */
int32
pb_tbl_quagga_debug_to_pb(uint32 only_key, tbl_quagga_debug_t *p_dbg, Cdb__TblQuaggaDebug *p_pb_dbg)
{
    p_pb_dbg->has_ospf_event = TRUE;
    p_pb_dbg->ospf_event = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_EVENT) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_ism_events = TRUE;
    p_pb_dbg->ospf_ism_events = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_ISM_EVENTS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_ism_status = TRUE;
    p_pb_dbg->ospf_ism_status = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_ISM_STATUS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_ism_timers = TRUE;
    p_pb_dbg->ospf_ism_timers = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_ISM_TIMERS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_lsa_flooding = TRUE;
    p_pb_dbg->ospf_lsa_flooding = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_LSA_FLOODING) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_lsa_generate = TRUE;
    p_pb_dbg->ospf_lsa_generate = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_LSA_GENERATE) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_lsa_install = TRUE;
    p_pb_dbg->ospf_lsa_install = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_LSA_INSTALL) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_lsa_refresh = TRUE;
    p_pb_dbg->ospf_lsa_refresh = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_LSA_REFRESH) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_nsm_events = TRUE;
    p_pb_dbg->ospf_nsm_events = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_NSM_EVENTS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_nsm_status = TRUE;
    p_pb_dbg->ospf_nsm_status = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_NSM_STATUS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_nsm_timers = TRUE;
    p_pb_dbg->ospf_nsm_timers = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_NSM_TIMERS) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_nssa = TRUE;
    p_pb_dbg->ospf_nssa = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_NSSA) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_packet_dd = TRUE;
    p_pb_dbg->ospf_packet_dd = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_PACKET_DD) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_packet_hello = TRUE;
    p_pb_dbg->ospf_packet_hello = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_PACKET_HELLO) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_packet_ls_ack = TRUE;
    p_pb_dbg->ospf_packet_ls_ack = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_PACKET_LS_ACK) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_packet_ls_request = TRUE;
    p_pb_dbg->ospf_packet_ls_request = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_PACKET_LS_REQUEST) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_packet_ls_update = TRUE;
    p_pb_dbg->ospf_packet_ls_update = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_PACKET_LS_UPDATE) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_zebra_interface = TRUE;
    p_pb_dbg->ospf_zebra_interface = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_ZEBRA_INTERFACE) ? TRUE : FALSE;
    p_pb_dbg->has_ospf_zebra_redistribute = TRUE;
    p_pb_dbg->ospf_zebra_redistribute = GLB_FLAG_ISSET(p_dbg->ospf, OSPFDBG_FLAG_ZEBRA_REDISTRIBUTE) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_as4_segment = TRUE;
    p_pb_dbg->bgp_as4_segment = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_AS4_SEGMENT) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_event = TRUE;
    p_pb_dbg->bgp_event = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_EVENT) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_filters = TRUE;
    p_pb_dbg->bgp_filters = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_FILTERS) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_fsm = TRUE;
    p_pb_dbg->bgp_fsm = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_FSM) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_keepalives = TRUE;
    p_pb_dbg->bgp_keepalives = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_KEEPALIVES) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_updates_in = TRUE;
    p_pb_dbg->bgp_updates_in = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_UPDATES_IN) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_updates_out = TRUE;
    p_pb_dbg->bgp_updates_out = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_UPDATES_OUT) ? TRUE : FALSE;
    p_pb_dbg->has_bgp_zebra = TRUE;
    p_pb_dbg->bgp_zebra = GLB_FLAG_ISSET(p_dbg->bgp, BGPDBG_FLAG_ZEBRA) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_quagga_debug_to_pb_free_packed(Cdb__TblQuaggaDebug *p_pb_dbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_quagga_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQuaggaDebug pb_dbg = CDB__TBL_QUAGGA_DEBUG__INIT;
    tbl_quagga_debug_t *p_dbg = (tbl_quagga_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_quagga_debug_to_pb(only_key, p_dbg, &pb_dbg);
    len = cdb__tbl_quagga_debug__pack(&pb_dbg, buf);
    pb_tbl_quagga_debug_to_pb_free_packed(&pb_dbg);

    return len;
}

int32
pb_tbl_quagga_debug_dump(Cdb__TblQuaggaDebug *p_pb_dbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/ospf_event=%u", p_pb_dbg->ospf_event);
    offset += sal_sprintf(out + offset, "/ospf_ism_events=%u", p_pb_dbg->ospf_ism_events);
    offset += sal_sprintf(out + offset, "/ospf_ism_status=%u", p_pb_dbg->ospf_ism_status);
    offset += sal_sprintf(out + offset, "/ospf_ism_timers=%u", p_pb_dbg->ospf_ism_timers);
    offset += sal_sprintf(out + offset, "/ospf_lsa_flooding=%u", p_pb_dbg->ospf_lsa_flooding);
    offset += sal_sprintf(out + offset, "/ospf_lsa_generate=%u", p_pb_dbg->ospf_lsa_generate);
    offset += sal_sprintf(out + offset, "/ospf_lsa_install=%u", p_pb_dbg->ospf_lsa_install);
    offset += sal_sprintf(out + offset, "/ospf_lsa_refresh=%u", p_pb_dbg->ospf_lsa_refresh);
    offset += sal_sprintf(out + offset, "/ospf_nsm_events=%u", p_pb_dbg->ospf_nsm_events);
    offset += sal_sprintf(out + offset, "/ospf_nsm_status=%u", p_pb_dbg->ospf_nsm_status);
    offset += sal_sprintf(out + offset, "/ospf_nsm_timers=%u", p_pb_dbg->ospf_nsm_timers);
    offset += sal_sprintf(out + offset, "/ospf_nssa=%u", p_pb_dbg->ospf_nssa);
    offset += sal_sprintf(out + offset, "/ospf_packet_dd=%u", p_pb_dbg->ospf_packet_dd);
    offset += sal_sprintf(out + offset, "/ospf_packet_hello=%u", p_pb_dbg->ospf_packet_hello);
    offset += sal_sprintf(out + offset, "/ospf_packet_ls_ack=%u", p_pb_dbg->ospf_packet_ls_ack);
    offset += sal_sprintf(out + offset, "/ospf_packet_ls_request=%u", p_pb_dbg->ospf_packet_ls_request);
    offset += sal_sprintf(out + offset, "/ospf_packet_ls_update=%u", p_pb_dbg->ospf_packet_ls_update);
    offset += sal_sprintf(out + offset, "/ospf_zebra_interface=%u", p_pb_dbg->ospf_zebra_interface);
    offset += sal_sprintf(out + offset, "/ospf_zebra_redistribute=%u", p_pb_dbg->ospf_zebra_redistribute);
    offset += sal_sprintf(out + offset, "/bgp_as4_segment=%u", p_pb_dbg->bgp_as4_segment);
    offset += sal_sprintf(out + offset, "/bgp_event=%u", p_pb_dbg->bgp_event);
    offset += sal_sprintf(out + offset, "/bgp_filters=%u", p_pb_dbg->bgp_filters);
    offset += sal_sprintf(out + offset, "/bgp_fsm=%u", p_pb_dbg->bgp_fsm);
    offset += sal_sprintf(out + offset, "/bgp_keepalives=%u", p_pb_dbg->bgp_keepalives);
    offset += sal_sprintf(out + offset, "/bgp_updates_in=%u", p_pb_dbg->bgp_updates_in);
    offset += sal_sprintf(out + offset, "/bgp_updates_out=%u", p_pb_dbg->bgp_updates_out);
    offset += sal_sprintf(out + offset, "/bgp_zebra=%u", p_pb_dbg->bgp_zebra);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LSRV_DEBUG */
int32
pb_tbl_lsrv_debug_to_pb(uint32 only_key, tbl_lsrv_debug_t *p_lsrvdbg, Cdb__TblLsrvDebug *p_pb_lsrvdbg)
{
    p_pb_lsrvdbg->has_card = TRUE;
    p_pb_lsrvdbg->card = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_CARD) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_port = TRUE;
    p_pb_lsrvdbg->port = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_PORT) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_fiber = TRUE;
    p_pb_lsrvdbg->fiber = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_FIBER) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_fan = TRUE;
    p_pb_lsrvdbg->fan = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_FAN) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_psu = TRUE;
    p_pb_lsrvdbg->psu = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_PSU) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_led = TRUE;
    p_pb_lsrvdbg->led = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_LED) ? TRUE : FALSE;
    p_pb_lsrvdbg->has_thermal = TRUE;
    p_pb_lsrvdbg->thermal = GLB_FLAG_ISSET(p_lsrvdbg->card, LSRVDBG_FLAG_CARD_SENSOR) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_lsrv_debug_to_pb_free_packed(Cdb__TblLsrvDebug *p_pb_lsrvdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_lsrv_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLsrvDebug pb_lsrvdbg = CDB__TBL_LSRV_DEBUG__INIT;
    tbl_lsrv_debug_t *p_lsrvdbg = (tbl_lsrv_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_lsrv_debug_to_pb(only_key, p_lsrvdbg, &pb_lsrvdbg);
    len = cdb__tbl_lsrv_debug__pack(&pb_lsrvdbg, buf);
    pb_tbl_lsrv_debug_to_pb_free_packed(&pb_lsrvdbg);

    return len;
}

int32
pb_tbl_lsrv_debug_dump(Cdb__TblLsrvDebug *p_pb_lsrvdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/card=%u", p_pb_lsrvdbg->card);
    offset += sal_sprintf(out + offset, "/port=%u", p_pb_lsrvdbg->port);
    offset += sal_sprintf(out + offset, "/fiber=%u", p_pb_lsrvdbg->fiber);
    offset += sal_sprintf(out + offset, "/fan=%u", p_pb_lsrvdbg->fan);
    offset += sal_sprintf(out + offset, "/psu=%u", p_pb_lsrvdbg->psu);
    offset += sal_sprintf(out + offset, "/led=%u", p_pb_lsrvdbg->led);
    offset += sal_sprintf(out + offset, "/thermal=%u", p_pb_lsrvdbg->thermal);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_HSRV_DEBUG */
int32
pb_tbl_hsrv_debug_to_pb(uint32 only_key, tbl_hsrv_debug_t *p_hsrvdbg, Cdb__TblHsrvDebug *p_pb_hsrvdbg)
{
    p_pb_hsrvdbg->has_vswitch = TRUE;
    p_pb_hsrvdbg->vswitch = GLB_FLAG_ISSET(p_hsrvdbg->vswitch, HSRVDBG_FLAG_VSWITCH_VSWITCH) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_interface_l2if = TRUE;
    p_pb_hsrvdbg->interface_l2if = GLB_FLAG_ISSET(p_hsrvdbg->interface, HSRVDBG_FLAG_INTERFACE_L2IF) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_interface_l3if = TRUE;
    p_pb_hsrvdbg->interface_l3if = GLB_FLAG_ISSET(p_hsrvdbg->interface, HSRVDBG_FLAG_INTERFACE_L3IF) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_interface_ifdb = TRUE;
    p_pb_hsrvdbg->interface_ifdb = GLB_FLAG_ISSET(p_hsrvdbg->interface, HSRVDBG_FLAG_INTERFACE_IFDB) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_message_pm2hsrv = TRUE;
    p_pb_hsrvdbg->message_pm2hsrv = GLB_FLAG_ISSET(p_hsrvdbg->message, HSRVDBG_FLAG_MESSAGE_PM2HSRV) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_message_hsrv2pm = TRUE;
    p_pb_hsrvdbg->message_hsrv2pm = GLB_FLAG_ISSET(p_hsrvdbg->message, HSRVDBG_FLAG_MESSAGE_HSRV2PM) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_rx = TRUE;
    p_pb_hsrvdbg->cpu_rx = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_RX) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_tx = TRUE;
    p_pb_hsrvdbg->cpu_tx = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_TX) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_bpdu = TRUE;
    p_pb_hsrvdbg->cpu_bpdu = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_BPDU) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_slowproto = TRUE;
    p_pb_hsrvdbg->cpu_slowproto = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_SLOW_PROTO) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_eapol = TRUE;
    p_pb_hsrvdbg->cpu_eapol = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_EAPOL) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_lldp = TRUE;
    p_pb_hsrvdbg->cpu_lldp = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_LLDP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_erps = TRUE;
    p_pb_hsrvdbg->cpu_erps = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_ERPS) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_macda = TRUE;
    p_pb_hsrvdbg->cpu_macda = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_MACDA) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_rip = TRUE;
    p_pb_hsrvdbg->cpu_rip = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_RIP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_ospf = TRUE;
    p_pb_hsrvdbg->cpu_ospf = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_OSPF) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_bgp = TRUE;
    p_pb_hsrvdbg->cpu_bgp = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_BGP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_arp = TRUE;
    p_pb_hsrvdbg->cpu_arp = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_ARP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_dhcp = TRUE;
    p_pb_hsrvdbg->cpu_dhcp = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_DHCP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_ipda = TRUE;
    p_pb_hsrvdbg->cpu_ipda = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_IPDA) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_igmp = TRUE;
    p_pb_hsrvdbg->cpu_igmp = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_IGMP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_maclimit = TRUE;
    p_pb_hsrvdbg->cpu_maclimit = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_MAC_LIMIT) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_macmismatch = TRUE;
    p_pb_hsrvdbg->cpu_macmismatch = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_MAC_MISMATCH) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_l3copycpu = TRUE;
    p_pb_hsrvdbg->cpu_l3copycpu = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_L3COPY_CPU) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_other = TRUE;
    p_pb_hsrvdbg->cpu_other = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_OTHER) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_cpu_raw = TRUE;
    p_pb_hsrvdbg->cpu_raw = GLB_FLAG_ISSET(p_hsrvdbg->cpu, HSRVDBG_FLAG_CPU_TRAFFIC_RAW) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_nexthop = TRUE;
    p_pb_hsrvdbg->nexthop = GLB_FLAG_ISSET(p_hsrvdbg->nexthop, HSRVDBG_FLAG_NEXTHOP_NEXTHOP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_vlan = TRUE;
    p_pb_hsrvdbg->vlan = GLB_FLAG_ISSET(p_hsrvdbg->vlan, HSRVDBG_FLAG_VLAN_VLAN) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_mirror = TRUE;
    p_pb_hsrvdbg->mirror = GLB_FLAG_ISSET(p_hsrvdbg->mirror, HSRVDBG_FLAG_MIRROR_MIRROR) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_fdb = TRUE;
    p_pb_hsrvdbg->fdb = GLB_FLAG_ISSET(p_hsrvdbg->fdb, HSRVDBG_FLAG_FDB_FDB) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_l2mc = TRUE;
    p_pb_hsrvdbg->l2mc = GLB_FLAG_ISSET(p_hsrvdbg->l2mc, HSRVDBG_FLAG_L2MC_L2MC) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_agg = TRUE;
    p_pb_hsrvdbg->agg = GLB_FLAG_ISSET(p_hsrvdbg->agg, HSRVDBG_FLAG_AGG_AGG) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_ipuc = TRUE;
    p_pb_hsrvdbg->ipuc = GLB_FLAG_ISSET(p_hsrvdbg->ipuc, HSRVDBG_FLAG_IPUC_IPUC) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_neighbor = TRUE;
    p_pb_hsrvdbg->neighbor = GLB_FLAG_ISSET(p_hsrvdbg->neighbor, HSRVDBG_FLAG_NEIGHBOR_NEIGHBOR) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_ecmp = TRUE;
    p_pb_hsrvdbg->ecmp = GLB_FLAG_ISSET(p_hsrvdbg->ecmp, HSRVDBG_FLAG_ECMP_ECMP) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_acl = TRUE;
    p_pb_hsrvdbg->acl = GLB_FLAG_ISSET(p_hsrvdbg->acl, HSRVDBG_FLAG_ACL_ACL) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_stats = TRUE;
    p_pb_hsrvdbg->stats = GLB_FLAG_ISSET(p_hsrvdbg->stats, HSRVDBG_FLAG_STATS_STATS) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_qos_class = TRUE;
    p_pb_hsrvdbg->qos_class = GLB_FLAG_ISSET(p_hsrvdbg->qos, HSRVDBG_FLAG_QOS_CLASS) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_qos_policer = TRUE;
    p_pb_hsrvdbg->qos_policer = GLB_FLAG_ISSET(p_hsrvdbg->qos, HSRVDBG_FLAG_QOS_POLICER) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_qos_process = TRUE;
    p_pb_hsrvdbg->qos_process = GLB_FLAG_ISSET(p_hsrvdbg->qos, HSRVDBG_FLAG_QOS_PROCESS) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_qos_queue = TRUE;
    p_pb_hsrvdbg->qos_queue = GLB_FLAG_ISSET(p_hsrvdbg->qos, HSRVDBG_FLAG_QOS_QUEUE) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_ipsour = TRUE;
    p_pb_hsrvdbg->ipsour = GLB_FLAG_ISSET(p_hsrvdbg->ipsour, HSRVDBG_FLAG_IPSOUR_IPSOUR) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_dot1x = TRUE;
    p_pb_hsrvdbg->dot1x = GLB_FLAG_ISSET(p_hsrvdbg->dot1x, HSRVDBG_FLAG_DOT1X_DOT1X) ? TRUE : FALSE;
    p_pb_hsrvdbg->has_stp = TRUE;
    p_pb_hsrvdbg->stp = GLB_FLAG_ISSET(p_hsrvdbg->stp, HSRVDBG_FLAG_STP_STP) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_hsrv_debug_to_pb_free_packed(Cdb__TblHsrvDebug *p_pb_hsrvdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_hsrv_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblHsrvDebug pb_hsrvdbg = CDB__TBL_HSRV_DEBUG__INIT;
    tbl_hsrv_debug_t *p_hsrvdbg = (tbl_hsrv_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_hsrv_debug_to_pb(only_key, p_hsrvdbg, &pb_hsrvdbg);
    len = cdb__tbl_hsrv_debug__pack(&pb_hsrvdbg, buf);
    pb_tbl_hsrv_debug_to_pb_free_packed(&pb_hsrvdbg);

    return len;
}

int32
pb_tbl_hsrv_debug_dump(Cdb__TblHsrvDebug *p_pb_hsrvdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/vswitch=%u", p_pb_hsrvdbg->vswitch);
    offset += sal_sprintf(out + offset, "/interface_l2if=%u", p_pb_hsrvdbg->interface_l2if);
    offset += sal_sprintf(out + offset, "/interface_l3if=%u", p_pb_hsrvdbg->interface_l3if);
    offset += sal_sprintf(out + offset, "/interface_ifdb=%u", p_pb_hsrvdbg->interface_ifdb);
    offset += sal_sprintf(out + offset, "/message_pm2hsrv=%u", p_pb_hsrvdbg->message_pm2hsrv);
    offset += sal_sprintf(out + offset, "/message_hsrv2pm=%u", p_pb_hsrvdbg->message_hsrv2pm);
    offset += sal_sprintf(out + offset, "/cpu_rx=%u", p_pb_hsrvdbg->cpu_rx);
    offset += sal_sprintf(out + offset, "/cpu_tx=%u", p_pb_hsrvdbg->cpu_tx);
    offset += sal_sprintf(out + offset, "/cpu_bpdu=%u", p_pb_hsrvdbg->cpu_bpdu);
    offset += sal_sprintf(out + offset, "/cpu_slowproto=%u", p_pb_hsrvdbg->cpu_slowproto);
    offset += sal_sprintf(out + offset, "/cpu_eapol=%u", p_pb_hsrvdbg->cpu_eapol);
    offset += sal_sprintf(out + offset, "/cpu_lldp=%u", p_pb_hsrvdbg->cpu_lldp);
    offset += sal_sprintf(out + offset, "/cpu_erps=%u", p_pb_hsrvdbg->cpu_erps);
    offset += sal_sprintf(out + offset, "/cpu_macda=%u", p_pb_hsrvdbg->cpu_macda);
    offset += sal_sprintf(out + offset, "/cpu_rip=%u", p_pb_hsrvdbg->cpu_rip);
    offset += sal_sprintf(out + offset, "/cpu_ospf=%u", p_pb_hsrvdbg->cpu_ospf);
    offset += sal_sprintf(out + offset, "/cpu_bgp=%u", p_pb_hsrvdbg->cpu_bgp);
    offset += sal_sprintf(out + offset, "/cpu_arp=%u", p_pb_hsrvdbg->cpu_arp);
    offset += sal_sprintf(out + offset, "/cpu_dhcp=%u", p_pb_hsrvdbg->cpu_dhcp);
    offset += sal_sprintf(out + offset, "/cpu_ipda=%u", p_pb_hsrvdbg->cpu_ipda);
    offset += sal_sprintf(out + offset, "/cpu_igmp=%u", p_pb_hsrvdbg->cpu_igmp);
    offset += sal_sprintf(out + offset, "/cpu_maclimit=%u", p_pb_hsrvdbg->cpu_maclimit);
    offset += sal_sprintf(out + offset, "/cpu_macmismatch=%u", p_pb_hsrvdbg->cpu_macmismatch);
    offset += sal_sprintf(out + offset, "/cpu_l3copycpu=%u", p_pb_hsrvdbg->cpu_l3copycpu);
    offset += sal_sprintf(out + offset, "/cpu_other=%u", p_pb_hsrvdbg->cpu_other);
    offset += sal_sprintf(out + offset, "/cpu_raw=%u", p_pb_hsrvdbg->cpu_raw);
    offset += sal_sprintf(out + offset, "/nexthop=%u", p_pb_hsrvdbg->nexthop);
    offset += sal_sprintf(out + offset, "/vlan=%u", p_pb_hsrvdbg->vlan);
    offset += sal_sprintf(out + offset, "/mirror=%u", p_pb_hsrvdbg->mirror);
    offset += sal_sprintf(out + offset, "/fdb=%u", p_pb_hsrvdbg->fdb);
    offset += sal_sprintf(out + offset, "/l2mc=%u", p_pb_hsrvdbg->l2mc);
    offset += sal_sprintf(out + offset, "/agg=%u", p_pb_hsrvdbg->agg);
    offset += sal_sprintf(out + offset, "/ipuc=%u", p_pb_hsrvdbg->ipuc);
    offset += sal_sprintf(out + offset, "/neighbor=%u", p_pb_hsrvdbg->neighbor);
    offset += sal_sprintf(out + offset, "/ecmp=%u", p_pb_hsrvdbg->ecmp);
    offset += sal_sprintf(out + offset, "/acl=%u", p_pb_hsrvdbg->acl);
    offset += sal_sprintf(out + offset, "/stats=%u", p_pb_hsrvdbg->stats);
    offset += sal_sprintf(out + offset, "/qos_class=%u", p_pb_hsrvdbg->qos_class);
    offset += sal_sprintf(out + offset, "/qos_policer=%u", p_pb_hsrvdbg->qos_policer);
    offset += sal_sprintf(out + offset, "/qos_process=%u", p_pb_hsrvdbg->qos_process);
    offset += sal_sprintf(out + offset, "/qos_queue=%u", p_pb_hsrvdbg->qos_queue);
    offset += sal_sprintf(out + offset, "/ipsour=%u", p_pb_hsrvdbg->ipsour);
    offset += sal_sprintf(out + offset, "/dot1x=%u", p_pb_hsrvdbg->dot1x);
    offset += sal_sprintf(out + offset, "/stp=%u", p_pb_hsrvdbg->stp);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_RIF */
int32
pb_tbl_rif_to_pb(uint32 only_key, tbl_rif_t *p_rif, Cdb__TblRif *p_pb_rif)
{
    p_pb_rif->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rif->key.name)+1);
    sal_strcpy(p_pb_rif->key->name, p_rif->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rif->has_rif_id = TRUE;
    p_pb_rif->rif_id = p_rif->rif_id;
    p_pb_rif->has_hostif_id = TRUE;
    p_pb_rif->hostif_id = p_rif->hostif_id;

    return PM_E_NONE;
}

int32
pb_tbl_rif_to_pb_free_packed(Cdb__TblRif *p_pb_rif)
{
    if (p_pb_rif->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rif->key->name);
        p_pb_rif->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_rif_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRifKey pb_rif_key = CDB__TBL_RIF_KEY__INIT;
    Cdb__TblRif pb_rif = CDB__TBL_RIF__INIT;
    tbl_rif_t *p_rif = (tbl_rif_t*)p_tbl;
    int32 len = 0;

    pb_rif.key = &pb_rif_key;
    pb_tbl_rif_to_pb(only_key, p_rif, &pb_rif);
    len = cdb__tbl_rif__pack(&pb_rif, buf);
    pb_tbl_rif_to_pb_free_packed(&pb_rif);

    return len;
}

int32
pb_tbl_rif_dump(Cdb__TblRif *p_pb_rif, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_rif->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/rif_id=%llu", p_pb_rif->rif_id);
    offset += sal_sprintf(out + offset, "/hostif_id=%llu", p_pb_rif->hostif_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_LAG */
int32
pb_tbl_fea_lag_to_pb(uint32 only_key, tbl_fea_lag_t *p_fea_lag, Cdb__TblFeaLag *p_pb_fea_lag)
{
    p_pb_fea_lag->key->id = p_fea_lag->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_lag->has_lag_id = TRUE;
    p_pb_fea_lag->lag_id = p_fea_lag->lag_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_lag_to_pb_free_packed(Cdb__TblFeaLag *p_pb_fea_lag)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_lag_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaLagKey pb_fea_lag_key = CDB__TBL_FEA_LAG_KEY__INIT;
    Cdb__TblFeaLag pb_fea_lag = CDB__TBL_FEA_LAG__INIT;
    tbl_fea_lag_t *p_fea_lag = (tbl_fea_lag_t*)p_tbl;
    int32 len = 0;

    pb_fea_lag.key = &pb_fea_lag_key;
    pb_tbl_fea_lag_to_pb(only_key, p_fea_lag, &pb_fea_lag);
    len = cdb__tbl_fea_lag__pack(&pb_fea_lag, buf);
    pb_tbl_fea_lag_to_pb_free_packed(&pb_fea_lag);

    return len;
}

int32
pb_tbl_fea_lag_dump(Cdb__TblFeaLag *p_pb_fea_lag, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_fea_lag->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/lag_id=%llu", p_pb_fea_lag->lag_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_GLOBAL */
int32
pb_tbl_fea_global_to_pb(uint32 only_key, tbl_fea_global_t *p_fea_global, Cdb__TblFeaGlobal *p_pb_fea_global)
{
    p_pb_fea_global->has_router_id = TRUE;
    p_pb_fea_global->router_id = p_fea_global->router_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_global_to_pb_free_packed(Cdb__TblFeaGlobal *p_pb_fea_global)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaGlobal pb_fea_global = CDB__TBL_FEA_GLOBAL__INIT;
    tbl_fea_global_t *p_fea_global = (tbl_fea_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_fea_global_to_pb(only_key, p_fea_global, &pb_fea_global);
    len = cdb__tbl_fea_global__pack(&pb_fea_global, buf);
    pb_tbl_fea_global_to_pb_free_packed(&pb_fea_global);

    return len;
}

int32
pb_tbl_fea_global_dump(Cdb__TblFeaGlobal *p_pb_fea_global, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/router_id=%llu", p_pb_fea_global->router_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_ACL_TABLE */
int32
pb_tbl_fea_acl_table_to_pb(uint32 only_key, tbl_fea_acl_table_t *p_fea_acl_table, Cdb__TblFeaAclTable *p_pb_fea_acl_table)
{
    p_pb_fea_acl_table->key->acl_table_id = p_fea_acl_table->key.acl_table_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_acl_table->has_direct_in = TRUE;
    p_pb_fea_acl_table->direct_in = p_fea_acl_table->direct_in;
    p_pb_fea_acl_table->has_priority = TRUE;
    p_pb_fea_acl_table->priority = p_fea_acl_table->priority;
    p_pb_fea_acl_table->table_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fea_acl_table->table_name)+1);
    sal_strcpy(p_pb_fea_acl_table->table_name, p_fea_acl_table->table_name);
    p_pb_fea_acl_table->has_sai_table_id = TRUE;
    p_pb_fea_acl_table->sai_table_id = p_fea_acl_table->sai_table_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_table_to_pb_free_packed(Cdb__TblFeaAclTable *p_pb_fea_acl_table)
{
    if (p_pb_fea_acl_table->table_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fea_acl_table->table_name);
        p_pb_fea_acl_table->table_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_table_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaAclTableKey pb_fea_acl_table_key = CDB__TBL_FEA_ACL_TABLE_KEY__INIT;
    Cdb__TblFeaAclTable pb_fea_acl_table = CDB__TBL_FEA_ACL_TABLE__INIT;
    tbl_fea_acl_table_t *p_fea_acl_table = (tbl_fea_acl_table_t*)p_tbl;
    int32 len = 0;

    pb_fea_acl_table.key = &pb_fea_acl_table_key;
    pb_tbl_fea_acl_table_to_pb(only_key, p_fea_acl_table, &pb_fea_acl_table);
    len = cdb__tbl_fea_acl_table__pack(&pb_fea_acl_table, buf);
    pb_tbl_fea_acl_table_to_pb_free_packed(&pb_fea_acl_table);

    return len;
}

int32
pb_tbl_fea_acl_table_dump(Cdb__TblFeaAclTable *p_pb_fea_acl_table, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->acl_table_id=%llu", p_pb_fea_acl_table->key->acl_table_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/direct_in=%u", p_pb_fea_acl_table->direct_in);
    offset += sal_sprintf(out + offset, "/priority=%u", p_pb_fea_acl_table->priority);
    offset += sal_sprintf(out + offset, "/table_name=%s", p_pb_fea_acl_table->table_name);
    offset += sal_sprintf(out + offset, "/sai_table_id=%llu", p_pb_fea_acl_table->sai_table_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_ACL */
int32
pb_tbl_fea_acl_to_pb(uint32 only_key, tbl_fea_acl_t *p_fea_acl, Cdb__TblFeaAcl *p_pb_fea_acl)
{
    p_pb_fea_acl->key->acl_id = p_fea_acl->key.acl_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_acl->has_sai_acl_id = TRUE;
    p_pb_fea_acl->sai_acl_id = p_fea_acl->sai_acl_id;
    p_pb_fea_acl->has_counter_id = TRUE;
    p_pb_fea_acl->counter_id = p_fea_acl->counter_id;
    p_pb_fea_acl->has_stats_packet = TRUE;
    p_pb_fea_acl->stats_packet = p_fea_acl->stats_packet;
    p_pb_fea_acl->has_stats_byte = TRUE;
    p_pb_fea_acl->stats_byte = p_fea_acl->stats_byte;

    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_to_pb_free_packed(Cdb__TblFeaAcl *p_pb_fea_acl)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaAclKey pb_fea_acl_key = CDB__TBL_FEA_ACL_KEY__INIT;
    Cdb__TblFeaAcl pb_fea_acl = CDB__TBL_FEA_ACL__INIT;
    tbl_fea_acl_t *p_fea_acl = (tbl_fea_acl_t*)p_tbl;
    int32 len = 0;

    pb_fea_acl.key = &pb_fea_acl_key;
    pb_tbl_fea_acl_to_pb(only_key, p_fea_acl, &pb_fea_acl);
    len = cdb__tbl_fea_acl__pack(&pb_fea_acl, buf);
    pb_tbl_fea_acl_to_pb_free_packed(&pb_fea_acl);

    return len;
}

int32
pb_tbl_fea_acl_dump(Cdb__TblFeaAcl *p_pb_fea_acl, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->acl_id=%llu", p_pb_fea_acl->key->acl_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/sai_acl_id=%llu", p_pb_fea_acl->sai_acl_id);
    offset += sal_sprintf(out + offset, "/counter_id=%llu", p_pb_fea_acl->counter_id);
    offset += sal_sprintf(out + offset, "/stats_packet=%llu", p_pb_fea_acl->stats_packet);
    offset += sal_sprintf(out + offset, "/stats_byte=%llu", p_pb_fea_acl->stats_byte);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_FDB */
int32
pb_tbl_fea_fdb_to_pb(uint32 only_key, tbl_fea_fdb_t *p_fdb, Cdb__TblFeaFdb *p_pb_fdb)
{
    pb_compose_fdb_key_t_to_pb(&p_fdb->key, p_pb_fdb->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fdb->has_ifindex = TRUE;
    p_pb_fdb->ifindex = p_fdb->ifindex;
    p_pb_fdb->has_mlag_source_ifindex = TRUE;
    p_pb_fdb->mlag_source_ifindex = p_fdb->mlag_source_ifindex;
    p_pb_fdb->has_portid = TRUE;
    p_pb_fdb->portid = p_fdb->portid;
    p_pb_fdb->has_flags = TRUE;
    p_pb_fdb->flags = p_fdb->flags;
    p_pb_fdb->has_fea_fail = TRUE;
    p_pb_fdb->fea_fail = p_fdb->fea_fail;

    return PM_E_NONE;
}

int32
pb_tbl_fea_fdb_to_pb_free_packed(Cdb__TblFeaFdb *p_pb_fdb)
{
    pb_compose_fdb_key_t_to_pb_free_packed(p_pb_fdb->key);
    return PM_E_NONE;
}

int32
pb_tbl_fea_fdb_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaFdbKey pb_fdb_key = CDB__TBL_FEA_FDB_KEY__INIT;
    Cdb__TblFeaFdb pb_fdb = CDB__TBL_FEA_FDB__INIT;
    tbl_fea_fdb_t *p_fdb = (tbl_fea_fdb_t*)p_tbl;
    int32 len = 0;

    pb_fdb.key = &pb_fdb_key;
    pb_tbl_fea_fdb_to_pb(only_key, p_fdb, &pb_fdb);
    len = cdb__tbl_fea_fdb__pack(&pb_fdb, buf);
    pb_tbl_fea_fdb_to_pb_free_packed(&pb_fdb);

    return len;
}

int32
pb_tbl_fea_fdb_dump(Cdb__TblFeaFdb *p_pb_fdb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_fdb_key_t_dump(p_pb_fdb->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_fdb->ifindex);
    offset += sal_sprintf(out + offset, "/mlag_source_ifindex=%u", p_pb_fdb->mlag_source_ifindex);
    offset += sal_sprintf(out + offset, "/portid=%llu", p_pb_fdb->portid);
    offset += sal_sprintf(out + offset, "/flags=%u", p_pb_fdb->flags);
    offset += sal_sprintf(out + offset, "/fea_fail=%u", p_pb_fdb->fea_fail);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_BRG_IF */
int32
pb_tbl_fea_brg_if_to_pb(uint32 only_key, tbl_fea_brg_if_t *p_brgif, Cdb__TblFeaBrgIf *p_pb_brgif)
{
    p_pb_brgif->key->ifindex = p_brgif->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_brgif->has_lag_id = TRUE;
    p_pb_brgif->lag_id = p_brgif->lag_id;
    p_pb_brgif->has_mac_learning_en = TRUE;
    p_pb_brgif->mac_learning_en = p_brgif->mac_learning_en;
    p_pb_brgif->has_port_security_en = TRUE;
    p_pb_brgif->port_security_en = p_brgif->port_security_en;
    p_pb_brgif->has_max_mac = TRUE;
    p_pb_brgif->max_mac = p_brgif->max_mac;
    p_pb_brgif->has_curr_mac = TRUE;
    p_pb_brgif->curr_mac = p_brgif->curr_mac;
    p_pb_brgif->has_curr_mac_static = TRUE;
    p_pb_brgif->curr_mac_static = p_brgif->curr_mac_static;
    p_pb_brgif->has_mlag_id = TRUE;
    p_pb_brgif->mlag_id = p_brgif->mlag_id;
    p_pb_brgif->has_mlag_peer_conf = TRUE;
    p_pb_brgif->mlag_peer_conf = p_brgif->mlag_peer_conf;
    p_pb_brgif->has_mlag_peer_if_up = TRUE;
    p_pb_brgif->mlag_peer_if_up = p_brgif->mlag_peer_if_up;
    p_pb_brgif->has_mlag_is_group = TRUE;
    p_pb_brgif->mlag_is_group = p_brgif->mlag_is_group;
    p_pb_brgif->has_hw_type = TRUE;
    p_pb_brgif->hw_type = p_brgif->hw_type;
    p_pb_brgif->has_portid = TRUE;
    p_pb_brgif->portid = p_brgif->portid;
    p_pb_brgif->has_disable_learn = TRUE;
    p_pb_brgif->disable_learn.len = sizeof(p_brgif->disable_learn);
    p_pb_brgif->disable_learn.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_brgif->disable_learn));
    sal_memcpy(p_pb_brgif->disable_learn.data, p_brgif->disable_learn, sizeof(p_brgif->disable_learn));

    return PM_E_NONE;
}

int32
pb_tbl_fea_brg_if_to_pb_free_packed(Cdb__TblFeaBrgIf *p_pb_brgif)
{
    if (p_pb_brgif->disable_learn.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_brgif->disable_learn.data);
        p_pb_brgif->disable_learn.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fea_brg_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaBrgIfKey pb_brgif_key = CDB__TBL_FEA_BRG_IF_KEY__INIT;
    Cdb__TblFeaBrgIf pb_brgif = CDB__TBL_FEA_BRG_IF__INIT;
    tbl_fea_brg_if_t *p_brgif = (tbl_fea_brg_if_t*)p_tbl;
    int32 len = 0;

    pb_brgif.key = &pb_brgif_key;
    pb_tbl_fea_brg_if_to_pb(only_key, p_brgif, &pb_brgif);
    len = cdb__tbl_fea_brg_if__pack(&pb_brgif, buf);
    pb_tbl_fea_brg_if_to_pb_free_packed(&pb_brgif);

    return len;
}

int32
pb_tbl_fea_brg_if_dump(Cdb__TblFeaBrgIf *p_pb_brgif, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_brgif->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/lag_id=%u", p_pb_brgif->lag_id);
    offset += sal_sprintf(out + offset, "/mac_learning_en=%u", p_pb_brgif->mac_learning_en);
    offset += sal_sprintf(out + offset, "/port_security_en=%u", p_pb_brgif->port_security_en);
    offset += sal_sprintf(out + offset, "/max_mac=%u", p_pb_brgif->max_mac);
    offset += sal_sprintf(out + offset, "/curr_mac=%d", p_pb_brgif->curr_mac);
    offset += sal_sprintf(out + offset, "/curr_mac_static=%d", p_pb_brgif->curr_mac_static);
    offset += sal_sprintf(out + offset, "/mlag_id=%u", p_pb_brgif->mlag_id);
    offset += sal_sprintf(out + offset, "/mlag_peer_conf=%u", p_pb_brgif->mlag_peer_conf);
    offset += sal_sprintf(out + offset, "/mlag_peer_if_up=%u", p_pb_brgif->mlag_peer_if_up);
    offset += sal_sprintf(out + offset, "/mlag_is_group=%u", p_pb_brgif->mlag_is_group);
    offset += sal_sprintf(out + offset, "/hw_type=%u", p_pb_brgif->hw_type);
    offset += sal_sprintf(out + offset, "/portid=%llu", p_pb_brgif->portid);
    offset += sal_sprintf(out + offset, "/disable_learn=");
    offset += pb_uint8_array_dump(p_pb_brgif->disable_learn.data, p_pb_brgif->disable_learn.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_WORM_FILTER */
int32
pb_tbl_acl_worm_filter_to_pb(uint32 only_key, tbl_acl_worm_filter_t *p_acl_worm_filter, Cdb__TblAclWormFilter *p_pb_acl_worm_filter)
{
    p_pb_acl_worm_filter->key->worm_filter_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_worm_filter->key.worm_filter_name)+1);
    sal_strcpy(p_pb_acl_worm_filter->key->worm_filter_name, p_acl_worm_filter->key.worm_filter_name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_worm_filter->has_seq_num = TRUE;
    p_pb_acl_worm_filter->seq_num = p_acl_worm_filter->seq_num;
    p_pb_acl_worm_filter->has_enable = TRUE;
    p_pb_acl_worm_filter->enable = p_acl_worm_filter->enable;
    p_pb_acl_worm_filter->has_istcp = TRUE;
    p_pb_acl_worm_filter->istcp = p_acl_worm_filter->istcp;
    p_pb_acl_worm_filter->has_dstport = TRUE;
    p_pb_acl_worm_filter->dstport = p_acl_worm_filter->dstport;
    p_pb_acl_worm_filter->has_isrange = TRUE;
    p_pb_acl_worm_filter->isrange = p_acl_worm_filter->isrange;
    p_pb_acl_worm_filter->has_stats_en = TRUE;
    p_pb_acl_worm_filter->stats_en = p_acl_worm_filter->stats_en;

    return PM_E_NONE;
}

int32
pb_tbl_acl_worm_filter_to_pb_free_packed(Cdb__TblAclWormFilter *p_pb_acl_worm_filter)
{
    if (p_pb_acl_worm_filter->key->worm_filter_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_worm_filter->key->worm_filter_name);
        p_pb_acl_worm_filter->key->worm_filter_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_worm_filter_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclWormFilterKey pb_acl_worm_filter_key = CDB__TBL_ACL_WORM_FILTER_KEY__INIT;
    Cdb__TblAclWormFilter pb_acl_worm_filter = CDB__TBL_ACL_WORM_FILTER__INIT;
    tbl_acl_worm_filter_t *p_acl_worm_filter = (tbl_acl_worm_filter_t*)p_tbl;
    int32 len = 0;

    pb_acl_worm_filter.key = &pb_acl_worm_filter_key;
    pb_tbl_acl_worm_filter_to_pb(only_key, p_acl_worm_filter, &pb_acl_worm_filter);
    len = cdb__tbl_acl_worm_filter__pack(&pb_acl_worm_filter, buf);
    pb_tbl_acl_worm_filter_to_pb_free_packed(&pb_acl_worm_filter);

    return len;
}

int32
pb_tbl_acl_worm_filter_dump(Cdb__TblAclWormFilter *p_pb_acl_worm_filter, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->worm_filter_name=%s", p_pb_acl_worm_filter->key->worm_filter_name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/seq_num=%u", p_pb_acl_worm_filter->seq_num);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_acl_worm_filter->enable);
    offset += sal_sprintf(out + offset, "/istcp=%u", p_pb_acl_worm_filter->istcp);
    offset += sal_sprintf(out + offset, "/dstport=%u", p_pb_acl_worm_filter->dstport);
    offset += sal_sprintf(out + offset, "/isrange=%u", p_pb_acl_worm_filter->isrange);
    offset += sal_sprintf(out + offset, "/stats_en=%u", p_pb_acl_worm_filter->stats_en);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_CONFIG */
int32
pb_tbl_acl_config_to_pb(uint32 only_key, tbl_acl_config_t *p_acl_config, Cdb__TblAclConfig *p_pb_acl_config)
{
    p_pb_acl_config->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_config->key.name)+1);
    sal_strcpy(p_pb_acl_config->key->name, p_acl_config->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_config->has_ace_ref = TRUE;
    p_pb_acl_config->ace_ref = p_acl_config->ace_ref;
    p_pb_acl_config->has_intf_ref_in = TRUE;
    p_pb_acl_config->intf_ref_in = p_acl_config->intf_ref_in;
    p_pb_acl_config->has_intf_ref_out = TRUE;
    p_pb_acl_config->intf_ref_out = p_acl_config->intf_ref_out;
    p_pb_acl_config->has_l4_port_ref = TRUE;
    p_pb_acl_config->l4_port_ref = p_acl_config->l4_port_ref;
    p_pb_acl_config->has_tcp_flags_ref = TRUE;
    p_pb_acl_config->tcp_flags_ref = p_acl_config->tcp_flags_ref;
    p_pb_acl_config->remark = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_config->remark)+1);
    sal_strcpy(p_pb_acl_config->remark, p_acl_config->remark);
    p_pb_acl_config->has_seq_ref = TRUE;
    p_pb_acl_config->seq_ref = p_acl_config->seq_ref;
    p_pb_acl_config->has_ether_ref = TRUE;
    p_pb_acl_config->ether_ref = p_acl_config->ether_ref;
    p_pb_acl_config->has_tap_ref = TRUE;
    p_pb_acl_config->tap_ref = p_acl_config->tap_ref;
    p_pb_acl_config->has_type_identifying = TRUE;
    p_pb_acl_config->type_identifying = p_acl_config->type_identifying;
    p_pb_acl_config->has_ace_truncation_ref_cnt = TRUE;
    p_pb_acl_config->ace_truncation_ref_cnt = p_acl_config->ace_truncation_ref_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_acl_config_to_pb_free_packed(Cdb__TblAclConfig *p_pb_acl_config)
{
    if (p_pb_acl_config->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_config->key->name);
        p_pb_acl_config->key->name = NULL;
    }

    if (p_pb_acl_config->remark)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_config->remark);
        p_pb_acl_config->remark = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclConfigKey pb_acl_config_key = CDB__TBL_ACL_CONFIG_KEY__INIT;
    Cdb__TblAclConfig pb_acl_config = CDB__TBL_ACL_CONFIG__INIT;
    tbl_acl_config_t *p_acl_config = (tbl_acl_config_t*)p_tbl;
    int32 len = 0;

    pb_acl_config.key = &pb_acl_config_key;
    pb_tbl_acl_config_to_pb(only_key, p_acl_config, &pb_acl_config);
    len = cdb__tbl_acl_config__pack(&pb_acl_config, buf);
    pb_tbl_acl_config_to_pb_free_packed(&pb_acl_config);

    return len;
}

int32
pb_tbl_acl_config_dump(Cdb__TblAclConfig *p_pb_acl_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_acl_config->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ace_ref=%u", p_pb_acl_config->ace_ref);
    offset += sal_sprintf(out + offset, "/intf_ref_in=%u", p_pb_acl_config->intf_ref_in);
    offset += sal_sprintf(out + offset, "/intf_ref_out=%u", p_pb_acl_config->intf_ref_out);
    offset += sal_sprintf(out + offset, "/l4_port_ref=%u", p_pb_acl_config->l4_port_ref);
    offset += sal_sprintf(out + offset, "/tcp_flags_ref=%u", p_pb_acl_config->tcp_flags_ref);
    offset += sal_sprintf(out + offset, "/remark=%s", p_pb_acl_config->remark);
    offset += sal_sprintf(out + offset, "/seq_ref=%u", p_pb_acl_config->seq_ref);
    offset += sal_sprintf(out + offset, "/ether_ref=%u", p_pb_acl_config->ether_ref);
    offset += sal_sprintf(out + offset, "/tap_ref=%u", p_pb_acl_config->tap_ref);
    offset += sal_sprintf(out + offset, "/type_identifying=%u", p_pb_acl_config->type_identifying);
    offset += sal_sprintf(out + offset, "/ace_truncation_ref_cnt=%u", p_pb_acl_config->ace_truncation_ref_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACE_CONFIG */
int32
pb_tbl_ace_config_to_pb(uint32 only_key, tbl_ace_config_t *p_ace_config, Cdb__TblAceConfig *p_pb_ace_config)
{
    pb_compose_ace_config_key_t_to_pb(&p_ace_config->key, p_pb_ace_config->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ace_config->has_key_flags = TRUE;
    p_pb_ace_config->key_flags = p_ace_config->key_flags;
    p_pb_ace_config->time_range = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ace_config->time_range)+1);
    sal_strcpy(p_pb_ace_config->time_range, p_ace_config->time_range);
    p_pb_ace_config->has_apply_cnt = TRUE;
    p_pb_ace_config->apply_cnt = p_ace_config->apply_cnt;
    p_pb_ace_config->has_in_port = TRUE;
    p_pb_ace_config->in_port = p_ace_config->in_port;
    p_pb_ace_config->has_out_port = TRUE;
    p_pb_ace_config->out_port = p_ace_config->out_port;
    p_pb_ace_config->has_ether_type = TRUE;
    p_pb_ace_config->ether_type = p_ace_config->ether_type;
    p_pb_ace_config->has_ether_type_mask = TRUE;
    p_pb_ace_config->ether_type_mask = p_ace_config->ether_type_mask;
    pb_compose_mac_addr_t_to_pb(p_ace_config->src_mac, p_pb_ace_config->src_mac);
    pb_compose_mac_addr_t_to_pb(p_ace_config->src_mac_mask, p_pb_ace_config->src_mac_mask);
    pb_compose_mac_addr_t_to_pb(p_ace_config->dst_mac, p_pb_ace_config->dst_mac);
    pb_compose_mac_addr_t_to_pb(p_ace_config->dst_mac_mask, p_pb_ace_config->dst_mac_mask);
    p_pb_ace_config->has_svlan = TRUE;
    p_pb_ace_config->svlan = p_ace_config->svlan;
    p_pb_ace_config->has_svlan_mask = TRUE;
    p_pb_ace_config->svlan_mask = p_ace_config->svlan_mask;
    p_pb_ace_config->has_svlan_cos = TRUE;
    p_pb_ace_config->svlan_cos = p_ace_config->svlan_cos;
    p_pb_ace_config->has_svlan_cos_mask = TRUE;
    p_pb_ace_config->svlan_cos_mask = p_ace_config->svlan_cos_mask;
    p_pb_ace_config->has_cvlan = TRUE;
    p_pb_ace_config->cvlan = p_ace_config->cvlan;
    p_pb_ace_config->has_cvlan_mask = TRUE;
    p_pb_ace_config->cvlan_mask = p_ace_config->cvlan_mask;
    p_pb_ace_config->has_cvlan_cos = TRUE;
    p_pb_ace_config->cvlan_cos = p_ace_config->cvlan_cos;
    p_pb_ace_config->has_cvlan_cos_mask = TRUE;
    p_pb_ace_config->cvlan_cos_mask = p_ace_config->cvlan_cos_mask;
    p_pb_ace_config->has_ip_type = TRUE;
    p_pb_ace_config->ip_type = p_ace_config->ip_type;
    p_pb_ace_config->has_ip_type_mask = TRUE;
    p_pb_ace_config->ip_type_mask = p_ace_config->ip_type_mask;
    p_pb_ace_config->has_ip_flags = TRUE;
    p_pb_ace_config->ip_flags = p_ace_config->ip_flags;
    p_pb_ace_config->has_ip_flags_mask = TRUE;
    p_pb_ace_config->ip_flags_mask = p_ace_config->ip_flags_mask;
    pb_compose_addr_ipv4_t_to_pb(&p_ace_config->src_ip, p_pb_ace_config->src_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_ace_config->src_ip_mask, p_pb_ace_config->src_ip_mask);
    pb_compose_addr_ipv4_t_to_pb(&p_ace_config->dst_ip, p_pb_ace_config->dst_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_ace_config->dst_ip_mask, p_pb_ace_config->dst_ip_mask);
    p_pb_ace_config->has_dscp = TRUE;
    p_pb_ace_config->dscp = p_ace_config->dscp;
    p_pb_ace_config->has_dscp_mask = TRUE;
    p_pb_ace_config->dscp_mask = p_ace_config->dscp_mask;
    p_pb_ace_config->has_ip_precedence = TRUE;
    p_pb_ace_config->ip_precedence = p_ace_config->ip_precedence;
    p_pb_ace_config->has_ip_precedence_mask = TRUE;
    p_pb_ace_config->ip_precedence_mask = p_ace_config->ip_precedence_mask;
    p_pb_ace_config->has_ip_protocol = TRUE;
    p_pb_ace_config->ip_protocol = p_ace_config->ip_protocol;
    p_pb_ace_config->has_ip_protocol_mask = TRUE;
    p_pb_ace_config->ip_protocol_mask = p_ace_config->ip_protocol_mask;
    p_pb_ace_config->has_l4_src_port_type = TRUE;
    p_pb_ace_config->l4_src_port_type = p_ace_config->l4_src_port_type;
    p_pb_ace_config->has_l4_src_port = TRUE;
    p_pb_ace_config->l4_src_port = p_ace_config->l4_src_port;
    p_pb_ace_config->has_l4_src_port_mask = TRUE;
    p_pb_ace_config->l4_src_port_mask = p_ace_config->l4_src_port_mask;
    p_pb_ace_config->has_l4_dst_port_type = TRUE;
    p_pb_ace_config->l4_dst_port_type = p_ace_config->l4_dst_port_type;
    p_pb_ace_config->has_l4_dst_port = TRUE;
    p_pb_ace_config->l4_dst_port = p_ace_config->l4_dst_port;
    p_pb_ace_config->has_l4_dst_port_mask = TRUE;
    p_pb_ace_config->l4_dst_port_mask = p_ace_config->l4_dst_port_mask;
    p_pb_ace_config->has_ip_frag = TRUE;
    p_pb_ace_config->ip_frag = p_ace_config->ip_frag;
    p_pb_ace_config->has_tcp_flags = TRUE;
    p_pb_ace_config->tcp_flags = p_ace_config->tcp_flags;
    p_pb_ace_config->has_tcp_flags_mask = TRUE;
    p_pb_ace_config->tcp_flags_mask = p_ace_config->tcp_flags_mask;
    p_pb_ace_config->has_igmp_type = TRUE;
    p_pb_ace_config->igmp_type = p_ace_config->igmp_type;
    p_pb_ace_config->has_icmp_type = TRUE;
    p_pb_ace_config->icmp_type = p_ace_config->icmp_type;
    p_pb_ace_config->has_icmp_code = TRUE;
    p_pb_ace_config->icmp_code = p_ace_config->icmp_code;
    p_pb_ace_config->has_l4_vxlan_vni = TRUE;
    p_pb_ace_config->l4_vxlan_vni = p_ace_config->l4_vxlan_vni;
    p_pb_ace_config->has_l4_vxlan_vni_mask = TRUE;
    p_pb_ace_config->l4_vxlan_vni_mask = p_ace_config->l4_vxlan_vni_mask;
    p_pb_ace_config->has_deny = TRUE;
    p_pb_ace_config->deny = p_ace_config->deny;
    p_pb_ace_config->has_stats_en = TRUE;
    p_pb_ace_config->stats_en = p_ace_config->stats_en;
    p_pb_ace_config->has_options = TRUE;
    p_pb_ace_config->options = p_ace_config->options;
    p_pb_ace_config->has_action_strip_header = TRUE;
    p_pb_ace_config->action_strip_header = p_ace_config->action_strip_header;
    p_pb_ace_config->has_tap_action_redirect = TRUE;
    p_pb_ace_config->tap_action_redirect = p_ace_config->tap_action_redirect;
    p_pb_ace_config->has_tap_action_mark_vlan = TRUE;
    p_pb_ace_config->tap_action_mark_vlan = p_ace_config->tap_action_mark_vlan;
    p_pb_ace_config->has_tap_action_untag = TRUE;
    p_pb_ace_config->tap_action_untag = p_ace_config->tap_action_untag;
    p_pb_ace_config->has_tap_action_trunction = TRUE;
    p_pb_ace_config->tap_action_trunction = p_ace_config->tap_action_trunction;
    p_pb_ace_config->has_tap_action_edit_dest_mac_en = TRUE;
    p_pb_ace_config->tap_action_edit_dest_mac_en = p_ace_config->tap_action_edit_dest_mac_en;
    pb_compose_mac_addr_t_to_pb(p_ace_config->tap_action_edit_dest_mac, p_pb_ace_config->tap_action_edit_dest_mac);
    p_pb_ace_config->has_tap_action_edit_src_mac_en = TRUE;
    p_pb_ace_config->tap_action_edit_src_mac_en = p_ace_config->tap_action_edit_src_mac_en;
    pb_compose_mac_addr_t_to_pb(p_ace_config->tap_action_edit_src_mac, p_pb_ace_config->tap_action_edit_src_mac);
    p_pb_ace_config->has_tap_action_edit_ipda_en = TRUE;
    p_pb_ace_config->tap_action_edit_ipda_en = p_ace_config->tap_action_edit_ipda_en;
    pb_compose_addr_t_to_pb(&p_ace_config->tap_action_edit_ipda, p_pb_ace_config->tap_action_edit_ipda);
    p_pb_ace_config->has_tap_action_edit_ipsa_en = TRUE;
    p_pb_ace_config->tap_action_edit_ipsa_en = p_ace_config->tap_action_edit_ipsa_en;
    pb_compose_addr_t_to_pb(&p_ace_config->tap_action_edit_ipsa, p_pb_ace_config->tap_action_edit_ipsa);
    p_pb_ace_config->has_tap_snmp_set = TRUE;
    p_pb_ace_config->tap_snmp_set = p_ace_config->tap_snmp_set;

    return PM_E_NONE;
}

int32
pb_tbl_ace_config_to_pb_free_packed(Cdb__TblAceConfig *p_pb_ace_config)
{
    pb_compose_ace_config_key_t_to_pb_free_packed(p_pb_ace_config->key);
    if (p_pb_ace_config->time_range)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ace_config->time_range);
        p_pb_ace_config->time_range = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->src_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->src_mac_mask);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->dst_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->dst_mac_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ace_config->src_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ace_config->src_ip_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ace_config->dst_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ace_config->dst_ip_mask);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->tap_action_edit_dest_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_ace_config->tap_action_edit_src_mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_ace_config->tap_action_edit_ipda);
    pb_compose_addr_t_to_pb_free_packed(p_pb_ace_config->tap_action_edit_ipsa);
    return PM_E_NONE;
}

int32
pb_tbl_ace_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAceConfigKey pb_ace_config_key = CDB__TBL_ACE_CONFIG_KEY__INIT;
    Cdb__TblAceConfig pb_ace_config = CDB__TBL_ACE_CONFIG__INIT;
    tbl_ace_config_t *p_ace_config = (tbl_ace_config_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT src_mac_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT dst_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT dst_mac_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T dst_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T dst_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeMacAddrT tap_action_edit_dest_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT tap_action_edit_src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT tap_action_edit_ipda = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__ComposeAddrT tap_action_edit_ipsa = CDB__COMPOSE_ADDR_T__INIT;

    pb_ace_config.key = &pb_ace_config_key;
    pb_ace_config.src_mac = &src_mac;
    pb_ace_config.src_mac_mask = &src_mac_mask;
    pb_ace_config.dst_mac = &dst_mac;
    pb_ace_config.dst_mac_mask = &dst_mac_mask;
    pb_ace_config.src_ip = &src_ip;
    pb_ace_config.src_ip_mask = &src_ip_mask;
    pb_ace_config.dst_ip = &dst_ip;
    pb_ace_config.dst_ip_mask = &dst_ip_mask;
    pb_ace_config.tap_action_edit_dest_mac = &tap_action_edit_dest_mac;
    pb_ace_config.tap_action_edit_src_mac = &tap_action_edit_src_mac;
    pb_ace_config.tap_action_edit_ipda = &tap_action_edit_ipda;
    pb_ace_config.tap_action_edit_ipsa = &tap_action_edit_ipsa;
    pb_tbl_ace_config_to_pb(only_key, p_ace_config, &pb_ace_config);
    len = cdb__tbl_ace_config__pack(&pb_ace_config, buf);
    pb_tbl_ace_config_to_pb_free_packed(&pb_ace_config);

    return len;
}

int32
pb_tbl_ace_config_dump(Cdb__TblAceConfig *p_pb_ace_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_ace_config_key_t_dump(p_pb_ace_config->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/key_flags=%u", p_pb_ace_config->key_flags);
    offset += sal_sprintf(out + offset, "/time_range=%s", p_pb_ace_config->time_range);
    offset += sal_sprintf(out + offset, "/apply_cnt=%u", p_pb_ace_config->apply_cnt);
    offset += sal_sprintf(out + offset, "/in_port=%u", p_pb_ace_config->in_port);
    offset += sal_sprintf(out + offset, "/out_port=%u", p_pb_ace_config->out_port);
    offset += sal_sprintf(out + offset, "/ether_type=%u", p_pb_ace_config->ether_type);
    offset += sal_sprintf(out + offset, "/ether_type_mask=%u", p_pb_ace_config->ether_type_mask);
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->src_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->src_mac_mask, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->dst_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->dst_mac_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/svlan=%u", p_pb_ace_config->svlan);
    offset += sal_sprintf(out + offset, "/svlan_mask=%u", p_pb_ace_config->svlan_mask);
    offset += sal_sprintf(out + offset, "/svlan_cos=%u", p_pb_ace_config->svlan_cos);
    offset += sal_sprintf(out + offset, "/svlan_cos_mask=%u", p_pb_ace_config->svlan_cos_mask);
    offset += sal_sprintf(out + offset, "/cvlan=%u", p_pb_ace_config->cvlan);
    offset += sal_sprintf(out + offset, "/cvlan_mask=%u", p_pb_ace_config->cvlan_mask);
    offset += sal_sprintf(out + offset, "/cvlan_cos=%u", p_pb_ace_config->cvlan_cos);
    offset += sal_sprintf(out + offset, "/cvlan_cos_mask=%u", p_pb_ace_config->cvlan_cos_mask);
    offset += sal_sprintf(out + offset, "/ip_type=%u", p_pb_ace_config->ip_type);
    offset += sal_sprintf(out + offset, "/ip_type_mask=%u", p_pb_ace_config->ip_type_mask);
    offset += sal_sprintf(out + offset, "/ip_flags=%u", p_pb_ace_config->ip_flags);
    offset += sal_sprintf(out + offset, "/ip_flags_mask=%u", p_pb_ace_config->ip_flags_mask);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ace_config->src_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ace_config->src_ip_mask, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ace_config->dst_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ace_config->dst_ip_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_ace_config->dscp);
    offset += sal_sprintf(out + offset, "/dscp_mask=%u", p_pb_ace_config->dscp_mask);
    offset += sal_sprintf(out + offset, "/ip_precedence=%u", p_pb_ace_config->ip_precedence);
    offset += sal_sprintf(out + offset, "/ip_precedence_mask=%u", p_pb_ace_config->ip_precedence_mask);
    offset += sal_sprintf(out + offset, "/ip_protocol=%u", p_pb_ace_config->ip_protocol);
    offset += sal_sprintf(out + offset, "/ip_protocol_mask=%u", p_pb_ace_config->ip_protocol_mask);
    offset += sal_sprintf(out + offset, "/l4_src_port_type=%u", p_pb_ace_config->l4_src_port_type);
    offset += sal_sprintf(out + offset, "/l4_src_port=%u", p_pb_ace_config->l4_src_port);
    offset += sal_sprintf(out + offset, "/l4_src_port_mask=%u", p_pb_ace_config->l4_src_port_mask);
    offset += sal_sprintf(out + offset, "/l4_dst_port_type=%u", p_pb_ace_config->l4_dst_port_type);
    offset += sal_sprintf(out + offset, "/l4_dst_port=%u", p_pb_ace_config->l4_dst_port);
    offset += sal_sprintf(out + offset, "/l4_dst_port_mask=%u", p_pb_ace_config->l4_dst_port_mask);
    offset += sal_sprintf(out + offset, "/ip_frag=%u", p_pb_ace_config->ip_frag);
    offset += sal_sprintf(out + offset, "/tcp_flags=%u", p_pb_ace_config->tcp_flags);
    offset += sal_sprintf(out + offset, "/tcp_flags_mask=%u", p_pb_ace_config->tcp_flags_mask);
    offset += sal_sprintf(out + offset, "/igmp_type=%u", p_pb_ace_config->igmp_type);
    offset += sal_sprintf(out + offset, "/icmp_type=%u", p_pb_ace_config->icmp_type);
    offset += sal_sprintf(out + offset, "/icmp_code=%u", p_pb_ace_config->icmp_code);
    offset += sal_sprintf(out + offset, "/l4_vxlan_vni=%u", p_pb_ace_config->l4_vxlan_vni);
    offset += sal_sprintf(out + offset, "/l4_vxlan_vni_mask=%u", p_pb_ace_config->l4_vxlan_vni_mask);
    offset += sal_sprintf(out + offset, "/deny=%u", p_pb_ace_config->deny);
    offset += sal_sprintf(out + offset, "/stats_en=%u", p_pb_ace_config->stats_en);
    offset += sal_sprintf(out + offset, "/options=%u", p_pb_ace_config->options);
    offset += sal_sprintf(out + offset, "/action_strip_header=%u", p_pb_ace_config->action_strip_header);
    offset += sal_sprintf(out + offset, "/tap_action_redirect=%u", p_pb_ace_config->tap_action_redirect);
    offset += sal_sprintf(out + offset, "/tap_action_mark_vlan=%u", p_pb_ace_config->tap_action_mark_vlan);
    offset += sal_sprintf(out + offset, "/tap_action_untag=%u", p_pb_ace_config->tap_action_untag);
    offset += sal_sprintf(out + offset, "/tap_action_trunction=%u", p_pb_ace_config->tap_action_trunction);
    offset += sal_sprintf(out + offset, "/tap_action_edit_dest_mac_en=%u", p_pb_ace_config->tap_action_edit_dest_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->tap_action_edit_dest_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_src_mac_en=%u", p_pb_ace_config->tap_action_edit_src_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_ace_config->tap_action_edit_src_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_ipda_en=%u", p_pb_ace_config->tap_action_edit_ipda_en);
    offset += pb_compose_addr_t_dump(p_pb_ace_config->tap_action_edit_ipda, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_ipsa_en=%u", p_pb_ace_config->tap_action_edit_ipsa_en);
    offset += pb_compose_addr_t_dump(p_pb_ace_config->tap_action_edit_ipsa, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_snmp_set=%u", p_pb_ace_config->tap_snmp_set);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_ENTRY */
int32
pb_tbl_acl_entry_to_pb(uint32 only_key, tbl_acl_entry_t *p_acl_entry, Cdb__TblAclEntry *p_pb_acl_entry)
{
    p_pb_acl_entry->key->aclid = p_acl_entry->key.aclid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_entry->has_tblid = TRUE;
    p_pb_acl_entry->tblid = p_acl_entry->tblid;
    p_pb_acl_entry->has_entry_priority = TRUE;
    p_pb_acl_entry->entry_priority = p_acl_entry->entry_priority;
    p_pb_acl_entry->time_range = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_entry->time_range)+1);
    sal_strcpy(p_pb_acl_entry->time_range, p_acl_entry->time_range);
    p_pb_acl_entry->has_key_flags = TRUE;
    p_pb_acl_entry->key_flags = p_acl_entry->key_flags;
    p_pb_acl_entry->has_invalid = TRUE;
    p_pb_acl_entry->invalid = p_acl_entry->invalid;
    p_pb_acl_entry->has_is_copp = TRUE;
    p_pb_acl_entry->is_copp = p_acl_entry->is_copp;
    p_pb_acl_entry->has_in_port = TRUE;
    p_pb_acl_entry->in_port = p_acl_entry->in_port;
    p_pb_acl_entry->has_out_port = TRUE;
    p_pb_acl_entry->out_port = p_acl_entry->out_port;
    p_pb_acl_entry->has_ether_type = TRUE;
    p_pb_acl_entry->ether_type = p_acl_entry->ether_type;
    p_pb_acl_entry->has_ether_type_mask = TRUE;
    p_pb_acl_entry->ether_type_mask = p_acl_entry->ether_type_mask;
    pb_compose_mac_addr_t_to_pb(p_acl_entry->src_mac, p_pb_acl_entry->src_mac);
    pb_compose_mac_addr_t_to_pb(p_acl_entry->src_mac_mask, p_pb_acl_entry->src_mac_mask);
    pb_compose_mac_addr_t_to_pb(p_acl_entry->dst_mac, p_pb_acl_entry->dst_mac);
    pb_compose_mac_addr_t_to_pb(p_acl_entry->dst_mac_mask, p_pb_acl_entry->dst_mac_mask);
    p_pb_acl_entry->has_svlan = TRUE;
    p_pb_acl_entry->svlan = p_acl_entry->svlan;
    p_pb_acl_entry->has_svlan_mask = TRUE;
    p_pb_acl_entry->svlan_mask = p_acl_entry->svlan_mask;
    p_pb_acl_entry->has_svlan_cos = TRUE;
    p_pb_acl_entry->svlan_cos = p_acl_entry->svlan_cos;
    p_pb_acl_entry->has_svlan_cos_mask = TRUE;
    p_pb_acl_entry->svlan_cos_mask = p_acl_entry->svlan_cos_mask;
    p_pb_acl_entry->has_cvlan = TRUE;
    p_pb_acl_entry->cvlan = p_acl_entry->cvlan;
    p_pb_acl_entry->has_cvlan_mask = TRUE;
    p_pb_acl_entry->cvlan_mask = p_acl_entry->cvlan_mask;
    p_pb_acl_entry->has_cvlan_cos = TRUE;
    p_pb_acl_entry->cvlan_cos = p_acl_entry->cvlan_cos;
    p_pb_acl_entry->has_cvlan_cos_mask = TRUE;
    p_pb_acl_entry->cvlan_cos_mask = p_acl_entry->cvlan_cos_mask;
    p_pb_acl_entry->has_ip_type = TRUE;
    p_pb_acl_entry->ip_type = p_acl_entry->ip_type;
    p_pb_acl_entry->has_ip_type_mask = TRUE;
    p_pb_acl_entry->ip_type_mask = p_acl_entry->ip_type_mask;
    p_pb_acl_entry->has_ip_flags = TRUE;
    p_pb_acl_entry->ip_flags = p_acl_entry->ip_flags;
    p_pb_acl_entry->has_ip_flags_mask = TRUE;
    p_pb_acl_entry->ip_flags_mask = p_acl_entry->ip_flags_mask;
    pb_compose_addr_ipv4_t_to_pb(&p_acl_entry->src_ip, p_pb_acl_entry->src_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_acl_entry->src_ip_mask, p_pb_acl_entry->src_ip_mask);
    pb_compose_addr_ipv4_t_to_pb(&p_acl_entry->dst_ip, p_pb_acl_entry->dst_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_acl_entry->dst_ip_mask, p_pb_acl_entry->dst_ip_mask);
    p_pb_acl_entry->has_dscp = TRUE;
    p_pb_acl_entry->dscp = p_acl_entry->dscp;
    p_pb_acl_entry->has_dscp_mask = TRUE;
    p_pb_acl_entry->dscp_mask = p_acl_entry->dscp_mask;
    p_pb_acl_entry->has_ip_precedence = TRUE;
    p_pb_acl_entry->ip_precedence = p_acl_entry->ip_precedence;
    p_pb_acl_entry->has_ip_precedence_mask = TRUE;
    p_pb_acl_entry->ip_precedence_mask = p_acl_entry->ip_precedence_mask;
    p_pb_acl_entry->has_ip_protocol = TRUE;
    p_pb_acl_entry->ip_protocol = p_acl_entry->ip_protocol;
    p_pb_acl_entry->has_ip_protocol_mask = TRUE;
    p_pb_acl_entry->ip_protocol_mask = p_acl_entry->ip_protocol_mask;
    p_pb_acl_entry->has_l4_src_port_type = TRUE;
    p_pb_acl_entry->l4_src_port_type = p_acl_entry->l4_src_port_type;
    p_pb_acl_entry->has_l4_src_port = TRUE;
    p_pb_acl_entry->l4_src_port = p_acl_entry->l4_src_port;
    p_pb_acl_entry->has_l4_src_port_mask = TRUE;
    p_pb_acl_entry->l4_src_port_mask = p_acl_entry->l4_src_port_mask;
    p_pb_acl_entry->has_l4_dst_port_type = TRUE;
    p_pb_acl_entry->l4_dst_port_type = p_acl_entry->l4_dst_port_type;
    p_pb_acl_entry->has_l4_dst_port = TRUE;
    p_pb_acl_entry->l4_dst_port = p_acl_entry->l4_dst_port;
    p_pb_acl_entry->has_l4_dst_port_mask = TRUE;
    p_pb_acl_entry->l4_dst_port_mask = p_acl_entry->l4_dst_port_mask;
    p_pb_acl_entry->has_ip_frag = TRUE;
    p_pb_acl_entry->ip_frag = p_acl_entry->ip_frag;
    p_pb_acl_entry->has_tcp_flags = TRUE;
    p_pb_acl_entry->tcp_flags = p_acl_entry->tcp_flags;
    p_pb_acl_entry->has_tcp_flags_mask = TRUE;
    p_pb_acl_entry->tcp_flags_mask = p_acl_entry->tcp_flags_mask;
    p_pb_acl_entry->has_igmp_type = TRUE;
    p_pb_acl_entry->igmp_type = p_acl_entry->igmp_type;
    p_pb_acl_entry->has_icmp_type = TRUE;
    p_pb_acl_entry->icmp_type = p_acl_entry->icmp_type;
    p_pb_acl_entry->has_icmp_code = TRUE;
    p_pb_acl_entry->icmp_code = p_acl_entry->icmp_code;
    p_pb_acl_entry->has_l4_vxlan_vni = TRUE;
    p_pb_acl_entry->l4_vxlan_vni = p_acl_entry->l4_vxlan_vni;
    p_pb_acl_entry->has_l4_vxlan_vni_mask = TRUE;
    p_pb_acl_entry->l4_vxlan_vni_mask = p_acl_entry->l4_vxlan_vni_mask;
    p_pb_acl_entry->has_deny = TRUE;
    p_pb_acl_entry->deny = p_acl_entry->deny;
    p_pb_acl_entry->has_stats_en = TRUE;
    p_pb_acl_entry->stats_en = p_acl_entry->stats_en;
    p_pb_acl_entry->has_options = TRUE;
    p_pb_acl_entry->options = p_acl_entry->options;
    p_pb_acl_entry->has_action_strip_header = TRUE;
    p_pb_acl_entry->action_strip_header = p_acl_entry->action_strip_header;
    p_pb_acl_entry->has_tap_action_redirect = TRUE;
    p_pb_acl_entry->tap_action_redirect = p_acl_entry->tap_action_redirect;
    p_pb_acl_entry->has_tap_action_mark_vlan = TRUE;
    p_pb_acl_entry->tap_action_mark_vlan = p_acl_entry->tap_action_mark_vlan;
    p_pb_acl_entry->has_tap_action_untag = TRUE;
    p_pb_acl_entry->tap_action_untag = p_acl_entry->tap_action_untag;
    p_pb_acl_entry->has_tap_action_trunction = TRUE;
    p_pb_acl_entry->tap_action_trunction = p_acl_entry->tap_action_trunction;
    p_pb_acl_entry->has_tap_action_edit_dest_mac_en = TRUE;
    p_pb_acl_entry->tap_action_edit_dest_mac_en = p_acl_entry->tap_action_edit_dest_mac_en;
    pb_compose_mac_addr_t_to_pb(p_acl_entry->tap_action_edit_dest_mac, p_pb_acl_entry->tap_action_edit_dest_mac);
    p_pb_acl_entry->has_tap_action_edit_src_mac_en = TRUE;
    p_pb_acl_entry->tap_action_edit_src_mac_en = p_acl_entry->tap_action_edit_src_mac_en;
    pb_compose_mac_addr_t_to_pb(p_acl_entry->tap_action_edit_src_mac, p_pb_acl_entry->tap_action_edit_src_mac);
    p_pb_acl_entry->has_tap_action_edit_ipda_en = TRUE;
    p_pb_acl_entry->tap_action_edit_ipda_en = p_acl_entry->tap_action_edit_ipda_en;
    pb_compose_addr_t_to_pb(&p_acl_entry->tap_action_edit_ipda, p_pb_acl_entry->tap_action_edit_ipda);
    p_pb_acl_entry->has_tap_action_edit_ipsa_en = TRUE;
    p_pb_acl_entry->tap_action_edit_ipsa_en = p_acl_entry->tap_action_edit_ipsa_en;
    pb_compose_addr_t_to_pb(&p_acl_entry->tap_action_edit_ipsa, p_pb_acl_entry->tap_action_edit_ipsa);
    p_pb_acl_entry->has_tap_group_oid = TRUE;
    p_pb_acl_entry->tap_group_oid = p_acl_entry->tap_group_oid;

    return PM_E_NONE;
}

int32
pb_tbl_acl_entry_to_pb_free_packed(Cdb__TblAclEntry *p_pb_acl_entry)
{
    if (p_pb_acl_entry->time_range)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_entry->time_range);
        p_pb_acl_entry->time_range = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->src_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->src_mac_mask);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->dst_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->dst_mac_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_entry->src_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_entry->src_ip_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_entry->dst_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_entry->dst_ip_mask);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->tap_action_edit_dest_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_entry->tap_action_edit_src_mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_acl_entry->tap_action_edit_ipda);
    pb_compose_addr_t_to_pb_free_packed(p_pb_acl_entry->tap_action_edit_ipsa);
    return PM_E_NONE;
}

int32
pb_tbl_acl_entry_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclEntryKey pb_acl_entry_key = CDB__TBL_ACL_ENTRY_KEY__INIT;
    Cdb__TblAclEntry pb_acl_entry = CDB__TBL_ACL_ENTRY__INIT;
    tbl_acl_entry_t *p_acl_entry = (tbl_acl_entry_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT src_mac_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT dst_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT dst_mac_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T dst_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T dst_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeMacAddrT tap_action_edit_dest_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT tap_action_edit_src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT tap_action_edit_ipda = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__ComposeAddrT tap_action_edit_ipsa = CDB__COMPOSE_ADDR_T__INIT;

    pb_acl_entry.key = &pb_acl_entry_key;
    pb_acl_entry.src_mac = &src_mac;
    pb_acl_entry.src_mac_mask = &src_mac_mask;
    pb_acl_entry.dst_mac = &dst_mac;
    pb_acl_entry.dst_mac_mask = &dst_mac_mask;
    pb_acl_entry.src_ip = &src_ip;
    pb_acl_entry.src_ip_mask = &src_ip_mask;
    pb_acl_entry.dst_ip = &dst_ip;
    pb_acl_entry.dst_ip_mask = &dst_ip_mask;
    pb_acl_entry.tap_action_edit_dest_mac = &tap_action_edit_dest_mac;
    pb_acl_entry.tap_action_edit_src_mac = &tap_action_edit_src_mac;
    pb_acl_entry.tap_action_edit_ipda = &tap_action_edit_ipda;
    pb_acl_entry.tap_action_edit_ipsa = &tap_action_edit_ipsa;
    pb_tbl_acl_entry_to_pb(only_key, p_acl_entry, &pb_acl_entry);
    len = cdb__tbl_acl_entry__pack(&pb_acl_entry, buf);
    pb_tbl_acl_entry_to_pb_free_packed(&pb_acl_entry);

    return len;
}

int32
pb_tbl_acl_entry_dump(Cdb__TblAclEntry *p_pb_acl_entry, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->aclid=%llu", p_pb_acl_entry->key->aclid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/tblid=%u", p_pb_acl_entry->tblid);
    offset += sal_sprintf(out + offset, "/entry_priority=%u", p_pb_acl_entry->entry_priority);
    offset += sal_sprintf(out + offset, "/time_range=%s", p_pb_acl_entry->time_range);
    offset += sal_sprintf(out + offset, "/key_flags=%u", p_pb_acl_entry->key_flags);
    offset += sal_sprintf(out + offset, "/invalid=%u", p_pb_acl_entry->invalid);
    offset += sal_sprintf(out + offset, "/is_copp=%u", p_pb_acl_entry->is_copp);
    offset += sal_sprintf(out + offset, "/in_port=%llu", p_pb_acl_entry->in_port);
    offset += sal_sprintf(out + offset, "/out_port=%llu", p_pb_acl_entry->out_port);
    offset += sal_sprintf(out + offset, "/ether_type=%u", p_pb_acl_entry->ether_type);
    offset += sal_sprintf(out + offset, "/ether_type_mask=%u", p_pb_acl_entry->ether_type_mask);
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->src_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->src_mac_mask, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->dst_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->dst_mac_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/svlan=%u", p_pb_acl_entry->svlan);
    offset += sal_sprintf(out + offset, "/svlan_mask=%u", p_pb_acl_entry->svlan_mask);
    offset += sal_sprintf(out + offset, "/svlan_cos=%u", p_pb_acl_entry->svlan_cos);
    offset += sal_sprintf(out + offset, "/svlan_cos_mask=%u", p_pb_acl_entry->svlan_cos_mask);
    offset += sal_sprintf(out + offset, "/cvlan=%u", p_pb_acl_entry->cvlan);
    offset += sal_sprintf(out + offset, "/cvlan_mask=%u", p_pb_acl_entry->cvlan_mask);
    offset += sal_sprintf(out + offset, "/cvlan_cos=%u", p_pb_acl_entry->cvlan_cos);
    offset += sal_sprintf(out + offset, "/cvlan_cos_mask=%u", p_pb_acl_entry->cvlan_cos_mask);
    offset += sal_sprintf(out + offset, "/ip_type=%u", p_pb_acl_entry->ip_type);
    offset += sal_sprintf(out + offset, "/ip_type_mask=%u", p_pb_acl_entry->ip_type_mask);
    offset += sal_sprintf(out + offset, "/ip_flags=%u", p_pb_acl_entry->ip_flags);
    offset += sal_sprintf(out + offset, "/ip_flags_mask=%u", p_pb_acl_entry->ip_flags_mask);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_entry->src_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_entry->src_ip_mask, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_entry->dst_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_entry->dst_ip_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_acl_entry->dscp);
    offset += sal_sprintf(out + offset, "/dscp_mask=%u", p_pb_acl_entry->dscp_mask);
    offset += sal_sprintf(out + offset, "/ip_precedence=%u", p_pb_acl_entry->ip_precedence);
    offset += sal_sprintf(out + offset, "/ip_precedence_mask=%u", p_pb_acl_entry->ip_precedence_mask);
    offset += sal_sprintf(out + offset, "/ip_protocol=%u", p_pb_acl_entry->ip_protocol);
    offset += sal_sprintf(out + offset, "/ip_protocol_mask=%u", p_pb_acl_entry->ip_protocol_mask);
    offset += sal_sprintf(out + offset, "/l4_src_port_type=%u", p_pb_acl_entry->l4_src_port_type);
    offset += sal_sprintf(out + offset, "/l4_src_port=%u", p_pb_acl_entry->l4_src_port);
    offset += sal_sprintf(out + offset, "/l4_src_port_mask=%u", p_pb_acl_entry->l4_src_port_mask);
    offset += sal_sprintf(out + offset, "/l4_dst_port_type=%u", p_pb_acl_entry->l4_dst_port_type);
    offset += sal_sprintf(out + offset, "/l4_dst_port=%u", p_pb_acl_entry->l4_dst_port);
    offset += sal_sprintf(out + offset, "/l4_dst_port_mask=%u", p_pb_acl_entry->l4_dst_port_mask);
    offset += sal_sprintf(out + offset, "/ip_frag=%u", p_pb_acl_entry->ip_frag);
    offset += sal_sprintf(out + offset, "/tcp_flags=%u", p_pb_acl_entry->tcp_flags);
    offset += sal_sprintf(out + offset, "/tcp_flags_mask=%u", p_pb_acl_entry->tcp_flags_mask);
    offset += sal_sprintf(out + offset, "/igmp_type=%u", p_pb_acl_entry->igmp_type);
    offset += sal_sprintf(out + offset, "/icmp_type=%u", p_pb_acl_entry->icmp_type);
    offset += sal_sprintf(out + offset, "/icmp_code=%u", p_pb_acl_entry->icmp_code);
    offset += sal_sprintf(out + offset, "/l4_vxlan_vni=%u", p_pb_acl_entry->l4_vxlan_vni);
    offset += sal_sprintf(out + offset, "/l4_vxlan_vni_mask=%u", p_pb_acl_entry->l4_vxlan_vni_mask);
    offset += sal_sprintf(out + offset, "/deny=%u", p_pb_acl_entry->deny);
    offset += sal_sprintf(out + offset, "/stats_en=%u", p_pb_acl_entry->stats_en);
    offset += sal_sprintf(out + offset, "/options=%u", p_pb_acl_entry->options);
    offset += sal_sprintf(out + offset, "/action_strip_header=%u", p_pb_acl_entry->action_strip_header);
    offset += sal_sprintf(out + offset, "/tap_action_redirect=%u", p_pb_acl_entry->tap_action_redirect);
    offset += sal_sprintf(out + offset, "/tap_action_mark_vlan=%u", p_pb_acl_entry->tap_action_mark_vlan);
    offset += sal_sprintf(out + offset, "/tap_action_untag=%u", p_pb_acl_entry->tap_action_untag);
    offset += sal_sprintf(out + offset, "/tap_action_trunction=%u", p_pb_acl_entry->tap_action_trunction);
    offset += sal_sprintf(out + offset, "/tap_action_edit_dest_mac_en=%u", p_pb_acl_entry->tap_action_edit_dest_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->tap_action_edit_dest_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_src_mac_en=%u", p_pb_acl_entry->tap_action_edit_src_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_entry->tap_action_edit_src_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_ipda_en=%u", p_pb_acl_entry->tap_action_edit_ipda_en);
    offset += pb_compose_addr_t_dump(p_pb_acl_entry->tap_action_edit_ipda, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_action_edit_ipsa_en=%u", p_pb_acl_entry->tap_action_edit_ipsa_en);
    offset += pb_compose_addr_t_dump(p_pb_acl_entry->tap_action_edit_ipsa, (out + offset));
    offset += sal_sprintf(out + offset, "/tap_group_oid=%llu", p_pb_acl_entry->tap_group_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_ENTRY_ACTION */
int32
pb_tbl_acl_entry_action_to_pb(uint32 only_key, tbl_acl_entry_action_t *p_acl_entry_action, Cdb__TblAclEntryAction *p_pb_acl_entry_action)
{
    p_pb_acl_entry_action->key->aclid = p_acl_entry_action->key.aclid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_entry_action->has_action_flag = TRUE;
    p_pb_acl_entry_action->action_flag = p_acl_entry_action->action_flag;
    p_pb_acl_entry_action->has_deny = TRUE;
    p_pb_acl_entry_action->deny = p_acl_entry_action->deny;
    p_pb_acl_entry_action->has_stats_enale = TRUE;
    p_pb_acl_entry_action->stats_enale = p_acl_entry_action->stats_enale;
    p_pb_acl_entry_action->policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_entry_action->policer)+1);
    sal_strcpy(p_pb_acl_entry_action->policer, p_acl_entry_action->policer);
    p_pb_acl_entry_action->has_nexthop_group = TRUE;
    p_pb_acl_entry_action->nexthop_group = p_acl_entry_action->nexthop_group;
    p_pb_acl_entry_action->has_logen = TRUE;
    p_pb_acl_entry_action->logen = p_acl_entry_action->logen;
    p_pb_acl_entry_action->has_tc = TRUE;
    p_pb_acl_entry_action->tc = p_acl_entry_action->tc;
    p_pb_acl_entry_action->has_color = TRUE;
    p_pb_acl_entry_action->color = p_acl_entry_action->color;
    p_pb_acl_entry_action->has_dscp = TRUE;
    p_pb_acl_entry_action->dscp = p_acl_entry_action->dscp;
    p_pb_acl_entry_action->has_session_id = TRUE;
    p_pb_acl_entry_action->session_id = p_acl_entry_action->session_id;
    p_pb_acl_entry_action->has_new_svlan_id = TRUE;
    p_pb_acl_entry_action->new_svlan_id = p_acl_entry_action->new_svlan_id;
    p_pb_acl_entry_action->has_new_cvlan_id = TRUE;
    p_pb_acl_entry_action->new_cvlan_id = p_acl_entry_action->new_cvlan_id;
    p_pb_acl_entry_action->has_new_scos = TRUE;
    p_pb_acl_entry_action->new_scos = p_acl_entry_action->new_scos;
    p_pb_acl_entry_action->has_new_ccos = TRUE;
    p_pb_acl_entry_action->new_ccos = p_acl_entry_action->new_ccos;
    p_pb_acl_entry_action->has_redirect_port_ifindex = TRUE;
    p_pb_acl_entry_action->redirect_port_ifindex = p_acl_entry_action->redirect_port_ifindex;

    return PM_E_NONE;
}

int32
pb_tbl_acl_entry_action_to_pb_free_packed(Cdb__TblAclEntryAction *p_pb_acl_entry_action)
{
    if (p_pb_acl_entry_action->policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_entry_action->policer);
        p_pb_acl_entry_action->policer = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_entry_action_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclEntryActionKey pb_acl_entry_action_key = CDB__TBL_ACL_ENTRY_ACTION_KEY__INIT;
    Cdb__TblAclEntryAction pb_acl_entry_action = CDB__TBL_ACL_ENTRY_ACTION__INIT;
    tbl_acl_entry_action_t *p_acl_entry_action = (tbl_acl_entry_action_t*)p_tbl;
    int32 len = 0;

    pb_acl_entry_action.key = &pb_acl_entry_action_key;
    pb_tbl_acl_entry_action_to_pb(only_key, p_acl_entry_action, &pb_acl_entry_action);
    len = cdb__tbl_acl_entry_action__pack(&pb_acl_entry_action, buf);
    pb_tbl_acl_entry_action_to_pb_free_packed(&pb_acl_entry_action);

    return len;
}

int32
pb_tbl_acl_entry_action_dump(Cdb__TblAclEntryAction *p_pb_acl_entry_action, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->aclid=%llu", p_pb_acl_entry_action->key->aclid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/action_flag=%u", p_pb_acl_entry_action->action_flag);
    offset += sal_sprintf(out + offset, "/deny=%u", p_pb_acl_entry_action->deny);
    offset += sal_sprintf(out + offset, "/stats_enale=%u", p_pb_acl_entry_action->stats_enale);
    offset += sal_sprintf(out + offset, "/policer=%s", p_pb_acl_entry_action->policer);
    offset += sal_sprintf(out + offset, "/nexthop_group=%u", p_pb_acl_entry_action->nexthop_group);
    offset += sal_sprintf(out + offset, "/logen=%u", p_pb_acl_entry_action->logen);
    offset += sal_sprintf(out + offset, "/tc=%u", p_pb_acl_entry_action->tc);
    offset += sal_sprintf(out + offset, "/color=%u", p_pb_acl_entry_action->color);
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_acl_entry_action->dscp);
    offset += sal_sprintf(out + offset, "/session_id=%u", p_pb_acl_entry_action->session_id);
    offset += sal_sprintf(out + offset, "/new_svlan_id=%u", p_pb_acl_entry_action->new_svlan_id);
    offset += sal_sprintf(out + offset, "/new_cvlan_id=%u", p_pb_acl_entry_action->new_cvlan_id);
    offset += sal_sprintf(out + offset, "/new_scos=%u", p_pb_acl_entry_action->new_scos);
    offset += sal_sprintf(out + offset, "/new_ccos=%u", p_pb_acl_entry_action->new_ccos);
    offset += sal_sprintf(out + offset, "/redirect_port_ifindex=%u", p_pb_acl_entry_action->redirect_port_ifindex);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_NEXTHOP_GROUP */
int32
pb_tbl_acl_nexthop_group_to_pb(uint32 only_key, tbl_acl_nexthop_group_t *p_acl_nexthop_group, Cdb__TblAclNexthopGroup *p_pb_acl_nexthop_group)
{
    uint32 i = 0;

    p_pb_acl_nexthop_group->key->nexthop_group = p_acl_nexthop_group->key.nexthop_group;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_nexthop_group->acl_nexthop_key = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*MAX_MEMBER);
    p_pb_acl_nexthop_group->n_acl_nexthop_key = MAX_MEMBER;
    for (i = 0; i < MAX_MEMBER; i++)
    {
        p_pb_acl_nexthop_group->acl_nexthop_key[i] = p_acl_nexthop_group->acl_nexthop_key[i];
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_nexthop_group_to_pb_free_packed(Cdb__TblAclNexthopGroup *p_pb_acl_nexthop_group)
{
    if (p_pb_acl_nexthop_group->acl_nexthop_key)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl_nexthop_group->acl_nexthop_key);
        p_pb_acl_nexthop_group->acl_nexthop_key = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_nexthop_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclNexthopGroupKey pb_acl_nexthop_group_key = CDB__TBL_ACL_NEXTHOP_GROUP_KEY__INIT;
    Cdb__TblAclNexthopGroup pb_acl_nexthop_group = CDB__TBL_ACL_NEXTHOP_GROUP__INIT;
    tbl_acl_nexthop_group_t *p_acl_nexthop_group = (tbl_acl_nexthop_group_t*)p_tbl;
    int32 len = 0;

    pb_acl_nexthop_group.key = &pb_acl_nexthop_group_key;
    pb_tbl_acl_nexthop_group_to_pb(only_key, p_acl_nexthop_group, &pb_acl_nexthop_group);
    len = cdb__tbl_acl_nexthop_group__pack(&pb_acl_nexthop_group, buf);
    pb_tbl_acl_nexthop_group_to_pb_free_packed(&pb_acl_nexthop_group);

    return len;
}

int32
pb_tbl_acl_nexthop_group_dump(Cdb__TblAclNexthopGroup *p_pb_acl_nexthop_group, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->nexthop_group=%u", p_pb_acl_nexthop_group->key->nexthop_group);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/acl_nexthop_key=");
    offset += pb_uint32_array_dump(p_pb_acl_nexthop_group->acl_nexthop_key, sizeof(p_pb_acl_nexthop_group->acl_nexthop_key), (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_NEXTHOP */
int32
pb_tbl_acl_nexthop_to_pb(uint32 only_key, tbl_acl_nexthop_t *p_acl_nexthop, Cdb__TblAclNexthop *p_pb_acl_nexthop)
{
    p_pb_acl_nexthop->key->acl_nexthop_id = p_acl_nexthop->key.acl_nexthop_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_nexthop->has_edit_flags = TRUE;
    p_pb_acl_nexthop->edit_flags = p_acl_nexthop->edit_flags;
    p_pb_acl_nexthop->has_port = TRUE;
    p_pb_acl_nexthop->port = p_acl_nexthop->port;
    pb_compose_mac_addr_t_to_pb(p_acl_nexthop->src_mac, p_pb_acl_nexthop->src_mac);
    pb_compose_mac_addr_t_to_pb(p_acl_nexthop->dst_mac, p_pb_acl_nexthop->dst_mac);
    p_pb_acl_nexthop->has_vlan = TRUE;
    p_pb_acl_nexthop->vlan = p_acl_nexthop->vlan;
    pb_compose_addr_ipv4_t_to_pb(&p_acl_nexthop->src_ipv4, p_pb_acl_nexthop->src_ipv4);
    pb_compose_addr_ipv4_t_to_pb(&p_acl_nexthop->dst_ipv4, p_pb_acl_nexthop->dst_ipv4);
    p_pb_acl_nexthop->has_dscp = TRUE;
    p_pb_acl_nexthop->dscp = p_acl_nexthop->dscp;
    p_pb_acl_nexthop->has_l4_src_port = TRUE;
    p_pb_acl_nexthop->l4_src_port = p_acl_nexthop->l4_src_port;
    p_pb_acl_nexthop->has_l4_dst_port = TRUE;
    p_pb_acl_nexthop->l4_dst_port = p_acl_nexthop->l4_dst_port;
    p_pb_acl_nexthop->has_ref = TRUE;
    p_pb_acl_nexthop->ref = p_acl_nexthop->ref;

    return PM_E_NONE;
}

int32
pb_tbl_acl_nexthop_to_pb_free_packed(Cdb__TblAclNexthop *p_pb_acl_nexthop)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_nexthop->src_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_acl_nexthop->dst_mac);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_nexthop->src_ipv4);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_acl_nexthop->dst_ipv4);
    return PM_E_NONE;
}

int32
pb_tbl_acl_nexthop_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclNexthopKey pb_acl_nexthop_key = CDB__TBL_ACL_NEXTHOP_KEY__INIT;
    Cdb__TblAclNexthop pb_acl_nexthop = CDB__TBL_ACL_NEXTHOP__INIT;
    tbl_acl_nexthop_t *p_acl_nexthop = (tbl_acl_nexthop_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT dst_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrIpv4T src_ipv4 = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T dst_ipv4 = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_acl_nexthop.key = &pb_acl_nexthop_key;
    pb_acl_nexthop.src_mac = &src_mac;
    pb_acl_nexthop.dst_mac = &dst_mac;
    pb_acl_nexthop.src_ipv4 = &src_ipv4;
    pb_acl_nexthop.dst_ipv4 = &dst_ipv4;
    pb_tbl_acl_nexthop_to_pb(only_key, p_acl_nexthop, &pb_acl_nexthop);
    len = cdb__tbl_acl_nexthop__pack(&pb_acl_nexthop, buf);
    pb_tbl_acl_nexthop_to_pb_free_packed(&pb_acl_nexthop);

    return len;
}

int32
pb_tbl_acl_nexthop_dump(Cdb__TblAclNexthop *p_pb_acl_nexthop, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->acl_nexthop_id=%u", p_pb_acl_nexthop->key->acl_nexthop_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/edit_flags=%u", p_pb_acl_nexthop->edit_flags);
    offset += sal_sprintf(out + offset, "/port=%u", p_pb_acl_nexthop->port);
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_nexthop->src_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_acl_nexthop->dst_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/vlan=%u", p_pb_acl_nexthop->vlan);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_nexthop->src_ipv4, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_acl_nexthop->dst_ipv4, (out + offset));
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_acl_nexthop->dscp);
    offset += sal_sprintf(out + offset, "/l4_src_port=%u", p_pb_acl_nexthop->l4_src_port);
    offset += sal_sprintf(out + offset, "/l4_dst_port=%u", p_pb_acl_nexthop->l4_dst_port);
    offset += sal_sprintf(out + offset, "/ref=%u", p_pb_acl_nexthop->ref);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PMAP */
int32
pb_tbl_pmap_to_pb(uint32 only_key, tbl_pmap_t *p_pmap, Cdb__TblPmap *p_pb_pmap)
{
    p_pb_pmap->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap->key.name)+1);
    sal_strcpy(p_pb_pmap->key->name, p_pmap->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_pmap->has_cmap_cnt = TRUE;
    p_pb_pmap->cmap_cnt = p_pmap->cmap_cnt;
    p_pb_pmap->has_attached = TRUE;
    p_pb_pmap->attached = p_pmap->attached;
    p_pb_pmap->has_attach_cnt = TRUE;
    p_pb_pmap->attach_cnt = p_pmap->attach_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_pmap_to_pb_free_packed(Cdb__TblPmap *p_pb_pmap)
{
    if (p_pb_pmap->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap->key->name);
        p_pb_pmap->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_pmap_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPmapKey pb_pmap_key = CDB__TBL_PMAP_KEY__INIT;
    Cdb__TblPmap pb_pmap = CDB__TBL_PMAP__INIT;
    tbl_pmap_t *p_pmap = (tbl_pmap_t*)p_tbl;
    int32 len = 0;

    pb_pmap.key = &pb_pmap_key;
    pb_tbl_pmap_to_pb(only_key, p_pmap, &pb_pmap);
    len = cdb__tbl_pmap__pack(&pb_pmap, buf);
    pb_tbl_pmap_to_pb_free_packed(&pb_pmap);

    return len;
}

int32
pb_tbl_pmap_dump(Cdb__TblPmap *p_pb_pmap, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_pmap->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/cmap_cnt=%u", p_pb_pmap->cmap_cnt);
    offset += sal_sprintf(out + offset, "/attached=%u", p_pb_pmap->attached);
    offset += sal_sprintf(out + offset, "/attach_cnt=%u", p_pb_pmap->attach_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CMAP */
int32
pb_tbl_cmap_to_pb(uint32 only_key, tbl_cmap_t *p_cmap, Cdb__TblCmap *p_pb_cmap)
{
    p_pb_cmap->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cmap->key.name)+1);
    sal_strcpy(p_pb_cmap->key->name, p_cmap->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cmap->has_any_or_all = TRUE;
    p_pb_cmap->any_or_all = p_cmap->any_or_all;
    p_pb_cmap->has_match_all_ace_num = TRUE;
    p_pb_cmap->match_all_ace_num = p_cmap->match_all_ace_num;
    p_pb_cmap->has_acl_count = TRUE;
    p_pb_cmap->acl_count = p_cmap->acl_count;
    p_pb_cmap->has_match_type = TRUE;
    p_pb_cmap->match_type = p_cmap->match_type;

    return PM_E_NONE;
}

int32
pb_tbl_cmap_to_pb_free_packed(Cdb__TblCmap *p_pb_cmap)
{
    if (p_pb_cmap->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cmap->key->name);
        p_pb_cmap->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_cmap_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCmapKey pb_cmap_key = CDB__TBL_CMAP_KEY__INIT;
    Cdb__TblCmap pb_cmap = CDB__TBL_CMAP__INIT;
    tbl_cmap_t *p_cmap = (tbl_cmap_t*)p_tbl;
    int32 len = 0;

    pb_cmap.key = &pb_cmap_key;
    pb_tbl_cmap_to_pb(only_key, p_cmap, &pb_cmap);
    len = cdb__tbl_cmap__pack(&pb_cmap, buf);
    pb_tbl_cmap_to_pb_free_packed(&pb_cmap);

    return len;
}

int32
pb_tbl_cmap_dump(Cdb__TblCmap *p_pb_cmap, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_cmap->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/any_or_all=%u", p_pb_cmap->any_or_all);
    offset += sal_sprintf(out + offset, "/match_all_ace_num=%u", p_pb_cmap->match_all_ace_num);
    offset += sal_sprintf(out + offset, "/acl_count=%u", p_pb_cmap->acl_count);
    offset += sal_sprintf(out + offset, "/match_type=%u", p_pb_cmap->match_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL */
int32
pb_tbl_acl_to_pb(uint32 only_key, tbl_acl_t *p_acl, Cdb__TblAcl *p_pb_acl)
{
    p_pb_acl->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl->key.name)+1);
    sal_strcpy(p_pb_acl->key->name, p_acl->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl->remark = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl->remark)+1);
    sal_strcpy(p_pb_acl->remark, p_acl->remark);
    p_pb_acl->has_ace_num = TRUE;
    p_pb_acl->ace_num = p_acl->ace_num;
    p_pb_acl->has_afi = TRUE;
    p_pb_acl->afi = p_acl->afi;

    return PM_E_NONE;
}

int32
pb_tbl_acl_to_pb_free_packed(Cdb__TblAcl *p_pb_acl)
{
    if (p_pb_acl->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl->key->name);
        p_pb_acl->key->name = NULL;
    }

    if (p_pb_acl->remark)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_acl->remark);
        p_pb_acl->remark = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_acl_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclKey pb_acl_key = CDB__TBL_ACL_KEY__INIT;
    Cdb__TblAcl pb_acl = CDB__TBL_ACL__INIT;
    tbl_acl_t *p_acl = (tbl_acl_t*)p_tbl;
    int32 len = 0;

    pb_acl.key = &pb_acl_key;
    pb_tbl_acl_to_pb(only_key, p_acl, &pb_acl);
    len = cdb__tbl_acl__pack(&pb_acl, buf);
    pb_tbl_acl_to_pb_free_packed(&pb_acl);

    return len;
}

int32
pb_tbl_acl_dump(Cdb__TblAcl *p_pb_acl, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_acl->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/remark=%s", p_pb_acl->remark);
    offset += sal_sprintf(out + offset, "/ace_num=%u", p_pb_acl->ace_num);
    offset += sal_sprintf(out + offset, "/afi=%u", p_pb_acl->afi);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_TIME_RANGE */
int32
pb_tbl_time_range_to_pb(uint32 only_key, tbl_time_range_t *p_time_range, Cdb__TblTimeRange *p_pb_time_range)
{
    p_pb_time_range->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_time_range->key.name)+1);
    sal_strcpy(p_pb_time_range->key->name, p_time_range->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_time_range_value_t_to_pb(&p_time_range->time, p_pb_time_range->time);
    p_pb_time_range->has_ref_cnt = TRUE;
    p_pb_time_range->ref_cnt = p_time_range->ref_cnt;
    pb_compose_time_range_timer_t_to_pb(&p_time_range->running_timer, p_pb_time_range->running_timer);

    return PM_E_NONE;
}

int32
pb_tbl_time_range_to_pb_free_packed(Cdb__TblTimeRange *p_pb_time_range)
{
    if (p_pb_time_range->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_time_range->key->name);
        p_pb_time_range->key->name = NULL;
    }

    pb_compose_time_range_value_t_to_pb_free_packed(p_pb_time_range->time);
    pb_compose_time_range_timer_t_to_pb_free_packed(p_pb_time_range->running_timer);
    return PM_E_NONE;
}

int32
pb_tbl_time_range_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblTimeRangeKey pb_time_range_key = CDB__TBL_TIME_RANGE_KEY__INIT;
    Cdb__TblTimeRange pb_time_range = CDB__TBL_TIME_RANGE__INIT;
    tbl_time_range_t *p_time_range = (tbl_time_range_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeTimeRangeValueT time = CDB__COMPOSE_TIME_RANGE_VALUE_T__INIT;
    Cdb__ComposeTimeRangeTimerT running_timer = CDB__COMPOSE_TIME_RANGE_TIMER_T__INIT;

    pb_time_range.key = &pb_time_range_key;
    pb_time_range.time = &time;
    pb_time_range.running_timer = &running_timer;
    pb_tbl_time_range_to_pb(only_key, p_time_range, &pb_time_range);
    len = cdb__tbl_time_range__pack(&pb_time_range, buf);
    pb_tbl_time_range_to_pb_free_packed(&pb_time_range);

    return len;
}

int32
pb_tbl_time_range_dump(Cdb__TblTimeRange *p_pb_time_range, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_time_range->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_time_range_value_t_dump(p_pb_time_range->time, (out + offset));
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_time_range->ref_cnt);
    offset += pb_compose_time_range_timer_t_dump(p_pb_time_range->running_timer, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SSH_CFG */
int32
pb_tbl_ssh_cfg_to_pb(uint32 only_key, tbl_ssh_cfg_t *p_ssh_cfg, Cdb__TblSshCfg *p_pb_ssh_cfg)
{
    p_pb_ssh_cfg->has_version = TRUE;
    p_pb_ssh_cfg->version = p_ssh_cfg->version;
    p_pb_ssh_cfg->has_enable = TRUE;
    p_pb_ssh_cfg->enable = p_ssh_cfg->enable;
    p_pb_ssh_cfg->has_auth_retry = TRUE;
    p_pb_ssh_cfg->auth_retry = p_ssh_cfg->auth_retry;
    p_pb_ssh_cfg->has_auth_timeout = TRUE;
    p_pb_ssh_cfg->auth_timeout = p_ssh_cfg->auth_timeout;
    p_pb_ssh_cfg->has_rekey_interval = TRUE;
    p_pb_ssh_cfg->rekey_interval = p_ssh_cfg->rekey_interval;
    p_pb_ssh_cfg->has_auth_type = TRUE;
    p_pb_ssh_cfg->auth_type = p_ssh_cfg->auth_type;
    p_pb_ssh_cfg->hostkey = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ssh_cfg->hostkey)+1);
    sal_strcpy(p_pb_ssh_cfg->hostkey, p_ssh_cfg->hostkey);

    return PM_E_NONE;
}

int32
pb_tbl_ssh_cfg_to_pb_free_packed(Cdb__TblSshCfg *p_pb_ssh_cfg)
{
    if (p_pb_ssh_cfg->hostkey)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ssh_cfg->hostkey);
        p_pb_ssh_cfg->hostkey = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ssh_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSshCfg pb_ssh_cfg = CDB__TBL_SSH_CFG__INIT;
    tbl_ssh_cfg_t *p_ssh_cfg = (tbl_ssh_cfg_t*)p_tbl;
    int32 len = 0;

    pb_tbl_ssh_cfg_to_pb(only_key, p_ssh_cfg, &pb_ssh_cfg);
    len = cdb__tbl_ssh_cfg__pack(&pb_ssh_cfg, buf);
    pb_tbl_ssh_cfg_to_pb_free_packed(&pb_ssh_cfg);

    return len;
}

int32
pb_tbl_ssh_cfg_dump(Cdb__TblSshCfg *p_pb_ssh_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/version=%u", p_pb_ssh_cfg->version);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_ssh_cfg->enable);
    offset += sal_sprintf(out + offset, "/auth_retry=%u", p_pb_ssh_cfg->auth_retry);
    offset += sal_sprintf(out + offset, "/auth_timeout=%u", p_pb_ssh_cfg->auth_timeout);
    offset += sal_sprintf(out + offset, "/rekey_interval=%u", p_pb_ssh_cfg->rekey_interval);
    offset += sal_sprintf(out + offset, "/auth_type=%u", p_pb_ssh_cfg->auth_type);
    offset += sal_sprintf(out + offset, "/hostkey=%s", p_pb_ssh_cfg->hostkey);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SNMP_CFG */
int32
pb_tbl_snmp_cfg_to_pb(uint32 only_key, tbl_snmp_cfg_t *p_snmp_cfg, Cdb__TblSnmpCfg *p_pb_snmp_cfg)
{
    p_pb_snmp_cfg->has_enable = TRUE;
    p_pb_snmp_cfg->enable = p_snmp_cfg->enable;
    p_pb_snmp_cfg->has_server_enable = TRUE;
    p_pb_snmp_cfg->server_enable = p_snmp_cfg->server_enable;
    p_pb_snmp_cfg->has_version = TRUE;
    p_pb_snmp_cfg->version = p_snmp_cfg->version;
    p_pb_snmp_cfg->engineid = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_snmp_cfg->engineid)+1);
    sal_strcpy(p_pb_snmp_cfg->engineid, p_snmp_cfg->engineid);
    pb_compose_snmp_info_t_to_pb(&p_snmp_cfg->contact, p_pb_snmp_cfg->contact);
    pb_compose_snmp_info_t_to_pb(&p_snmp_cfg->location, p_pb_snmp_cfg->location);
    p_pb_snmp_cfg->has_trap_enable_coldstart = TRUE;
    p_pb_snmp_cfg->trap_enable_coldstart = GLB_FLAG_ISSET(p_snmp_cfg->trap_enable, GLB_TRAP_TYPE_COLDSTART) ? TRUE : FALSE;
    p_pb_snmp_cfg->has_trap_enable_warmstart = TRUE;
    p_pb_snmp_cfg->trap_enable_warmstart = GLB_FLAG_ISSET(p_snmp_cfg->trap_enable, GLB_TRAP_TYPE_WARMSTART) ? TRUE : FALSE;
    p_pb_snmp_cfg->has_trap_enable_linkdown = TRUE;
    p_pb_snmp_cfg->trap_enable_linkdown = GLB_FLAG_ISSET(p_snmp_cfg->trap_enable, GLB_TRAP_TYPE_LINKDOWN) ? TRUE : FALSE;
    p_pb_snmp_cfg->has_trap_enable_linkup = TRUE;
    p_pb_snmp_cfg->trap_enable_linkup = GLB_FLAG_ISSET(p_snmp_cfg->trap_enable, GLB_TRAP_TYPE_LINKUP) ? TRUE : FALSE;
    p_pb_snmp_cfg->has_trap_enable_system = TRUE;
    p_pb_snmp_cfg->trap_enable_system = GLB_FLAG_ISSET(p_snmp_cfg->trap_enable, GLB_TRAP_TYPE_SYSTEM) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_snmp_cfg_to_pb_free_packed(Cdb__TblSnmpCfg *p_pb_snmp_cfg)
{
    if (p_pb_snmp_cfg->engineid)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_snmp_cfg->engineid);
        p_pb_snmp_cfg->engineid = NULL;
    }

    pb_compose_snmp_info_t_to_pb_free_packed(p_pb_snmp_cfg->contact);
    pb_compose_snmp_info_t_to_pb_free_packed(p_pb_snmp_cfg->location);
    return PM_E_NONE;
}

int32
pb_tbl_snmp_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSnmpCfg pb_snmp_cfg = CDB__TBL_SNMP_CFG__INIT;
    tbl_snmp_cfg_t *p_snmp_cfg = (tbl_snmp_cfg_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeSnmpInfoT contact = CDB__COMPOSE_SNMP_INFO_T__INIT;
    Cdb__ComposeSnmpInfoT location = CDB__COMPOSE_SNMP_INFO_T__INIT;

    pb_snmp_cfg.contact = &contact;
    pb_snmp_cfg.location = &location;
    pb_tbl_snmp_cfg_to_pb(only_key, p_snmp_cfg, &pb_snmp_cfg);
    len = cdb__tbl_snmp_cfg__pack(&pb_snmp_cfg, buf);
    pb_tbl_snmp_cfg_to_pb_free_packed(&pb_snmp_cfg);

    return len;
}

int32
pb_tbl_snmp_cfg_dump(Cdb__TblSnmpCfg *p_pb_snmp_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_snmp_cfg->enable);
    offset += sal_sprintf(out + offset, "/server_enable=%u", p_pb_snmp_cfg->server_enable);
    offset += sal_sprintf(out + offset, "/version=%u", p_pb_snmp_cfg->version);
    offset += sal_sprintf(out + offset, "/engineid=%s", p_pb_snmp_cfg->engineid);
    offset += pb_compose_snmp_info_t_dump(p_pb_snmp_cfg->contact, (out + offset));
    offset += pb_compose_snmp_info_t_dump(p_pb_snmp_cfg->location, (out + offset));
    offset += sal_sprintf(out + offset, "/trap_enable_coldstart=%u", p_pb_snmp_cfg->trap_enable_coldstart);
    offset += sal_sprintf(out + offset, "/trap_enable_warmstart=%u", p_pb_snmp_cfg->trap_enable_warmstart);
    offset += sal_sprintf(out + offset, "/trap_enable_linkdown=%u", p_pb_snmp_cfg->trap_enable_linkdown);
    offset += sal_sprintf(out + offset, "/trap_enable_linkup=%u", p_pb_snmp_cfg->trap_enable_linkup);
    offset += sal_sprintf(out + offset, "/trap_enable_system=%u", p_pb_snmp_cfg->trap_enable_system);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SNMP_VIEW */
int32
pb_tbl_snmp_view_to_pb(uint32 only_key, tbl_snmp_view_t *p_snmp_view, Cdb__TblSnmpView *p_pb_snmp_view)
{
    pb_compose_snmp_view_key_t_to_pb(&p_snmp_view->key.view, p_pb_snmp_view->key->view);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_snmp_view->has_type = TRUE;
    p_pb_snmp_view->type = p_snmp_view->type;
    p_pb_snmp_view->mask = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_snmp_view->mask)+1);
    sal_strcpy(p_pb_snmp_view->mask, p_snmp_view->mask);
    p_pb_snmp_view->has_refcnt = TRUE;
    p_pb_snmp_view->refcnt = p_snmp_view->refcnt;

    return PM_E_NONE;
}

int32
pb_tbl_snmp_view_to_pb_free_packed(Cdb__TblSnmpView *p_pb_snmp_view)
{
    pb_compose_snmp_view_key_t_to_pb_free_packed(p_pb_snmp_view->key->view);
    if (p_pb_snmp_view->mask)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_snmp_view->mask);
        p_pb_snmp_view->mask = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_snmp_view_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeSnmpViewKeyT view = CDB__COMPOSE_SNMP_VIEW_KEY_T__INIT;
    Cdb__TblSnmpViewKey pb_snmp_view_key = CDB__TBL_SNMP_VIEW_KEY__INIT;
    Cdb__TblSnmpView pb_snmp_view = CDB__TBL_SNMP_VIEW__INIT;
    tbl_snmp_view_t *p_snmp_view = (tbl_snmp_view_t*)p_tbl;
    int32 len = 0;

    pb_snmp_view_key.view = &view;
    pb_snmp_view.key = &pb_snmp_view_key;
    pb_tbl_snmp_view_to_pb(only_key, p_snmp_view, &pb_snmp_view);
    len = cdb__tbl_snmp_view__pack(&pb_snmp_view, buf);
    pb_tbl_snmp_view_to_pb_free_packed(&pb_snmp_view);

    return len;
}

int32
pb_tbl_snmp_view_dump(Cdb__TblSnmpView *p_pb_snmp_view, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_snmp_view_key_t_dump(p_pb_snmp_view->key->view, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_snmp_view->type);
    offset += sal_sprintf(out + offset, "/mask=%s", p_pb_snmp_view->mask);
    offset += sal_sprintf(out + offset, "/refcnt=%u", p_pb_snmp_view->refcnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SNMP_COMMUNITY */
int32
pb_tbl_snmp_community_to_pb(uint32 only_key, tbl_snmp_community_t *p_snmp_community, Cdb__TblSnmpCommunity *p_pb_snmp_community)
{
    p_pb_snmp_community->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_snmp_community->key.name)+1);
    sal_strcpy(p_pb_snmp_community->key->name, p_snmp_community->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_snmp_community->has_type = TRUE;
    p_pb_snmp_community->type = p_snmp_community->type;
    p_pb_snmp_community->view = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_snmp_community->view)+1);
    sal_strcpy(p_pb_snmp_community->view, p_snmp_community->view);
    p_pb_snmp_community->has_secidx = TRUE;
    p_pb_snmp_community->secidx = p_snmp_community->secidx;

    return PM_E_NONE;
}

int32
pb_tbl_snmp_community_to_pb_free_packed(Cdb__TblSnmpCommunity *p_pb_snmp_community)
{
    if (p_pb_snmp_community->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_snmp_community->key->name);
        p_pb_snmp_community->key->name = NULL;
    }

    if (p_pb_snmp_community->view)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_snmp_community->view);
        p_pb_snmp_community->view = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_snmp_community_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSnmpCommunityKey pb_snmp_community_key = CDB__TBL_SNMP_COMMUNITY_KEY__INIT;
    Cdb__TblSnmpCommunity pb_snmp_community = CDB__TBL_SNMP_COMMUNITY__INIT;
    tbl_snmp_community_t *p_snmp_community = (tbl_snmp_community_t*)p_tbl;
    int32 len = 0;

    pb_snmp_community.key = &pb_snmp_community_key;
    pb_tbl_snmp_community_to_pb(only_key, p_snmp_community, &pb_snmp_community);
    len = cdb__tbl_snmp_community__pack(&pb_snmp_community, buf);
    pb_tbl_snmp_community_to_pb_free_packed(&pb_snmp_community);

    return len;
}

int32
pb_tbl_snmp_community_dump(Cdb__TblSnmpCommunity *p_pb_snmp_community, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_snmp_community->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_snmp_community->type);
    offset += sal_sprintf(out + offset, "/view=%s", p_pb_snmp_community->view);
    offset += sal_sprintf(out + offset, "/secidx=%u", p_pb_snmp_community->secidx);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SNMP_TRAP */
int32
pb_tbl_snmp_trap_to_pb(uint32 only_key, tbl_snmp_trap_t *p_snmp_trap, Cdb__TblSnmpTrap *p_pb_snmp_trap)
{
    pb_compose_snmp_trap_key_t_to_pb(&p_snmp_trap->key.trap, p_pb_snmp_trap->key->trap);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_snmp_trap->has_is_inband = TRUE;
    p_pb_snmp_trap->is_inband = p_snmp_trap->is_inband;

    return PM_E_NONE;
}

int32
pb_tbl_snmp_trap_to_pb_free_packed(Cdb__TblSnmpTrap *p_pb_snmp_trap)
{
    pb_compose_snmp_trap_key_t_to_pb_free_packed(p_pb_snmp_trap->key->trap);
    return PM_E_NONE;
}

int32
pb_tbl_snmp_trap_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeSnmpTrapKeyT trap = CDB__COMPOSE_SNMP_TRAP_KEY_T__INIT;
    Cdb__TblSnmpTrapKey pb_snmp_trap_key = CDB__TBL_SNMP_TRAP_KEY__INIT;
    Cdb__TblSnmpTrap pb_snmp_trap = CDB__TBL_SNMP_TRAP__INIT;
    tbl_snmp_trap_t *p_snmp_trap = (tbl_snmp_trap_t*)p_tbl;
    int32 len = 0;

    pb_snmp_trap_key.trap = &trap;
    pb_snmp_trap.key = &pb_snmp_trap_key;
    pb_tbl_snmp_trap_to_pb(only_key, p_snmp_trap, &pb_snmp_trap);
    len = cdb__tbl_snmp_trap__pack(&pb_snmp_trap, buf);
    pb_tbl_snmp_trap_to_pb_free_packed(&pb_snmp_trap);

    return len;
}

int32
pb_tbl_snmp_trap_dump(Cdb__TblSnmpTrap *p_pb_snmp_trap, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_snmp_trap_key_t_dump(p_pb_snmp_trap->key->trap, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_snmp_trap->is_inband);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SNMP_INFORM */
int32
pb_tbl_snmp_inform_to_pb(uint32 only_key, tbl_snmp_inform_t *p_snmp_inform, Cdb__TblSnmpInform *p_pb_snmp_inform)
{
    pb_compose_snmp_inform_key_t_to_pb(&p_snmp_inform->key.inform, p_pb_snmp_inform->key->inform);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_snmp_inform->has_is_inband = TRUE;
    p_pb_snmp_inform->is_inband = p_snmp_inform->is_inband;

    return PM_E_NONE;
}

int32
pb_tbl_snmp_inform_to_pb_free_packed(Cdb__TblSnmpInform *p_pb_snmp_inform)
{
    pb_compose_snmp_inform_key_t_to_pb_free_packed(p_pb_snmp_inform->key->inform);
    return PM_E_NONE;
}

int32
pb_tbl_snmp_inform_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeSnmpInformKeyT inform = CDB__COMPOSE_SNMP_INFORM_KEY_T__INIT;
    Cdb__TblSnmpInformKey pb_snmp_inform_key = CDB__TBL_SNMP_INFORM_KEY__INIT;
    Cdb__TblSnmpInform pb_snmp_inform = CDB__TBL_SNMP_INFORM__INIT;
    tbl_snmp_inform_t *p_snmp_inform = (tbl_snmp_inform_t*)p_tbl;
    int32 len = 0;

    pb_snmp_inform_key.inform = &inform;
    pb_snmp_inform.key = &pb_snmp_inform_key;
    pb_tbl_snmp_inform_to_pb(only_key, p_snmp_inform, &pb_snmp_inform);
    len = cdb__tbl_snmp_inform__pack(&pb_snmp_inform, buf);
    pb_tbl_snmp_inform_to_pb_free_packed(&pb_snmp_inform);

    return len;
}

int32
pb_tbl_snmp_inform_dump(Cdb__TblSnmpInform *p_pb_snmp_inform, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_snmp_inform_key_t_dump(p_pb_snmp_inform->key->inform, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_snmp_inform->is_inband);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SYSLOG_CFG */
int32
pb_tbl_syslog_cfg_to_pb(uint32 only_key, tbl_syslog_cfg_t *p_syslog_cfg, Cdb__TblSyslogCfg *p_pb_syslog_cfg)
{
    p_pb_syslog_cfg->has_enable_to_server = TRUE;
    p_pb_syslog_cfg->enable_to_server = p_syslog_cfg->enable_to_server;
    p_pb_syslog_cfg->has_enable_to_file = TRUE;
    p_pb_syslog_cfg->enable_to_file = p_syslog_cfg->enable_to_file;
    p_pb_syslog_cfg->has_enable_to_trap = TRUE;
    p_pb_syslog_cfg->enable_to_trap = p_syslog_cfg->enable_to_trap;
    p_pb_syslog_cfg->has_enable_to_diag = TRUE;
    p_pb_syslog_cfg->enable_to_diag = p_syslog_cfg->enable_to_diag;
    p_pb_syslog_cfg->has_logging_lines = TRUE;
    p_pb_syslog_cfg->logging_lines = p_syslog_cfg->logging_lines;
    p_pb_syslog_cfg->server_addr = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_syslog_cfg->server_addr)+1);
    sal_strcpy(p_pb_syslog_cfg->server_addr, p_syslog_cfg->server_addr);
    p_pb_syslog_cfg->has_server_facility = TRUE;
    p_pb_syslog_cfg->server_facility = p_syslog_cfg->server_facility;
    p_pb_syslog_cfg->has_server_severity = TRUE;
    p_pb_syslog_cfg->server_severity = p_syslog_cfg->server_severity;
    p_pb_syslog_cfg->has_trap_facility = TRUE;
    p_pb_syslog_cfg->trap_facility = p_syslog_cfg->trap_facility;
    p_pb_syslog_cfg->has_trap_severity = TRUE;
    p_pb_syslog_cfg->trap_severity = p_syslog_cfg->trap_severity;
    p_pb_syslog_cfg->has_timestamp = TRUE;
    p_pb_syslog_cfg->timestamp = p_syslog_cfg->timestamp;
    p_pb_syslog_cfg->has_file_severity = TRUE;
    p_pb_syslog_cfg->file_severity = p_syslog_cfg->file_severity;
    p_pb_syslog_cfg->has_module_severity = TRUE;
    p_pb_syslog_cfg->module_severity = p_syslog_cfg->module_severity;
    p_pb_syslog_cfg->has_enable_merge = TRUE;
    p_pb_syslog_cfg->enable_merge = p_syslog_cfg->enable_merge;
    p_pb_syslog_cfg->has_merge_timeout = TRUE;
    p_pb_syslog_cfg->merge_timeout = p_syslog_cfg->merge_timeout;
    p_pb_syslog_cfg->has_merge_fifosize = TRUE;
    p_pb_syslog_cfg->merge_fifosize = p_syslog_cfg->merge_fifosize;

    return PM_E_NONE;
}

int32
pb_tbl_syslog_cfg_to_pb_free_packed(Cdb__TblSyslogCfg *p_pb_syslog_cfg)
{
    if (p_pb_syslog_cfg->server_addr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_syslog_cfg->server_addr);
        p_pb_syslog_cfg->server_addr = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_syslog_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSyslogCfg pb_syslog_cfg = CDB__TBL_SYSLOG_CFG__INIT;
    tbl_syslog_cfg_t *p_syslog_cfg = (tbl_syslog_cfg_t*)p_tbl;
    int32 len = 0;

    pb_tbl_syslog_cfg_to_pb(only_key, p_syslog_cfg, &pb_syslog_cfg);
    len = cdb__tbl_syslog_cfg__pack(&pb_syslog_cfg, buf);
    pb_tbl_syslog_cfg_to_pb_free_packed(&pb_syslog_cfg);

    return len;
}

int32
pb_tbl_syslog_cfg_dump(Cdb__TblSyslogCfg *p_pb_syslog_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable_to_server=%u", p_pb_syslog_cfg->enable_to_server);
    offset += sal_sprintf(out + offset, "/enable_to_file=%u", p_pb_syslog_cfg->enable_to_file);
    offset += sal_sprintf(out + offset, "/enable_to_trap=%u", p_pb_syslog_cfg->enable_to_trap);
    offset += sal_sprintf(out + offset, "/enable_to_diag=%u", p_pb_syslog_cfg->enable_to_diag);
    offset += sal_sprintf(out + offset, "/logging_lines=%u", p_pb_syslog_cfg->logging_lines);
    offset += sal_sprintf(out + offset, "/server_addr=%s", p_pb_syslog_cfg->server_addr);
    offset += sal_sprintf(out + offset, "/server_facility=%u", p_pb_syslog_cfg->server_facility);
    offset += sal_sprintf(out + offset, "/server_severity=%u", p_pb_syslog_cfg->server_severity);
    offset += sal_sprintf(out + offset, "/trap_facility=%u", p_pb_syslog_cfg->trap_facility);
    offset += sal_sprintf(out + offset, "/trap_severity=%u", p_pb_syslog_cfg->trap_severity);
    offset += sal_sprintf(out + offset, "/timestamp=%u", p_pb_syslog_cfg->timestamp);
    offset += sal_sprintf(out + offset, "/file_severity=%u", p_pb_syslog_cfg->file_severity);
    offset += sal_sprintf(out + offset, "/module_severity=%u", p_pb_syslog_cfg->module_severity);
    offset += sal_sprintf(out + offset, "/enable_merge=%u", p_pb_syslog_cfg->enable_merge);
    offset += sal_sprintf(out + offset, "/merge_timeout=%u", p_pb_syslog_cfg->merge_timeout);
    offset += sal_sprintf(out + offset, "/merge_fifosize=%u", p_pb_syslog_cfg->merge_fifosize);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_SERVER */
int32
pb_tbl_ntp_server_to_pb(uint32 only_key, tbl_ntp_server_t *p_ntp_server, Cdb__TblNtpServer *p_pb_ntp_server)
{
    p_pb_ntp_server->key->host = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_server->key.host)+1);
    sal_strcpy(p_pb_ntp_server->key->host, p_ntp_server->key.host);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ntp_server->has_keyid = TRUE;
    p_pb_ntp_server->keyid = p_ntp_server->keyid;
    p_pb_ntp_server->has_version = TRUE;
    p_pb_ntp_server->version = p_ntp_server->version;
    p_pb_ntp_server->has_prefer = TRUE;
    p_pb_ntp_server->prefer = p_ntp_server->prefer;
    p_pb_ntp_server->has_type = TRUE;
    p_pb_ntp_server->type = p_ntp_server->type;
    p_pb_ntp_server->has_is_inband = TRUE;
    p_pb_ntp_server->is_inband = p_ntp_server->is_inband;

    return PM_E_NONE;
}

int32
pb_tbl_ntp_server_to_pb_free_packed(Cdb__TblNtpServer *p_pb_ntp_server)
{
    if (p_pb_ntp_server->key->host)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_server->key->host);
        p_pb_ntp_server->key->host = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ntp_server_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpServerKey pb_ntp_server_key = CDB__TBL_NTP_SERVER_KEY__INIT;
    Cdb__TblNtpServer pb_ntp_server = CDB__TBL_NTP_SERVER__INIT;
    tbl_ntp_server_t *p_ntp_server = (tbl_ntp_server_t*)p_tbl;
    int32 len = 0;

    pb_ntp_server.key = &pb_ntp_server_key;
    pb_tbl_ntp_server_to_pb(only_key, p_ntp_server, &pb_ntp_server);
    len = cdb__tbl_ntp_server__pack(&pb_ntp_server, buf);
    pb_tbl_ntp_server_to_pb_free_packed(&pb_ntp_server);

    return len;
}

int32
pb_tbl_ntp_server_dump(Cdb__TblNtpServer *p_pb_ntp_server, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->host=%s", p_pb_ntp_server->key->host);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/keyid=%u", p_pb_ntp_server->keyid);
    offset += sal_sprintf(out + offset, "/version=%u", p_pb_ntp_server->version);
    offset += sal_sprintf(out + offset, "/prefer=%u", p_pb_ntp_server->prefer);
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_ntp_server->type);
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_ntp_server->is_inband);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_ACE */
int32
pb_tbl_ntp_ace_to_pb(uint32 only_key, tbl_ntp_ace_t *p_ntp_ace, Cdb__TblNtpAce *p_pb_ntp_ace)
{
    p_pb_ntp_ace->key->host = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_ace->key.host)+1);
    sal_strcpy(p_pb_ntp_ace->key->host, p_ntp_ace->key.host);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ntp_ace->has_option = TRUE;
    p_pb_ntp_ace->option = p_ntp_ace->option;
    p_pb_ntp_ace->has_family = TRUE;
    p_pb_ntp_ace->family = p_ntp_ace->family;
    p_pb_ntp_ace->has_masklen = TRUE;
    p_pb_ntp_ace->masklen = p_ntp_ace->masklen;

    return PM_E_NONE;
}

int32
pb_tbl_ntp_ace_to_pb_free_packed(Cdb__TblNtpAce *p_pb_ntp_ace)
{
    if (p_pb_ntp_ace->key->host)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_ace->key->host);
        p_pb_ntp_ace->key->host = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ntp_ace_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpAceKey pb_ntp_ace_key = CDB__TBL_NTP_ACE_KEY__INIT;
    Cdb__TblNtpAce pb_ntp_ace = CDB__TBL_NTP_ACE__INIT;
    tbl_ntp_ace_t *p_ntp_ace = (tbl_ntp_ace_t*)p_tbl;
    int32 len = 0;

    pb_ntp_ace.key = &pb_ntp_ace_key;
    pb_tbl_ntp_ace_to_pb(only_key, p_ntp_ace, &pb_ntp_ace);
    len = cdb__tbl_ntp_ace__pack(&pb_ntp_ace, buf);
    pb_tbl_ntp_ace_to_pb_free_packed(&pb_ntp_ace);

    return len;
}

int32
pb_tbl_ntp_ace_dump(Cdb__TblNtpAce *p_pb_ntp_ace, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->host=%s", p_pb_ntp_ace->key->host);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/option=%u", p_pb_ntp_ace->option);
    offset += sal_sprintf(out + offset, "/family=%u", p_pb_ntp_ace->family);
    offset += sal_sprintf(out + offset, "/masklen=%u", p_pb_ntp_ace->masklen);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_KEY */
int32
pb_tbl_ntp_key_to_pb(uint32 only_key, tbl_ntp_key_t *p_ntp_key, Cdb__TblNtpKey *p_pb_ntp_key)
{
    p_pb_ntp_key->key->keyid = p_ntp_key->key.keyid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ntp_key->value = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_key->value)+1);
    sal_strcpy(p_pb_ntp_key->value, p_ntp_key->value);
    p_pb_ntp_key->has_trusted = TRUE;
    p_pb_ntp_key->trusted = p_ntp_key->trusted;

    return PM_E_NONE;
}

int32
pb_tbl_ntp_key_to_pb_free_packed(Cdb__TblNtpKey *p_pb_ntp_key)
{
    if (p_pb_ntp_key->value)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_key->value);
        p_pb_ntp_key->value = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ntp_key_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpKeyKey pb_ntp_key_key = CDB__TBL_NTP_KEY_KEY__INIT;
    Cdb__TblNtpKey pb_ntp_key = CDB__TBL_NTP_KEY__INIT;
    tbl_ntp_key_t *p_ntp_key = (tbl_ntp_key_t*)p_tbl;
    int32 len = 0;

    pb_ntp_key.key = &pb_ntp_key_key;
    pb_tbl_ntp_key_to_pb(only_key, p_ntp_key, &pb_ntp_key);
    len = cdb__tbl_ntp_key__pack(&pb_ntp_key, buf);
    pb_tbl_ntp_key_to_pb_free_packed(&pb_ntp_key);

    return len;
}

int32
pb_tbl_ntp_key_dump(Cdb__TblNtpKey *p_pb_ntp_key, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->keyid=%u", p_pb_ntp_key->key->keyid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/value=%s", p_pb_ntp_key->value);
    offset += sal_sprintf(out + offset, "/trusted=%u", p_pb_ntp_key->trusted);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_CFG */
int32
pb_tbl_ntp_cfg_to_pb(uint32 only_key, tbl_ntp_cfg_t *p_ntp_cfg, Cdb__TblNtpCfg *p_pb_ntp_cfg)
{
    p_pb_ntp_cfg->has_aclcount = TRUE;
    p_pb_ntp_cfg->aclcount = p_ntp_cfg->aclCount;
    p_pb_ntp_cfg->has_ucastservercount = TRUE;
    p_pb_ntp_cfg->ucastservercount = p_ntp_cfg->ucastServerCount;
    p_pb_ntp_cfg->has_ucastclientcount = TRUE;
    p_pb_ntp_cfg->ucastclientcount = p_ntp_cfg->ucastClientCount;
    p_pb_ntp_cfg->has_bcastservercount = TRUE;
    p_pb_ntp_cfg->bcastservercount = p_ntp_cfg->bcastServerCount;
    p_pb_ntp_cfg->has_mcastclientcount = TRUE;
    p_pb_ntp_cfg->mcastclientcount = p_ntp_cfg->mcastClientCount;
    p_pb_ntp_cfg->has_mcastservercount = TRUE;
    p_pb_ntp_cfg->mcastservercount = p_ntp_cfg->mcastServerCount;
    p_pb_ntp_cfg->has_bcastdelay = TRUE;
    p_pb_ntp_cfg->bcastdelay = p_ntp_cfg->bcastDelay;
    p_pb_ntp_cfg->has_minimumdistance = TRUE;
    p_pb_ntp_cfg->minimumdistance = p_ntp_cfg->minimumDistance;
    p_pb_ntp_cfg->has_authentication = TRUE;
    p_pb_ntp_cfg->authentication = p_ntp_cfg->authentication;
    p_pb_ntp_cfg->has_brefclock = TRUE;
    p_pb_ntp_cfg->brefclock = p_ntp_cfg->brefclock;
    p_pb_ntp_cfg->has_refclock_stratum = TRUE;
    p_pb_ntp_cfg->refclock_stratum = p_ntp_cfg->refclock_stratum;
    p_pb_ntp_cfg->has_ifreloadcount = TRUE;
    p_pb_ntp_cfg->ifreloadcount = p_ntp_cfg->ifreloadCount;
    p_pb_ntp_cfg->has_clearstats = TRUE;
    p_pb_ntp_cfg->clearstats = p_ntp_cfg->clearStats;

    return PM_E_NONE;
}

int32
pb_tbl_ntp_cfg_to_pb_free_packed(Cdb__TblNtpCfg *p_pb_ntp_cfg)
{
    return PM_E_NONE;
}

int32
pb_tbl_ntp_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpCfg pb_ntp_cfg = CDB__TBL_NTP_CFG__INIT;
    tbl_ntp_cfg_t *p_ntp_cfg = (tbl_ntp_cfg_t*)p_tbl;
    int32 len = 0;

    pb_tbl_ntp_cfg_to_pb(only_key, p_ntp_cfg, &pb_ntp_cfg);
    len = cdb__tbl_ntp_cfg__pack(&pb_ntp_cfg, buf);
    pb_tbl_ntp_cfg_to_pb_free_packed(&pb_ntp_cfg);

    return len;
}

int32
pb_tbl_ntp_cfg_dump(Cdb__TblNtpCfg *p_pb_ntp_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/aclCount=%d", p_pb_ntp_cfg->aclcount);
    offset += sal_sprintf(out + offset, "/ucastServerCount=%d", p_pb_ntp_cfg->ucastservercount);
    offset += sal_sprintf(out + offset, "/ucastClientCount=%d", p_pb_ntp_cfg->ucastclientcount);
    offset += sal_sprintf(out + offset, "/bcastServerCount=%d", p_pb_ntp_cfg->bcastservercount);
    offset += sal_sprintf(out + offset, "/mcastClientCount=%d", p_pb_ntp_cfg->mcastclientcount);
    offset += sal_sprintf(out + offset, "/mcastServerCount=%d", p_pb_ntp_cfg->mcastservercount);
    offset += sal_sprintf(out + offset, "/bcastDelay=%d", p_pb_ntp_cfg->bcastdelay);
    offset += sal_sprintf(out + offset, "/minimumDistance=%d", p_pb_ntp_cfg->minimumdistance);
    offset += sal_sprintf(out + offset, "/authentication=%d", p_pb_ntp_cfg->authentication);
    offset += sal_sprintf(out + offset, "/brefclock=%d", p_pb_ntp_cfg->brefclock);
    offset += sal_sprintf(out + offset, "/refclock_stratum=%d", p_pb_ntp_cfg->refclock_stratum);
    offset += sal_sprintf(out + offset, "/ifreloadCount=%d", p_pb_ntp_cfg->ifreloadcount);
    offset += sal_sprintf(out + offset, "/clearStats=%d", p_pb_ntp_cfg->clearstats);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_IF */
int32
pb_tbl_ntp_if_to_pb(uint32 only_key, tbl_ntp_if_t *p_ntp_if, Cdb__TblNtpIf *p_pb_ntp_if)
{
    p_pb_ntp_if->has_disable = TRUE;
    p_pb_ntp_if->disable = p_ntp_if->disable;
    p_pb_ntp_if->has_broadcastclient = TRUE;
    p_pb_ntp_if->broadcastclient = p_ntp_if->broadcastClient;

    return PM_E_NONE;
}

int32
pb_tbl_ntp_if_to_pb_free_packed(Cdb__TblNtpIf *p_pb_ntp_if)
{
    return PM_E_NONE;
}

int32
pb_tbl_ntp_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpIf pb_ntp_if = CDB__TBL_NTP_IF__INIT;
    tbl_ntp_if_t *p_ntp_if = (tbl_ntp_if_t*)p_tbl;
    int32 len = 0;

    pb_tbl_ntp_if_to_pb(only_key, p_ntp_if, &pb_ntp_if);
    len = cdb__tbl_ntp_if__pack(&pb_ntp_if, buf);
    pb_tbl_ntp_if_to_pb_free_packed(&pb_ntp_if);

    return len;
}

int32
pb_tbl_ntp_if_dump(Cdb__TblNtpIf *p_pb_ntp_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/disable=%d", p_pb_ntp_if->disable);
    offset += sal_sprintf(out + offset, "/broadcastClient=%d", p_pb_ntp_if->broadcastclient);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NTP_SYNCSTATUS */
int32
pb_tbl_ntp_syncstatus_to_pb(uint32 only_key, tbl_ntp_syncstatus_t *p_ntp_syncstatus, Cdb__TblNtpSyncstatus *p_pb_ntp_syncstatus)
{
    p_pb_ntp_syncstatus->status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->status)+1);
    sal_strcpy(p_pb_ntp_syncstatus->status, p_ntp_syncstatus->status);
    p_pb_ntp_syncstatus->stratum = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->stratum)+1);
    sal_strcpy(p_pb_ntp_syncstatus->stratum, p_ntp_syncstatus->stratum);
    p_pb_ntp_syncstatus->frequency = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->frequency)+1);
    sal_strcpy(p_pb_ntp_syncstatus->frequency, p_ntp_syncstatus->frequency);
    p_pb_ntp_syncstatus->precision = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->precision)+1);
    sal_strcpy(p_pb_ntp_syncstatus->precision, p_ntp_syncstatus->precision);
    p_pb_ntp_syncstatus->reference_time = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->reference_time)+1);
    sal_strcpy(p_pb_ntp_syncstatus->reference_time, p_ntp_syncstatus->reference_time);
    p_pb_ntp_syncstatus->root_delay = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->root_delay)+1);
    sal_strcpy(p_pb_ntp_syncstatus->root_delay, p_ntp_syncstatus->root_delay);
    p_pb_ntp_syncstatus->root_dispersion = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->root_dispersion)+1);
    sal_strcpy(p_pb_ntp_syncstatus->root_dispersion, p_ntp_syncstatus->root_dispersion);
    p_pb_ntp_syncstatus->stability = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ntp_syncstatus->stability)+1);
    sal_strcpy(p_pb_ntp_syncstatus->stability, p_ntp_syncstatus->stability);

    return PM_E_NONE;
}

int32
pb_tbl_ntp_syncstatus_to_pb_free_packed(Cdb__TblNtpSyncstatus *p_pb_ntp_syncstatus)
{
    if (p_pb_ntp_syncstatus->status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->status);
        p_pb_ntp_syncstatus->status = NULL;
    }

    if (p_pb_ntp_syncstatus->stratum)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->stratum);
        p_pb_ntp_syncstatus->stratum = NULL;
    }

    if (p_pb_ntp_syncstatus->frequency)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->frequency);
        p_pb_ntp_syncstatus->frequency = NULL;
    }

    if (p_pb_ntp_syncstatus->precision)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->precision);
        p_pb_ntp_syncstatus->precision = NULL;
    }

    if (p_pb_ntp_syncstatus->reference_time)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->reference_time);
        p_pb_ntp_syncstatus->reference_time = NULL;
    }

    if (p_pb_ntp_syncstatus->root_delay)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->root_delay);
        p_pb_ntp_syncstatus->root_delay = NULL;
    }

    if (p_pb_ntp_syncstatus->root_dispersion)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->root_dispersion);
        p_pb_ntp_syncstatus->root_dispersion = NULL;
    }

    if (p_pb_ntp_syncstatus->stability)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ntp_syncstatus->stability);
        p_pb_ntp_syncstatus->stability = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ntp_syncstatus_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNtpSyncstatus pb_ntp_syncstatus = CDB__TBL_NTP_SYNCSTATUS__INIT;
    tbl_ntp_syncstatus_t *p_ntp_syncstatus = (tbl_ntp_syncstatus_t*)p_tbl;
    int32 len = 0;

    pb_tbl_ntp_syncstatus_to_pb(only_key, p_ntp_syncstatus, &pb_ntp_syncstatus);
    len = cdb__tbl_ntp_syncstatus__pack(&pb_ntp_syncstatus, buf);
    pb_tbl_ntp_syncstatus_to_pb_free_packed(&pb_ntp_syncstatus);

    return len;
}

int32
pb_tbl_ntp_syncstatus_dump(Cdb__TblNtpSyncstatus *p_pb_ntp_syncstatus, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/status=%s", p_pb_ntp_syncstatus->status);
    offset += sal_sprintf(out + offset, "/stratum=%s", p_pb_ntp_syncstatus->stratum);
    offset += sal_sprintf(out + offset, "/frequency=%s", p_pb_ntp_syncstatus->frequency);
    offset += sal_sprintf(out + offset, "/precision=%s", p_pb_ntp_syncstatus->precision);
    offset += sal_sprintf(out + offset, "/reference_time=%s", p_pb_ntp_syncstatus->reference_time);
    offset += sal_sprintf(out + offset, "/root_delay=%s", p_pb_ntp_syncstatus->root_delay);
    offset += sal_sprintf(out + offset, "/root_dispersion=%s", p_pb_ntp_syncstatus->root_dispersion);
    offset += sal_sprintf(out + offset, "/stability=%s", p_pb_ntp_syncstatus->stability);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_STATIC_DNS */
int32
pb_tbl_static_dns_to_pb(uint32 only_key, tbl_static_dns_t *p_static_cfg, Cdb__TblStaticDns *p_pb_static_cfg)
{
    p_pb_static_cfg->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_static_cfg->key.name)+1);
    sal_strcpy(p_pb_static_cfg->key->name, p_static_cfg->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_addr_t_to_pb(&p_static_cfg->ip_addr, p_pb_static_cfg->ip_addr);

    return PM_E_NONE;
}

int32
pb_tbl_static_dns_to_pb_free_packed(Cdb__TblStaticDns *p_pb_static_cfg)
{
    if (p_pb_static_cfg->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_static_cfg->key->name);
        p_pb_static_cfg->key->name = NULL;
    }

    pb_compose_addr_t_to_pb_free_packed(p_pb_static_cfg->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_static_dns_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblStaticDnsKey pb_static_cfg_key = CDB__TBL_STATIC_DNS_KEY__INIT;
    Cdb__TblStaticDns pb_static_cfg = CDB__TBL_STATIC_DNS__INIT;
    tbl_static_dns_t *p_static_cfg = (tbl_static_dns_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrT ip_addr = CDB__COMPOSE_ADDR_T__INIT;

    pb_static_cfg.key = &pb_static_cfg_key;
    pb_static_cfg.ip_addr = &ip_addr;
    pb_tbl_static_dns_to_pb(only_key, p_static_cfg, &pb_static_cfg);
    len = cdb__tbl_static_dns__pack(&pb_static_cfg, buf);
    pb_tbl_static_dns_to_pb_free_packed(&pb_static_cfg);

    return len;
}

int32
pb_tbl_static_dns_dump(Cdb__TblStaticDns *p_pb_static_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_static_cfg->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_addr_t_dump(p_pb_static_cfg->ip_addr, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DYNAMIC_DNS_DOMAIN */
int32
pb_tbl_dynamic_dns_domain_to_pb(uint32 only_key, tbl_dynamic_dns_domain_t *p_dynamic_domain_cfg, Cdb__TblDynamicDnsDomain *p_pb_dynamic_domain_cfg)
{
    p_pb_dynamic_domain_cfg->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dynamic_domain_cfg->key.name)+1);
    sal_strcpy(p_pb_dynamic_domain_cfg->key->name, p_dynamic_domain_cfg->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }


    return PM_E_NONE;
}

int32
pb_tbl_dynamic_dns_domain_to_pb_free_packed(Cdb__TblDynamicDnsDomain *p_pb_dynamic_domain_cfg)
{
    if (p_pb_dynamic_domain_cfg->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dynamic_domain_cfg->key->name);
        p_pb_dynamic_domain_cfg->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dynamic_dns_domain_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDynamicDnsDomainKey pb_dynamic_domain_cfg_key = CDB__TBL_DYNAMIC_DNS_DOMAIN_KEY__INIT;
    Cdb__TblDynamicDnsDomain pb_dynamic_domain_cfg = CDB__TBL_DYNAMIC_DNS_DOMAIN__INIT;
    tbl_dynamic_dns_domain_t *p_dynamic_domain_cfg = (tbl_dynamic_dns_domain_t*)p_tbl;
    int32 len = 0;

    pb_dynamic_domain_cfg.key = &pb_dynamic_domain_cfg_key;
    pb_tbl_dynamic_dns_domain_to_pb(only_key, p_dynamic_domain_cfg, &pb_dynamic_domain_cfg);
    len = cdb__tbl_dynamic_dns_domain__pack(&pb_dynamic_domain_cfg, buf);
    pb_tbl_dynamic_dns_domain_to_pb_free_packed(&pb_dynamic_domain_cfg);

    return len;
}

int32
pb_tbl_dynamic_dns_domain_dump(Cdb__TblDynamicDnsDomain *p_pb_dynamic_domain_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_dynamic_domain_cfg->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DYNAMIC_DNS_SERVER */
int32
pb_tbl_dynamic_dns_server_to_pb(uint32 only_key, tbl_dynamic_dns_server_t *p_dynamic_server_cfg, Cdb__TblDynamicDnsServer *p_pb_dynamic_server_cfg)
{
    pb_compose_addr_t_to_pb(&p_dynamic_server_cfg->key.ip_addr, p_pb_dynamic_server_cfg->key->ip_addr);

    if (only_key)
    {
        return PM_E_NONE;
    }


    return PM_E_NONE;
}

int32
pb_tbl_dynamic_dns_server_to_pb_free_packed(Cdb__TblDynamicDnsServer *p_pb_dynamic_server_cfg)
{
    pb_compose_addr_t_to_pb_free_packed(p_pb_dynamic_server_cfg->key->ip_addr);
    return PM_E_NONE;
}

int32
pb_tbl_dynamic_dns_server_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeAddrT ip_addr = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__TblDynamicDnsServerKey pb_dynamic_server_cfg_key = CDB__TBL_DYNAMIC_DNS_SERVER_KEY__INIT;
    Cdb__TblDynamicDnsServer pb_dynamic_server_cfg = CDB__TBL_DYNAMIC_DNS_SERVER__INIT;
    tbl_dynamic_dns_server_t *p_dynamic_server_cfg = (tbl_dynamic_dns_server_t*)p_tbl;
    int32 len = 0;

    pb_dynamic_server_cfg_key.ip_addr = &ip_addr;
    pb_dynamic_server_cfg.key = &pb_dynamic_server_cfg_key;
    pb_tbl_dynamic_dns_server_to_pb(only_key, p_dynamic_server_cfg, &pb_dynamic_server_cfg);
    len = cdb__tbl_dynamic_dns_server__pack(&pb_dynamic_server_cfg, buf);
    pb_tbl_dynamic_dns_server_to_pb_free_packed(&pb_dynamic_server_cfg);

    return len;
}

int32
pb_tbl_dynamic_dns_server_dump(Cdb__TblDynamicDnsServer *p_pb_dynamic_server_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_addr_t_dump(p_pb_dynamic_server_cfg->key->ip_addr, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_DOMAIN */
int32
pb_tbl_qos_domain_to_pb(uint32 only_key, tbl_qos_domain_t *p_qos_domain, Cdb__TblQosDomain *p_pb_qos_domain)
{
    uint32 i = 0;

    p_pb_qos_domain->key->id = p_qos_domain->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_qos_domain->has_phb_enable = TRUE;
    p_pb_qos_domain->phb_enable = p_qos_domain->phb_enable;
    p_pb_qos_domain->has_cfi_enable = TRUE;
    p_pb_qos_domain->cfi_enable = p_qos_domain->cfi_enable;
    p_pb_qos_domain->cos2pri = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_COS_NUM);
    p_pb_qos_domain->n_cos2pri = GLB_QOS_COS_NUM;
    for (i = 0; i < GLB_QOS_COS_NUM; i++)
    {
        p_pb_qos_domain->cos2pri[i] = p_qos_domain->cos2pri[i];
    }
    p_pb_qos_domain->cos2color = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_COS_NUM);
    p_pb_qos_domain->n_cos2color = GLB_QOS_COS_NUM;
    for (i = 0; i < GLB_QOS_COS_NUM; i++)
    {
        p_pb_qos_domain->cos2color[i] = p_qos_domain->cos2color[i];
    }
    p_pb_qos_domain->cos2phb = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_COS_NUM);
    p_pb_qos_domain->n_cos2phb = GLB_QOS_COS_NUM;
    for (i = 0; i < GLB_QOS_COS_NUM; i++)
    {
        p_pb_qos_domain->cos2phb[i] = p_qos_domain->cos2phb[i];
    }
    p_pb_qos_domain->dscp2pri = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_DSCP_NUM);
    p_pb_qos_domain->n_dscp2pri = GLB_QOS_DSCP_NUM;
    for (i = 0; i < GLB_QOS_DSCP_NUM; i++)
    {
        p_pb_qos_domain->dscp2pri[i] = p_qos_domain->dscp2pri[i];
    }
    p_pb_qos_domain->dscp2color = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_DSCP_NUM);
    p_pb_qos_domain->n_dscp2color = GLB_QOS_DSCP_NUM;
    for (i = 0; i < GLB_QOS_DSCP_NUM; i++)
    {
        p_pb_qos_domain->dscp2color[i] = p_qos_domain->dscp2color[i];
    }
    p_pb_qos_domain->dscp2phb = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_DSCP_NUM);
    p_pb_qos_domain->n_dscp2phb = GLB_QOS_DSCP_NUM;
    for (i = 0; i < GLB_QOS_DSCP_NUM; i++)
    {
        p_pb_qos_domain->dscp2phb[i] = p_qos_domain->dscp2phb[i];
    }
    p_pb_qos_domain->prec2pri = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_IP_PREC_NUM);
    p_pb_qos_domain->n_prec2pri = GLB_QOS_IP_PREC_NUM;
    for (i = 0; i < GLB_QOS_IP_PREC_NUM; i++)
    {
        p_pb_qos_domain->prec2pri[i] = p_qos_domain->prec2pri[i];
    }
    p_pb_qos_domain->prec2color = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_IP_PREC_NUM);
    p_pb_qos_domain->n_prec2color = GLB_QOS_IP_PREC_NUM;
    for (i = 0; i < GLB_QOS_IP_PREC_NUM; i++)
    {
        p_pb_qos_domain->prec2color[i] = p_qos_domain->prec2color[i];
    }
    p_pb_qos_domain->prec2phb = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_IP_PREC_NUM);
    p_pb_qos_domain->n_prec2phb = GLB_QOS_IP_PREC_NUM;
    for (i = 0; i < GLB_QOS_IP_PREC_NUM; i++)
    {
        p_pb_qos_domain->prec2phb[i] = p_qos_domain->prec2phb[i];
    }
    p_pb_qos_domain->exp2pri = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_EXP_NUM);
    p_pb_qos_domain->n_exp2pri = GLB_QOS_EXP_NUM;
    for (i = 0; i < GLB_QOS_EXP_NUM; i++)
    {
        p_pb_qos_domain->exp2pri[i] = p_qos_domain->exp2pri[i];
    }
    p_pb_qos_domain->exp2color = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_EXP_NUM);
    p_pb_qos_domain->n_exp2color = GLB_QOS_EXP_NUM;
    for (i = 0; i < GLB_QOS_EXP_NUM; i++)
    {
        p_pb_qos_domain->exp2color[i] = p_qos_domain->exp2color[i];
    }
    p_pb_qos_domain->exp2phb = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_EXP_NUM);
    p_pb_qos_domain->n_exp2phb = GLB_QOS_EXP_NUM;
    for (i = 0; i < GLB_QOS_EXP_NUM; i++)
    {
        p_pb_qos_domain->exp2phb[i] = p_qos_domain->exp2phb[i];
    }
    p_pb_qos_domain->pri_color2cos = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PRI_COLOR_TABLE_SIZE);
    p_pb_qos_domain->n_pri_color2cos = GLB_QOS_PRI_COLOR_TABLE_SIZE;
    for (i = 0; i < GLB_QOS_PRI_COLOR_TABLE_SIZE; i++)
    {
        p_pb_qos_domain->pri_color2cos[i] = p_qos_domain->pri_color2cos[i];
    }
    p_pb_qos_domain->pri_color2dscp = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PRI_COLOR_TABLE_SIZE);
    p_pb_qos_domain->n_pri_color2dscp = GLB_QOS_PRI_COLOR_TABLE_SIZE;
    for (i = 0; i < GLB_QOS_PRI_COLOR_TABLE_SIZE; i++)
    {
        p_pb_qos_domain->pri_color2dscp[i] = p_qos_domain->pri_color2dscp[i];
    }
    p_pb_qos_domain->pri_color2exp = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PRI_COLOR_TABLE_SIZE);
    p_pb_qos_domain->n_pri_color2exp = GLB_QOS_PRI_COLOR_TABLE_SIZE;
    for (i = 0; i < GLB_QOS_PRI_COLOR_TABLE_SIZE; i++)
    {
        p_pb_qos_domain->pri_color2exp[i] = p_qos_domain->pri_color2exp[i];
    }
    p_pb_qos_domain->phb2cos = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PHB_MAX);
    p_pb_qos_domain->n_phb2cos = GLB_QOS_PHB_MAX;
    for (i = 0; i < GLB_QOS_PHB_MAX; i++)
    {
        p_pb_qos_domain->phb2cos[i] = p_qos_domain->phb2cos[i];
    }
    p_pb_qos_domain->phb2dscp = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PHB_MAX);
    p_pb_qos_domain->n_phb2dscp = GLB_QOS_PHB_MAX;
    for (i = 0; i < GLB_QOS_PHB_MAX; i++)
    {
        p_pb_qos_domain->phb2dscp[i] = p_qos_domain->phb2dscp[i];
    }
    p_pb_qos_domain->phb2exp = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PHB_MAX);
    p_pb_qos_domain->n_phb2exp = GLB_QOS_PHB_MAX;
    for (i = 0; i < GLB_QOS_PHB_MAX; i++)
    {
        p_pb_qos_domain->phb2exp[i] = p_qos_domain->phb2exp[i];
    }
    p_pb_qos_domain->cos2tc = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_COS_NUM);
    p_pb_qos_domain->n_cos2tc = GLB_QOS_COS_NUM;
    for (i = 0; i < GLB_QOS_COS_NUM; i++)
    {
        p_pb_qos_domain->cos2tc[i] = p_qos_domain->cos2tc[i];
    }
    p_pb_qos_domain->dscp2tc = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_DSCP_NUM);
    p_pb_qos_domain->n_dscp2tc = GLB_QOS_DSCP_NUM;
    for (i = 0; i < GLB_QOS_DSCP_NUM; i++)
    {
        p_pb_qos_domain->dscp2tc[i] = p_qos_domain->dscp2tc[i];
    }
    p_pb_qos_domain->tc_color2cos = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_TC_COLOR_TABLE_SIZE);
    p_pb_qos_domain->n_tc_color2cos = GLB_QOS_TC_COLOR_TABLE_SIZE;
    for (i = 0; i < GLB_QOS_TC_COLOR_TABLE_SIZE; i++)
    {
        p_pb_qos_domain->tc_color2cos[i] = p_qos_domain->tc_color2cos[i];
    }
    p_pb_qos_domain->tc_color2dscp = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_TC_COLOR_TABLE_SIZE);
    p_pb_qos_domain->n_tc_color2dscp = GLB_QOS_TC_COLOR_TABLE_SIZE;
    for (i = 0; i < GLB_QOS_TC_COLOR_TABLE_SIZE; i++)
    {
        p_pb_qos_domain->tc_color2dscp[i] = p_qos_domain->tc_color2dscp[i];
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_domain_to_pb_free_packed(Cdb__TblQosDomain *p_pb_qos_domain)
{
    if (p_pb_qos_domain->cos2pri)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->cos2pri);
        p_pb_qos_domain->cos2pri = NULL;
    }

    if (p_pb_qos_domain->cos2color)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->cos2color);
        p_pb_qos_domain->cos2color = NULL;
    }

    if (p_pb_qos_domain->cos2phb)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->cos2phb);
        p_pb_qos_domain->cos2phb = NULL;
    }

    if (p_pb_qos_domain->dscp2pri)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->dscp2pri);
        p_pb_qos_domain->dscp2pri = NULL;
    }

    if (p_pb_qos_domain->dscp2color)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->dscp2color);
        p_pb_qos_domain->dscp2color = NULL;
    }

    if (p_pb_qos_domain->dscp2phb)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->dscp2phb);
        p_pb_qos_domain->dscp2phb = NULL;
    }

    if (p_pb_qos_domain->prec2pri)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->prec2pri);
        p_pb_qos_domain->prec2pri = NULL;
    }

    if (p_pb_qos_domain->prec2color)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->prec2color);
        p_pb_qos_domain->prec2color = NULL;
    }

    if (p_pb_qos_domain->prec2phb)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->prec2phb);
        p_pb_qos_domain->prec2phb = NULL;
    }

    if (p_pb_qos_domain->exp2pri)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->exp2pri);
        p_pb_qos_domain->exp2pri = NULL;
    }

    if (p_pb_qos_domain->exp2color)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->exp2color);
        p_pb_qos_domain->exp2color = NULL;
    }

    if (p_pb_qos_domain->exp2phb)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->exp2phb);
        p_pb_qos_domain->exp2phb = NULL;
    }

    if (p_pb_qos_domain->pri_color2cos)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->pri_color2cos);
        p_pb_qos_domain->pri_color2cos = NULL;
    }

    if (p_pb_qos_domain->pri_color2dscp)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->pri_color2dscp);
        p_pb_qos_domain->pri_color2dscp = NULL;
    }

    if (p_pb_qos_domain->pri_color2exp)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->pri_color2exp);
        p_pb_qos_domain->pri_color2exp = NULL;
    }

    if (p_pb_qos_domain->phb2cos)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->phb2cos);
        p_pb_qos_domain->phb2cos = NULL;
    }

    if (p_pb_qos_domain->phb2dscp)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->phb2dscp);
        p_pb_qos_domain->phb2dscp = NULL;
    }

    if (p_pb_qos_domain->phb2exp)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->phb2exp);
        p_pb_qos_domain->phb2exp = NULL;
    }

    if (p_pb_qos_domain->cos2tc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->cos2tc);
        p_pb_qos_domain->cos2tc = NULL;
    }

    if (p_pb_qos_domain->dscp2tc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->dscp2tc);
        p_pb_qos_domain->dscp2tc = NULL;
    }

    if (p_pb_qos_domain->tc_color2cos)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->tc_color2cos);
        p_pb_qos_domain->tc_color2cos = NULL;
    }

    if (p_pb_qos_domain->tc_color2dscp)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_domain->tc_color2dscp);
        p_pb_qos_domain->tc_color2dscp = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_domain_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosDomainKey pb_qos_domain_key = CDB__TBL_QOS_DOMAIN_KEY__INIT;
    Cdb__TblQosDomain pb_qos_domain = CDB__TBL_QOS_DOMAIN__INIT;
    tbl_qos_domain_t *p_qos_domain = (tbl_qos_domain_t*)p_tbl;
    int32 len = 0;

    pb_qos_domain.key = &pb_qos_domain_key;
    pb_tbl_qos_domain_to_pb(only_key, p_qos_domain, &pb_qos_domain);
    len = cdb__tbl_qos_domain__pack(&pb_qos_domain, buf);
    pb_tbl_qos_domain_to_pb_free_packed(&pb_qos_domain);

    return len;
}

int32
pb_tbl_qos_domain_dump(Cdb__TblQosDomain *p_pb_qos_domain, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_qos_domain->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/phb_enable=%u", p_pb_qos_domain->phb_enable);
    offset += sal_sprintf(out + offset, "/cfi_enable=%u", p_pb_qos_domain->cfi_enable);
    offset += sal_sprintf(out + offset, "/cos2pri=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->cos2pri, sizeof(p_pb_qos_domain->cos2pri), (out + offset));
    offset += sal_sprintf(out + offset, "/cos2color=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->cos2color, sizeof(p_pb_qos_domain->cos2color), (out + offset));
    offset += sal_sprintf(out + offset, "/cos2phb=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->cos2phb, sizeof(p_pb_qos_domain->cos2phb), (out + offset));
    offset += sal_sprintf(out + offset, "/dscp2pri=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->dscp2pri, sizeof(p_pb_qos_domain->dscp2pri), (out + offset));
    offset += sal_sprintf(out + offset, "/dscp2color=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->dscp2color, sizeof(p_pb_qos_domain->dscp2color), (out + offset));
    offset += sal_sprintf(out + offset, "/dscp2phb=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->dscp2phb, sizeof(p_pb_qos_domain->dscp2phb), (out + offset));
    offset += sal_sprintf(out + offset, "/prec2pri=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->prec2pri, sizeof(p_pb_qos_domain->prec2pri), (out + offset));
    offset += sal_sprintf(out + offset, "/prec2color=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->prec2color, sizeof(p_pb_qos_domain->prec2color), (out + offset));
    offset += sal_sprintf(out + offset, "/prec2phb=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->prec2phb, sizeof(p_pb_qos_domain->prec2phb), (out + offset));
    offset += sal_sprintf(out + offset, "/exp2pri=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->exp2pri, sizeof(p_pb_qos_domain->exp2pri), (out + offset));
    offset += sal_sprintf(out + offset, "/exp2color=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->exp2color, sizeof(p_pb_qos_domain->exp2color), (out + offset));
    offset += sal_sprintf(out + offset, "/exp2phb=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->exp2phb, sizeof(p_pb_qos_domain->exp2phb), (out + offset));
    offset += sal_sprintf(out + offset, "/pri_color2cos=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->pri_color2cos, sizeof(p_pb_qos_domain->pri_color2cos), (out + offset));
    offset += sal_sprintf(out + offset, "/pri_color2dscp=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->pri_color2dscp, sizeof(p_pb_qos_domain->pri_color2dscp), (out + offset));
    offset += sal_sprintf(out + offset, "/pri_color2exp=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->pri_color2exp, sizeof(p_pb_qos_domain->pri_color2exp), (out + offset));
    offset += sal_sprintf(out + offset, "/phb2cos=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->phb2cos, sizeof(p_pb_qos_domain->phb2cos), (out + offset));
    offset += sal_sprintf(out + offset, "/phb2dscp=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->phb2dscp, sizeof(p_pb_qos_domain->phb2dscp), (out + offset));
    offset += sal_sprintf(out + offset, "/phb2exp=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->phb2exp, sizeof(p_pb_qos_domain->phb2exp), (out + offset));
    offset += sal_sprintf(out + offset, "/cos2tc=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->cos2tc, sizeof(p_pb_qos_domain->cos2tc), (out + offset));
    offset += sal_sprintf(out + offset, "/dscp2tc=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->dscp2tc, sizeof(p_pb_qos_domain->dscp2tc), (out + offset));
    offset += sal_sprintf(out + offset, "/tc_color2cos=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->tc_color2cos, sizeof(p_pb_qos_domain->tc_color2cos), (out + offset));
    offset += sal_sprintf(out + offset, "/tc_color2dscp=");
    offset += pb_uint32_array_dump(p_pb_qos_domain->tc_color2dscp, sizeof(p_pb_qos_domain->tc_color2dscp), (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_POLICER_PROFILE */
int32
pb_tbl_qos_policer_profile_to_pb(uint32 only_key, tbl_qos_policer_profile_t *p_qos_policer_profile, Cdb__TblQosPolicerProfile *p_pb_qos_policer_profile)
{
    p_pb_qos_policer_profile->key->id = p_qos_policer_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_qos_policer_profile->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_qos_policer_profile->name)+1);
    sal_strcpy(p_pb_qos_policer_profile->name, p_qos_policer_profile->name);
    p_pb_qos_policer_profile->has_flags_policer_agp = TRUE;
    p_pb_qos_policer_profile->flags_policer_agp = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_AGP) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_algorithm_mode = TRUE;
    p_pb_qos_policer_profile->flags_algorithm_mode = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_ALGORITHM_MODE) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_color_mode = TRUE;
    p_pb_qos_policer_profile->flags_color_mode = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_COLOR_MODE) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_cir = TRUE;
    p_pb_qos_policer_profile->flags_cir = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_CIR) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_cbs = TRUE;
    p_pb_qos_policer_profile->flags_cbs = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_CBS) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_eir_or_pir = TRUE;
    p_pb_qos_policer_profile->flags_eir_or_pir = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_EIR_OR_PIR) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_ebs_or_pbs = TRUE;
    p_pb_qos_policer_profile->flags_ebs_or_pbs = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_EBS_OR_PBS) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_drop_color = TRUE;
    p_pb_qos_policer_profile->flags_drop_color = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_DROP_COLOR) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_use_l3_legth = TRUE;
    p_pb_qos_policer_profile->flags_use_l3_legth = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_USE_L3_LENGTH) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_stats = TRUE;
    p_pb_qos_policer_profile->flags_stats = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_STATS) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_flags_dump_stats = TRUE;
    p_pb_qos_policer_profile->flags_dump_stats = GLB_FLAG_ISSET(p_qos_policer_profile->flags, GLB_POLICER_PROFILE_FLAGS_DUMP_STATS) ? TRUE : FALSE;
    p_pb_qos_policer_profile->has_algorithm_mode = TRUE;
    p_pb_qos_policer_profile->algorithm_mode = p_qos_policer_profile->algorithm_mode;
    p_pb_qos_policer_profile->has_color_mode = TRUE;
    p_pb_qos_policer_profile->color_mode = p_qos_policer_profile->color_mode;
    p_pb_qos_policer_profile->has_drop_color = TRUE;
    p_pb_qos_policer_profile->drop_color = p_qos_policer_profile->drop_color;
    p_pb_qos_policer_profile->has_cir = TRUE;
    p_pb_qos_policer_profile->cir = p_qos_policer_profile->cir;
    p_pb_qos_policer_profile->has_cbs = TRUE;
    p_pb_qos_policer_profile->cbs = p_qos_policer_profile->cbs;
    p_pb_qos_policer_profile->has_eir_or_pir = TRUE;
    p_pb_qos_policer_profile->eir_or_pir = p_qos_policer_profile->eir_or_pir;
    p_pb_qos_policer_profile->has_ebs_or_pbs = TRUE;
    p_pb_qos_policer_profile->ebs_or_pbs = p_qos_policer_profile->ebs_or_pbs;
    p_pb_qos_policer_profile->has_confirm_pkt = TRUE;
    p_pb_qos_policer_profile->confirm_pkt = p_qos_policer_profile->confirm_pkt;
    p_pb_qos_policer_profile->has_confirm_byte = TRUE;
    p_pb_qos_policer_profile->confirm_byte = p_qos_policer_profile->confirm_byte;
    p_pb_qos_policer_profile->has_exceed_pkt = TRUE;
    p_pb_qos_policer_profile->exceed_pkt = p_qos_policer_profile->exceed_pkt;
    p_pb_qos_policer_profile->has_exceed_byte = TRUE;
    p_pb_qos_policer_profile->exceed_byte = p_qos_policer_profile->exceed_byte;
    p_pb_qos_policer_profile->has_violate_pkt = TRUE;
    p_pb_qos_policer_profile->violate_pkt = p_qos_policer_profile->violate_pkt;
    p_pb_qos_policer_profile->has_violate_byte = TRUE;
    p_pb_qos_policer_profile->violate_byte = p_qos_policer_profile->violate_byte;
    p_pb_qos_policer_profile->has_ref_cnt = TRUE;
    p_pb_qos_policer_profile->ref_cnt = p_qos_policer_profile->ref_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_qos_policer_profile_to_pb_free_packed(Cdb__TblQosPolicerProfile *p_pb_qos_policer_profile)
{
    if (p_pb_qos_policer_profile->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_policer_profile->name);
        p_pb_qos_policer_profile->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_policer_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosPolicerProfileKey pb_qos_policer_profile_key = CDB__TBL_QOS_POLICER_PROFILE_KEY__INIT;
    Cdb__TblQosPolicerProfile pb_qos_policer_profile = CDB__TBL_QOS_POLICER_PROFILE__INIT;
    tbl_qos_policer_profile_t *p_qos_policer_profile = (tbl_qos_policer_profile_t*)p_tbl;
    int32 len = 0;

    pb_qos_policer_profile.key = &pb_qos_policer_profile_key;
    pb_tbl_qos_policer_profile_to_pb(only_key, p_qos_policer_profile, &pb_qos_policer_profile);
    len = cdb__tbl_qos_policer_profile__pack(&pb_qos_policer_profile, buf);
    pb_tbl_qos_policer_profile_to_pb_free_packed(&pb_qos_policer_profile);

    return len;
}

int32
pb_tbl_qos_policer_profile_dump(Cdb__TblQosPolicerProfile *p_pb_qos_policer_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_qos_policer_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_qos_policer_profile->name);
    offset += sal_sprintf(out + offset, "/flags_policer_agp=%u", p_pb_qos_policer_profile->flags_policer_agp);
    offset += sal_sprintf(out + offset, "/flags_algorithm_mode=%u", p_pb_qos_policer_profile->flags_algorithm_mode);
    offset += sal_sprintf(out + offset, "/flags_color_mode=%u", p_pb_qos_policer_profile->flags_color_mode);
    offset += sal_sprintf(out + offset, "/flags_cir=%u", p_pb_qos_policer_profile->flags_cir);
    offset += sal_sprintf(out + offset, "/flags_cbs=%u", p_pb_qos_policer_profile->flags_cbs);
    offset += sal_sprintf(out + offset, "/flags_eir_or_pir=%u", p_pb_qos_policer_profile->flags_eir_or_pir);
    offset += sal_sprintf(out + offset, "/flags_ebs_or_pbs=%u", p_pb_qos_policer_profile->flags_ebs_or_pbs);
    offset += sal_sprintf(out + offset, "/flags_drop_color=%u", p_pb_qos_policer_profile->flags_drop_color);
    offset += sal_sprintf(out + offset, "/flags_use_l3_legth=%u", p_pb_qos_policer_profile->flags_use_l3_legth);
    offset += sal_sprintf(out + offset, "/flags_stats=%u", p_pb_qos_policer_profile->flags_stats);
    offset += sal_sprintf(out + offset, "/flags_dump_stats=%u", p_pb_qos_policer_profile->flags_dump_stats);
    offset += sal_sprintf(out + offset, "/algorithm_mode=%u", p_pb_qos_policer_profile->algorithm_mode);
    offset += sal_sprintf(out + offset, "/color_mode=%u", p_pb_qos_policer_profile->color_mode);
    offset += sal_sprintf(out + offset, "/drop_color=%u", p_pb_qos_policer_profile->drop_color);
    offset += sal_sprintf(out + offset, "/cir=%llu", p_pb_qos_policer_profile->cir);
    offset += sal_sprintf(out + offset, "/cbs=%u", p_pb_qos_policer_profile->cbs);
    offset += sal_sprintf(out + offset, "/eir_or_pir=%llu", p_pb_qos_policer_profile->eir_or_pir);
    offset += sal_sprintf(out + offset, "/ebs_or_pbs=%u", p_pb_qos_policer_profile->ebs_or_pbs);
    offset += sal_sprintf(out + offset, "/confirm_pkt=%llu", p_pb_qos_policer_profile->confirm_pkt);
    offset += sal_sprintf(out + offset, "/confirm_byte=%llu", p_pb_qos_policer_profile->confirm_byte);
    offset += sal_sprintf(out + offset, "/exceed_pkt=%llu", p_pb_qos_policer_profile->exceed_pkt);
    offset += sal_sprintf(out + offset, "/exceed_byte=%llu", p_pb_qos_policer_profile->exceed_byte);
    offset += sal_sprintf(out + offset, "/violate_pkt=%llu", p_pb_qos_policer_profile->violate_pkt);
    offset += sal_sprintf(out + offset, "/violate_byte=%llu", p_pb_qos_policer_profile->violate_byte);
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_qos_policer_profile->ref_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_DROP_PROFILE */
int32
pb_tbl_qos_drop_profile_to_pb(uint32 only_key, tbl_qos_drop_profile_t *p_qos_drop_profile, Cdb__TblQosDropProfile *p_pb_qos_drop_profile)
{
    p_pb_qos_drop_profile->key->id = p_qos_drop_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_qos_drop_profile->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_qos_drop_profile->name)+1);
    sal_strcpy(p_pb_qos_drop_profile->name, p_qos_drop_profile->name);
    p_pb_qos_drop_profile->has_flags_green_max_threshold = TRUE;
    p_pb_qos_drop_profile->flags_green_max_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_GREEN_MAX_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_green_min_threshold = TRUE;
    p_pb_qos_drop_profile->flags_green_min_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_GREEN_MIN_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_green_probabilty = TRUE;
    p_pb_qos_drop_profile->flags_green_probabilty = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_GREEN_PROB) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_yellow_max_threshold = TRUE;
    p_pb_qos_drop_profile->flags_yellow_max_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_YELLOW_MAX_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_yellow_min_threshold = TRUE;
    p_pb_qos_drop_profile->flags_yellow_min_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_YELLOW_MIN_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_yellow_probabilty = TRUE;
    p_pb_qos_drop_profile->flags_yellow_probabilty = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_YELLOW_PROB) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_red_max_threshold = TRUE;
    p_pb_qos_drop_profile->flags_red_max_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_RED_MAX_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_red_min_threshold = TRUE;
    p_pb_qos_drop_profile->flags_red_min_threshold = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_RED_MIN_THRD) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_red_probabilty = TRUE;
    p_pb_qos_drop_profile->flags_red_probabilty = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_RED_PROB) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_flags_random_detect = TRUE;
    p_pb_qos_drop_profile->flags_random_detect = GLB_FLAG_ISSET(p_qos_drop_profile->flags, GLB_DROP_PROFILE_FLAGS_RANDOM_DETECT) ? TRUE : FALSE;
    p_pb_qos_drop_profile->has_green_max_threashold = TRUE;
    p_pb_qos_drop_profile->green_max_threashold = p_qos_drop_profile->green_max_threashold;
    p_pb_qos_drop_profile->has_green_min_threashold = TRUE;
    p_pb_qos_drop_profile->green_min_threashold = p_qos_drop_profile->green_min_threashold;
    p_pb_qos_drop_profile->has_green_probability = TRUE;
    p_pb_qos_drop_profile->green_probability = p_qos_drop_profile->green_probability;
    p_pb_qos_drop_profile->has_yellow_max_threashold = TRUE;
    p_pb_qos_drop_profile->yellow_max_threashold = p_qos_drop_profile->yellow_max_threashold;
    p_pb_qos_drop_profile->has_yellow_min_threashold = TRUE;
    p_pb_qos_drop_profile->yellow_min_threashold = p_qos_drop_profile->yellow_min_threashold;
    p_pb_qos_drop_profile->has_yellow_probability = TRUE;
    p_pb_qos_drop_profile->yellow_probability = p_qos_drop_profile->yellow_probability;
    p_pb_qos_drop_profile->has_red_max_threashold = TRUE;
    p_pb_qos_drop_profile->red_max_threashold = p_qos_drop_profile->red_max_threashold;
    p_pb_qos_drop_profile->has_red_min_threashold = TRUE;
    p_pb_qos_drop_profile->red_min_threashold = p_qos_drop_profile->red_min_threashold;
    p_pb_qos_drop_profile->has_red_probability = TRUE;
    p_pb_qos_drop_profile->red_probability = p_qos_drop_profile->red_probability;
    p_pb_qos_drop_profile->has_ref_cnt = TRUE;
    p_pb_qos_drop_profile->ref_cnt = p_qos_drop_profile->ref_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_qos_drop_profile_to_pb_free_packed(Cdb__TblQosDropProfile *p_pb_qos_drop_profile)
{
    if (p_pb_qos_drop_profile->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_drop_profile->name);
        p_pb_qos_drop_profile->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_drop_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosDropProfileKey pb_qos_drop_profile_key = CDB__TBL_QOS_DROP_PROFILE_KEY__INIT;
    Cdb__TblQosDropProfile pb_qos_drop_profile = CDB__TBL_QOS_DROP_PROFILE__INIT;
    tbl_qos_drop_profile_t *p_qos_drop_profile = (tbl_qos_drop_profile_t*)p_tbl;
    int32 len = 0;

    pb_qos_drop_profile.key = &pb_qos_drop_profile_key;
    pb_tbl_qos_drop_profile_to_pb(only_key, p_qos_drop_profile, &pb_qos_drop_profile);
    len = cdb__tbl_qos_drop_profile__pack(&pb_qos_drop_profile, buf);
    pb_tbl_qos_drop_profile_to_pb_free_packed(&pb_qos_drop_profile);

    return len;
}

int32
pb_tbl_qos_drop_profile_dump(Cdb__TblQosDropProfile *p_pb_qos_drop_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_qos_drop_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_qos_drop_profile->name);
    offset += sal_sprintf(out + offset, "/flags_green_max_threshold=%u", p_pb_qos_drop_profile->flags_green_max_threshold);
    offset += sal_sprintf(out + offset, "/flags_green_min_threshold=%u", p_pb_qos_drop_profile->flags_green_min_threshold);
    offset += sal_sprintf(out + offset, "/flags_green_probabilty=%u", p_pb_qos_drop_profile->flags_green_probabilty);
    offset += sal_sprintf(out + offset, "/flags_yellow_max_threshold=%u", p_pb_qos_drop_profile->flags_yellow_max_threshold);
    offset += sal_sprintf(out + offset, "/flags_yellow_min_threshold=%u", p_pb_qos_drop_profile->flags_yellow_min_threshold);
    offset += sal_sprintf(out + offset, "/flags_yellow_probabilty=%u", p_pb_qos_drop_profile->flags_yellow_probabilty);
    offset += sal_sprintf(out + offset, "/flags_red_max_threshold=%u", p_pb_qos_drop_profile->flags_red_max_threshold);
    offset += sal_sprintf(out + offset, "/flags_red_min_threshold=%u", p_pb_qos_drop_profile->flags_red_min_threshold);
    offset += sal_sprintf(out + offset, "/flags_red_probabilty=%u", p_pb_qos_drop_profile->flags_red_probabilty);
    offset += sal_sprintf(out + offset, "/flags_random_detect=%u", p_pb_qos_drop_profile->flags_random_detect);
    offset += sal_sprintf(out + offset, "/green_max_threashold=%u", p_pb_qos_drop_profile->green_max_threashold);
    offset += sal_sprintf(out + offset, "/green_min_threashold=%u", p_pb_qos_drop_profile->green_min_threashold);
    offset += sal_sprintf(out + offset, "/green_probability=%u", p_pb_qos_drop_profile->green_probability);
    offset += sal_sprintf(out + offset, "/yellow_max_threashold=%u", p_pb_qos_drop_profile->yellow_max_threashold);
    offset += sal_sprintf(out + offset, "/yellow_min_threashold=%u", p_pb_qos_drop_profile->yellow_min_threashold);
    offset += sal_sprintf(out + offset, "/yellow_probability=%u", p_pb_qos_drop_profile->yellow_probability);
    offset += sal_sprintf(out + offset, "/red_max_threashold=%u", p_pb_qos_drop_profile->red_max_threashold);
    offset += sal_sprintf(out + offset, "/red_min_threashold=%u", p_pb_qos_drop_profile->red_min_threashold);
    offset += sal_sprintf(out + offset, "/red_probability=%u", p_pb_qos_drop_profile->red_probability);
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_qos_drop_profile->ref_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_QUEUE_SHAPE_PROFILE */
int32
pb_tbl_qos_queue_shape_profile_to_pb(uint32 only_key, tbl_qos_queue_shape_profile_t *p_qos_queue_shape_profile, Cdb__TblQosQueueShapeProfile *p_pb_qos_queue_shape_profile)
{
    p_pb_qos_queue_shape_profile->key->id = p_qos_queue_shape_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_qos_queue_shape_profile->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_qos_queue_shape_profile->name)+1);
    sal_strcpy(p_pb_qos_queue_shape_profile->name, p_qos_queue_shape_profile->name);
    p_pb_qos_queue_shape_profile->has_pir = TRUE;
    p_pb_qos_queue_shape_profile->pir = p_qos_queue_shape_profile->pir;
    p_pb_qos_queue_shape_profile->has_cir = TRUE;
    p_pb_qos_queue_shape_profile->cir = p_qos_queue_shape_profile->cir;
    p_pb_qos_queue_shape_profile->has_mode = TRUE;
    p_pb_qos_queue_shape_profile->mode = p_qos_queue_shape_profile->mode;
    p_pb_qos_queue_shape_profile->has_queue_weight = TRUE;
    p_pb_qos_queue_shape_profile->queue_weight = p_qos_queue_shape_profile->queue_weight;
    p_pb_qos_queue_shape_profile->has_ref_cnt = TRUE;
    p_pb_qos_queue_shape_profile->ref_cnt = p_qos_queue_shape_profile->ref_cnt;
    p_pb_qos_queue_shape_profile->has_flags_pir = TRUE;
    p_pb_qos_queue_shape_profile->flags_pir = GLB_FLAG_ISSET(p_qos_queue_shape_profile->flags, GLB_QUEUE_SHAPE_PROFILE_FLAGS_PIR) ? TRUE : FALSE;
    p_pb_qos_queue_shape_profile->has_flags_cir = TRUE;
    p_pb_qos_queue_shape_profile->flags_cir = GLB_FLAG_ISSET(p_qos_queue_shape_profile->flags, GLB_QUEUE_SHAPE_PROFILE_FLAGS_CIR) ? TRUE : FALSE;
    p_pb_qos_queue_shape_profile->has_flags_mode = TRUE;
    p_pb_qos_queue_shape_profile->flags_mode = GLB_FLAG_ISSET(p_qos_queue_shape_profile->flags, GLB_QUEUE_SHAPE_PROFILE_FLAGS_MODE) ? TRUE : FALSE;
    p_pb_qos_queue_shape_profile->has_flags_weight = TRUE;
    p_pb_qos_queue_shape_profile->flags_weight = GLB_FLAG_ISSET(p_qos_queue_shape_profile->flags, GLB_QUEUE_SHAPE_PROFILE_FLAGS_WEIGHT) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_qos_queue_shape_profile_to_pb_free_packed(Cdb__TblQosQueueShapeProfile *p_pb_qos_queue_shape_profile)
{
    if (p_pb_qos_queue_shape_profile->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_queue_shape_profile->name);
        p_pb_qos_queue_shape_profile->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_queue_shape_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosQueueShapeProfileKey pb_qos_queue_shape_profile_key = CDB__TBL_QOS_QUEUE_SHAPE_PROFILE_KEY__INIT;
    Cdb__TblQosQueueShapeProfile pb_qos_queue_shape_profile = CDB__TBL_QOS_QUEUE_SHAPE_PROFILE__INIT;
    tbl_qos_queue_shape_profile_t *p_qos_queue_shape_profile = (tbl_qos_queue_shape_profile_t*)p_tbl;
    int32 len = 0;

    pb_qos_queue_shape_profile.key = &pb_qos_queue_shape_profile_key;
    pb_tbl_qos_queue_shape_profile_to_pb(only_key, p_qos_queue_shape_profile, &pb_qos_queue_shape_profile);
    len = cdb__tbl_qos_queue_shape_profile__pack(&pb_qos_queue_shape_profile, buf);
    pb_tbl_qos_queue_shape_profile_to_pb_free_packed(&pb_qos_queue_shape_profile);

    return len;
}

int32
pb_tbl_qos_queue_shape_profile_dump(Cdb__TblQosQueueShapeProfile *p_pb_qos_queue_shape_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_qos_queue_shape_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_qos_queue_shape_profile->name);
    offset += sal_sprintf(out + offset, "/pir=%u", p_pb_qos_queue_shape_profile->pir);
    offset += sal_sprintf(out + offset, "/cir=%u", p_pb_qos_queue_shape_profile->cir);
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_qos_queue_shape_profile->mode);
    offset += sal_sprintf(out + offset, "/queue_weight=%u", p_pb_qos_queue_shape_profile->queue_weight);
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_qos_queue_shape_profile->ref_cnt);
    offset += sal_sprintf(out + offset, "/flags_pir=%u", p_pb_qos_queue_shape_profile->flags_pir);
    offset += sal_sprintf(out + offset, "/flags_cir=%u", p_pb_qos_queue_shape_profile->flags_cir);
    offset += sal_sprintf(out + offset, "/flags_mode=%u", p_pb_qos_queue_shape_profile->flags_mode);
    offset += sal_sprintf(out + offset, "/flags_weight=%u", p_pb_qos_queue_shape_profile->flags_weight);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_PORT_SHAPE_PROFILE */
int32
pb_tbl_qos_port_shape_profile_to_pb(uint32 only_key, tbl_qos_port_shape_profile_t *p_qos_port_shape_profile, Cdb__TblQosPortShapeProfile *p_pb_qos_port_shape_profile)
{
    p_pb_qos_port_shape_profile->key->id = p_qos_port_shape_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_qos_port_shape_profile->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_qos_port_shape_profile->name)+1);
    sal_strcpy(p_pb_qos_port_shape_profile->name, p_qos_port_shape_profile->name);
    p_pb_qos_port_shape_profile->has_pir = TRUE;
    p_pb_qos_port_shape_profile->pir = p_qos_port_shape_profile->pir;
    p_pb_qos_port_shape_profile->has_ref_cnt = TRUE;
    p_pb_qos_port_shape_profile->ref_cnt = p_qos_port_shape_profile->ref_cnt;
    p_pb_qos_port_shape_profile->has_flags_pir = TRUE;
    p_pb_qos_port_shape_profile->flags_pir = GLB_FLAG_ISSET(p_qos_port_shape_profile->flags, GLB_PORT_SHAPE_PROFILE_FLAGS_PIR) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_qos_port_shape_profile_to_pb_free_packed(Cdb__TblQosPortShapeProfile *p_pb_qos_port_shape_profile)
{
    if (p_pb_qos_port_shape_profile->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_qos_port_shape_profile->name);
        p_pb_qos_port_shape_profile->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_qos_port_shape_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosPortShapeProfileKey pb_qos_port_shape_profile_key = CDB__TBL_QOS_PORT_SHAPE_PROFILE_KEY__INIT;
    Cdb__TblQosPortShapeProfile pb_qos_port_shape_profile = CDB__TBL_QOS_PORT_SHAPE_PROFILE__INIT;
    tbl_qos_port_shape_profile_t *p_qos_port_shape_profile = (tbl_qos_port_shape_profile_t*)p_tbl;
    int32 len = 0;

    pb_qos_port_shape_profile.key = &pb_qos_port_shape_profile_key;
    pb_tbl_qos_port_shape_profile_to_pb(only_key, p_qos_port_shape_profile, &pb_qos_port_shape_profile);
    len = cdb__tbl_qos_port_shape_profile__pack(&pb_qos_port_shape_profile, buf);
    pb_tbl_qos_port_shape_profile_to_pb_free_packed(&pb_qos_port_shape_profile);

    return len;
}

int32
pb_tbl_qos_port_shape_profile_dump(Cdb__TblQosPortShapeProfile *p_pb_qos_port_shape_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_qos_port_shape_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_qos_port_shape_profile->name);
    offset += sal_sprintf(out + offset, "/pir=%u", p_pb_qos_port_shape_profile->pir);
    offset += sal_sprintf(out + offset, "/ref_cnt=%u", p_pb_qos_port_shape_profile->ref_cnt);
    offset += sal_sprintf(out + offset, "/flags_pir=%u", p_pb_qos_port_shape_profile->flags_pir);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_QOS_GLOBAL */
int32
pb_tbl_qos_global_to_pb(uint32 only_key, tbl_qos_global_t *p_qos_glb, Cdb__TblQosGlobal *p_pb_qos_glb)
{
    p_pb_qos_glb->has_qos_enable = TRUE;
    p_pb_qos_glb->qos_enable = p_qos_glb->qos_enable;
    p_pb_qos_glb->has_phb_enable = TRUE;
    p_pb_qos_glb->phb_enable = p_qos_glb->phb_enable;
    p_pb_qos_glb->has_port_policer_first_enable = TRUE;
    p_pb_qos_glb->port_policer_first_enable = p_qos_glb->port_policer_first_enable;
    p_pb_qos_glb->has_policer_stats_enable = TRUE;
    p_pb_qos_glb->policer_stats_enable = p_qos_glb->policer_stats_enable;
    p_pb_qos_glb->has_cur_cpu_rate = TRUE;
    p_pb_qos_glb->cur_cpu_rate = p_qos_glb->cur_cpu_rate;
    p_pb_qos_glb->has_def_cpu_rate = TRUE;
    p_pb_qos_glb->def_cpu_rate = p_qos_glb->def_cpu_rate;

    return PM_E_NONE;
}

int32
pb_tbl_qos_global_to_pb_free_packed(Cdb__TblQosGlobal *p_pb_qos_glb)
{
    return PM_E_NONE;
}

int32
pb_tbl_qos_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblQosGlobal pb_qos_glb = CDB__TBL_QOS_GLOBAL__INIT;
    tbl_qos_global_t *p_qos_glb = (tbl_qos_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_qos_global_to_pb(only_key, p_qos_glb, &pb_qos_glb);
    len = cdb__tbl_qos_global__pack(&pb_qos_glb, buf);
    pb_tbl_qos_global_to_pb_free_packed(&pb_qos_glb);

    return len;
}

int32
pb_tbl_qos_global_dump(Cdb__TblQosGlobal *p_pb_qos_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/qos_enable=%u", p_pb_qos_glb->qos_enable);
    offset += sal_sprintf(out + offset, "/phb_enable=%u", p_pb_qos_glb->phb_enable);
    offset += sal_sprintf(out + offset, "/port_policer_first_enable=%u", p_pb_qos_glb->port_policer_first_enable);
    offset += sal_sprintf(out + offset, "/policer_stats_enable=%u", p_pb_qos_glb->policer_stats_enable);
    offset += sal_sprintf(out + offset, "/cur_cpu_rate=%u", p_pb_qos_glb->cur_cpu_rate);
    offset += sal_sprintf(out + offset, "/def_cpu_rate=%u", p_pb_qos_glb->def_cpu_rate);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MIRROR */
int32
pb_tbl_mirror_to_pb(uint32 only_key, tbl_mirror_t *p_mirror, Cdb__TblMirror *p_pb_mirror)
{
    p_pb_mirror->key->id = p_mirror->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_mirror->has_source_igs_port_bmp = TRUE;
    p_pb_mirror->source_igs_port_bmp.len = sizeof(p_mirror->source_igs_port_bmp);
    p_pb_mirror->source_igs_port_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mirror->source_igs_port_bmp));
    sal_memcpy(p_pb_mirror->source_igs_port_bmp.data, p_mirror->source_igs_port_bmp, sizeof(p_mirror->source_igs_port_bmp));
    p_pb_mirror->has_source_egs_port_bmp = TRUE;
    p_pb_mirror->source_egs_port_bmp.len = sizeof(p_mirror->source_egs_port_bmp);
    p_pb_mirror->source_egs_port_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mirror->source_egs_port_bmp));
    sal_memcpy(p_pb_mirror->source_egs_port_bmp.data, p_mirror->source_egs_port_bmp, sizeof(p_mirror->source_egs_port_bmp));
    p_pb_mirror->has_source_igs_vlan_bmp = TRUE;
    p_pb_mirror->source_igs_vlan_bmp.len = sizeof(p_mirror->source_igs_vlan_bmp);
    p_pb_mirror->source_igs_vlan_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mirror->source_igs_vlan_bmp));
    sal_memcpy(p_pb_mirror->source_igs_vlan_bmp.data, p_mirror->source_igs_vlan_bmp, sizeof(p_mirror->source_igs_vlan_bmp));
    p_pb_mirror->has_source_egs_vlan_bmp = TRUE;
    p_pb_mirror->source_egs_vlan_bmp.len = sizeof(p_mirror->source_egs_vlan_bmp);
    p_pb_mirror->source_egs_vlan_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mirror->source_egs_vlan_bmp));
    sal_memcpy(p_pb_mirror->source_egs_vlan_bmp.data, p_mirror->source_egs_vlan_bmp, sizeof(p_mirror->source_egs_vlan_bmp));
    p_pb_mirror->has_dest_type = TRUE;
    p_pb_mirror->dest_type = p_mirror->dest_type;
    p_pb_mirror->has_dest_port_bmp = TRUE;
    p_pb_mirror->dest_port_bmp.len = sizeof(p_mirror->dest_port_bmp);
    p_pb_mirror->dest_port_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_mirror->dest_port_bmp));
    sal_memcpy(p_pb_mirror->dest_port_bmp.data, p_mirror->dest_port_bmp, sizeof(p_mirror->dest_port_bmp));
    p_pb_mirror->has_dest_port = TRUE;
    p_pb_mirror->dest_port = p_mirror->dest_port;
    p_pb_mirror->has_dest_group = TRUE;
    p_pb_mirror->dest_group = p_mirror->dest_group;
    p_pb_mirror->has_dest_vlan = TRUE;
    p_pb_mirror->dest_vlan = p_mirror->dest_vlan;

    return PM_E_NONE;
}

int32
pb_tbl_mirror_to_pb_free_packed(Cdb__TblMirror *p_pb_mirror)
{
    if (p_pb_mirror->source_igs_port_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mirror->source_igs_port_bmp.data);
        p_pb_mirror->source_igs_port_bmp.data = NULL;
    }

    if (p_pb_mirror->source_egs_port_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mirror->source_egs_port_bmp.data);
        p_pb_mirror->source_egs_port_bmp.data = NULL;
    }

    if (p_pb_mirror->source_igs_vlan_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mirror->source_igs_vlan_bmp.data);
        p_pb_mirror->source_igs_vlan_bmp.data = NULL;
    }

    if (p_pb_mirror->source_egs_vlan_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mirror->source_egs_vlan_bmp.data);
        p_pb_mirror->source_egs_vlan_bmp.data = NULL;
    }

    if (p_pb_mirror->dest_port_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mirror->dest_port_bmp.data);
        p_pb_mirror->dest_port_bmp.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_mirror_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMirrorKey pb_mirror_key = CDB__TBL_MIRROR_KEY__INIT;
    Cdb__TblMirror pb_mirror = CDB__TBL_MIRROR__INIT;
    tbl_mirror_t *p_mirror = (tbl_mirror_t*)p_tbl;
    int32 len = 0;

    pb_mirror.key = &pb_mirror_key;
    pb_tbl_mirror_to_pb(only_key, p_mirror, &pb_mirror);
    len = cdb__tbl_mirror__pack(&pb_mirror, buf);
    pb_tbl_mirror_to_pb_free_packed(&pb_mirror);

    return len;
}

int32
pb_tbl_mirror_dump(Cdb__TblMirror *p_pb_mirror, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_mirror->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/source_igs_port_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mirror->source_igs_port_bmp.data, p_pb_mirror->source_igs_port_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/source_egs_port_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mirror->source_egs_port_bmp.data, p_pb_mirror->source_egs_port_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/source_igs_vlan_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mirror->source_igs_vlan_bmp.data, p_pb_mirror->source_igs_vlan_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/source_egs_vlan_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mirror->source_egs_vlan_bmp.data, p_pb_mirror->source_egs_vlan_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/dest_type=%u", p_pb_mirror->dest_type);
    offset += sal_sprintf(out + offset, "/dest_port_bmp=");
    offset += pb_bitmap_array_dump(p_pb_mirror->dest_port_bmp.data, p_pb_mirror->dest_port_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/dest_port=%u", p_pb_mirror->dest_port);
    offset += sal_sprintf(out + offset, "/dest_group=%u", p_pb_mirror->dest_group);
    offset += sal_sprintf(out + offset, "/dest_vlan=%u", p_pb_mirror->dest_vlan);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MIRROR_MAC_ESCAPE */
int32
pb_tbl_mirror_mac_escape_to_pb(uint32 only_key, tbl_mirror_mac_escape_t *p_mirror_mac_escape, Cdb__TblMirrorMacEscape *p_pb_mirror_mac_escape)
{
    pb_compose_mirror_mac_escape_key_t_to_pb(&p_mirror_mac_escape->key, p_pb_mirror_mac_escape->key);

    if (only_key)
    {
        return PM_E_NONE;
    }


    return PM_E_NONE;
}

int32
pb_tbl_mirror_mac_escape_to_pb_free_packed(Cdb__TblMirrorMacEscape *p_pb_mirror_mac_escape)
{
    pb_compose_mirror_mac_escape_key_t_to_pb_free_packed(p_pb_mirror_mac_escape->key);
    return PM_E_NONE;
}

int32
pb_tbl_mirror_mac_escape_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblMirrorMacEscapeKey pb_mirror_mac_escape_key = CDB__TBL_MIRROR_MAC_ESCAPE_KEY__INIT;
    Cdb__TblMirrorMacEscape pb_mirror_mac_escape = CDB__TBL_MIRROR_MAC_ESCAPE__INIT;
    tbl_mirror_mac_escape_t *p_mirror_mac_escape = (tbl_mirror_mac_escape_t*)p_tbl;
    int32 len = 0;

    pb_mirror_mac_escape.key = &pb_mirror_mac_escape_key;
    pb_tbl_mirror_mac_escape_to_pb(only_key, p_mirror_mac_escape, &pb_mirror_mac_escape);
    len = cdb__tbl_mirror_mac_escape__pack(&pb_mirror_mac_escape, buf);
    pb_tbl_mirror_mac_escape_to_pb_free_packed(&pb_mirror_mac_escape);

    return len;
}

int32
pb_tbl_mirror_mac_escape_dump(Cdb__TblMirrorMacEscape *p_pb_mirror_mac_escape, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_mirror_mac_escape_key_t_dump(p_pb_mirror_mac_escape->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_TAP_GROUP_INGRESS */
int32
pb_tbl_tap_group_ingress_to_pb(uint32 only_key, tbl_tap_group_ingress_t *p_tap_group_ingress, Cdb__TblTapGroupIngress *p_pb_tap_group_ingress)
{
    pb_compose_tap_group_ingress_key_t_to_pb(&p_tap_group_ingress->key, p_pb_tap_group_ingress->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_tap_group_ingress->has_ing_mark_vlan_en = TRUE;
    p_pb_tap_group_ingress->ing_mark_vlan_en = p_tap_group_ingress->ing_mark_vlan_en;
    p_pb_tap_group_ingress->has_ing_mark_vlan_vid = TRUE;
    p_pb_tap_group_ingress->ing_mark_vlan_vid = p_tap_group_ingress->ing_mark_vlan_vid;
    p_pb_tap_group_ingress->has_ing_untag_en = TRUE;
    p_pb_tap_group_ingress->ing_untag_en = p_tap_group_ingress->ing_untag_en;
    p_pb_tap_group_ingress->has_ing_trunction_en = TRUE;
    p_pb_tap_group_ingress->ing_trunction_en = p_tap_group_ingress->ing_trunction_en;
    p_pb_tap_group_ingress->has_ing_tap_group_member_oid = TRUE;
    p_pb_tap_group_ingress->ing_tap_group_member_oid = p_tap_group_ingress->ing_tap_group_member_oid;
    p_pb_tap_group_ingress->has_ing_edit_dest_mac_en = TRUE;
    p_pb_tap_group_ingress->ing_edit_dest_mac_en = p_tap_group_ingress->ing_edit_dest_mac_en;
    pb_compose_mac_addr_t_to_pb(p_tap_group_ingress->ing_edit_dest_mac, p_pb_tap_group_ingress->ing_edit_dest_mac);
    p_pb_tap_group_ingress->has_ing_edit_src_mac_en = TRUE;
    p_pb_tap_group_ingress->ing_edit_src_mac_en = p_tap_group_ingress->ing_edit_src_mac_en;
    pb_compose_mac_addr_t_to_pb(p_tap_group_ingress->ing_edit_src_mac, p_pb_tap_group_ingress->ing_edit_src_mac);
    p_pb_tap_group_ingress->has_ing_edit_ipda_en = TRUE;
    p_pb_tap_group_ingress->ing_edit_ipda_en = p_tap_group_ingress->ing_edit_ipda_en;
    pb_compose_addr_t_to_pb(&p_tap_group_ingress->ing_edit_ipda, p_pb_tap_group_ingress->ing_edit_ipda);
    p_pb_tap_group_ingress->has_ing_edit_ipsa_en = TRUE;
    p_pb_tap_group_ingress->ing_edit_ipsa_en = p_tap_group_ingress->ing_edit_ipsa_en;
    pb_compose_addr_t_to_pb(&p_tap_group_ingress->ing_edit_ipsa, p_pb_tap_group_ingress->ing_edit_ipsa);

    return PM_E_NONE;
}

int32
pb_tbl_tap_group_ingress_to_pb_free_packed(Cdb__TblTapGroupIngress *p_pb_tap_group_ingress)
{
    pb_compose_tap_group_ingress_key_t_to_pb_free_packed(p_pb_tap_group_ingress->key);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_tap_group_ingress->ing_edit_dest_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_tap_group_ingress->ing_edit_src_mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_tap_group_ingress->ing_edit_ipda);
    pb_compose_addr_t_to_pb_free_packed(p_pb_tap_group_ingress->ing_edit_ipsa);
    return PM_E_NONE;
}

int32
pb_tbl_tap_group_ingress_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblTapGroupIngressKey pb_tap_group_ingress_key = CDB__TBL_TAP_GROUP_INGRESS_KEY__INIT;
    Cdb__TblTapGroupIngress pb_tap_group_ingress = CDB__TBL_TAP_GROUP_INGRESS__INIT;
    tbl_tap_group_ingress_t *p_tap_group_ingress = (tbl_tap_group_ingress_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT ing_edit_dest_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT ing_edit_src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT ing_edit_ipda = CDB__COMPOSE_ADDR_T__INIT;
    Cdb__ComposeAddrT ing_edit_ipsa = CDB__COMPOSE_ADDR_T__INIT;

    pb_tap_group_ingress.key = &pb_tap_group_ingress_key;
    pb_tap_group_ingress.ing_edit_dest_mac = &ing_edit_dest_mac;
    pb_tap_group_ingress.ing_edit_src_mac = &ing_edit_src_mac;
    pb_tap_group_ingress.ing_edit_ipda = &ing_edit_ipda;
    pb_tap_group_ingress.ing_edit_ipsa = &ing_edit_ipsa;
    pb_tbl_tap_group_ingress_to_pb(only_key, p_tap_group_ingress, &pb_tap_group_ingress);
    len = cdb__tbl_tap_group_ingress__pack(&pb_tap_group_ingress, buf);
    pb_tbl_tap_group_ingress_to_pb_free_packed(&pb_tap_group_ingress);

    return len;
}

int32
pb_tbl_tap_group_ingress_dump(Cdb__TblTapGroupIngress *p_pb_tap_group_ingress, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_tap_group_ingress_key_t_dump(p_pb_tap_group_ingress->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ing_mark_vlan_en=%u", p_pb_tap_group_ingress->ing_mark_vlan_en);
    offset += sal_sprintf(out + offset, "/ing_mark_vlan_vid=%u", p_pb_tap_group_ingress->ing_mark_vlan_vid);
    offset += sal_sprintf(out + offset, "/ing_untag_en=%u", p_pb_tap_group_ingress->ing_untag_en);
    offset += sal_sprintf(out + offset, "/ing_trunction_en=%u", p_pb_tap_group_ingress->ing_trunction_en);
    offset += sal_sprintf(out + offset, "/ing_tap_group_member_oid=%llu", p_pb_tap_group_ingress->ing_tap_group_member_oid);
    offset += sal_sprintf(out + offset, "/ing_edit_dest_mac_en=%u", p_pb_tap_group_ingress->ing_edit_dest_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_tap_group_ingress->ing_edit_dest_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/ing_edit_src_mac_en=%u", p_pb_tap_group_ingress->ing_edit_src_mac_en);
    offset += pb_compose_mac_addr_t_dump(p_pb_tap_group_ingress->ing_edit_src_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/ing_edit_ipda_en=%u", p_pb_tap_group_ingress->ing_edit_ipda_en);
    offset += pb_compose_addr_t_dump(p_pb_tap_group_ingress->ing_edit_ipda, (out + offset));
    offset += sal_sprintf(out + offset, "/ing_edit_ipsa_en=%u", p_pb_tap_group_ingress->ing_edit_ipsa_en);
    offset += pb_compose_addr_t_dump(p_pb_tap_group_ingress->ing_edit_ipsa, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_TAP_GROUP_INGRESS_FLOW */
int32
pb_tbl_tap_group_ingress_flow_to_pb(uint32 only_key, tbl_tap_group_ingress_flow_t *p_tap_group_ingress_flow, Cdb__TblTapGroupIngressFlow *p_pb_tap_group_ingress_flow)
{
    pb_compose_tap_group_ingress_flow_key_t_to_pb(&p_tap_group_ingress_flow->key, p_pb_tap_group_ingress_flow->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_tap_group_ingress_flow->has_tap_grp_id = TRUE;
    p_pb_tap_group_ingress_flow->tap_grp_id = p_tap_group_ingress_flow->tap_grp_id;
    p_pb_tap_group_ingress_flow->has_if_idx = TRUE;
    p_pb_tap_group_ingress_flow->if_idx = p_tap_group_ingress_flow->if_idx;
    p_pb_tap_group_ingress_flow->has_ing_untag_en = TRUE;
    p_pb_tap_group_ingress_flow->ing_untag_en = p_tap_group_ingress_flow->ing_untag_en;
    p_pb_tap_group_ingress_flow->has_ing_mark_vlan_en = TRUE;
    p_pb_tap_group_ingress_flow->ing_mark_vlan_en = p_tap_group_ingress_flow->ing_mark_vlan_en;
    p_pb_tap_group_ingress_flow->has_ing_mark_vlan_vid = TRUE;
    p_pb_tap_group_ingress_flow->ing_mark_vlan_vid = p_tap_group_ingress_flow->ing_mark_vlan_vid;
    p_pb_tap_group_ingress_flow->has_ing_tap_group_member_oid = TRUE;
    p_pb_tap_group_ingress_flow->ing_tap_group_member_oid = p_tap_group_ingress_flow->ing_tap_group_member_oid;

    return PM_E_NONE;
}

int32
pb_tbl_tap_group_ingress_flow_to_pb_free_packed(Cdb__TblTapGroupIngressFlow *p_pb_tap_group_ingress_flow)
{
    pb_compose_tap_group_ingress_flow_key_t_to_pb_free_packed(p_pb_tap_group_ingress_flow->key);
    return PM_E_NONE;
}

int32
pb_tbl_tap_group_ingress_flow_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblTapGroupIngressFlowKey pb_tap_group_ingress_flow_key = CDB__TBL_TAP_GROUP_INGRESS_FLOW_KEY__INIT;
    Cdb__TblTapGroupIngressFlow pb_tap_group_ingress_flow = CDB__TBL_TAP_GROUP_INGRESS_FLOW__INIT;
    tbl_tap_group_ingress_flow_t *p_tap_group_ingress_flow = (tbl_tap_group_ingress_flow_t*)p_tbl;
    int32 len = 0;

    pb_tap_group_ingress_flow.key = &pb_tap_group_ingress_flow_key;
    pb_tbl_tap_group_ingress_flow_to_pb(only_key, p_tap_group_ingress_flow, &pb_tap_group_ingress_flow);
    len = cdb__tbl_tap_group_ingress_flow__pack(&pb_tap_group_ingress_flow, buf);
    pb_tbl_tap_group_ingress_flow_to_pb_free_packed(&pb_tap_group_ingress_flow);

    return len;
}

int32
pb_tbl_tap_group_ingress_flow_dump(Cdb__TblTapGroupIngressFlow *p_pb_tap_group_ingress_flow, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_tap_group_ingress_flow_key_t_dump(p_pb_tap_group_ingress_flow->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/tap_grp_id=%u", p_pb_tap_group_ingress_flow->tap_grp_id);
    offset += sal_sprintf(out + offset, "/if_idx=%u", p_pb_tap_group_ingress_flow->if_idx);
    offset += sal_sprintf(out + offset, "/ing_untag_en=%u", p_pb_tap_group_ingress_flow->ing_untag_en);
    offset += sal_sprintf(out + offset, "/ing_mark_vlan_en=%u", p_pb_tap_group_ingress_flow->ing_mark_vlan_en);
    offset += sal_sprintf(out + offset, "/ing_mark_vlan_vid=%u", p_pb_tap_group_ingress_flow->ing_mark_vlan_vid);
    offset += sal_sprintf(out + offset, "/ing_tap_group_member_oid=%llu", p_pb_tap_group_ingress_flow->ing_tap_group_member_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_TAP_GROUP_EGRESS */
int32
pb_tbl_tap_group_egress_to_pb(uint32 only_key, tbl_tap_group_egress_t *p_tap_group_egress, Cdb__TblTapGroupEgress *p_pb_tap_group_egress)
{
    pb_compose_tap_group_egress_key_t_to_pb(&p_tap_group_egress->key, p_pb_tap_group_egress->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_tap_group_egress->has_timestamp_en = TRUE;
    p_pb_tap_group_egress->timestamp_en = p_tap_group_egress->timestamp_en;
    p_pb_tap_group_egress->has_tap_group_member_oid = TRUE;
    p_pb_tap_group_egress->tap_group_member_oid = p_tap_group_egress->tap_group_member_oid;

    return PM_E_NONE;
}

int32
pb_tbl_tap_group_egress_to_pb_free_packed(Cdb__TblTapGroupEgress *p_pb_tap_group_egress)
{
    pb_compose_tap_group_egress_key_t_to_pb_free_packed(p_pb_tap_group_egress->key);
    return PM_E_NONE;
}

int32
pb_tbl_tap_group_egress_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblTapGroupEgressKey pb_tap_group_egress_key = CDB__TBL_TAP_GROUP_EGRESS_KEY__INIT;
    Cdb__TblTapGroupEgress pb_tap_group_egress = CDB__TBL_TAP_GROUP_EGRESS__INIT;
    tbl_tap_group_egress_t *p_tap_group_egress = (tbl_tap_group_egress_t*)p_tbl;
    int32 len = 0;

    pb_tap_group_egress.key = &pb_tap_group_egress_key;
    pb_tbl_tap_group_egress_to_pb(only_key, p_tap_group_egress, &pb_tap_group_egress);
    len = cdb__tbl_tap_group_egress__pack(&pb_tap_group_egress, buf);
    pb_tbl_tap_group_egress_to_pb_free_packed(&pb_tap_group_egress);

    return len;
}

int32
pb_tbl_tap_group_egress_dump(Cdb__TblTapGroupEgress *p_pb_tap_group_egress, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_tap_group_egress_key_t_dump(p_pb_tap_group_egress->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/timestamp_en=%u", p_pb_tap_group_egress->timestamp_en);
    offset += sal_sprintf(out + offset, "/tap_group_member_oid=%llu", p_pb_tap_group_egress->tap_group_member_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_TAP_GROUP */
int32
pb_tbl_tap_group_to_pb(uint32 only_key, tbl_tap_group_t *p_tap_group, Cdb__TblTapGroup *p_pb_tap_group)
{
    p_pb_tap_group->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tap_group->key.name)+1);
    sal_strcpy(p_pb_tap_group->key->name, p_tap_group->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_tap_group->has_id = TRUE;
    p_pb_tap_group->id = p_tap_group->id;
    p_pb_tap_group->has_flags = TRUE;
    p_pb_tap_group->flags = p_tap_group->flags;
    p_pb_tap_group->desc = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tap_group->desc)+1);
    sal_strcpy(p_pb_tap_group->desc, p_tap_group->desc);
    p_pb_tap_group->has_truncation_use = TRUE;
    p_pb_tap_group->truncation_use = p_tap_group->truncation_use;
    p_pb_tap_group->has_tap_group_oid = TRUE;
    p_pb_tap_group->tap_group_oid = p_tap_group->tap_group_oid;

    return PM_E_NONE;
}

int32
pb_tbl_tap_group_to_pb_free_packed(Cdb__TblTapGroup *p_pb_tap_group)
{
    if (p_pb_tap_group->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tap_group->key->name);
        p_pb_tap_group->key->name = NULL;
    }

    if (p_pb_tap_group->desc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tap_group->desc);
        p_pb_tap_group->desc = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_tap_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblTapGroupKey pb_tap_group_key = CDB__TBL_TAP_GROUP_KEY__INIT;
    Cdb__TblTapGroup pb_tap_group = CDB__TBL_TAP_GROUP__INIT;
    tbl_tap_group_t *p_tap_group = (tbl_tap_group_t*)p_tbl;
    int32 len = 0;

    pb_tap_group.key = &pb_tap_group_key;
    pb_tbl_tap_group_to_pb(only_key, p_tap_group, &pb_tap_group);
    len = cdb__tbl_tap_group__pack(&pb_tap_group, buf);
    pb_tbl_tap_group_to_pb_free_packed(&pb_tap_group);

    return len;
}

int32
pb_tbl_tap_group_dump(Cdb__TblTapGroup *p_pb_tap_group, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_tap_group->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/id=%u", p_pb_tap_group->id);
    offset += sal_sprintf(out + offset, "/flags=%u", p_pb_tap_group->flags);
    offset += sal_sprintf(out + offset, "/desc=%s", p_pb_tap_group->desc);
    offset += sal_sprintf(out + offset, "/truncation_use=%u", p_pb_tap_group->truncation_use);
    offset += sal_sprintf(out + offset, "/tap_group_oid=%llu", p_pb_tap_group->tap_group_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_USER */
int32
pb_tbl_user_to_pb(uint32 only_key, tbl_user_t *p_user, Cdb__TblUser *p_pb_user)
{
    p_pb_user->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_user->key.name)+1);
    sal_strcpy(p_pb_user->key->name, p_user->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_user->has_uid = TRUE;
    p_pb_user->uid = p_user->uid;
    p_pb_user->has_privilege = TRUE;
    p_pb_user->privilege = p_user->privilege;
    p_pb_user->enc_passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_user->enc_passwd)+1);
    sal_strcpy(p_pb_user->enc_passwd, p_user->enc_passwd);
    p_pb_user->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_user->passwd)+1);
    sal_strcpy(p_pb_user->passwd, p_user->passwd);
    p_pb_user->rsakey = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_user->rsakey)+1);
    sal_strcpy(p_pb_user->rsakey, p_user->rsakey);

    return PM_E_NONE;
}

int32
pb_tbl_user_to_pb_free_packed(Cdb__TblUser *p_pb_user)
{
    if (p_pb_user->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_user->key->name);
        p_pb_user->key->name = NULL;
    }

    if (p_pb_user->enc_passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_user->enc_passwd);
        p_pb_user->enc_passwd = NULL;
    }

    if (p_pb_user->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_user->passwd);
        p_pb_user->passwd = NULL;
    }

    if (p_pb_user->rsakey)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_user->rsakey);
        p_pb_user->rsakey = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_user_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblUserKey pb_user_key = CDB__TBL_USER_KEY__INIT;
    Cdb__TblUser pb_user = CDB__TBL_USER__INIT;
    tbl_user_t *p_user = (tbl_user_t*)p_tbl;
    int32 len = 0;

    pb_user.key = &pb_user_key;
    pb_tbl_user_to_pb(only_key, p_user, &pb_user);
    len = cdb__tbl_user__pack(&pb_user, buf);
    pb_tbl_user_to_pb_free_packed(&pb_user);

    return len;
}

int32
pb_tbl_user_dump(Cdb__TblUser *p_pb_user, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_user->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/uid=%u", p_pb_user->uid);
    offset += sal_sprintf(out + offset, "/privilege=%u", p_pb_user->privilege);
    offset += sal_sprintf(out + offset, "/enc_passwd=%s", p_pb_user->enc_passwd);
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_user->passwd);
    offset += sal_sprintf(out + offset, "/rsakey=%s", p_pb_user->rsakey);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_VTY */
int32
pb_tbl_vty_to_pb(uint32 only_key, tbl_vty_t *p_vty, Cdb__TblVty *p_pb_vty)
{
    p_pb_vty->key->id = p_vty->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_vty->has_timeout_min = TRUE;
    p_pb_vty->timeout_min = p_vty->timeout_min;
    p_pb_vty->has_timeout_sec = TRUE;
    p_pb_vty->timeout_sec = p_vty->timeout_sec;
    p_pb_vty->protocol = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->protocol)+1);
    sal_strcpy(p_pb_vty->protocol, p_vty->protocol);
    p_pb_vty->has_login = TRUE;
    p_pb_vty->login = p_vty->login;
    p_pb_vty->has_privilege = TRUE;
    p_pb_vty->privilege = p_vty->privilege;
    p_pb_vty->enc_passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->enc_passwd)+1);
    sal_strcpy(p_pb_vty->enc_passwd, p_vty->enc_passwd);
    p_pb_vty->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->passwd)+1);
    sal_strcpy(p_pb_vty->passwd, p_vty->passwd);
    p_pb_vty->auth_method = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->auth_method)+1);
    sal_strcpy(p_pb_vty->auth_method, p_vty->auth_method);
    p_pb_vty->has_inuse = TRUE;
    p_pb_vty->inuse = p_vty->inuse;
    p_pb_vty->author_method = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->author_method)+1);
    sal_strcpy(p_pb_vty->author_method, p_vty->author_method);
    p_pb_vty->account_method = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->account_method)+1);
    sal_strcpy(p_pb_vty->account_method, p_vty->account_method);
    p_pb_vty->accountcmd_method = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->accountcmd_method)+1);
    sal_strcpy(p_pb_vty->accountcmd_method, p_vty->accountcmd_method);
    p_pb_vty->has_aaa_privilege = TRUE;
    p_pb_vty->aaa_privilege = p_vty->aaa_privilege;
    p_pb_vty->has_config_privilege = TRUE;
    p_pb_vty->config_privilege = p_vty->config_privilege;
    p_pb_vty->has_aaa_start_time = TRUE;
    p_pb_vty->aaa_start_time = p_vty->aaa_start_time;
    p_pb_vty->has_cmd_buf = TRUE;
    p_pb_vty->cmd_buf.len = sizeof(p_vty->cmd_buf);
    p_pb_vty->cmd_buf.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_vty->cmd_buf));
    sal_memcpy(p_pb_vty->cmd_buf.data, p_vty->cmd_buf, sizeof(p_vty->cmd_buf));
    p_pb_vty->has_old_cmd_buf = TRUE;
    p_pb_vty->old_cmd_buf.len = sizeof(p_vty->old_cmd_buf);
    p_pb_vty->old_cmd_buf.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_vty->old_cmd_buf));
    sal_memcpy(p_pb_vty->old_cmd_buf.data, p_vty->old_cmd_buf, sizeof(p_vty->old_cmd_buf));
    p_pb_vty->acct_stop_ipaddr = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_vty->acct_stop_ipaddr)+1);
    sal_strcpy(p_pb_vty->acct_stop_ipaddr, p_vty->acct_stop_ipaddr);
    p_pb_vty->has_acct_stop_pid = TRUE;
    p_pb_vty->acct_stop_pid = p_vty->acct_stop_pid;
    p_pb_vty->has_acct_stop_privilege = TRUE;
    p_pb_vty->acct_stop_privilege = p_vty->acct_stop_privilege;
    p_pb_vty->has_is_not_ssh_key = TRUE;
    p_pb_vty->is_not_ssh_key = p_vty->is_not_ssh_key;

    return PM_E_NONE;
}

int32
pb_tbl_vty_to_pb_free_packed(Cdb__TblVty *p_pb_vty)
{
    if (p_pb_vty->protocol)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->protocol);
        p_pb_vty->protocol = NULL;
    }

    if (p_pb_vty->enc_passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->enc_passwd);
        p_pb_vty->enc_passwd = NULL;
    }

    if (p_pb_vty->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->passwd);
        p_pb_vty->passwd = NULL;
    }

    if (p_pb_vty->auth_method)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->auth_method);
        p_pb_vty->auth_method = NULL;
    }

    if (p_pb_vty->author_method)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->author_method);
        p_pb_vty->author_method = NULL;
    }

    if (p_pb_vty->account_method)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->account_method);
        p_pb_vty->account_method = NULL;
    }

    if (p_pb_vty->accountcmd_method)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->accountcmd_method);
        p_pb_vty->accountcmd_method = NULL;
    }

    if (p_pb_vty->cmd_buf.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->cmd_buf.data);
        p_pb_vty->cmd_buf.data = NULL;
    }

    if (p_pb_vty->old_cmd_buf.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->old_cmd_buf.data);
        p_pb_vty->old_cmd_buf.data = NULL;
    }

    if (p_pb_vty->acct_stop_ipaddr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vty->acct_stop_ipaddr);
        p_pb_vty->acct_stop_ipaddr = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_vty_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblVtyKey pb_vty_key = CDB__TBL_VTY_KEY__INIT;
    Cdb__TblVty pb_vty = CDB__TBL_VTY__INIT;
    tbl_vty_t *p_vty = (tbl_vty_t*)p_tbl;
    int32 len = 0;

    pb_vty.key = &pb_vty_key;
    pb_tbl_vty_to_pb(only_key, p_vty, &pb_vty);
    len = cdb__tbl_vty__pack(&pb_vty, buf);
    pb_tbl_vty_to_pb_free_packed(&pb_vty);

    return len;
}

int32
pb_tbl_vty_dump(Cdb__TblVty *p_pb_vty, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_vty->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/timeout_min=%u", p_pb_vty->timeout_min);
    offset += sal_sprintf(out + offset, "/timeout_sec=%u", p_pb_vty->timeout_sec);
    offset += sal_sprintf(out + offset, "/protocol=%s", p_pb_vty->protocol);
    offset += sal_sprintf(out + offset, "/login=%u", p_pb_vty->login);
    offset += sal_sprintf(out + offset, "/privilege=%u", p_pb_vty->privilege);
    offset += sal_sprintf(out + offset, "/enc_passwd=%s", p_pb_vty->enc_passwd);
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_vty->passwd);
    offset += sal_sprintf(out + offset, "/auth_method=%s", p_pb_vty->auth_method);
    offset += sal_sprintf(out + offset, "/inuse=%u", p_pb_vty->inuse);
    offset += sal_sprintf(out + offset, "/author_method=%s", p_pb_vty->author_method);
    offset += sal_sprintf(out + offset, "/account_method=%s", p_pb_vty->account_method);
    offset += sal_sprintf(out + offset, "/accountcmd_method=%s", p_pb_vty->accountcmd_method);
    offset += sal_sprintf(out + offset, "/aaa_privilege=%u", p_pb_vty->aaa_privilege);
    offset += sal_sprintf(out + offset, "/config_privilege=%u", p_pb_vty->config_privilege);
    offset += sal_sprintf(out + offset, "/aaa_start_time=%u", p_pb_vty->aaa_start_time);
    offset += sal_sprintf(out + offset, "/cmd_buf=");
    offset += pb_uint8_array_dump(p_pb_vty->cmd_buf.data, p_pb_vty->cmd_buf.len, (out + offset));
    offset += sal_sprintf(out + offset, "/old_cmd_buf=");
    offset += pb_uint8_array_dump(p_pb_vty->old_cmd_buf.data, p_pb_vty->old_cmd_buf.len, (out + offset));
    offset += sal_sprintf(out + offset, "/acct_stop_ipaddr=%s", p_pb_vty->acct_stop_ipaddr);
    offset += sal_sprintf(out + offset, "/acct_stop_pid=%u", p_pb_vty->acct_stop_pid);
    offset += sal_sprintf(out + offset, "/acct_stop_privilege=%u", p_pb_vty->acct_stop_privilege);
    offset += sal_sprintf(out + offset, "/is_not_ssh_key=%u", p_pb_vty->is_not_ssh_key);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CONSOLE */
int32
pb_tbl_console_to_pb(uint32 only_key, tbl_console_t *p_console, Cdb__TblConsole *p_pb_console)
{
    p_pb_console->has_timeout_min = TRUE;
    p_pb_console->timeout_min = p_console->timeout_min;
    p_pb_console->has_timeout_sec = TRUE;
    p_pb_console->timeout_sec = p_console->timeout_sec;
    p_pb_console->has_login = TRUE;
    p_pb_console->login = p_console->login;
    p_pb_console->has_privilege = TRUE;
    p_pb_console->privilege = p_console->privilege;
    p_pb_console->enc_passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_console->enc_passwd)+1);
    sal_strcpy(p_pb_console->enc_passwd, p_console->enc_passwd);
    p_pb_console->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_console->passwd)+1);
    sal_strcpy(p_pb_console->passwd, p_console->passwd);
    p_pb_console->auth_method = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_console->auth_method)+1);
    sal_strcpy(p_pb_console->auth_method, p_console->auth_method);
    p_pb_console->has_stopbits = TRUE;
    p_pb_console->stopbits = p_console->stopbits;
    p_pb_console->has_parity = TRUE;
    p_pb_console->parity = p_console->parity;
    p_pb_console->has_databits = TRUE;
    p_pb_console->databits = p_console->databits;
    p_pb_console->has_baudrate = TRUE;
    p_pb_console->baudrate = p_console->baudrate;
    p_pb_console->has_inuse = TRUE;
    p_pb_console->inuse = p_console->inuse;

    return PM_E_NONE;
}

int32
pb_tbl_console_to_pb_free_packed(Cdb__TblConsole *p_pb_console)
{
    if (p_pb_console->enc_passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_console->enc_passwd);
        p_pb_console->enc_passwd = NULL;
    }

    if (p_pb_console->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_console->passwd);
        p_pb_console->passwd = NULL;
    }

    if (p_pb_console->auth_method)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_console->auth_method);
        p_pb_console->auth_method = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_console_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblConsole pb_console = CDB__TBL_CONSOLE__INIT;
    tbl_console_t *p_console = (tbl_console_t*)p_tbl;
    int32 len = 0;

    pb_tbl_console_to_pb(only_key, p_console, &pb_console);
    len = cdb__tbl_console__pack(&pb_console, buf);
    pb_tbl_console_to_pb_free_packed(&pb_console);

    return len;
}

int32
pb_tbl_console_dump(Cdb__TblConsole *p_pb_console, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/timeout_min=%u", p_pb_console->timeout_min);
    offset += sal_sprintf(out + offset, "/timeout_sec=%u", p_pb_console->timeout_sec);
    offset += sal_sprintf(out + offset, "/login=%u", p_pb_console->login);
    offset += sal_sprintf(out + offset, "/privilege=%u", p_pb_console->privilege);
    offset += sal_sprintf(out + offset, "/enc_passwd=%s", p_pb_console->enc_passwd);
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_console->passwd);
    offset += sal_sprintf(out + offset, "/auth_method=%s", p_pb_console->auth_method);
    offset += sal_sprintf(out + offset, "/stopbits=%u", p_pb_console->stopbits);
    offset += sal_sprintf(out + offset, "/parity=%u", p_pb_console->parity);
    offset += sal_sprintf(out + offset, "/databits=%u", p_pb_console->databits);
    offset += sal_sprintf(out + offset, "/baudrate=%u", p_pb_console->baudrate);
    offset += sal_sprintf(out + offset, "/inuse=%u", p_pb_console->inuse);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTHEN */
int32
pb_tbl_authen_to_pb(uint32 only_key, tbl_authen_t *p_authen, Cdb__TblAuthen *p_pb_authen)
{
    p_pb_authen->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_authen->key.name)+1);
    sal_strcpy(p_pb_authen->key->name, p_authen->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_authen->methods = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_authen->methods)+1);
    sal_strcpy(p_pb_authen->methods, p_authen->methods);

    return PM_E_NONE;
}

int32
pb_tbl_authen_to_pb_free_packed(Cdb__TblAuthen *p_pb_authen)
{
    if (p_pb_authen->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_authen->key->name);
        p_pb_authen->key->name = NULL;
    }

    if (p_pb_authen->methods)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_authen->methods);
        p_pb_authen->methods = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_authen_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthenKey pb_authen_key = CDB__TBL_AUTHEN_KEY__INIT;
    Cdb__TblAuthen pb_authen = CDB__TBL_AUTHEN__INIT;
    tbl_authen_t *p_authen = (tbl_authen_t*)p_tbl;
    int32 len = 0;

    pb_authen.key = &pb_authen_key;
    pb_tbl_authen_to_pb(only_key, p_authen, &pb_authen);
    len = cdb__tbl_authen__pack(&pb_authen, buf);
    pb_tbl_authen_to_pb_free_packed(&pb_authen);

    return len;
}

int32
pb_tbl_authen_dump(Cdb__TblAuthen *p_pb_authen, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_authen->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/methods=%s", p_pb_authen->methods);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LOGIN */
int32
pb_tbl_login_to_pb(uint32 only_key, tbl_login_t *p_login, Cdb__TblLogin *p_pb_login)
{
    p_pb_login->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_login->key.name)+1);
    sal_strcpy(p_pb_login->key->name, p_login->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_user_t_to_pb(&p_login->user, p_pb_login->user);
    p_pb_login->vty = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_login->vty)+1);
    sal_strcpy(p_pb_login->vty, p_login->vty);
    p_pb_login->has_privilege = TRUE;
    p_pb_login->privilege = p_login->privilege;
    p_pb_login->ipaddr = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_login->ipaddr)+1);
    sal_strcpy(p_pb_login->ipaddr, p_login->ipaddr);
    p_pb_login->protocol = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_login->protocol)+1);
    sal_strcpy(p_pb_login->protocol, p_login->protocol);
    p_pb_login->has_expire_time = TRUE;
    p_pb_login->expire_time = p_login->expire_time;
    p_pb_login->has_pid = TRUE;
    p_pb_login->pid = p_login->pid;

    return PM_E_NONE;
}

int32
pb_tbl_login_to_pb_free_packed(Cdb__TblLogin *p_pb_login)
{
    if (p_pb_login->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_login->key->name);
        p_pb_login->key->name = NULL;
    }

    pb_compose_user_t_to_pb_free_packed(p_pb_login->user);
    if (p_pb_login->vty)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_login->vty);
        p_pb_login->vty = NULL;
    }

    if (p_pb_login->ipaddr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_login->ipaddr);
        p_pb_login->ipaddr = NULL;
    }

    if (p_pb_login->protocol)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_login->protocol);
        p_pb_login->protocol = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_login_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLoginKey pb_login_key = CDB__TBL_LOGIN_KEY__INIT;
    Cdb__TblLogin pb_login = CDB__TBL_LOGIN__INIT;
    tbl_login_t *p_login = (tbl_login_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeUserT user = CDB__COMPOSE_USER_T__INIT;

    pb_login.key = &pb_login_key;
    pb_login.user = &user;
    pb_tbl_login_to_pb(only_key, p_login, &pb_login);
    len = cdb__tbl_login__pack(&pb_login, buf);
    pb_tbl_login_to_pb_free_packed(&pb_login);

    return len;
}

int32
pb_tbl_login_dump(Cdb__TblLogin *p_pb_login, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_login->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_user_t_dump(p_pb_login->user, (out + offset));
    offset += sal_sprintf(out + offset, "/vty=%s", p_pb_login->vty);
    offset += sal_sprintf(out + offset, "/privilege=%u", p_pb_login->privilege);
    offset += sal_sprintf(out + offset, "/ipaddr=%s", p_pb_login->ipaddr);
    offset += sal_sprintf(out + offset, "/protocol=%s", p_pb_login->protocol);
    offset += sal_sprintf(out + offset, "/expire_time=%u", p_pb_login->expire_time);
    offset += sal_sprintf(out + offset, "/pid=%u", p_pb_login->pid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_RSA */
int32
pb_tbl_rsa_to_pb(uint32 only_key, tbl_rsa_t *p_rsa, Cdb__TblRsa *p_pb_rsa)
{
    p_pb_rsa->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rsa->key.name)+1);
    sal_strcpy(p_pb_rsa->key->name, p_rsa->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_rsa->has_type = TRUE;
    p_pb_rsa->type = p_rsa->type;
    p_pb_rsa->has_refcnt = TRUE;
    p_pb_rsa->refcnt = p_rsa->refcnt;
    pb_compose_rsa_keystr_t_to_pb(&p_rsa->pem, p_pb_rsa->pem);
    p_pb_rsa->enc_passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rsa->enc_passwd)+1);
    sal_strcpy(p_pb_rsa->enc_passwd, p_rsa->enc_passwd);
    p_pb_rsa->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rsa->passwd)+1);
    sal_strcpy(p_pb_rsa->passwd, p_rsa->passwd);

    return PM_E_NONE;
}

int32
pb_tbl_rsa_to_pb_free_packed(Cdb__TblRsa *p_pb_rsa)
{
    if (p_pb_rsa->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rsa->key->name);
        p_pb_rsa->key->name = NULL;
    }

    pb_compose_rsa_keystr_t_to_pb_free_packed(p_pb_rsa->pem);
    if (p_pb_rsa->enc_passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rsa->enc_passwd);
        p_pb_rsa->enc_passwd = NULL;
    }

    if (p_pb_rsa->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_rsa->passwd);
        p_pb_rsa->passwd = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_rsa_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRsaKey pb_rsa_key = CDB__TBL_RSA_KEY__INIT;
    Cdb__TblRsa pb_rsa = CDB__TBL_RSA__INIT;
    tbl_rsa_t *p_rsa = (tbl_rsa_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeRsaKeystrT pem = CDB__COMPOSE_RSA_KEYSTR_T__INIT;

    pb_rsa.key = &pb_rsa_key;
    pb_rsa.pem = &pem;
    pb_tbl_rsa_to_pb(only_key, p_rsa, &pb_rsa);
    len = cdb__tbl_rsa__pack(&pb_rsa, buf);
    pb_tbl_rsa_to_pb_free_packed(&pb_rsa);

    return len;
}

int32
pb_tbl_rsa_dump(Cdb__TblRsa *p_pb_rsa, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_rsa->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_rsa->type);
    offset += sal_sprintf(out + offset, "/refcnt=%u", p_pb_rsa->refcnt);
    offset += pb_compose_rsa_keystr_t_dump(p_pb_rsa->pem, (out + offset));
    offset += sal_sprintf(out + offset, "/enc_passwd=%s", p_pb_rsa->enc_passwd);
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_rsa->passwd);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPENFLOW */
int32
pb_tbl_openflow_to_pb(uint32 only_key, tbl_openflow_t *p_openflow, Cdb__TblOpenflow *p_pb_openflow)
{
    p_pb_openflow->has_group_hash_key = TRUE;
    p_pb_openflow->group_hash_key = p_openflow->group_hash_key;
    p_pb_openflow->has_bond_hash_key = TRUE;
    p_pb_openflow->bond_hash_key = p_openflow->bond_hash_key;
    p_pb_openflow->has_bond_hash_use = TRUE;
    p_pb_openflow->bond_hash_use = p_openflow->bond_hash_use;
    p_pb_openflow->has_lacp_local_proc = TRUE;
    p_pb_openflow->lacp_local_proc = p_openflow->lacp_local_proc;
    pb_compose_addr_ipv4_t_to_pb(&p_openflow->local_vtep_ip, p_pb_openflow->local_vtep_ip);
    p_pb_openflow->decap_mode = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_openflow->decap_mode)+1);
    sal_strcpy(p_pb_openflow->decap_mode, p_openflow->decap_mode);
    p_pb_openflow->has_flow_drop_pkt_to_ingress_port = TRUE;
    p_pb_openflow->flow_drop_pkt_to_ingress_port = p_openflow->flow_drop_pkt_to_ingress_port;
    p_pb_openflow->has_group_drop_pkt_to_ingress_port = TRUE;
    p_pb_openflow->group_drop_pkt_to_ingress_port = p_openflow->group_drop_pkt_to_ingress_port;
    p_pb_openflow->has_udf_parser = TRUE;
    p_pb_openflow->udf_parser = p_openflow->udf_parser;
    p_pb_openflow->has_meter_ipg = TRUE;
    p_pb_openflow->meter_ipg = p_openflow->meter_ipg;
    p_pb_openflow->has_inband_en = TRUE;
    p_pb_openflow->inband_en = p_openflow->inband_en;
    p_pb_openflow->has_ptp_e2e_en = TRUE;
    p_pb_openflow->ptp_e2e_en = p_openflow->ptp_e2e_en;
    p_pb_openflow->has_inband_stag = TRUE;
    p_pb_openflow->inband_stag = p_openflow->inband_stag;
    pb_compose_prefix_ipv4_t_to_pb(&p_openflow->inband_addr, p_pb_openflow->inband_addr);
    pb_compose_addr_ipv4_t_to_pb(&p_openflow->inband_gw, p_pb_openflow->inband_gw);
    p_pb_openflow->has_mpls_parser = TRUE;
    p_pb_openflow->mpls_parser = p_openflow->mpls_parser;
    p_pb_openflow->has_stpid = TRUE;
    p_pb_openflow->stpid = p_openflow->stpid;
    p_pb_openflow->has_ctpid = TRUE;
    p_pb_openflow->ctpid = p_openflow->ctpid;
    p_pb_openflow->has_inband_downlink_port_bmp = TRUE;
    p_pb_openflow->inband_downlink_port_bmp.len = sizeof(p_openflow->inband_downlink_port_bmp);
    p_pb_openflow->inband_downlink_port_bmp.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_openflow->inband_downlink_port_bmp));
    sal_memcpy(p_pb_openflow->inband_downlink_port_bmp.data, p_openflow->inband_downlink_port_bmp, sizeof(p_openflow->inband_downlink_port_bmp));
    p_pb_openflow->inband_uplink_port_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_openflow->inband_uplink_port_name)+1);
    sal_strcpy(p_pb_openflow->inband_uplink_port_name, p_openflow->inband_uplink_port_name);
    p_pb_openflow->has_flow_hash_key = TRUE;
    p_pb_openflow->flow_hash_key = p_openflow->flow_hash_key;
    p_pb_openflow->has_vxlan_hash_merge_en = TRUE;
    p_pb_openflow->vxlan_hash_merge_en = p_openflow->vxlan_hash_merge_en;
    p_pb_openflow->has_nvgre_hash_merge_en = TRUE;
    p_pb_openflow->nvgre_hash_merge_en = p_openflow->nvgre_hash_merge_en;
    p_pb_openflow->has_efd_tcp_only_enable = TRUE;
    p_pb_openflow->efd_tcp_only_enable = p_openflow->efd_tcp_only_enable;
    p_pb_openflow->has_efd_granularity = TRUE;
    p_pb_openflow->efd_granularity = p_openflow->efd_granularity;
    p_pb_openflow->has_efd_detect_speed = TRUE;
    p_pb_openflow->efd_detect_speed = p_openflow->efd_detect_speed;
    p_pb_openflow->has_efd_detect_time_interval = TRUE;
    p_pb_openflow->efd_detect_time_interval = p_openflow->efd_detect_time_interval;
    p_pb_openflow->has_efd_aging_timer = TRUE;
    p_pb_openflow->efd_aging_timer = p_openflow->efd_aging_timer;
    p_pb_openflow->has_efd_flow_traffic_class = TRUE;
    p_pb_openflow->efd_flow_traffic_class = p_openflow->efd_flow_traffic_class;
    p_pb_openflow->has_efd_flow_color = TRUE;
    p_pb_openflow->efd_flow_color = p_openflow->efd_flow_color;
    p_pb_openflow->has_efd_ipg_enable = TRUE;
    p_pb_openflow->efd_ipg_enable = p_openflow->efd_ipg_enable;

    return PM_E_NONE;
}

int32
pb_tbl_openflow_to_pb_free_packed(Cdb__TblOpenflow *p_pb_openflow)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_openflow->local_vtep_ip);
    if (p_pb_openflow->decap_mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_openflow->decap_mode);
        p_pb_openflow->decap_mode = NULL;
    }

    pb_compose_prefix_ipv4_t_to_pb_free_packed(p_pb_openflow->inband_addr);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_openflow->inband_gw);
    if (p_pb_openflow->inband_downlink_port_bmp.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_openflow->inband_downlink_port_bmp.data);
        p_pb_openflow->inband_downlink_port_bmp.data = NULL;
    }

    if (p_pb_openflow->inband_uplink_port_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_openflow->inband_uplink_port_name);
        p_pb_openflow->inband_uplink_port_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_openflow_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpenflow pb_openflow = CDB__TBL_OPENFLOW__INIT;
    tbl_openflow_t *p_openflow = (tbl_openflow_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T local_vtep_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposePrefixIpv4T inband_addr = CDB__COMPOSE_PREFIX_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T inband_gw = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_openflow.local_vtep_ip = &local_vtep_ip;
    pb_openflow.inband_addr = &inband_addr;
    pb_openflow.inband_gw = &inband_gw;
    pb_tbl_openflow_to_pb(only_key, p_openflow, &pb_openflow);
    len = cdb__tbl_openflow__pack(&pb_openflow, buf);
    pb_tbl_openflow_to_pb_free_packed(&pb_openflow);

    return len;
}

int32
pb_tbl_openflow_dump(Cdb__TblOpenflow *p_pb_openflow, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/group_hash_key=%u", p_pb_openflow->group_hash_key);
    offset += sal_sprintf(out + offset, "/bond_hash_key=%u", p_pb_openflow->bond_hash_key);
    offset += sal_sprintf(out + offset, "/bond_hash_use=%u", p_pb_openflow->bond_hash_use);
    offset += sal_sprintf(out + offset, "/lacp_local_proc=%u", p_pb_openflow->lacp_local_proc);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_openflow->local_vtep_ip, (out + offset));
    offset += sal_sprintf(out + offset, "/decap_mode=%s", p_pb_openflow->decap_mode);
    offset += sal_sprintf(out + offset, "/flow_drop_pkt_to_ingress_port=%u", p_pb_openflow->flow_drop_pkt_to_ingress_port);
    offset += sal_sprintf(out + offset, "/group_drop_pkt_to_ingress_port=%u", p_pb_openflow->group_drop_pkt_to_ingress_port);
    offset += sal_sprintf(out + offset, "/udf_parser=%u", p_pb_openflow->udf_parser);
    offset += sal_sprintf(out + offset, "/meter_ipg=%u", p_pb_openflow->meter_ipg);
    offset += sal_sprintf(out + offset, "/inband_en=%u", p_pb_openflow->inband_en);
    offset += sal_sprintf(out + offset, "/ptp_e2e_en=%u", p_pb_openflow->ptp_e2e_en);
    offset += sal_sprintf(out + offset, "/inband_stag=%u", p_pb_openflow->inband_stag);
    offset += pb_compose_prefix_ipv4_t_dump(p_pb_openflow->inband_addr, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_openflow->inband_gw, (out + offset));
    offset += sal_sprintf(out + offset, "/mpls_parser=%u", p_pb_openflow->mpls_parser);
    offset += sal_sprintf(out + offset, "/stpid=%d", p_pb_openflow->stpid);
    offset += sal_sprintf(out + offset, "/ctpid=%d", p_pb_openflow->ctpid);
    offset += sal_sprintf(out + offset, "/inband_downlink_port_bmp=");
    offset += pb_bitmap_array_dump(p_pb_openflow->inband_downlink_port_bmp.data, p_pb_openflow->inband_downlink_port_bmp.len, (out + offset));
    offset += sal_sprintf(out + offset, "/inband_uplink_port_name=%s", p_pb_openflow->inband_uplink_port_name);
    offset += sal_sprintf(out + offset, "/flow_hash_key=%u", p_pb_openflow->flow_hash_key);
    offset += sal_sprintf(out + offset, "/vxlan_hash_merge_en=%u", p_pb_openflow->vxlan_hash_merge_en);
    offset += sal_sprintf(out + offset, "/nvgre_hash_merge_en=%u", p_pb_openflow->nvgre_hash_merge_en);
    offset += sal_sprintf(out + offset, "/efd_tcp_only_enable=%u", p_pb_openflow->efd_tcp_only_enable);
    offset += sal_sprintf(out + offset, "/efd_granularity=%u", p_pb_openflow->efd_granularity);
    offset += sal_sprintf(out + offset, "/efd_detect_speed=%u", p_pb_openflow->efd_detect_speed);
    offset += sal_sprintf(out + offset, "/efd_detect_time_interval=%u", p_pb_openflow->efd_detect_time_interval);
    offset += sal_sprintf(out + offset, "/efd_aging_timer=%u", p_pb_openflow->efd_aging_timer);
    offset += sal_sprintf(out + offset, "/efd_flow_traffic_class=%u", p_pb_openflow->efd_flow_traffic_class);
    offset += sal_sprintf(out + offset, "/efd_flow_color=%u", p_pb_openflow->efd_flow_color);
    offset += sal_sprintf(out + offset, "/efd_ipg_enable=%u", p_pb_openflow->efd_ipg_enable);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CPU_TRAFFIC */
int32
pb_tbl_cpu_traffic_to_pb(uint32 only_key, tbl_cpu_traffic_t *p_cpu_traffic, Cdb__TblCpuTraffic *p_pb_cpu_traffic)
{
    p_pb_cpu_traffic->key->reason_id = p_cpu_traffic->key.reason_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cpu_traffic->has_rate = TRUE;
    p_pb_cpu_traffic->rate = p_cpu_traffic->rate;
    p_pb_cpu_traffic->has_class_id = TRUE;
    p_pb_cpu_traffic->class_id = p_cpu_traffic->class_id;

    return PM_E_NONE;
}

int32
pb_tbl_cpu_traffic_to_pb_free_packed(Cdb__TblCpuTraffic *p_pb_cpu_traffic)
{
    return PM_E_NONE;
}

int32
pb_tbl_cpu_traffic_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCpuTrafficKey pb_cpu_traffic_key = CDB__TBL_CPU_TRAFFIC_KEY__INIT;
    Cdb__TblCpuTraffic pb_cpu_traffic = CDB__TBL_CPU_TRAFFIC__INIT;
    tbl_cpu_traffic_t *p_cpu_traffic = (tbl_cpu_traffic_t*)p_tbl;
    int32 len = 0;

    pb_cpu_traffic.key = &pb_cpu_traffic_key;
    pb_tbl_cpu_traffic_to_pb(only_key, p_cpu_traffic, &pb_cpu_traffic);
    len = cdb__tbl_cpu_traffic__pack(&pb_cpu_traffic, buf);
    pb_tbl_cpu_traffic_to_pb_free_packed(&pb_cpu_traffic);

    return len;
}

int32
pb_tbl_cpu_traffic_dump(Cdb__TblCpuTraffic *p_pb_cpu_traffic, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->reason_id=%u", p_pb_cpu_traffic->key->reason_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/rate=%llu", p_pb_cpu_traffic->rate);
    offset += sal_sprintf(out + offset, "/class_id=%u", p_pb_cpu_traffic->class_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CPU_TRAFFIC_GROUP */
int32
pb_tbl_cpu_traffic_group_to_pb(uint32 only_key, tbl_cpu_traffic_group_t *p_cpu_traffic_group, Cdb__TblCpuTrafficGroup *p_pb_cpu_traffic_group)
{
    p_pb_cpu_traffic_group->key->class_id = p_cpu_traffic_group->key.class_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cpu_traffic_group->has_rate = TRUE;
    p_pb_cpu_traffic_group->rate = p_cpu_traffic_group->rate;

    return PM_E_NONE;
}

int32
pb_tbl_cpu_traffic_group_to_pb_free_packed(Cdb__TblCpuTrafficGroup *p_pb_cpu_traffic_group)
{
    return PM_E_NONE;
}

int32
pb_tbl_cpu_traffic_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCpuTrafficGroupKey pb_cpu_traffic_group_key = CDB__TBL_CPU_TRAFFIC_GROUP_KEY__INIT;
    Cdb__TblCpuTrafficGroup pb_cpu_traffic_group = CDB__TBL_CPU_TRAFFIC_GROUP__INIT;
    tbl_cpu_traffic_group_t *p_cpu_traffic_group = (tbl_cpu_traffic_group_t*)p_tbl;
    int32 len = 0;

    pb_cpu_traffic_group.key = &pb_cpu_traffic_group_key;
    pb_tbl_cpu_traffic_group_to_pb(only_key, p_cpu_traffic_group, &pb_cpu_traffic_group);
    len = cdb__tbl_cpu_traffic_group__pack(&pb_cpu_traffic_group, buf);
    pb_tbl_cpu_traffic_group_to_pb_free_packed(&pb_cpu_traffic_group);

    return len;
}

int32
pb_tbl_cpu_traffic_group_dump(Cdb__TblCpuTrafficGroup *p_pb_cpu_traffic_group, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->class_id=%u", p_pb_cpu_traffic_group->key->class_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/rate=%llu", p_pb_cpu_traffic_group->rate);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CPU_UTILIZATION */
int32
pb_tbl_cpu_utilization_to_pb(uint32 only_key, tbl_cpu_utilization_t *p_cpu_utilize, Cdb__TblCpuUtilization *p_pb_cpu_utilize)
{
    p_pb_cpu_utilize->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cpu_utilize->key.name)+1);
    sal_strcpy(p_pb_cpu_utilize->key->name, p_cpu_utilize->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cpu_utilize->has_cpu_usage = TRUE;
    p_pb_cpu_utilize->cpu_usage = p_cpu_utilize->cpu_usage;

    return PM_E_NONE;
}

int32
pb_tbl_cpu_utilization_to_pb_free_packed(Cdb__TblCpuUtilization *p_pb_cpu_utilize)
{
    if (p_pb_cpu_utilize->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cpu_utilize->key->name);
        p_pb_cpu_utilize->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_cpu_utilization_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCpuUtilizationKey pb_cpu_utilize_key = CDB__TBL_CPU_UTILIZATION_KEY__INIT;
    Cdb__TblCpuUtilization pb_cpu_utilize = CDB__TBL_CPU_UTILIZATION__INIT;
    tbl_cpu_utilization_t *p_cpu_utilize = (tbl_cpu_utilization_t*)p_tbl;
    int32 len = 0;

    pb_cpu_utilize.key = &pb_cpu_utilize_key;
    pb_tbl_cpu_utilization_to_pb(only_key, p_cpu_utilize, &pb_cpu_utilize);
    len = cdb__tbl_cpu_utilization__pack(&pb_cpu_utilize, buf);
    pb_tbl_cpu_utilization_to_pb_free_packed(&pb_cpu_utilize);

    return len;
}

int32
pb_tbl_cpu_utilization_dump(Cdb__TblCpuUtilization *p_pb_cpu_utilize, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_cpu_utilize->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/cpu_usage=%f", p_pb_cpu_utilize->cpu_usage);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CPU_LIMIT */
int32
pb_tbl_cpu_limit_to_pb(uint32 only_key, tbl_cpu_limit_t *p_cpu_limit, Cdb__TblCpuLimit *p_pb_cpu_limit)
{
    p_pb_cpu_limit->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cpu_limit->key.name)+1);
    sal_strcpy(p_pb_cpu_limit->key->name, p_cpu_limit->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cpu_limit->has_percent = TRUE;
    p_pb_cpu_limit->percent = p_cpu_limit->percent;

    return PM_E_NONE;
}

int32
pb_tbl_cpu_limit_to_pb_free_packed(Cdb__TblCpuLimit *p_pb_cpu_limit)
{
    if (p_pb_cpu_limit->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cpu_limit->key->name);
        p_pb_cpu_limit->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_cpu_limit_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCpuLimitKey pb_cpu_limit_key = CDB__TBL_CPU_LIMIT_KEY__INIT;
    Cdb__TblCpuLimit pb_cpu_limit = CDB__TBL_CPU_LIMIT__INIT;
    tbl_cpu_limit_t *p_cpu_limit = (tbl_cpu_limit_t*)p_tbl;
    int32 len = 0;

    pb_cpu_limit.key = &pb_cpu_limit_key;
    pb_tbl_cpu_limit_to_pb(only_key, p_cpu_limit, &pb_cpu_limit);
    len = cdb__tbl_cpu_limit__pack(&pb_cpu_limit, buf);
    pb_tbl_cpu_limit_to_pb_free_packed(&pb_cpu_limit);

    return len;
}

int32
pb_tbl_cpu_limit_dump(Cdb__TblCpuLimit *p_pb_cpu_limit, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_cpu_limit->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/percent=%u", p_pb_cpu_limit->percent);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCRELAY */
int32
pb_tbl_dhcrelay_to_pb(uint32 only_key, tbl_dhcrelay_t *p_dhcrelay, Cdb__TblDhcrelay *p_pb_dhcrelay)
{
    p_pb_dhcrelay->has_enable = TRUE;
    p_pb_dhcrelay->enable = p_dhcrelay->enable;
    p_pb_dhcrelay->has_drop_agent_mismatch = TRUE;
    p_pb_dhcrelay->drop_agent_mismatch = p_dhcrelay->drop_agent_mismatch;
    p_pb_dhcrelay->has_add_agent_options = TRUE;
    p_pb_dhcrelay->add_agent_options = p_dhcrelay->add_agent_options;
    p_pb_dhcrelay->has_agent_proc_option = TRUE;
    p_pb_dhcrelay->agent_proc_option = p_dhcrelay->agent_proc_option;
    p_pb_dhcrelay->has_trust_all = TRUE;
    p_pb_dhcrelay->trust_all = p_dhcrelay->trust_all;

    return PM_E_NONE;
}

int32
pb_tbl_dhcrelay_to_pb_free_packed(Cdb__TblDhcrelay *p_pb_dhcrelay)
{
    return PM_E_NONE;
}

int32
pb_tbl_dhcrelay_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhcrelay pb_dhcrelay = CDB__TBL_DHCRELAY__INIT;
    tbl_dhcrelay_t *p_dhcrelay = (tbl_dhcrelay_t*)p_tbl;
    int32 len = 0;

    pb_tbl_dhcrelay_to_pb(only_key, p_dhcrelay, &pb_dhcrelay);
    len = cdb__tbl_dhcrelay__pack(&pb_dhcrelay, buf);
    pb_tbl_dhcrelay_to_pb_free_packed(&pb_dhcrelay);

    return len;
}

int32
pb_tbl_dhcrelay_dump(Cdb__TblDhcrelay *p_pb_dhcrelay, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_dhcrelay->enable);
    offset += sal_sprintf(out + offset, "/drop_agent_mismatch=%u", p_pb_dhcrelay->drop_agent_mismatch);
    offset += sal_sprintf(out + offset, "/add_agent_options=%u", p_pb_dhcrelay->add_agent_options);
    offset += sal_sprintf(out + offset, "/agent_proc_option=%u", p_pb_dhcrelay->agent_proc_option);
    offset += sal_sprintf(out + offset, "/trust_all=%u", p_pb_dhcrelay->trust_all);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCSRVGRP */
int32
pb_tbl_dhcsrvgrp_to_pb(uint32 only_key, tbl_dhcsrvgrp_t *p_dhcsrvgrp, Cdb__TblDhcsrvgrp *p_pb_dhcsrvgrp)
{
    p_pb_dhcsrvgrp->key->id = p_dhcsrvgrp->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_dhcsrvgrp->has_cnt = TRUE;
    p_pb_dhcsrvgrp->cnt = p_dhcsrvgrp->cnt;
    p_pb_dhcsrvgrp->addrs = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhcsrvgrp->addrs)+1);
    sal_strcpy(p_pb_dhcsrvgrp->addrs, p_dhcsrvgrp->addrs);

    return PM_E_NONE;
}

int32
pb_tbl_dhcsrvgrp_to_pb_free_packed(Cdb__TblDhcsrvgrp *p_pb_dhcsrvgrp)
{
    if (p_pb_dhcsrvgrp->addrs)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhcsrvgrp->addrs);
        p_pb_dhcsrvgrp->addrs = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dhcsrvgrp_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhcsrvgrpKey pb_dhcsrvgrp_key = CDB__TBL_DHCSRVGRP_KEY__INIT;
    Cdb__TblDhcsrvgrp pb_dhcsrvgrp = CDB__TBL_DHCSRVGRP__INIT;
    tbl_dhcsrvgrp_t *p_dhcsrvgrp = (tbl_dhcsrvgrp_t*)p_tbl;
    int32 len = 0;

    pb_dhcsrvgrp.key = &pb_dhcsrvgrp_key;
    pb_tbl_dhcsrvgrp_to_pb(only_key, p_dhcsrvgrp, &pb_dhcsrvgrp);
    len = cdb__tbl_dhcsrvgrp__pack(&pb_dhcsrvgrp, buf);
    pb_tbl_dhcsrvgrp_to_pb_free_packed(&pb_dhcsrvgrp);

    return len;
}

int32
pb_tbl_dhcsrvgrp_dump(Cdb__TblDhcsrvgrp *p_pb_dhcsrvgrp, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_dhcsrvgrp->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/cnt=%u", p_pb_dhcsrvgrp->cnt);
    offset += sal_sprintf(out + offset, "/addrs=%s", p_pb_dhcsrvgrp->addrs);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCP_DEBUG */
int32
pb_tbl_dhcp_debug_to_pb(uint32 only_key, tbl_dhcp_debug_t *p_dhcp_debug, Cdb__TblDhcpDebug *p_pb_dhcp_debug)
{
    p_pb_dhcp_debug->has_relay_error = TRUE;
    p_pb_dhcp_debug->relay_error = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_RELAY_ERROR) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_relay_events = TRUE;
    p_pb_dhcp_debug->relay_events = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_RELAY_EVENTS) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_relay_packet = TRUE;
    p_pb_dhcp_debug->relay_packet = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_RELAY_PACKET) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_relay_dump = TRUE;
    p_pb_dhcp_debug->relay_dump = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_RELAY_DUMP) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snooping_error = TRUE;
    p_pb_dhcp_debug->snooping_error = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPING_ERROR) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snooping_event = TRUE;
    p_pb_dhcp_debug->snooping_event = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPING_EVENTS) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snooping_packet = TRUE;
    p_pb_dhcp_debug->snooping_packet = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPING_PACKET) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snooping_dump = TRUE;
    p_pb_dhcp_debug->snooping_dump = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPING_DUMP) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snoopingv6_error = TRUE;
    p_pb_dhcp_debug->snoopingv6_error = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPINGV6_ERROR) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snoopingv6_events = TRUE;
    p_pb_dhcp_debug->snoopingv6_events = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPINGV6_EVENTS) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snoopingv6_packet = TRUE;
    p_pb_dhcp_debug->snoopingv6_packet = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPINGV6_PACKET) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_snoopingv6_dump = TRUE;
    p_pb_dhcp_debug->snoopingv6_dump = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_SNOOPINGV6_DUMP) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_client_error = TRUE;
    p_pb_dhcp_debug->client_error = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_CLIENT_ERROR) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_client_events = TRUE;
    p_pb_dhcp_debug->client_events = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_CLIENT_EVENTS) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_client_packet = TRUE;
    p_pb_dhcp_debug->client_packet = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_CLIENT_PACKET) ? TRUE : FALSE;
    p_pb_dhcp_debug->has_client_dump = TRUE;
    p_pb_dhcp_debug->client_dump = GLB_FLAG_ISSET(p_dhcp_debug->flags, DHCDBG_FLAG_CLIENT_DUMP) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_dhcp_debug_to_pb_free_packed(Cdb__TblDhcpDebug *p_pb_dhcp_debug)
{
    return PM_E_NONE;
}

int32
pb_tbl_dhcp_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhcpDebug pb_dhcp_debug = CDB__TBL_DHCP_DEBUG__INIT;
    tbl_dhcp_debug_t *p_dhcp_debug = (tbl_dhcp_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_dhcp_debug_to_pb(only_key, p_dhcp_debug, &pb_dhcp_debug);
    len = cdb__tbl_dhcp_debug__pack(&pb_dhcp_debug, buf);
    pb_tbl_dhcp_debug_to_pb_free_packed(&pb_dhcp_debug);

    return len;
}

int32
pb_tbl_dhcp_debug_dump(Cdb__TblDhcpDebug *p_pb_dhcp_debug, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/relay_error=%u", p_pb_dhcp_debug->relay_error);
    offset += sal_sprintf(out + offset, "/relay_events=%u", p_pb_dhcp_debug->relay_events);
    offset += sal_sprintf(out + offset, "/relay_packet=%u", p_pb_dhcp_debug->relay_packet);
    offset += sal_sprintf(out + offset, "/relay_dump=%u", p_pb_dhcp_debug->relay_dump);
    offset += sal_sprintf(out + offset, "/snooping_error=%u", p_pb_dhcp_debug->snooping_error);
    offset += sal_sprintf(out + offset, "/snooping_event=%u", p_pb_dhcp_debug->snooping_event);
    offset += sal_sprintf(out + offset, "/snooping_packet=%u", p_pb_dhcp_debug->snooping_packet);
    offset += sal_sprintf(out + offset, "/snooping_dump=%u", p_pb_dhcp_debug->snooping_dump);
    offset += sal_sprintf(out + offset, "/snoopingv6_error=%u", p_pb_dhcp_debug->snoopingv6_error);
    offset += sal_sprintf(out + offset, "/snoopingv6_events=%u", p_pb_dhcp_debug->snoopingv6_events);
    offset += sal_sprintf(out + offset, "/snoopingv6_packet=%u", p_pb_dhcp_debug->snoopingv6_packet);
    offset += sal_sprintf(out + offset, "/snoopingv6_dump=%u", p_pb_dhcp_debug->snoopingv6_dump);
    offset += sal_sprintf(out + offset, "/client_error=%u", p_pb_dhcp_debug->client_error);
    offset += sal_sprintf(out + offset, "/client_events=%u", p_pb_dhcp_debug->client_events);
    offset += sal_sprintf(out + offset, "/client_packet=%u", p_pb_dhcp_debug->client_packet);
    offset += sal_sprintf(out + offset, "/client_dump=%u", p_pb_dhcp_debug->client_dump);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCLIENT */
int32
pb_tbl_dhclient_to_pb(uint32 only_key, tbl_dhclient_t *p_dhclient, Cdb__TblDhclient *p_pb_dhclient)
{
    p_pb_dhclient->has_enable = TRUE;
    p_pb_dhclient->enable = p_dhclient->enable;
    p_pb_dhclient->has_distance = TRUE;
    p_pb_dhclient->distance = p_dhclient->distance;
    p_pb_dhclient->has_broadcast = TRUE;
    p_pb_dhclient->broadcast = p_dhclient->broadcast;

    return PM_E_NONE;
}

int32
pb_tbl_dhclient_to_pb_free_packed(Cdb__TblDhclient *p_pb_dhclient)
{
    return PM_E_NONE;
}

int32
pb_tbl_dhclient_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhclient pb_dhclient = CDB__TBL_DHCLIENT__INIT;
    tbl_dhclient_t *p_dhclient = (tbl_dhclient_t*)p_tbl;
    int32 len = 0;

    pb_tbl_dhclient_to_pb(only_key, p_dhclient, &pb_dhclient);
    len = cdb__tbl_dhclient__pack(&pb_dhclient, buf);
    pb_tbl_dhclient_to_pb_free_packed(&pb_dhclient);

    return len;
}

int32
pb_tbl_dhclient_dump(Cdb__TblDhclient *p_pb_dhclient, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_dhclient->enable);
    offset += sal_sprintf(out + offset, "/distance=%u", p_pb_dhclient->distance);
    offset += sal_sprintf(out + offset, "/broadcast=%u", p_pb_dhclient->broadcast);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCSNOOPING */
int32
pb_tbl_dhcsnooping_to_pb(uint32 only_key, tbl_dhcsnooping_t *p_dhcsnooping, Cdb__TblDhcsnooping *p_pb_dhcsnooping)
{
    p_pb_dhcsnooping->has_verify_mac_address = TRUE;
    p_pb_dhcsnooping->verify_mac_address = p_dhcsnooping->verify_mac_address;
    p_pb_dhcsnooping->has_add_agent_options = TRUE;
    p_pb_dhcsnooping->add_agent_options = p_dhcsnooping->add_agent_options;
    p_pb_dhcsnooping->has_allow_untrusted = TRUE;
    p_pb_dhcsnooping->allow_untrusted = p_dhcsnooping->allow_untrusted;
    p_pb_dhcsnooping->has_hostname_as_remote_id = TRUE;
    p_pb_dhcsnooping->hostname_as_remote_id = p_dhcsnooping->hostname_as_remote_id;
    p_pb_dhcsnooping->remote_id_string = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhcsnooping->remote_id_string)+1);
    sal_strcpy(p_pb_dhcsnooping->remote_id_string, p_dhcsnooping->remote_id_string);
    p_pb_dhcsnooping->has_database_save_interval = TRUE;
    p_pb_dhcsnooping->database_save_interval = p_dhcsnooping->database_save_interval;
    p_pb_dhcsnooping->has_vlans = TRUE;
    p_pb_dhcsnooping->vlans.len = sizeof(p_dhcsnooping->vlans);
    p_pb_dhcsnooping->vlans.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dhcsnooping->vlans));
    sal_memcpy(p_pb_dhcsnooping->vlans.data, p_dhcsnooping->vlans, sizeof(p_dhcsnooping->vlans));
    p_pb_dhcsnooping->has_snooping_acl_applied = TRUE;
    p_pb_dhcsnooping->snooping_acl_applied.len = sizeof(p_dhcsnooping->snooping_acl_applied);
    p_pb_dhcsnooping->snooping_acl_applied.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dhcsnooping->snooping_acl_applied));
    sal_memcpy(p_pb_dhcsnooping->snooping_acl_applied.data, p_dhcsnooping->snooping_acl_applied, sizeof(p_dhcsnooping->snooping_acl_applied));

    return PM_E_NONE;
}

int32
pb_tbl_dhcsnooping_to_pb_free_packed(Cdb__TblDhcsnooping *p_pb_dhcsnooping)
{
    if (p_pb_dhcsnooping->remote_id_string)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhcsnooping->remote_id_string);
        p_pb_dhcsnooping->remote_id_string = NULL;
    }

    if (p_pb_dhcsnooping->vlans.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhcsnooping->vlans.data);
        p_pb_dhcsnooping->vlans.data = NULL;
    }

    if (p_pb_dhcsnooping->snooping_acl_applied.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhcsnooping->snooping_acl_applied.data);
        p_pb_dhcsnooping->snooping_acl_applied.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dhcsnooping_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhcsnooping pb_dhcsnooping = CDB__TBL_DHCSNOOPING__INIT;
    tbl_dhcsnooping_t *p_dhcsnooping = (tbl_dhcsnooping_t*)p_tbl;
    int32 len = 0;

    pb_tbl_dhcsnooping_to_pb(only_key, p_dhcsnooping, &pb_dhcsnooping);
    len = cdb__tbl_dhcsnooping__pack(&pb_dhcsnooping, buf);
    pb_tbl_dhcsnooping_to_pb_free_packed(&pb_dhcsnooping);

    return len;
}

int32
pb_tbl_dhcsnooping_dump(Cdb__TblDhcsnooping *p_pb_dhcsnooping, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/verify_mac_address=%u", p_pb_dhcsnooping->verify_mac_address);
    offset += sal_sprintf(out + offset, "/add_agent_options=%u", p_pb_dhcsnooping->add_agent_options);
    offset += sal_sprintf(out + offset, "/allow_untrusted=%u", p_pb_dhcsnooping->allow_untrusted);
    offset += sal_sprintf(out + offset, "/hostname_as_remote_id=%u", p_pb_dhcsnooping->hostname_as_remote_id);
    offset += sal_sprintf(out + offset, "/remote_id_string=%s", p_pb_dhcsnooping->remote_id_string);
    offset += sal_sprintf(out + offset, "/database_save_interval=%u", p_pb_dhcsnooping->database_save_interval);
    offset += sal_sprintf(out + offset, "/vlans=");
    offset += pb_bitmap_array_dump(p_pb_dhcsnooping->vlans.data, p_pb_dhcsnooping->vlans.len, (out + offset));
    offset += sal_sprintf(out + offset, "/snooping_acl_applied=");
    offset += pb_bitmap_array_dump(p_pb_dhcsnooping->snooping_acl_applied.data, p_pb_dhcsnooping->snooping_acl_applied.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DHCBINDING */
int32
pb_tbl_dhcbinding_to_pb(uint32 only_key, tbl_dhcbinding_t *p_dhcbinding, Cdb__TblDhcbinding *p_pb_dhcbinding)
{
    pb_compose_binding_key_t_to_pb(&p_dhcbinding->key, p_pb_dhcbinding->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_dhcbinding->has_vid = TRUE;
    p_pb_dhcbinding->vid = p_dhcbinding->vid;
    p_pb_dhcbinding->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhcbinding->ifname)+1);
    sal_strcpy(p_pb_dhcbinding->ifname, p_dhcbinding->ifname);
    pb_compose_mac_addr_t_to_pb(p_dhcbinding->client_mac, p_pb_dhcbinding->client_mac);
    pb_compose_addr_t_to_pb(&p_dhcbinding->client_ip, p_pb_dhcbinding->client_ip);
    p_pb_dhcbinding->has_cipsour = TRUE;
    p_pb_dhcbinding->cipsour = p_dhcbinding->cIpsour;
    p_pb_dhcbinding->has_lease = TRUE;
    p_pb_dhcbinding->lease = p_dhcbinding->lease;
    p_pb_dhcbinding->has_transid = TRUE;
    p_pb_dhcbinding->transid = p_dhcbinding->transid;
    p_pb_dhcbinding->has_ipsg_tbl_exsit = TRUE;
    p_pb_dhcbinding->ipsg_tbl_exsit = p_dhcbinding->ipsg_tbl_exsit;
    p_pb_dhcbinding->has_state = TRUE;
    p_pb_dhcbinding->state = p_dhcbinding->state;
    p_pb_dhcbinding->has_type = TRUE;
    p_pb_dhcbinding->type = p_dhcbinding->type;

    return PM_E_NONE;
}

int32
pb_tbl_dhcbinding_to_pb_free_packed(Cdb__TblDhcbinding *p_pb_dhcbinding)
{
    pb_compose_binding_key_t_to_pb_free_packed(p_pb_dhcbinding->key);
    if (p_pb_dhcbinding->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhcbinding->ifname);
        p_pb_dhcbinding->ifname = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_dhcbinding->client_mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_dhcbinding->client_ip);
    return PM_E_NONE;
}

int32
pb_tbl_dhcbinding_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDhcbindingKey pb_dhcbinding_key = CDB__TBL_DHCBINDING_KEY__INIT;
    Cdb__TblDhcbinding pb_dhcbinding = CDB__TBL_DHCBINDING__INIT;
    tbl_dhcbinding_t *p_dhcbinding = (tbl_dhcbinding_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT client_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT client_ip = CDB__COMPOSE_ADDR_T__INIT;

    pb_dhcbinding.key = &pb_dhcbinding_key;
    pb_dhcbinding.client_mac = &client_mac;
    pb_dhcbinding.client_ip = &client_ip;
    pb_tbl_dhcbinding_to_pb(only_key, p_dhcbinding, &pb_dhcbinding);
    len = cdb__tbl_dhcbinding__pack(&pb_dhcbinding, buf);
    pb_tbl_dhcbinding_to_pb_free_packed(&pb_dhcbinding);

    return len;
}

int32
pb_tbl_dhcbinding_dump(Cdb__TblDhcbinding *p_pb_dhcbinding, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_binding_key_t_dump(p_pb_dhcbinding->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_dhcbinding->vid);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_dhcbinding->ifname);
    offset += pb_compose_mac_addr_t_dump(p_pb_dhcbinding->client_mac, (out + offset));
    offset += pb_compose_addr_t_dump(p_pb_dhcbinding->client_ip, (out + offset));
    offset += sal_sprintf(out + offset, "/cIpsour=%u", p_pb_dhcbinding->cipsour);
    offset += sal_sprintf(out + offset, "/lease=%u", p_pb_dhcbinding->lease);
    offset += sal_sprintf(out + offset, "/transid=%u", p_pb_dhcbinding->transid);
    offset += sal_sprintf(out + offset, "/ipsg_tbl_exsit=%u", p_pb_dhcbinding->ipsg_tbl_exsit);
    offset += sal_sprintf(out + offset, "/state=%u", p_pb_dhcbinding->state);
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_dhcbinding->type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IPTABLES_PREVENT */
int32
pb_tbl_iptables_prevent_to_pb(uint32 only_key, tbl_iptables_prevent_t *p_iptables_prevent, Cdb__TblIptablesPrevent *p_pb_iptables_prevent)
{
    p_pb_iptables_prevent->has_ipt_cfg_icmp = TRUE;
    p_pb_iptables_prevent->ipt_cfg_icmp = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_ICMP) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_smurf = TRUE;
    p_pb_iptables_prevent->ipt_cfg_smurf = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_SMURF) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_fraggle = TRUE;
    p_pb_iptables_prevent->ipt_cfg_fraggle = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_FRAGGLE) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_udp = TRUE;
    p_pb_iptables_prevent->ipt_cfg_udp = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_UDP) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_tcp = TRUE;
    p_pb_iptables_prevent->ipt_cfg_tcp = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_TCP) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_small_pkt = TRUE;
    p_pb_iptables_prevent->ipt_cfg_small_pkt = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_SMALL_PKT) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_maceq = TRUE;
    p_pb_iptables_prevent->ipt_cfg_maceq = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_MACEQ) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_ipt_cfg_ipeq = TRUE;
    p_pb_iptables_prevent->ipt_cfg_ipeq = GLB_FLAG_ISSET(p_iptables_prevent->flags, GLB_IPTABLES_CFG_FLAG_IPEQ) ? TRUE : FALSE;
    p_pb_iptables_prevent->has_icmp_rate_limit = TRUE;
    p_pb_iptables_prevent->icmp_rate_limit = p_iptables_prevent->icmp_rate_limit;
    p_pb_iptables_prevent->has_tcp_rate_limit = TRUE;
    p_pb_iptables_prevent->tcp_rate_limit = p_iptables_prevent->tcp_rate_limit;
    p_pb_iptables_prevent->has_udp_rate_limit = TRUE;
    p_pb_iptables_prevent->udp_rate_limit = p_iptables_prevent->udp_rate_limit;
    p_pb_iptables_prevent->has_small_pkt_length = TRUE;
    p_pb_iptables_prevent->small_pkt_length = p_iptables_prevent->small_pkt_length;
    p_pb_iptables_prevent->has_small_pkt_static_base = TRUE;
    p_pb_iptables_prevent->small_pkt_static_base = p_iptables_prevent->small_pkt_static_base;
    p_pb_iptables_prevent->has_small_pkt_mgmt_static_base = TRUE;
    p_pb_iptables_prevent->small_pkt_mgmt_static_base = p_iptables_prevent->small_pkt_mgmt_static_base;
    p_pb_iptables_prevent->has_icmp_count = TRUE;
    p_pb_iptables_prevent->icmp_count = p_iptables_prevent->icmp_count;
    p_pb_iptables_prevent->has_smurf_count = TRUE;
    p_pb_iptables_prevent->smurf_count = p_iptables_prevent->smurf_count;
    p_pb_iptables_prevent->has_fraggle_count = TRUE;
    p_pb_iptables_prevent->fraggle_count = p_iptables_prevent->fraggle_count;
    p_pb_iptables_prevent->has_udp_count = TRUE;
    p_pb_iptables_prevent->udp_count = p_iptables_prevent->udp_count;
    p_pb_iptables_prevent->has_tcp_count = TRUE;
    p_pb_iptables_prevent->tcp_count = p_iptables_prevent->tcp_count;
    p_pb_iptables_prevent->has_small_pkt_count = TRUE;
    p_pb_iptables_prevent->small_pkt_count = p_iptables_prevent->small_pkt_count;
    p_pb_iptables_prevent->has_icmp_mgmt_count = TRUE;
    p_pb_iptables_prevent->icmp_mgmt_count = p_iptables_prevent->icmp_mgmt_count;
    p_pb_iptables_prevent->has_smurf_mgmt_count = TRUE;
    p_pb_iptables_prevent->smurf_mgmt_count = p_iptables_prevent->smurf_mgmt_count;
    p_pb_iptables_prevent->has_fraggle_mgmt_count = TRUE;
    p_pb_iptables_prevent->fraggle_mgmt_count = p_iptables_prevent->fraggle_mgmt_count;
    p_pb_iptables_prevent->has_udp_mgmt_count = TRUE;
    p_pb_iptables_prevent->udp_mgmt_count = p_iptables_prevent->udp_mgmt_count;
    p_pb_iptables_prevent->has_tcp_mgmt_count = TRUE;
    p_pb_iptables_prevent->tcp_mgmt_count = p_iptables_prevent->tcp_mgmt_count;
    p_pb_iptables_prevent->has_small_pkt_mgmt_count = TRUE;
    p_pb_iptables_prevent->small_pkt_mgmt_count = p_iptables_prevent->small_pkt_mgmt_count;

    return PM_E_NONE;
}

int32
pb_tbl_iptables_prevent_to_pb_free_packed(Cdb__TblIptablesPrevent *p_pb_iptables_prevent)
{
    return PM_E_NONE;
}

int32
pb_tbl_iptables_prevent_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIptablesPrevent pb_iptables_prevent = CDB__TBL_IPTABLES_PREVENT__INIT;
    tbl_iptables_prevent_t *p_iptables_prevent = (tbl_iptables_prevent_t*)p_tbl;
    int32 len = 0;

    pb_tbl_iptables_prevent_to_pb(only_key, p_iptables_prevent, &pb_iptables_prevent);
    len = cdb__tbl_iptables_prevent__pack(&pb_iptables_prevent, buf);
    pb_tbl_iptables_prevent_to_pb_free_packed(&pb_iptables_prevent);

    return len;
}

int32
pb_tbl_iptables_prevent_dump(Cdb__TblIptablesPrevent *p_pb_iptables_prevent, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/ipt_cfg_icmp=%u", p_pb_iptables_prevent->ipt_cfg_icmp);
    offset += sal_sprintf(out + offset, "/ipt_cfg_smurf=%u", p_pb_iptables_prevent->ipt_cfg_smurf);
    offset += sal_sprintf(out + offset, "/ipt_cfg_fraggle=%u", p_pb_iptables_prevent->ipt_cfg_fraggle);
    offset += sal_sprintf(out + offset, "/ipt_cfg_udp=%u", p_pb_iptables_prevent->ipt_cfg_udp);
    offset += sal_sprintf(out + offset, "/ipt_cfg_tcp=%u", p_pb_iptables_prevent->ipt_cfg_tcp);
    offset += sal_sprintf(out + offset, "/ipt_cfg_small_pkt=%u", p_pb_iptables_prevent->ipt_cfg_small_pkt);
    offset += sal_sprintf(out + offset, "/ipt_cfg_maceq=%u", p_pb_iptables_prevent->ipt_cfg_maceq);
    offset += sal_sprintf(out + offset, "/ipt_cfg_ipeq=%u", p_pb_iptables_prevent->ipt_cfg_ipeq);
    offset += sal_sprintf(out + offset, "/icmp_rate_limit=%u", p_pb_iptables_prevent->icmp_rate_limit);
    offset += sal_sprintf(out + offset, "/tcp_rate_limit=%u", p_pb_iptables_prevent->tcp_rate_limit);
    offset += sal_sprintf(out + offset, "/udp_rate_limit=%u", p_pb_iptables_prevent->udp_rate_limit);
    offset += sal_sprintf(out + offset, "/small_pkt_length=%u", p_pb_iptables_prevent->small_pkt_length);
    offset += sal_sprintf(out + offset, "/small_pkt_static_base=%u", p_pb_iptables_prevent->small_pkt_static_base);
    offset += sal_sprintf(out + offset, "/small_pkt_mgmt_static_base=%u", p_pb_iptables_prevent->small_pkt_mgmt_static_base);
    offset += sal_sprintf(out + offset, "/icmp_count=%u", p_pb_iptables_prevent->icmp_count);
    offset += sal_sprintf(out + offset, "/smurf_count=%u", p_pb_iptables_prevent->smurf_count);
    offset += sal_sprintf(out + offset, "/fraggle_count=%u", p_pb_iptables_prevent->fraggle_count);
    offset += sal_sprintf(out + offset, "/udp_count=%u", p_pb_iptables_prevent->udp_count);
    offset += sal_sprintf(out + offset, "/tcp_count=%u", p_pb_iptables_prevent->tcp_count);
    offset += sal_sprintf(out + offset, "/small_pkt_count=%u", p_pb_iptables_prevent->small_pkt_count);
    offset += sal_sprintf(out + offset, "/icmp_mgmt_count=%u", p_pb_iptables_prevent->icmp_mgmt_count);
    offset += sal_sprintf(out + offset, "/smurf_mgmt_count=%u", p_pb_iptables_prevent->smurf_mgmt_count);
    offset += sal_sprintf(out + offset, "/fraggle_mgmt_count=%u", p_pb_iptables_prevent->fraggle_mgmt_count);
    offset += sal_sprintf(out + offset, "/udp_mgmt_count=%u", p_pb_iptables_prevent->udp_mgmt_count);
    offset += sal_sprintf(out + offset, "/tcp_mgmt_count=%u", p_pb_iptables_prevent->tcp_mgmt_count);
    offset += sal_sprintf(out + offset, "/small_pkt_mgmt_count=%u", p_pb_iptables_prevent->small_pkt_mgmt_count);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ERRDISABLE */
int32
pb_tbl_errdisable_to_pb(uint32 only_key, tbl_errdisable_t *p_errdisable, Cdb__TblErrdisable *p_pb_errdisable)
{
    p_pb_errdisable->key->reason = p_errdisable->key.reason;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_errdisable->has_errdisable_en = TRUE;
    p_pb_errdisable->errdisable_en = p_errdisable->errdisable_en;
    p_pb_errdisable->has_recovery_en = TRUE;
    p_pb_errdisable->recovery_en = p_errdisable->recovery_en;

    return PM_E_NONE;
}

int32
pb_tbl_errdisable_to_pb_free_packed(Cdb__TblErrdisable *p_pb_errdisable)
{
    return PM_E_NONE;
}

int32
pb_tbl_errdisable_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblErrdisableKey pb_errdisable_key = CDB__TBL_ERRDISABLE_KEY__INIT;
    Cdb__TblErrdisable pb_errdisable = CDB__TBL_ERRDISABLE__INIT;
    tbl_errdisable_t *p_errdisable = (tbl_errdisable_t*)p_tbl;
    int32 len = 0;

    pb_errdisable.key = &pb_errdisable_key;
    pb_tbl_errdisable_to_pb(only_key, p_errdisable, &pb_errdisable);
    len = cdb__tbl_errdisable__pack(&pb_errdisable, buf);
    pb_tbl_errdisable_to_pb_free_packed(&pb_errdisable);

    return len;
}

int32
pb_tbl_errdisable_dump(Cdb__TblErrdisable *p_pb_errdisable, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->reason=%u", p_pb_errdisable->key->reason);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/errdisable_en=%u", p_pb_errdisable->errdisable_en);
    offset += sal_sprintf(out + offset, "/recovery_en=%u", p_pb_errdisable->recovery_en);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NS_PORT_FORWARDING */
int32
pb_tbl_ns_port_forwarding_to_pb(uint32 only_key, tbl_ns_port_forwarding_t *p_ns_port_forwarding, Cdb__TblNsPortForwarding *p_pb_ns_port_forwarding)
{
    pb_compose_ns_port_forwarding_key_t_to_pb(&p_ns_port_forwarding->key, p_pb_ns_port_forwarding->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_addr_ipv4_t_to_pb(&p_ns_port_forwarding->ip, p_pb_ns_port_forwarding->ip);

    return PM_E_NONE;
}

int32
pb_tbl_ns_port_forwarding_to_pb_free_packed(Cdb__TblNsPortForwarding *p_pb_ns_port_forwarding)
{
    pb_compose_ns_port_forwarding_key_t_to_pb_free_packed(p_pb_ns_port_forwarding->key);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ns_port_forwarding->ip);
    return PM_E_NONE;
}

int32
pb_tbl_ns_port_forwarding_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNsPortForwardingKey pb_ns_port_forwarding_key = CDB__TBL_NS_PORT_FORWARDING_KEY__INIT;
    Cdb__TblNsPortForwarding pb_ns_port_forwarding = CDB__TBL_NS_PORT_FORWARDING__INIT;
    tbl_ns_port_forwarding_t *p_ns_port_forwarding = (tbl_ns_port_forwarding_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_ns_port_forwarding.key = &pb_ns_port_forwarding_key;
    pb_ns_port_forwarding.ip = &ip;
    pb_tbl_ns_port_forwarding_to_pb(only_key, p_ns_port_forwarding, &pb_ns_port_forwarding);
    len = cdb__tbl_ns_port_forwarding__pack(&pb_ns_port_forwarding, buf);
    pb_tbl_ns_port_forwarding_to_pb_free_packed(&pb_ns_port_forwarding);

    return len;
}

int32
pb_tbl_ns_port_forwarding_dump(Cdb__TblNsPortForwarding *p_pb_ns_port_forwarding, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_ns_port_forwarding_key_t_dump(p_pb_ns_port_forwarding->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ns_port_forwarding->ip, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LOG_GLOBAL */
int32
pb_tbl_log_global_to_pb(uint32 only_key, tbl_log_global_t *p_log_glb, Cdb__TblLogGlobal *p_pb_log_glb)
{
    p_pb_log_glb->has_log_to_cdb = TRUE;
    p_pb_log_glb->log_to_cdb.len = sizeof(p_log_glb->log_to_cdb);
    p_pb_log_glb->log_to_cdb.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_log_glb->log_to_cdb));
    sal_memcpy(p_pb_log_glb->log_to_cdb.data, p_log_glb->log_to_cdb, sizeof(p_log_glb->log_to_cdb));

    return PM_E_NONE;
}

int32
pb_tbl_log_global_to_pb_free_packed(Cdb__TblLogGlobal *p_pb_log_glb)
{
    if (p_pb_log_glb->log_to_cdb.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_log_glb->log_to_cdb.data);
        p_pb_log_glb->log_to_cdb.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_log_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLogGlobal pb_log_glb = CDB__TBL_LOG_GLOBAL__INIT;
    tbl_log_global_t *p_log_glb = (tbl_log_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_log_global_to_pb(only_key, p_log_glb, &pb_log_glb);
    len = cdb__tbl_log_global__pack(&pb_log_glb, buf);
    pb_tbl_log_global_to_pb_free_packed(&pb_log_glb);

    return len;
}

int32
pb_tbl_log_global_dump(Cdb__TblLogGlobal *p_pb_log_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/log_to_cdb=");
    offset += pb_bitmap_array_dump(p_pb_log_glb->log_to_cdb.data, p_pb_log_glb->log_to_cdb.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LOG */
int32
pb_tbl_log_to_pb(uint32 only_key, tbl_log_t *p_log, Cdb__TblLog *p_pb_log)
{
    p_pb_log->key->sequence_id = p_log->key.sequence_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_log->has_log_id = TRUE;
    p_pb_log->log_id = p_log->log_id;
    p_pb_log->has_severity = TRUE;
    p_pb_log->severity = p_log->severity;
    pb_compose_timestamp_t_to_pb(&p_log->timestamp, p_pb_log->timestamp);
    p_pb_log->data = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_log->data)+1);
    sal_strcpy(p_pb_log->data, p_log->data);

    return PM_E_NONE;
}

int32
pb_tbl_log_to_pb_free_packed(Cdb__TblLog *p_pb_log)
{
    pb_compose_timestamp_t_to_pb_free_packed(p_pb_log->timestamp);
    if (p_pb_log->data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_log->data);
        p_pb_log->data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_log_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLogKey pb_log_key = CDB__TBL_LOG_KEY__INIT;
    Cdb__TblLog pb_log = CDB__TBL_LOG__INIT;
    tbl_log_t *p_log = (tbl_log_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeTimestampT timestamp = CDB__COMPOSE_TIMESTAMP_T__INIT;

    pb_log.key = &pb_log_key;
    pb_log.timestamp = &timestamp;
    pb_tbl_log_to_pb(only_key, p_log, &pb_log);
    len = cdb__tbl_log__pack(&pb_log, buf);
    pb_tbl_log_to_pb_free_packed(&pb_log);

    return len;
}

int32
pb_tbl_log_dump(Cdb__TblLog *p_pb_log, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->sequence_id=%u", p_pb_log->key->sequence_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/log_id=%u", p_pb_log->log_id);
    offset += sal_sprintf(out + offset, "/severity=%u", p_pb_log->severity);
    offset += pb_compose_timestamp_t_dump(p_pb_log->timestamp, (out + offset));
    offset += sal_sprintf(out + offset, "/data=%s", p_pb_log->data);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SYS_LOAD */
int32
pb_tbl_sys_load_to_pb(uint32 only_key, tbl_sys_load_t *p_sys_load, Cdb__TblSysLoad *p_pb_sys_load)
{
    p_pb_sys_load->has_sys_load_en = TRUE;
    p_pb_sys_load->sys_load_en = p_sys_load->sys_load_en;
    p_pb_sys_load->has_cli_back_pressure_en = TRUE;
    p_pb_sys_load->cli_back_pressure_en = p_sys_load->cli_back_pressure_en;
    p_pb_sys_load->has_cdb_queue_notice_threshold = TRUE;
    p_pb_sys_load->cdb_queue_notice_threshold = p_sys_load->cdb_queue_notice_threshold;
    p_pb_sys_load->has_cdb_queue_warning_threshold = TRUE;
    p_pb_sys_load->cdb_queue_warning_threshold = p_sys_load->cdb_queue_warning_threshold;
    p_pb_sys_load->has_cdb_queue_depth_switch = TRUE;
    p_pb_sys_load->cdb_queue_depth_switch = p_sys_load->cdb_queue_depth_switch;
    p_pb_sys_load->has_cdb_queue_depth_routed = TRUE;
    p_pb_sys_load->cdb_queue_depth_routed = p_sys_load->cdb_queue_depth_routed;
    p_pb_sys_load->has_cdb_queue_depth_cds = TRUE;
    p_pb_sys_load->cdb_queue_depth_cds = p_sys_load->cdb_queue_depth_cds;
    p_pb_sys_load->has_cdb_queue_depth_fea = TRUE;
    p_pb_sys_load->cdb_queue_depth_fea = p_sys_load->cdb_queue_depth_fea;

    return PM_E_NONE;
}

int32
pb_tbl_sys_load_to_pb_free_packed(Cdb__TblSysLoad *p_pb_sys_load)
{
    return PM_E_NONE;
}

int32
pb_tbl_sys_load_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSysLoad pb_sys_load = CDB__TBL_SYS_LOAD__INIT;
    tbl_sys_load_t *p_sys_load = (tbl_sys_load_t*)p_tbl;
    int32 len = 0;

    pb_tbl_sys_load_to_pb(only_key, p_sys_load, &pb_sys_load);
    len = cdb__tbl_sys_load__pack(&pb_sys_load, buf);
    pb_tbl_sys_load_to_pb_free_packed(&pb_sys_load);

    return len;
}

int32
pb_tbl_sys_load_dump(Cdb__TblSysLoad *p_pb_sys_load, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/sys_load_en=%u", p_pb_sys_load->sys_load_en);
    offset += sal_sprintf(out + offset, "/cli_back_pressure_en=%u", p_pb_sys_load->cli_back_pressure_en);
    offset += sal_sprintf(out + offset, "/cdb_queue_notice_threshold=%u", p_pb_sys_load->cdb_queue_notice_threshold);
    offset += sal_sprintf(out + offset, "/cdb_queue_warning_threshold=%u", p_pb_sys_load->cdb_queue_warning_threshold);
    offset += sal_sprintf(out + offset, "/cdb_queue_depth_switch=%u", p_pb_sys_load->cdb_queue_depth_switch);
    offset += sal_sprintf(out + offset, "/cdb_queue_depth_routed=%u", p_pb_sys_load->cdb_queue_depth_routed);
    offset += sal_sprintf(out + offset, "/cdb_queue_depth_cds=%u", p_pb_sys_load->cdb_queue_depth_cds);
    offset += sal_sprintf(out + offset, "/cdb_queue_depth_fea=%u", p_pb_sys_load->cdb_queue_depth_fea);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CEM */
int32
pb_tbl_cem_to_pb(uint32 only_key, tbl_cem_t *p_cem, Cdb__TblCem *p_pb_cem)
{
    p_pb_cem->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cem->key.name)+1);
    sal_strcpy(p_pb_cem->key->name, p_cem->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_cem->event = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cem->event)+1);
    sal_strcpy(p_pb_cem->event, p_cem->event);
    p_pb_cem->has_threshold = TRUE;
    p_pb_cem->threshold = p_cem->threshold;
    p_pb_cem->has_snmptrap = TRUE;
    p_pb_cem->snmptrap = p_cem->snmptrap;
    p_pb_cem->loadpath = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_cem->loadpath)+1);
    sal_strcpy(p_pb_cem->loadpath, p_cem->loadpath);
    pb_compose_mail_t_to_pb(&p_cem->mail, p_pb_cem->mail);

    return PM_E_NONE;
}

int32
pb_tbl_cem_to_pb_free_packed(Cdb__TblCem *p_pb_cem)
{
    if (p_pb_cem->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cem->key->name);
        p_pb_cem->key->name = NULL;
    }

    if (p_pb_cem->event)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cem->event);
        p_pb_cem->event = NULL;
    }

    if (p_pb_cem->loadpath)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_cem->loadpath);
        p_pb_cem->loadpath = NULL;
    }

    pb_compose_mail_t_to_pb_free_packed(p_pb_cem->mail);
    return PM_E_NONE;
}

int32
pb_tbl_cem_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCemKey pb_cem_key = CDB__TBL_CEM_KEY__INIT;
    Cdb__TblCem pb_cem = CDB__TBL_CEM__INIT;
    tbl_cem_t *p_cem = (tbl_cem_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMailT mail = CDB__COMPOSE_MAIL_T__INIT;

    pb_cem.key = &pb_cem_key;
    pb_cem.mail = &mail;
    pb_tbl_cem_to_pb(only_key, p_cem, &pb_cem);
    len = cdb__tbl_cem__pack(&pb_cem, buf);
    pb_tbl_cem_to_pb_free_packed(&pb_cem);

    return len;
}

int32
pb_tbl_cem_dump(Cdb__TblCem *p_pb_cem, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_cem->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/event=%s", p_pb_cem->event);
    offset += sal_sprintf(out + offset, "/threshold=%u", p_pb_cem->threshold);
    offset += sal_sprintf(out + offset, "/snmptrap=%u", p_pb_cem->snmptrap);
    offset += sal_sprintf(out + offset, "/loadpath=%s", p_pb_cem->loadpath);
    offset += pb_compose_mail_t_dump(p_pb_cem->mail, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CLOCK */
int32
pb_tbl_clock_to_pb(uint32 only_key, tbl_clock_t *p_clk, Cdb__TblClock *p_pb_clk)
{
    p_pb_clk->has_timezone_positive = TRUE;
    p_pb_clk->timezone_positive = p_clk->timezone_positive;
    p_pb_clk->has_timezone_hour = TRUE;
    p_pb_clk->timezone_hour = p_clk->timezone_hour;
    p_pb_clk->has_timezone_minute = TRUE;
    p_pb_clk->timezone_minute = p_clk->timezone_minute;
    p_pb_clk->has_timezone_second = TRUE;
    p_pb_clk->timezone_second = p_clk->timezone_second;
    p_pb_clk->timezone_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_clk->timezone_name)+1);
    sal_strcpy(p_pb_clk->timezone_name, p_clk->timezone_name);

    return PM_E_NONE;
}

int32
pb_tbl_clock_to_pb_free_packed(Cdb__TblClock *p_pb_clk)
{
    if (p_pb_clk->timezone_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_clk->timezone_name);
        p_pb_clk->timezone_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_clock_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblClock pb_clk = CDB__TBL_CLOCK__INIT;
    tbl_clock_t *p_clk = (tbl_clock_t*)p_tbl;
    int32 len = 0;

    pb_tbl_clock_to_pb(only_key, p_clk, &pb_clk);
    len = cdb__tbl_clock__pack(&pb_clk, buf);
    pb_tbl_clock_to_pb_free_packed(&pb_clk);

    return len;
}

int32
pb_tbl_clock_dump(Cdb__TblClock *p_pb_clk, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/timezone_positive=%u", p_pb_clk->timezone_positive);
    offset += sal_sprintf(out + offset, "/timezone_hour=%u", p_pb_clk->timezone_hour);
    offset += sal_sprintf(out + offset, "/timezone_minute=%u", p_pb_clk->timezone_minute);
    offset += sal_sprintf(out + offset, "/timezone_second=%u", p_pb_clk->timezone_second);
    offset += sal_sprintf(out + offset, "/timezone_name=%s", p_pb_clk->timezone_name);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PORT_STATS */
int32
pb_tbl_port_stats_to_pb(uint32 only_key, tbl_port_stats_t *p_port_stats, Cdb__TblPortStats *p_pb_port_stats)
{
    p_pb_port_stats->key->ifindex = p_port_stats->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_port_stats->has_port_id = TRUE;
    p_pb_port_stats->port_id = p_port_stats->port_id;
    p_pb_port_stats->has_octets_rcv = TRUE;
    p_pb_port_stats->octets_rcv = p_port_stats->octets_rcv;
    p_pb_port_stats->has_pkts_rcv = TRUE;
    p_pb_port_stats->pkts_rcv = p_port_stats->pkts_rcv;
    p_pb_port_stats->has_uc_pkts_rcv = TRUE;
    p_pb_port_stats->uc_pkts_rcv = p_port_stats->uc_pkts_rcv;
    p_pb_port_stats->has_brdc_pkts_rcv = TRUE;
    p_pb_port_stats->brdc_pkts_rcv = p_port_stats->brdc_pkts_rcv;
    p_pb_port_stats->has_mc_pkts_rcv = TRUE;
    p_pb_port_stats->mc_pkts_rcv = p_port_stats->mc_pkts_rcv;
    p_pb_port_stats->has_oam_pkts_rcv = TRUE;
    p_pb_port_stats->oam_pkts_rcv = p_port_stats->oam_pkts_rcv;
    p_pb_port_stats->has_undersize_pkts = TRUE;
    p_pb_port_stats->undersize_pkts = p_port_stats->undersize_pkts;
    p_pb_port_stats->has_oversize_pkts = TRUE;
    p_pb_port_stats->oversize_pkts = p_port_stats->oversize_pkts;
    p_pb_port_stats->has_mac_rcv_error = TRUE;
    p_pb_port_stats->mac_rcv_error = p_port_stats->mac_rcv_error;
    p_pb_port_stats->has_bad_crc = TRUE;
    p_pb_port_stats->bad_crc = p_port_stats->bad_crc;
    p_pb_port_stats->has_frame_error = TRUE;
    p_pb_port_stats->frame_error = p_port_stats->frame_error;
    p_pb_port_stats->has_drop_events = TRUE;
    p_pb_port_stats->drop_events = p_port_stats->drop_events;
    p_pb_port_stats->has_pause_rcv = TRUE;
    p_pb_port_stats->pause_rcv = p_port_stats->pause_rcv;
    p_pb_port_stats->has_octets_send = TRUE;
    p_pb_port_stats->octets_send = p_port_stats->octets_send;
    p_pb_port_stats->has_pkts_send = TRUE;
    p_pb_port_stats->pkts_send = p_port_stats->pkts_send;
    p_pb_port_stats->has_uc_pkts_send = TRUE;
    p_pb_port_stats->uc_pkts_send = p_port_stats->uc_pkts_send;
    p_pb_port_stats->has_brdc_pkts_send = TRUE;
    p_pb_port_stats->brdc_pkts_send = p_port_stats->brdc_pkts_send;
    p_pb_port_stats->has_mc_pkts_send = TRUE;
    p_pb_port_stats->mc_pkts_send = p_port_stats->mc_pkts_send;
    p_pb_port_stats->has_oam_pkts_send = TRUE;
    p_pb_port_stats->oam_pkts_send = p_port_stats->oam_pkts_send;
    p_pb_port_stats->has_underruns = TRUE;
    p_pb_port_stats->underruns = p_port_stats->underruns;
    p_pb_port_stats->has_mac_transmit_err = TRUE;
    p_pb_port_stats->mac_transmit_err = p_port_stats->mac_transmit_err;
    p_pb_port_stats->has_pause_send = TRUE;
    p_pb_port_stats->pause_send = p_port_stats->pause_send;
    p_pb_port_stats->has_fcs_pkts_rcv = TRUE;
    p_pb_port_stats->fcs_pkts_rcv = p_port_stats->fcs_pkts_rcv;
    p_pb_port_stats->has_fcs_octets_rcv = TRUE;
    p_pb_port_stats->fcs_octets_rcv = p_port_stats->fcs_octets_rcv;
    p_pb_port_stats->has_fcs_pkts_send = TRUE;
    p_pb_port_stats->fcs_pkts_send = p_port_stats->fcs_pkts_send;
    p_pb_port_stats->has_fcs_octets_send = TRUE;
    p_pb_port_stats->fcs_octets_send = p_port_stats->fcs_octets_send;
    p_pb_port_stats->has_fragments_pkts = TRUE;
    p_pb_port_stats->fragments_pkts = p_port_stats->fragments_pkts;
    p_pb_port_stats->has_bad_pkts_rcv = TRUE;
    p_pb_port_stats->bad_pkts_rcv = p_port_stats->bad_pkts_rcv;
    p_pb_port_stats->has_bad_octets_rcv = TRUE;
    p_pb_port_stats->bad_octets_rcv = p_port_stats->bad_octets_rcv;

    return PM_E_NONE;
}

int32
pb_tbl_port_stats_to_pb_free_packed(Cdb__TblPortStats *p_pb_port_stats)
{
    return PM_E_NONE;
}

int32
pb_tbl_port_stats_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPortStatsKey pb_port_stats_key = CDB__TBL_PORT_STATS_KEY__INIT;
    Cdb__TblPortStats pb_port_stats = CDB__TBL_PORT_STATS__INIT;
    tbl_port_stats_t *p_port_stats = (tbl_port_stats_t*)p_tbl;
    int32 len = 0;

    pb_port_stats.key = &pb_port_stats_key;
    pb_tbl_port_stats_to_pb(only_key, p_port_stats, &pb_port_stats);
    len = cdb__tbl_port_stats__pack(&pb_port_stats, buf);
    pb_tbl_port_stats_to_pb_free_packed(&pb_port_stats);

    return len;
}

int32
pb_tbl_port_stats_dump(Cdb__TblPortStats *p_pb_port_stats, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_port_stats->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/port_id=%u", p_pb_port_stats->port_id);
    offset += sal_sprintf(out + offset, "/octets_rcv=%llu", p_pb_port_stats->octets_rcv);
    offset += sal_sprintf(out + offset, "/pkts_rcv=%llu", p_pb_port_stats->pkts_rcv);
    offset += sal_sprintf(out + offset, "/uc_pkts_rcv=%llu", p_pb_port_stats->uc_pkts_rcv);
    offset += sal_sprintf(out + offset, "/brdc_pkts_rcv=%llu", p_pb_port_stats->brdc_pkts_rcv);
    offset += sal_sprintf(out + offset, "/mc_pkts_rcv=%llu", p_pb_port_stats->mc_pkts_rcv);
    offset += sal_sprintf(out + offset, "/oam_pkts_rcv=%llu", p_pb_port_stats->oam_pkts_rcv);
    offset += sal_sprintf(out + offset, "/undersize_pkts=%llu", p_pb_port_stats->undersize_pkts);
    offset += sal_sprintf(out + offset, "/oversize_pkts=%llu", p_pb_port_stats->oversize_pkts);
    offset += sal_sprintf(out + offset, "/mac_rcv_error=%llu", p_pb_port_stats->mac_rcv_error);
    offset += sal_sprintf(out + offset, "/bad_crc=%llu", p_pb_port_stats->bad_crc);
    offset += sal_sprintf(out + offset, "/frame_error=%llu", p_pb_port_stats->frame_error);
    offset += sal_sprintf(out + offset, "/drop_events=%llu", p_pb_port_stats->drop_events);
    offset += sal_sprintf(out + offset, "/pause_rcv=%llu", p_pb_port_stats->pause_rcv);
    offset += sal_sprintf(out + offset, "/octets_send=%llu", p_pb_port_stats->octets_send);
    offset += sal_sprintf(out + offset, "/pkts_send=%llu", p_pb_port_stats->pkts_send);
    offset += sal_sprintf(out + offset, "/uc_pkts_send=%llu", p_pb_port_stats->uc_pkts_send);
    offset += sal_sprintf(out + offset, "/brdc_pkts_send=%llu", p_pb_port_stats->brdc_pkts_send);
    offset += sal_sprintf(out + offset, "/mc_pkts_send=%llu", p_pb_port_stats->mc_pkts_send);
    offset += sal_sprintf(out + offset, "/oam_pkts_send=%llu", p_pb_port_stats->oam_pkts_send);
    offset += sal_sprintf(out + offset, "/underruns=%llu", p_pb_port_stats->underruns);
    offset += sal_sprintf(out + offset, "/mac_transmit_err=%llu", p_pb_port_stats->mac_transmit_err);
    offset += sal_sprintf(out + offset, "/pause_send=%llu", p_pb_port_stats->pause_send);
    offset += sal_sprintf(out + offset, "/fcs_pkts_rcv=%llu", p_pb_port_stats->fcs_pkts_rcv);
    offset += sal_sprintf(out + offset, "/fcs_octets_rcv=%llu", p_pb_port_stats->fcs_octets_rcv);
    offset += sal_sprintf(out + offset, "/fcs_pkts_send=%llu", p_pb_port_stats->fcs_pkts_send);
    offset += sal_sprintf(out + offset, "/fcs_octets_send=%llu", p_pb_port_stats->fcs_octets_send);
    offset += sal_sprintf(out + offset, "/fragments_pkts=%llu", p_pb_port_stats->fragments_pkts);
    offset += sal_sprintf(out + offset, "/bad_pkts_rcv=%llu", p_pb_port_stats->bad_pkts_rcv);
    offset += sal_sprintf(out + offset, "/bad_octets_rcv=%llu", p_pb_port_stats->bad_octets_rcv);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PORT_STATS_RATE */
int32
pb_tbl_port_stats_rate_to_pb(uint32 only_key, tbl_port_stats_rate_t *p_port_stats_rate, Cdb__TblPortStatsRate *p_pb_port_stats_rate)
{
    p_pb_port_stats_rate->key->ifindex = p_port_stats_rate->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_port_stats_rate->has_port_id = TRUE;
    p_pb_port_stats_rate->port_id = p_port_stats_rate->port_id;
    p_pb_port_stats_rate->has_octets_rcv_rate = TRUE;
    p_pb_port_stats_rate->octets_rcv_rate = p_port_stats_rate->octets_rcv_rate;
    p_pb_port_stats_rate->has_pkts_rcv_rate = TRUE;
    p_pb_port_stats_rate->pkts_rcv_rate = p_port_stats_rate->pkts_rcv_rate;
    p_pb_port_stats_rate->has_octets_send_rate = TRUE;
    p_pb_port_stats_rate->octets_send_rate = p_port_stats_rate->octets_send_rate;
    p_pb_port_stats_rate->has_pkts_send_rate = TRUE;
    p_pb_port_stats_rate->pkts_send_rate = p_port_stats_rate->pkts_send_rate;

    return PM_E_NONE;
}

int32
pb_tbl_port_stats_rate_to_pb_free_packed(Cdb__TblPortStatsRate *p_pb_port_stats_rate)
{
    return PM_E_NONE;
}

int32
pb_tbl_port_stats_rate_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPortStatsRateKey pb_port_stats_rate_key = CDB__TBL_PORT_STATS_RATE_KEY__INIT;
    Cdb__TblPortStatsRate pb_port_stats_rate = CDB__TBL_PORT_STATS_RATE__INIT;
    tbl_port_stats_rate_t *p_port_stats_rate = (tbl_port_stats_rate_t*)p_tbl;
    int32 len = 0;

    pb_port_stats_rate.key = &pb_port_stats_rate_key;
    pb_tbl_port_stats_rate_to_pb(only_key, p_port_stats_rate, &pb_port_stats_rate);
    len = cdb__tbl_port_stats_rate__pack(&pb_port_stats_rate, buf);
    pb_tbl_port_stats_rate_to_pb_free_packed(&pb_port_stats_rate);

    return len;
}

int32
pb_tbl_port_stats_rate_dump(Cdb__TblPortStatsRate *p_pb_port_stats_rate, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_port_stats_rate->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/port_id=%u", p_pb_port_stats_rate->port_id);
    offset += sal_sprintf(out + offset, "/octets_rcv_rate=%llu", p_pb_port_stats_rate->octets_rcv_rate);
    offset += sal_sprintf(out + offset, "/pkts_rcv_rate=%llu", p_pb_port_stats_rate->pkts_rcv_rate);
    offset += sal_sprintf(out + offset, "/octets_send_rate=%llu", p_pb_port_stats_rate->octets_send_rate);
    offset += sal_sprintf(out + offset, "/pkts_send_rate=%llu", p_pb_port_stats_rate->pkts_send_rate);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACLQOS_IF */
int32
pb_tbl_aclqos_if_to_pb(uint32 only_key, tbl_aclqos_if_t *p_aclqos_if, Cdb__TblAclqosIf *p_pb_aclqos_if)
{
    uint32 i = 0;

    p_pb_aclqos_if->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->key.name)+1);
    sal_strcpy(p_pb_aclqos_if->key->name, p_aclqos_if->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_aclqos_if->has_flags_domain = TRUE;
    p_pb_aclqos_if->flags_domain = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_DOMAIN) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_port_shape_profile = TRUE;
    p_pb_aclqos_if->flags_port_shape_profile = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_PORT_SHAPE_PROFILE) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_input_policer = TRUE;
    p_pb_aclqos_if->flags_input_policer = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_INPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_output_policer = TRUE;
    p_pb_aclqos_if->flags_output_policer = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_OUTPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_queue_shape_profile = TRUE;
    p_pb_aclqos_if->flags_queue_shape_profile = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_QUEUE_SHAPE_PROFILE) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_queue_drop_profile = TRUE;
    p_pb_aclqos_if->flags_queue_drop_profile = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_QUEUE_DROP_PROFILE) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_queue_drop_mode = TRUE;
    p_pb_aclqos_if->flags_queue_drop_mode = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_QUEUE_DROP_MODE) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_replace_dscp = TRUE;
    p_pb_aclqos_if->flags_replace_dscp = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_REPLACE_DSCP) ? TRUE : FALSE;
    p_pb_aclqos_if->has_flags_replace_cos = TRUE;
    p_pb_aclqos_if->flags_replace_cos = GLB_FLAG_ISSET(p_aclqos_if->flags, GLB_ACLQOS_IF_FLAGS_REPLACE_COS) ? TRUE : FALSE;
    p_pb_aclqos_if->has_domain = TRUE;
    p_pb_aclqos_if->domain = p_aclqos_if->domain;
    p_pb_aclqos_if->port_shape_profile = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->port_shape_profile)+1);
    sal_strcpy(p_pb_aclqos_if->port_shape_profile, p_aclqos_if->port_shape_profile);
    p_pb_aclqos_if->input_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->input_policy_map)+1);
    sal_strcpy(p_pb_aclqos_if->input_policy_map, p_aclqos_if->input_policy_map);
    p_pb_aclqos_if->output_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->output_policy_map)+1);
    sal_strcpy(p_pb_aclqos_if->output_policy_map, p_aclqos_if->output_policy_map);
    p_pb_aclqos_if->input_policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->input_policer)+1);
    sal_strcpy(p_pb_aclqos_if->input_policer, p_aclqos_if->input_policer);
    p_pb_aclqos_if->output_policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->output_policer)+1);
    sal_strcpy(p_pb_aclqos_if->output_policer, p_aclqos_if->output_policer);
    p_pb_aclqos_if->queue_shape_profile = XCALLOC(MEM_LIB_PROTOBUF, sizeof(char*)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_shape_profile = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_shape_profile[i] = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->queue_shape_profile[i])+1);
        sal_strcpy(p_pb_aclqos_if->queue_shape_profile[i], p_aclqos_if->queue_shape_profile[i]);
    }
    p_pb_aclqos_if->queue_drop_profile = XCALLOC(MEM_LIB_PROTOBUF, sizeof(char*)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_profile = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_profile[i] = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->queue_drop_profile[i])+1);
        sal_strcpy(p_pb_aclqos_if->queue_drop_profile[i], p_aclqos_if->queue_drop_profile[i]);
    }
    p_pb_aclqos_if->queue_drop_mode = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_mode = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_mode[i] = p_aclqos_if->queue_drop_mode[i];
    }
    p_pb_aclqos_if->has_replace_dscp = TRUE;
    p_pb_aclqos_if->replace_dscp = p_aclqos_if->replace_dscp;
    p_pb_aclqos_if->has_replace_cos = TRUE;
    p_pb_aclqos_if->replace_cos = p_aclqos_if->replace_cos;

    return PM_E_NONE;
}

int32
pb_tbl_aclqos_if_to_pb_free_packed(Cdb__TblAclqosIf *p_pb_aclqos_if)
{
    uint32 i = 0;

    if (p_pb_aclqos_if->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->key->name);
        p_pb_aclqos_if->key->name = NULL;
    }

    if (p_pb_aclqos_if->port_shape_profile)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->port_shape_profile);
        p_pb_aclqos_if->port_shape_profile = NULL;
    }

    if (p_pb_aclqos_if->input_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->input_policy_map);
        p_pb_aclqos_if->input_policy_map = NULL;
    }

    if (p_pb_aclqos_if->output_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->output_policy_map);
        p_pb_aclqos_if->output_policy_map = NULL;
    }

    if (p_pb_aclqos_if->input_policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->input_policer);
        p_pb_aclqos_if->input_policer = NULL;
    }

    if (p_pb_aclqos_if->output_policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->output_policer);
        p_pb_aclqos_if->output_policer = NULL;
    }

    if (p_pb_aclqos_if->queue_shape_profile)
    {
        for (i = 0; i < p_pb_aclqos_if->n_queue_shape_profile; i++)
        {
            if (p_pb_aclqos_if->queue_shape_profile[i])
            {
                XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_shape_profile[i]);
                p_pb_aclqos_if->queue_shape_profile[i] = NULL;
            }
        }
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_shape_profile);
        p_pb_aclqos_if->queue_shape_profile = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_profile)
    {
        for (i = 0; i < p_pb_aclqos_if->n_queue_drop_profile; i++)
        {
            if (p_pb_aclqos_if->queue_drop_profile[i])
            {
                XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_profile[i]);
                p_pb_aclqos_if->queue_drop_profile[i] = NULL;
            }
        }
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_profile);
        p_pb_aclqos_if->queue_drop_profile = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_mode);
        p_pb_aclqos_if->queue_drop_mode = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_aclqos_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclqosIfKey pb_aclqos_if_key = CDB__TBL_ACLQOS_IF_KEY__INIT;
    Cdb__TblAclqosIf pb_aclqos_if = CDB__TBL_ACLQOS_IF__INIT;
    tbl_aclqos_if_t *p_aclqos_if = (tbl_aclqos_if_t*)p_tbl;
    int32 len = 0;

    pb_aclqos_if.key = &pb_aclqos_if_key;
    pb_tbl_aclqos_if_to_pb(only_key, p_aclqos_if, &pb_aclqos_if);
    len = cdb__tbl_aclqos_if__pack(&pb_aclqos_if, buf);
    pb_tbl_aclqos_if_to_pb_free_packed(&pb_aclqos_if);

    return len;
}

int32
pb_tbl_aclqos_if_dump(Cdb__TblAclqosIf *p_pb_aclqos_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_aclqos_if->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/flags_domain=%u", p_pb_aclqos_if->flags_domain);
    offset += sal_sprintf(out + offset, "/flags_port_shape_profile=%u", p_pb_aclqos_if->flags_port_shape_profile);
    offset += sal_sprintf(out + offset, "/flags_input_policer=%u", p_pb_aclqos_if->flags_input_policer);
    offset += sal_sprintf(out + offset, "/flags_output_policer=%u", p_pb_aclqos_if->flags_output_policer);
    offset += sal_sprintf(out + offset, "/flags_queue_shape_profile=%u", p_pb_aclqos_if->flags_queue_shape_profile);
    offset += sal_sprintf(out + offset, "/flags_queue_drop_profile=%u", p_pb_aclqos_if->flags_queue_drop_profile);
    offset += sal_sprintf(out + offset, "/flags_queue_drop_mode=%u", p_pb_aclqos_if->flags_queue_drop_mode);
    offset += sal_sprintf(out + offset, "/flags_replace_dscp=%u", p_pb_aclqos_if->flags_replace_dscp);
    offset += sal_sprintf(out + offset, "/flags_replace_cos=%u", p_pb_aclqos_if->flags_replace_cos);
    offset += sal_sprintf(out + offset, "/domain=%u", p_pb_aclqos_if->domain);
    offset += sal_sprintf(out + offset, "/port_shape_profile=%s", p_pb_aclqos_if->port_shape_profile);
    offset += sal_sprintf(out + offset, "/input_policy_map=%s", p_pb_aclqos_if->input_policy_map);
    offset += sal_sprintf(out + offset, "/output_policy_map=%s", p_pb_aclqos_if->output_policy_map);
    offset += sal_sprintf(out + offset, "/input_policer=%s", p_pb_aclqos_if->input_policer);
    offset += sal_sprintf(out + offset, "/output_policer=%s", p_pb_aclqos_if->output_policer);
    offset += sal_sprintf(out + offset, "/queue_shape_profile=");
    offset += pb_string_array_dump(p_pb_aclqos_if->queue_shape_profile, p_pb_aclqos_if->n_queue_shape_profile, (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_profile=");
    offset += pb_string_array_dump(p_pb_aclqos_if->queue_drop_profile, p_pb_aclqos_if->n_queue_drop_profile, (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_mode=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_drop_mode, sizeof(p_pb_aclqos_if->queue_drop_mode), (out + offset));
    offset += sal_sprintf(out + offset, "/replace_dscp=%u", p_pb_aclqos_if->replace_dscp);
    offset += sal_sprintf(out + offset, "/replace_cos=%u", p_pb_aclqos_if->replace_cos);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_L2_ACTION */
int32
pb_tbl_l2_action_to_pb(uint32 only_key, tbl_l2_action_t *p_l2_act, Cdb__TblL2Action *p_pb_l2_act)
{

    return PM_E_NONE;
}

int32
pb_tbl_l2_action_to_pb_free_packed(Cdb__TblL2Action *p_pb_l2_act)
{
    return PM_E_NONE;
}

int32
pb_tbl_l2_action_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblL2Action pb_l2_act = CDB__TBL_L2_ACTION__INIT;
    tbl_l2_action_t *p_l2_act = (tbl_l2_action_t*)p_tbl;
    int32 len = 0;

    pb_tbl_l2_action_to_pb(only_key, p_l2_act, &pb_l2_act);
    len = cdb__tbl_l2_action__pack(&pb_l2_act, buf);
    pb_tbl_l2_action_to_pb_free_packed(&pb_l2_act);

    return len;
}

int32
pb_tbl_l2_action_dump(Cdb__TblL2Action *p_pb_l2_act, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_QOS_DROP_PROFILE */
int32
pb_tbl_fea_qos_drop_profile_to_pb(uint32 only_key, tbl_fea_qos_drop_profile_t *p_fea_qos_drop_profile, Cdb__TblFeaQosDropProfile *p_pb_fea_qos_drop_profile)
{
    p_pb_fea_qos_drop_profile->key->id = p_fea_qos_drop_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_qos_drop_profile->has_sai_drop_id = TRUE;
    p_pb_fea_qos_drop_profile->sai_drop_id = p_fea_qos_drop_profile->sai_drop_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_drop_profile_to_pb_free_packed(Cdb__TblFeaQosDropProfile *p_pb_fea_qos_drop_profile)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_drop_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaQosDropProfileKey pb_fea_qos_drop_profile_key = CDB__TBL_FEA_QOS_DROP_PROFILE_KEY__INIT;
    Cdb__TblFeaQosDropProfile pb_fea_qos_drop_profile = CDB__TBL_FEA_QOS_DROP_PROFILE__INIT;
    tbl_fea_qos_drop_profile_t *p_fea_qos_drop_profile = (tbl_fea_qos_drop_profile_t*)p_tbl;
    int32 len = 0;

    pb_fea_qos_drop_profile.key = &pb_fea_qos_drop_profile_key;
    pb_tbl_fea_qos_drop_profile_to_pb(only_key, p_fea_qos_drop_profile, &pb_fea_qos_drop_profile);
    len = cdb__tbl_fea_qos_drop_profile__pack(&pb_fea_qos_drop_profile, buf);
    pb_tbl_fea_qos_drop_profile_to_pb_free_packed(&pb_fea_qos_drop_profile);

    return len;
}

int32
pb_tbl_fea_qos_drop_profile_dump(Cdb__TblFeaQosDropProfile *p_pb_fea_qos_drop_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_fea_qos_drop_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/sai_drop_id=%llu", p_pb_fea_qos_drop_profile->sai_drop_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_QOS_DOMAIN */
int32
pb_tbl_fea_qos_domain_to_pb(uint32 only_key, tbl_fea_qos_domain_t *p_fea_qos_domain, Cdb__TblFeaQosDomain *p_pb_fea_qos_domain)
{
    p_pb_fea_qos_domain->key->id = p_fea_qos_domain->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_qos_domain->has_dot1p_to_tc_color_map_id = TRUE;
    p_pb_fea_qos_domain->dot1p_to_tc_color_map_id = p_fea_qos_domain->dot1p_to_tc_color_map_id;
    p_pb_fea_qos_domain->has_dscp_to_tc_color_map_id = TRUE;
    p_pb_fea_qos_domain->dscp_to_tc_color_map_id = p_fea_qos_domain->dscp_to_tc_color_map_id;
    p_pb_fea_qos_domain->has_tc_and_color_to_dot1p_map_id = TRUE;
    p_pb_fea_qos_domain->tc_and_color_to_dot1p_map_id = p_fea_qos_domain->tc_and_color_to_dot1p_map_id;
    p_pb_fea_qos_domain->has_tc_and_color_to_dscp_map_id = TRUE;
    p_pb_fea_qos_domain->tc_and_color_to_dscp_map_id = p_fea_qos_domain->tc_and_color_to_dscp_map_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_domain_to_pb_free_packed(Cdb__TblFeaQosDomain *p_pb_fea_qos_domain)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_domain_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaQosDomainKey pb_fea_qos_domain_key = CDB__TBL_FEA_QOS_DOMAIN_KEY__INIT;
    Cdb__TblFeaQosDomain pb_fea_qos_domain = CDB__TBL_FEA_QOS_DOMAIN__INIT;
    tbl_fea_qos_domain_t *p_fea_qos_domain = (tbl_fea_qos_domain_t*)p_tbl;
    int32 len = 0;

    pb_fea_qos_domain.key = &pb_fea_qos_domain_key;
    pb_tbl_fea_qos_domain_to_pb(only_key, p_fea_qos_domain, &pb_fea_qos_domain);
    len = cdb__tbl_fea_qos_domain__pack(&pb_fea_qos_domain, buf);
    pb_tbl_fea_qos_domain_to_pb_free_packed(&pb_fea_qos_domain);

    return len;
}

int32
pb_tbl_fea_qos_domain_dump(Cdb__TblFeaQosDomain *p_pb_fea_qos_domain, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_fea_qos_domain->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/dot1p_to_tc_color_map_id=%llu", p_pb_fea_qos_domain->dot1p_to_tc_color_map_id);
    offset += sal_sprintf(out + offset, "/dscp_to_tc_color_map_id=%llu", p_pb_fea_qos_domain->dscp_to_tc_color_map_id);
    offset += sal_sprintf(out + offset, "/tc_and_color_to_dot1p_map_id=%llu", p_pb_fea_qos_domain->tc_and_color_to_dot1p_map_id);
    offset += sal_sprintf(out + offset, "/tc_and_color_to_dscp_map_id=%llu", p_pb_fea_qos_domain->tc_and_color_to_dscp_map_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_QOS_QUEUE_SHAPE_PROFILE */
int32
pb_tbl_fea_qos_queue_shape_profile_to_pb(uint32 only_key, tbl_fea_qos_queue_shape_profile_t *p_fea_qos_queue_shape_profile, Cdb__TblFeaQosQueueShapeProfile *p_pb_fea_qos_queue_shape_profile)
{
    p_pb_fea_qos_queue_shape_profile->key->id = p_fea_qos_queue_shape_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_qos_queue_shape_profile->has_sai_scheduler_id = TRUE;
    p_pb_fea_qos_queue_shape_profile->sai_scheduler_id = p_fea_qos_queue_shape_profile->sai_scheduler_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_queue_shape_profile_to_pb_free_packed(Cdb__TblFeaQosQueueShapeProfile *p_pb_fea_qos_queue_shape_profile)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_queue_shape_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaQosQueueShapeProfileKey pb_fea_qos_queue_shape_profile_key = CDB__TBL_FEA_QOS_QUEUE_SHAPE_PROFILE_KEY__INIT;
    Cdb__TblFeaQosQueueShapeProfile pb_fea_qos_queue_shape_profile = CDB__TBL_FEA_QOS_QUEUE_SHAPE_PROFILE__INIT;
    tbl_fea_qos_queue_shape_profile_t *p_fea_qos_queue_shape_profile = (tbl_fea_qos_queue_shape_profile_t*)p_tbl;
    int32 len = 0;

    pb_fea_qos_queue_shape_profile.key = &pb_fea_qos_queue_shape_profile_key;
    pb_tbl_fea_qos_queue_shape_profile_to_pb(only_key, p_fea_qos_queue_shape_profile, &pb_fea_qos_queue_shape_profile);
    len = cdb__tbl_fea_qos_queue_shape_profile__pack(&pb_fea_qos_queue_shape_profile, buf);
    pb_tbl_fea_qos_queue_shape_profile_to_pb_free_packed(&pb_fea_qos_queue_shape_profile);

    return len;
}

int32
pb_tbl_fea_qos_queue_shape_profile_dump(Cdb__TblFeaQosQueueShapeProfile *p_pb_fea_qos_queue_shape_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_fea_qos_queue_shape_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/sai_scheduler_id=%llu", p_pb_fea_qos_queue_shape_profile->sai_scheduler_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_QOS_PORT_SHAPE_PROFILE */
int32
pb_tbl_fea_qos_port_shape_profile_to_pb(uint32 only_key, tbl_fea_qos_port_shape_profile_t *p_fea_qos_port_shape_profile, Cdb__TblFeaQosPortShapeProfile *p_pb_fea_qos_port_shape_profile)
{
    p_pb_fea_qos_port_shape_profile->key->id = p_fea_qos_port_shape_profile->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_qos_port_shape_profile->has_sai_scheduler_id = TRUE;
    p_pb_fea_qos_port_shape_profile->sai_scheduler_id = p_fea_qos_port_shape_profile->sai_scheduler_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_port_shape_profile_to_pb_free_packed(Cdb__TblFeaQosPortShapeProfile *p_pb_fea_qos_port_shape_profile)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_qos_port_shape_profile_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaQosPortShapeProfileKey pb_fea_qos_port_shape_profile_key = CDB__TBL_FEA_QOS_PORT_SHAPE_PROFILE_KEY__INIT;
    Cdb__TblFeaQosPortShapeProfile pb_fea_qos_port_shape_profile = CDB__TBL_FEA_QOS_PORT_SHAPE_PROFILE__INIT;
    tbl_fea_qos_port_shape_profile_t *p_fea_qos_port_shape_profile = (tbl_fea_qos_port_shape_profile_t*)p_tbl;
    int32 len = 0;

    pb_fea_qos_port_shape_profile.key = &pb_fea_qos_port_shape_profile_key;
    pb_tbl_fea_qos_port_shape_profile_to_pb(only_key, p_fea_qos_port_shape_profile, &pb_fea_qos_port_shape_profile);
    len = cdb__tbl_fea_qos_port_shape_profile__pack(&pb_fea_qos_port_shape_profile, buf);
    pb_tbl_fea_qos_port_shape_profile_to_pb_free_packed(&pb_fea_qos_port_shape_profile);

    return len;
}

int32
pb_tbl_fea_qos_port_shape_profile_dump(Cdb__TblFeaQosPortShapeProfile *p_pb_fea_qos_port_shape_profile, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_fea_qos_port_shape_profile->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/sai_scheduler_id=%llu", p_pb_fea_qos_port_shape_profile->sai_scheduler_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_PORT_POLICER_APPLY */
int32
pb_tbl_fea_port_policer_apply_to_pb(uint32 only_key, tbl_fea_port_policer_apply_t *p_fea_port_policer_apply, Cdb__TblFeaPortPolicerApply *p_pb_fea_port_policer_apply)
{
    p_pb_fea_port_policer_apply->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fea_port_policer_apply->key.name)+1);
    sal_strcpy(p_pb_fea_port_policer_apply->key->name, p_fea_port_policer_apply->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_port_policer_apply->has_in_policer_id = TRUE;
    p_pb_fea_port_policer_apply->in_policer_id = p_fea_port_policer_apply->in_policer_id;
    p_pb_fea_port_policer_apply->has_out_policer_id = TRUE;
    p_pb_fea_port_policer_apply->out_policer_id = p_fea_port_policer_apply->out_policer_id;

    return PM_E_NONE;
}

int32
pb_tbl_fea_port_policer_apply_to_pb_free_packed(Cdb__TblFeaPortPolicerApply *p_pb_fea_port_policer_apply)
{
    if (p_pb_fea_port_policer_apply->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fea_port_policer_apply->key->name);
        p_pb_fea_port_policer_apply->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fea_port_policer_apply_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaPortPolicerApplyKey pb_fea_port_policer_apply_key = CDB__TBL_FEA_PORT_POLICER_APPLY_KEY__INIT;
    Cdb__TblFeaPortPolicerApply pb_fea_port_policer_apply = CDB__TBL_FEA_PORT_POLICER_APPLY__INIT;
    tbl_fea_port_policer_apply_t *p_fea_port_policer_apply = (tbl_fea_port_policer_apply_t*)p_tbl;
    int32 len = 0;

    pb_fea_port_policer_apply.key = &pb_fea_port_policer_apply_key;
    pb_tbl_fea_port_policer_apply_to_pb(only_key, p_fea_port_policer_apply, &pb_fea_port_policer_apply);
    len = cdb__tbl_fea_port_policer_apply__pack(&pb_fea_port_policer_apply, buf);
    pb_tbl_fea_port_policer_apply_to_pb_free_packed(&pb_fea_port_policer_apply);

    return len;
}

int32
pb_tbl_fea_port_policer_apply_dump(Cdb__TblFeaPortPolicerApply *p_pb_fea_port_policer_apply, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_fea_port_policer_apply->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/in_policer_id=%llu", p_pb_fea_port_policer_apply->in_policer_id);
    offset += sal_sprintf(out + offset, "/out_policer_id=%llu", p_pb_fea_port_policer_apply->out_policer_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACLQOS_IF_STATS */
int32
pb_tbl_aclqos_if_stats_to_pb(uint32 only_key, tbl_aclqos_if_stats_t *p_aclqos_if_stats, Cdb__TblAclqosIfStats *p_pb_aclqos_if_stats)
{
    uint32 i = 0;

    p_pb_aclqos_if_stats->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if_stats->key.name)+1);
    sal_strcpy(p_pb_aclqos_if_stats->key->name, p_aclqos_if_stats->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_aclqos_if_stats->has_flags_port_get_input_policer_stats = TRUE;
    p_pb_aclqos_if_stats->flags_port_get_input_policer_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_GET_INPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->has_flags_port_get_output_policer_stats = TRUE;
    p_pb_aclqos_if_stats->flags_port_get_output_policer_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_GET_OUTPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->has_flags_port_clear_input_policer_stats = TRUE;
    p_pb_aclqos_if_stats->flags_port_clear_input_policer_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_CLEAR_INPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->has_flags_port_clear_output_policer_stats = TRUE;
    p_pb_aclqos_if_stats->flags_port_clear_output_policer_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_CLEAR_OUTPUT_POLICER) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->has_flags_get_queue_stats = TRUE;
    p_pb_aclqos_if_stats->flags_get_queue_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_GET_QUEUE) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->has_flags_clear_queue_stats = TRUE;
    p_pb_aclqos_if_stats->flags_clear_queue_stats = GLB_FLAG_ISSET(p_aclqos_if_stats->flags, GLB_ACLQOS_IF_STATS_FLAGS_PORT_CLEAR_QUEUE) ? TRUE : FALSE;
    p_pb_aclqos_if_stats->queue_transimt_pkt = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint64_t)*GLB_QOS_MAX_PORT_QUEUE_NUM);
    p_pb_aclqos_if_stats->n_queue_transimt_pkt = GLB_QOS_MAX_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_MAX_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if_stats->queue_transimt_pkt[i] = p_aclqos_if_stats->queue_transimt_pkt[i];
    }
    p_pb_aclqos_if_stats->queue_transimt_byte = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint64_t)*GLB_QOS_MAX_PORT_QUEUE_NUM);
    p_pb_aclqos_if_stats->n_queue_transimt_byte = GLB_QOS_MAX_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_MAX_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if_stats->queue_transimt_byte[i] = p_aclqos_if_stats->queue_transimt_byte[i];
    }
    p_pb_aclqos_if_stats->queue_drop_pkt = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint64_t)*GLB_QOS_MAX_PORT_QUEUE_NUM);
    p_pb_aclqos_if_stats->n_queue_drop_pkt = GLB_QOS_MAX_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_MAX_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if_stats->queue_drop_pkt[i] = p_aclqos_if_stats->queue_drop_pkt[i];
    }
    p_pb_aclqos_if_stats->queue_drop_byte = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint64_t)*GLB_QOS_MAX_PORT_QUEUE_NUM);
    p_pb_aclqos_if_stats->n_queue_drop_byte = GLB_QOS_MAX_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_MAX_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if_stats->queue_drop_byte[i] = p_aclqos_if_stats->queue_drop_byte[i];
    }
    p_pb_aclqos_if_stats->has_green_packet = TRUE;
    p_pb_aclqos_if_stats->green_packet = p_aclqos_if_stats->green_packet;
    p_pb_aclqos_if_stats->has_green_byte = TRUE;
    p_pb_aclqos_if_stats->green_byte = p_aclqos_if_stats->green_byte;
    p_pb_aclqos_if_stats->has_yellow_packet = TRUE;
    p_pb_aclqos_if_stats->yellow_packet = p_aclqos_if_stats->yellow_packet;
    p_pb_aclqos_if_stats->has_yellow_byte = TRUE;
    p_pb_aclqos_if_stats->yellow_byte = p_aclqos_if_stats->yellow_byte;
    p_pb_aclqos_if_stats->has_red_packet = TRUE;
    p_pb_aclqos_if_stats->red_packet = p_aclqos_if_stats->red_packet;
    p_pb_aclqos_if_stats->has_red_byte = TRUE;
    p_pb_aclqos_if_stats->red_byte = p_aclqos_if_stats->red_byte;
    p_pb_aclqos_if_stats->has_green_packet_out = TRUE;
    p_pb_aclqos_if_stats->green_packet_out = p_aclqos_if_stats->green_packet_out;
    p_pb_aclqos_if_stats->has_green_byte_out = TRUE;
    p_pb_aclqos_if_stats->green_byte_out = p_aclqos_if_stats->green_byte_out;
    p_pb_aclqos_if_stats->has_yellow_packet_out = TRUE;
    p_pb_aclqos_if_stats->yellow_packet_out = p_aclqos_if_stats->yellow_packet_out;
    p_pb_aclqos_if_stats->has_yellow_byte_out = TRUE;
    p_pb_aclqos_if_stats->yellow_byte_out = p_aclqos_if_stats->yellow_byte_out;
    p_pb_aclqos_if_stats->has_red_packet_out = TRUE;
    p_pb_aclqos_if_stats->red_packet_out = p_aclqos_if_stats->red_packet_out;
    p_pb_aclqos_if_stats->has_red_byte_out = TRUE;
    p_pb_aclqos_if_stats->red_byte_out = p_aclqos_if_stats->red_byte_out;

    return PM_E_NONE;
}

int32
pb_tbl_aclqos_if_stats_to_pb_free_packed(Cdb__TblAclqosIfStats *p_pb_aclqos_if_stats)
{
    if (p_pb_aclqos_if_stats->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if_stats->key->name);
        p_pb_aclqos_if_stats->key->name = NULL;
    }

    if (p_pb_aclqos_if_stats->queue_transimt_pkt)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if_stats->queue_transimt_pkt);
        p_pb_aclqos_if_stats->queue_transimt_pkt = NULL;
    }

    if (p_pb_aclqos_if_stats->queue_transimt_byte)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if_stats->queue_transimt_byte);
        p_pb_aclqos_if_stats->queue_transimt_byte = NULL;
    }

    if (p_pb_aclqos_if_stats->queue_drop_pkt)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if_stats->queue_drop_pkt);
        p_pb_aclqos_if_stats->queue_drop_pkt = NULL;
    }

    if (p_pb_aclqos_if_stats->queue_drop_byte)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if_stats->queue_drop_byte);
        p_pb_aclqos_if_stats->queue_drop_byte = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_aclqos_if_stats_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclqosIfStatsKey pb_aclqos_if_stats_key = CDB__TBL_ACLQOS_IF_STATS_KEY__INIT;
    Cdb__TblAclqosIfStats pb_aclqos_if_stats = CDB__TBL_ACLQOS_IF_STATS__INIT;
    tbl_aclqos_if_stats_t *p_aclqos_if_stats = (tbl_aclqos_if_stats_t*)p_tbl;
    int32 len = 0;

    pb_aclqos_if_stats.key = &pb_aclqos_if_stats_key;
    pb_tbl_aclqos_if_stats_to_pb(only_key, p_aclqos_if_stats, &pb_aclqos_if_stats);
    len = cdb__tbl_aclqos_if_stats__pack(&pb_aclqos_if_stats, buf);
    pb_tbl_aclqos_if_stats_to_pb_free_packed(&pb_aclqos_if_stats);

    return len;
}

int32
pb_tbl_aclqos_if_stats_dump(Cdb__TblAclqosIfStats *p_pb_aclqos_if_stats, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_aclqos_if_stats->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/flags_port_get_input_policer_stats=%u", p_pb_aclqos_if_stats->flags_port_get_input_policer_stats);
    offset += sal_sprintf(out + offset, "/flags_port_get_output_policer_stats=%u", p_pb_aclqos_if_stats->flags_port_get_output_policer_stats);
    offset += sal_sprintf(out + offset, "/flags_port_clear_input_policer_stats=%u", p_pb_aclqos_if_stats->flags_port_clear_input_policer_stats);
    offset += sal_sprintf(out + offset, "/flags_port_clear_output_policer_stats=%u", p_pb_aclqos_if_stats->flags_port_clear_output_policer_stats);
    offset += sal_sprintf(out + offset, "/flags_get_queue_stats=%u", p_pb_aclqos_if_stats->flags_get_queue_stats);
    offset += sal_sprintf(out + offset, "/flags_clear_queue_stats=%u", p_pb_aclqos_if_stats->flags_clear_queue_stats);
    offset += sal_sprintf(out + offset, "/queue_transimt_pkt=");
    offset += sal_sprintf(out + offset, "/queue_transimt_byte=");
    offset += sal_sprintf(out + offset, "/queue_drop_pkt=");
    offset += sal_sprintf(out + offset, "/queue_drop_byte=");
    offset += sal_sprintf(out + offset, "/green_packet=%llu", p_pb_aclqos_if_stats->green_packet);
    offset += sal_sprintf(out + offset, "/green_byte=%llu", p_pb_aclqos_if_stats->green_byte);
    offset += sal_sprintf(out + offset, "/yellow_packet=%llu", p_pb_aclqos_if_stats->yellow_packet);
    offset += sal_sprintf(out + offset, "/yellow_byte=%llu", p_pb_aclqos_if_stats->yellow_byte);
    offset += sal_sprintf(out + offset, "/red_packet=%llu", p_pb_aclqos_if_stats->red_packet);
    offset += sal_sprintf(out + offset, "/red_byte=%llu", p_pb_aclqos_if_stats->red_byte);
    offset += sal_sprintf(out + offset, "/green_packet_out=%llu", p_pb_aclqos_if_stats->green_packet_out);
    offset += sal_sprintf(out + offset, "/green_byte_out=%llu", p_pb_aclqos_if_stats->green_byte_out);
    offset += sal_sprintf(out + offset, "/yellow_packet_out=%llu", p_pb_aclqos_if_stats->yellow_packet_out);
    offset += sal_sprintf(out + offset, "/yellow_byte_out=%llu", p_pb_aclqos_if_stats->yellow_byte_out);
    offset += sal_sprintf(out + offset, "/red_packet_out=%llu", p_pb_aclqos_if_stats->red_packet_out);
    offset += sal_sprintf(out + offset, "/red_byte_out=%llu", p_pb_aclqos_if_stats->red_byte_out);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_VERSION */
int32
pb_tbl_version_to_pb(uint32 only_key, tbl_version_t *p_ver, Cdb__TblVersion *p_pb_ver)
{
    p_pb_ver->version = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ver->version)+1);
    sal_strcpy(p_pb_ver->version, p_ver->version);
    p_pb_ver->company = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ver->company)+1);
    sal_strcpy(p_pb_ver->company, p_ver->company);
    p_pb_ver->package = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ver->package)+1);
    sal_strcpy(p_pb_ver->package, p_ver->package);
    p_pb_ver->product = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ver->product)+1);
    sal_strcpy(p_pb_ver->product, p_ver->product);
    p_pb_ver->hw_type = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ver->hw_type)+1);
    sal_strcpy(p_pb_ver->hw_type, p_ver->hw_type);

    return PM_E_NONE;
}

int32
pb_tbl_version_to_pb_free_packed(Cdb__TblVersion *p_pb_ver)
{
    if (p_pb_ver->version)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ver->version);
        p_pb_ver->version = NULL;
    }

    if (p_pb_ver->company)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ver->company);
        p_pb_ver->company = NULL;
    }

    if (p_pb_ver->package)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ver->package);
        p_pb_ver->package = NULL;
    }

    if (p_pb_ver->product)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ver->product);
        p_pb_ver->product = NULL;
    }

    if (p_pb_ver->hw_type)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ver->hw_type);
        p_pb_ver->hw_type = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_version_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblVersion pb_ver = CDB__TBL_VERSION__INIT;
    tbl_version_t *p_ver = (tbl_version_t*)p_tbl;
    int32 len = 0;

    pb_tbl_version_to_pb(only_key, p_ver, &pb_ver);
    len = cdb__tbl_version__pack(&pb_ver, buf);
    pb_tbl_version_to_pb_free_packed(&pb_ver);

    return len;
}

int32
pb_tbl_version_dump(Cdb__TblVersion *p_pb_ver, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/version=%s", p_pb_ver->version);
    offset += sal_sprintf(out + offset, "/company=%s", p_pb_ver->company);
    offset += sal_sprintf(out + offset, "/package=%s", p_pb_ver->package);
    offset += sal_sprintf(out + offset, "/product=%s", p_pb_ver->product);
    offset += sal_sprintf(out + offset, "/hw_type=%s", p_pb_ver->hw_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_MANAGE_IF */
int32
pb_tbl_manage_if_to_pb(uint32 only_key, tbl_manage_if_t *p_mng_if, Cdb__TblManageIf *p_pb_mng_if)
{
    pb_compose_prefix_ipv4_t_to_pb(&p_mng_if->addr, p_pb_mng_if->addr);
    pb_compose_addr_ipv4_t_to_pb(&p_mng_if->gateway, p_pb_mng_if->gateway);

    return PM_E_NONE;
}

int32
pb_tbl_manage_if_to_pb_free_packed(Cdb__TblManageIf *p_pb_mng_if)
{
    pb_compose_prefix_ipv4_t_to_pb_free_packed(p_pb_mng_if->addr);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_mng_if->gateway);
    return PM_E_NONE;
}

int32
pb_tbl_manage_if_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblManageIf pb_mng_if = CDB__TBL_MANAGE_IF__INIT;
    tbl_manage_if_t *p_mng_if = (tbl_manage_if_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposePrefixIpv4T addr = CDB__COMPOSE_PREFIX_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T gateway = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_mng_if.addr = &addr;
    pb_mng_if.gateway = &gateway;
    pb_tbl_manage_if_to_pb(only_key, p_mng_if, &pb_mng_if);
    len = cdb__tbl_manage_if__pack(&pb_mng_if, buf);
    pb_tbl_manage_if_to_pb_free_packed(&pb_mng_if);

    return len;
}

int32
pb_tbl_manage_if_dump(Cdb__TblManageIf *p_pb_mng_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_prefix_ipv4_t_dump(p_pb_mng_if->addr, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_mng_if->gateway, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_BOOTIMAGE */
int32
pb_tbl_bootimage_to_pb(uint32 only_key, tbl_bootimage_t *p_boot, Cdb__TblBootimage *p_pb_boot)
{
    p_pb_boot->has_mode = TRUE;
    p_pb_boot->mode = p_boot->mode;
    p_pb_boot->image = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_boot->image)+1);
    sal_strcpy(p_pb_boot->image, p_boot->image);
    p_pb_boot->serverip = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_boot->serverip)+1);
    sal_strcpy(p_pb_boot->serverip, p_boot->serverip);
    p_pb_boot->ipaddr = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_boot->ipaddr)+1);
    sal_strcpy(p_pb_boot->ipaddr, p_boot->ipaddr);
    p_pb_boot->bootcmd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_boot->bootcmd)+1);
    sal_strcpy(p_pb_boot->bootcmd, p_boot->bootcmd);
    p_pb_boot->current_image = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_boot->current_image)+1);
    sal_strcpy(p_pb_boot->current_image, p_boot->current_image);

    return PM_E_NONE;
}

int32
pb_tbl_bootimage_to_pb_free_packed(Cdb__TblBootimage *p_pb_boot)
{
    if (p_pb_boot->image)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_boot->image);
        p_pb_boot->image = NULL;
    }

    if (p_pb_boot->serverip)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_boot->serverip);
        p_pb_boot->serverip = NULL;
    }

    if (p_pb_boot->ipaddr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_boot->ipaddr);
        p_pb_boot->ipaddr = NULL;
    }

    if (p_pb_boot->bootcmd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_boot->bootcmd);
        p_pb_boot->bootcmd = NULL;
    }

    if (p_pb_boot->current_image)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_boot->current_image);
        p_pb_boot->current_image = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_bootimage_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblBootimage pb_boot = CDB__TBL_BOOTIMAGE__INIT;
    tbl_bootimage_t *p_boot = (tbl_bootimage_t*)p_tbl;
    int32 len = 0;

    pb_tbl_bootimage_to_pb(only_key, p_boot, &pb_boot);
    len = cdb__tbl_bootimage__pack(&pb_boot, buf);
    pb_tbl_bootimage_to_pb_free_packed(&pb_boot);

    return len;
}

int32
pb_tbl_bootimage_dump(Cdb__TblBootimage *p_pb_boot, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_boot->mode);
    offset += sal_sprintf(out + offset, "/image=%s", p_pb_boot->image);
    offset += sal_sprintf(out + offset, "/serverip=%s", p_pb_boot->serverip);
    offset += sal_sprintf(out + offset, "/ipaddr=%s", p_pb_boot->ipaddr);
    offset += sal_sprintf(out + offset, "/bootcmd=%s", p_pb_boot->bootcmd);
    offset += sal_sprintf(out + offset, "/current_image=%s", p_pb_boot->current_image);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CHASSIS */
int32
pb_tbl_chassis_to_pb(uint32 only_key, tbl_chassis_t *p_chassis, Cdb__TblChassis *p_pb_chassis)
{
    p_pb_chassis->has_type = TRUE;
    p_pb_chassis->type = p_chassis->type;
    p_pb_chassis->has_slot_num = TRUE;
    p_pb_chassis->slot_num = p_chassis->slot_num;
    p_pb_chassis->has_cur_stm_mode = TRUE;
    p_pb_chassis->cur_stm_mode = p_chassis->cur_stm_mode;
    p_pb_chassis->has_next_stm_mode = TRUE;
    p_pb_chassis->next_stm_mode = p_chassis->next_stm_mode;
    p_pb_chassis->has_mac_num = TRUE;
    p_pb_chassis->mac_num = p_chassis->mac_num;
    pb_compose_mac_addr_t_to_pb(p_chassis->sys_mac, p_pb_chassis->sys_mac);
    p_pb_chassis->has_location_led = TRUE;
    p_pb_chassis->location_led = p_chassis->location_led;
    p_pb_chassis->has_reset_reboot_info = TRUE;
    p_pb_chassis->reset_reboot_info = p_chassis->reset_reboot_info;
    p_pb_chassis->has_support_reboot_info = TRUE;
    p_pb_chassis->support_reboot_info = p_chassis->support_reboot_info;
    p_pb_chassis->has_one_minute_reboot_alarm = TRUE;
    p_pb_chassis->one_minute_reboot_alarm = p_chassis->one_minute_reboot_alarm;

    return PM_E_NONE;
}

int32
pb_tbl_chassis_to_pb_free_packed(Cdb__TblChassis *p_pb_chassis)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_chassis->sys_mac);
    return PM_E_NONE;
}

int32
pb_tbl_chassis_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblChassis pb_chassis = CDB__TBL_CHASSIS__INIT;
    tbl_chassis_t *p_chassis = (tbl_chassis_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT sys_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_chassis.sys_mac = &sys_mac;
    pb_tbl_chassis_to_pb(only_key, p_chassis, &pb_chassis);
    len = cdb__tbl_chassis__pack(&pb_chassis, buf);
    pb_tbl_chassis_to_pb_free_packed(&pb_chassis);

    return len;
}

int32
pb_tbl_chassis_dump(Cdb__TblChassis *p_pb_chassis, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/type=%d", p_pb_chassis->type);
    offset += sal_sprintf(out + offset, "/slot_num=%d", p_pb_chassis->slot_num);
    offset += sal_sprintf(out + offset, "/cur_stm_mode=%d", p_pb_chassis->cur_stm_mode);
    offset += sal_sprintf(out + offset, "/next_stm_mode=%d", p_pb_chassis->next_stm_mode);
    offset += sal_sprintf(out + offset, "/mac_num=%d", p_pb_chassis->mac_num);
    offset += pb_compose_mac_addr_t_dump(p_pb_chassis->sys_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/location_led=%u", p_pb_chassis->location_led);
    offset += sal_sprintf(out + offset, "/reset_reboot_info=%u", p_pb_chassis->reset_reboot_info);
    offset += sal_sprintf(out + offset, "/support_reboot_info=%u", p_pb_chassis->support_reboot_info);
    offset += sal_sprintf(out + offset, "/one_minute_reboot_alarm=%u", p_pb_chassis->one_minute_reboot_alarm);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IFNAME_INFO */
int32
pb_tbl_ifname_info_to_pb(uint32 only_key, tbl_ifname_info_t *p_ifname_info, Cdb__TblIfnameInfo *p_pb_ifname_info)
{
    p_pb_ifname_info->key->id = p_ifname_info->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ifname_info->has_connection = TRUE;
    p_pb_ifname_info->connection = p_ifname_info->connection;
    p_pb_ifname_info->has_sub_connection = TRUE;
    p_pb_ifname_info->sub_connection = p_ifname_info->sub_connection;
    p_pb_ifname_info->has_prefix_num = TRUE;
    p_pb_ifname_info->prefix_num = p_ifname_info->prefix_num;
    p_pb_ifname_info->prefix = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ifname_info->prefix)+1);
    sal_strcpy(p_pb_ifname_info->prefix, p_ifname_info->prefix);
    p_pb_ifname_info->full_prefix = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ifname_info->full_prefix)+1);
    sal_strcpy(p_pb_ifname_info->full_prefix, p_ifname_info->full_prefix);

    return PM_E_NONE;
}

int32
pb_tbl_ifname_info_to_pb_free_packed(Cdb__TblIfnameInfo *p_pb_ifname_info)
{
    if (p_pb_ifname_info->prefix)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ifname_info->prefix);
        p_pb_ifname_info->prefix = NULL;
    }

    if (p_pb_ifname_info->full_prefix)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ifname_info->full_prefix);
        p_pb_ifname_info->full_prefix = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ifname_info_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIfnameInfoKey pb_ifname_info_key = CDB__TBL_IFNAME_INFO_KEY__INIT;
    Cdb__TblIfnameInfo pb_ifname_info = CDB__TBL_IFNAME_INFO__INIT;
    tbl_ifname_info_t *p_ifname_info = (tbl_ifname_info_t*)p_tbl;
    int32 len = 0;

    pb_ifname_info.key = &pb_ifname_info_key;
    pb_tbl_ifname_info_to_pb(only_key, p_ifname_info, &pb_ifname_info);
    len = cdb__tbl_ifname_info__pack(&pb_ifname_info, buf);
    pb_tbl_ifname_info_to_pb_free_packed(&pb_ifname_info);

    return len;
}

int32
pb_tbl_ifname_info_dump(Cdb__TblIfnameInfo *p_pb_ifname_info, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_ifname_info->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/connection=%d", p_pb_ifname_info->connection);
    offset += sal_sprintf(out + offset, "/sub_connection=%d", p_pb_ifname_info->sub_connection);
    offset += sal_sprintf(out + offset, "/prefix_num=%d", p_pb_ifname_info->prefix_num);
    offset += sal_sprintf(out + offset, "/prefix=%s", p_pb_ifname_info->prefix);
    offset += sal_sprintf(out + offset, "/full_prefix=%s", p_pb_ifname_info->full_prefix);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CARD */
int32
pb_tbl_card_to_pb(uint32 only_key, tbl_card_t *p_card, Cdb__TblCard *p_pb_card)
{
    p_pb_card->key->id = p_card->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_card->has_slot = TRUE;
    p_pb_card->slot = p_card->slot;
    p_pb_card->product_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->product_name)+1);
    sal_strcpy(p_pb_card->product_name, p_card->product_name);
    p_pb_card->hardware_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->hardware_name)+1);
    sal_strcpy(p_pb_card->hardware_name, p_card->hardware_name);
    p_pb_card->company_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->company_name)+1);
    sal_strcpy(p_pb_card->company_name, p_card->company_name);
    p_pb_card->package_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->package_name)+1);
    sal_strcpy(p_pb_card->package_name, p_card->package_name);
    p_pb_card->enterprise_oid = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->enterprise_oid)+1);
    sal_strcpy(p_pb_card->enterprise_oid, p_card->enterprise_oid);
    p_pb_card->hardware_type = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->hardware_type)+1);
    sal_strcpy(p_pb_card->hardware_type, p_card->hardware_type);
    p_pb_card->serial_no = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->serial_no)+1);
    sal_strcpy(p_pb_card->serial_no, p_card->serial_no);
    p_pb_card->bootrom_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->bootrom_ver)+1);
    sal_strcpy(p_pb_card->bootrom_ver, p_card->bootrom_ver);
    p_pb_card->epld_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->epld_ver)+1);
    sal_strcpy(p_pb_card->epld_ver, p_card->epld_ver);
    p_pb_card->sw_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->sw_ver)+1);
    sal_strcpy(p_pb_card->sw_ver, p_card->sw_ver);
    p_pb_card->hardware_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->hardware_ver)+1);
    sal_strcpy(p_pb_card->hardware_ver, p_card->hardware_ver);
    p_pb_card->bootcmd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->bootcmd)+1);
    sal_strcpy(p_pb_card->bootcmd, p_card->bootcmd);
    p_pb_card->has_flash_size = TRUE;
    p_pb_card->flash_size = p_card->flash_size;
    p_pb_card->has_dram_size = TRUE;
    p_pb_card->dram_size = p_card->dram_size;
    p_pb_card->has_port_num = TRUE;
    p_pb_card->port_num = p_card->port_num;
    p_pb_card->has_uptime_day = TRUE;
    p_pb_card->uptime_day = p_card->uptime_day;
    p_pb_card->has_uptime_hour = TRUE;
    p_pb_card->uptime_hour = p_card->uptime_hour;
    p_pb_card->has_uptime_min = TRUE;
    p_pb_card->uptime_min = p_card->uptime_min;
    pb_compose_sal_time_t_to_pb(&p_card->attach_time, p_pb_card->attach_time);
    p_pb_card->has_attach_count = TRUE;
    p_pb_card->attach_count = p_card->attach_count;
    p_pb_card->has_tmpr_low = TRUE;
    p_pb_card->tmpr_low = p_card->tmpr_low;
    p_pb_card->has_tmpr_high = TRUE;
    p_pb_card->tmpr_high = p_card->tmpr_high;
    p_pb_card->has_tmpr_critical = TRUE;
    p_pb_card->tmpr_critical = p_card->tmpr_critical;
    p_pb_card->has_status = TRUE;
    p_pb_card->status = p_card->status;
    p_pb_card->has_reboot = TRUE;
    p_pb_card->reboot = p_card->reboot;
    p_pb_card->update_epld_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->update_epld_name)+1);
    sal_strcpy(p_pb_card->update_epld_name, p_card->update_epld_name);
    p_pb_card->update_bootrom_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_card->update_bootrom_name)+1);
    sal_strcpy(p_pb_card->update_bootrom_name, p_card->update_bootrom_name);
    p_pb_card->has_platform_type = TRUE;
    p_pb_card->platform_type = p_card->platform_type;

    return PM_E_NONE;
}

int32
pb_tbl_card_to_pb_free_packed(Cdb__TblCard *p_pb_card)
{
    if (p_pb_card->product_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->product_name);
        p_pb_card->product_name = NULL;
    }

    if (p_pb_card->hardware_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->hardware_name);
        p_pb_card->hardware_name = NULL;
    }

    if (p_pb_card->company_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->company_name);
        p_pb_card->company_name = NULL;
    }

    if (p_pb_card->package_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->package_name);
        p_pb_card->package_name = NULL;
    }

    if (p_pb_card->enterprise_oid)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->enterprise_oid);
        p_pb_card->enterprise_oid = NULL;
    }

    if (p_pb_card->hardware_type)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->hardware_type);
        p_pb_card->hardware_type = NULL;
    }

    if (p_pb_card->serial_no)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->serial_no);
        p_pb_card->serial_no = NULL;
    }

    if (p_pb_card->bootrom_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->bootrom_ver);
        p_pb_card->bootrom_ver = NULL;
    }

    if (p_pb_card->epld_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->epld_ver);
        p_pb_card->epld_ver = NULL;
    }

    if (p_pb_card->sw_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->sw_ver);
        p_pb_card->sw_ver = NULL;
    }

    if (p_pb_card->hardware_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->hardware_ver);
        p_pb_card->hardware_ver = NULL;
    }

    if (p_pb_card->bootcmd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->bootcmd);
        p_pb_card->bootcmd = NULL;
    }

    pb_compose_sal_time_t_to_pb_free_packed(p_pb_card->attach_time);
    if (p_pb_card->update_epld_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->update_epld_name);
        p_pb_card->update_epld_name = NULL;
    }

    if (p_pb_card->update_bootrom_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_card->update_bootrom_name);
        p_pb_card->update_bootrom_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_card_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCardKey pb_card_key = CDB__TBL_CARD_KEY__INIT;
    Cdb__TblCard pb_card = CDB__TBL_CARD__INIT;
    tbl_card_t *p_card = (tbl_card_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeSalTimeT attach_time = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_card.key = &pb_card_key;
    pb_card.attach_time = &attach_time;
    pb_tbl_card_to_pb(only_key, p_card, &pb_card);
    len = cdb__tbl_card__pack(&pb_card, buf);
    pb_tbl_card_to_pb_free_packed(&pb_card);

    return len;
}

int32
pb_tbl_card_dump(Cdb__TblCard *p_pb_card, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_card->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot=%u", p_pb_card->slot);
    offset += sal_sprintf(out + offset, "/product_name=%s", p_pb_card->product_name);
    offset += sal_sprintf(out + offset, "/hardware_name=%s", p_pb_card->hardware_name);
    offset += sal_sprintf(out + offset, "/company_name=%s", p_pb_card->company_name);
    offset += sal_sprintf(out + offset, "/package_name=%s", p_pb_card->package_name);
    offset += sal_sprintf(out + offset, "/enterprise_oid=%s", p_pb_card->enterprise_oid);
    offset += sal_sprintf(out + offset, "/hardware_type=%s", p_pb_card->hardware_type);
    offset += sal_sprintf(out + offset, "/serial_no=%s", p_pb_card->serial_no);
    offset += sal_sprintf(out + offset, "/bootrom_ver=%s", p_pb_card->bootrom_ver);
    offset += sal_sprintf(out + offset, "/epld_ver=%s", p_pb_card->epld_ver);
    offset += sal_sprintf(out + offset, "/sw_ver=%s", p_pb_card->sw_ver);
    offset += sal_sprintf(out + offset, "/hardware_ver=%s", p_pb_card->hardware_ver);
    offset += sal_sprintf(out + offset, "/bootcmd=%s", p_pb_card->bootcmd);
    offset += sal_sprintf(out + offset, "/flash_size=%d", p_pb_card->flash_size);
    offset += sal_sprintf(out + offset, "/dram_size=%d", p_pb_card->dram_size);
    offset += sal_sprintf(out + offset, "/port_num=%d", p_pb_card->port_num);
    offset += sal_sprintf(out + offset, "/uptime_day=%d", p_pb_card->uptime_day);
    offset += sal_sprintf(out + offset, "/uptime_hour=%d", p_pb_card->uptime_hour);
    offset += sal_sprintf(out + offset, "/uptime_min=%d", p_pb_card->uptime_min);
    offset += pb_compose_sal_time_t_dump(p_pb_card->attach_time, (out + offset));
    offset += sal_sprintf(out + offset, "/attach_count=%u", p_pb_card->attach_count);
    offset += sal_sprintf(out + offset, "/tmpr_low=%d", p_pb_card->tmpr_low);
    offset += sal_sprintf(out + offset, "/tmpr_high=%d", p_pb_card->tmpr_high);
    offset += sal_sprintf(out + offset, "/tmpr_critical=%d", p_pb_card->tmpr_critical);
    offset += sal_sprintf(out + offset, "/status=%u", p_pb_card->status);
    offset += sal_sprintf(out + offset, "/reboot=%u", p_pb_card->reboot);
    offset += sal_sprintf(out + offset, "/update_epld_name=%s", p_pb_card->update_epld_name);
    offset += sal_sprintf(out + offset, "/update_bootrom_name=%s", p_pb_card->update_bootrom_name);
    offset += sal_sprintf(out + offset, "/platform_type=%d", p_pb_card->platform_type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PORT */
int32
pb_tbl_port_to_pb(uint32 only_key, tbl_port_t *p_port, Cdb__TblPort *p_pb_port)
{
    p_pb_port->key->port_id = p_port->key.port_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_port->has_slot_no = TRUE;
    p_pb_port->slot_no = p_port->slot_no;
    p_pb_port->has_panel_port_no = TRUE;
    p_pb_port->panel_port_no = p_port->panel_port_no;
    p_pb_port->has_panel_sub_port_no = TRUE;
    p_pb_port->panel_sub_port_no = p_port->panel_sub_port_no;
    p_pb_port->has_phy_type = TRUE;
    p_pb_port->phy_type = p_port->phy_type;
    p_pb_port->has_phyinfo_flag = TRUE;
    p_pb_port->phyinfo_flag = p_port->phyinfo_flag;
    p_pb_port->has_speed_capbility = TRUE;
    p_pb_port->speed_capbility = p_port->speed_capbility;
    p_pb_port->has_logic_port_id = TRUE;
    p_pb_port->logic_port_id = p_port->logic_port_id;
    p_pb_port->has_media = TRUE;
    p_pb_port->media = p_port->media;
    p_pb_port->has_port_media_type = TRUE;
    p_pb_port->port_media_type = p_port->port_media_type;
    p_pb_port->has_support_media_switch = TRUE;
    p_pb_port->support_media_switch = p_port->support_media_switch;
    p_pb_port->has_split_type = TRUE;
    p_pb_port->split_type = p_port->split_type;
    p_pb_port->has_training_enable = TRUE;
    p_pb_port->training_enable = p_port->training_enable;
    p_pb_port->has_training_status = TRUE;
    p_pb_port->training_status = p_port->training_status;
    p_pb_port->has_present_status = TRUE;
    p_pb_port->present_status = p_port->present_status;
    p_pb_port->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_port->name)+1);
    sal_strcpy(p_pb_port->name, p_port->name);
    pb_compose_mac_addr_t_to_pb(p_port->mac, p_pb_port->mac);

    return PM_E_NONE;
}

int32
pb_tbl_port_to_pb_free_packed(Cdb__TblPort *p_pb_port)
{
    if (p_pb_port->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_port->name);
        p_pb_port->name = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_port->mac);
    return PM_E_NONE;
}

int32
pb_tbl_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPortKey pb_port_key = CDB__TBL_PORT_KEY__INIT;
    Cdb__TblPort pb_port = CDB__TBL_PORT__INIT;
    tbl_port_t *p_port = (tbl_port_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_port.key = &pb_port_key;
    pb_port.mac = &mac;
    pb_tbl_port_to_pb(only_key, p_port, &pb_port);
    len = cdb__tbl_port__pack(&pb_port, buf);
    pb_tbl_port_to_pb_free_packed(&pb_port);

    return len;
}

int32
pb_tbl_port_dump(Cdb__TblPort *p_pb_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->port_id=%d", p_pb_port->key->port_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot_no=%d", p_pb_port->slot_no);
    offset += sal_sprintf(out + offset, "/panel_port_no=%d", p_pb_port->panel_port_no);
    offset += sal_sprintf(out + offset, "/panel_sub_port_no=%d", p_pb_port->panel_sub_port_no);
    offset += sal_sprintf(out + offset, "/phy_type=%d", p_pb_port->phy_type);
    offset += sal_sprintf(out + offset, "/phyinfo_flag=%d", p_pb_port->phyinfo_flag);
    offset += sal_sprintf(out + offset, "/speed_capbility=%d", p_pb_port->speed_capbility);
    offset += sal_sprintf(out + offset, "/logic_port_id=%d", p_pb_port->logic_port_id);
    offset += sal_sprintf(out + offset, "/media=%d", p_pb_port->media);
    offset += sal_sprintf(out + offset, "/port_media_type=%d", p_pb_port->port_media_type);
    offset += sal_sprintf(out + offset, "/support_media_switch=%d", p_pb_port->support_media_switch);
    offset += sal_sprintf(out + offset, "/split_type=%d", p_pb_port->split_type);
    offset += sal_sprintf(out + offset, "/training_enable=%d", p_pb_port->training_enable);
    offset += sal_sprintf(out + offset, "/training_status=%d", p_pb_port->training_status);
    offset += sal_sprintf(out + offset, "/present_status=%d", p_pb_port->present_status);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_port->name);
    offset += pb_compose_mac_addr_t_dump(p_pb_port->mac, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FIBER */
int32
pb_tbl_fiber_to_pb(uint32 only_key, tbl_fiber_t *p_fiber, Cdb__TblFiber *p_pb_fiber)
{
    uint32 i = 0;

    p_pb_fiber->key->port_id = p_fiber->key.port_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fiber->interface_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->interface_name)+1);
    sal_strcpy(p_pb_fiber->interface_name, p_fiber->interface_name);
    p_pb_fiber->fiber_type_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->fiber_type_name)+1);
    sal_strcpy(p_pb_fiber->fiber_type_name, p_fiber->fiber_type_name);
    p_pb_fiber->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->name)+1);
    sal_strcpy(p_pb_fiber->name, p_fiber->name);
    p_pb_fiber->has_oui = TRUE;
    p_pb_fiber->oui.len = sizeof(p_fiber->oui);
    p_pb_fiber->oui.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_fiber->oui));
    sal_memcpy(p_pb_fiber->oui.data, p_fiber->oui, sizeof(p_fiber->oui));
    p_pb_fiber->pn = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->pn)+1);
    sal_strcpy(p_pb_fiber->pn, p_fiber->pn);
    p_pb_fiber->rev = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->rev)+1);
    sal_strcpy(p_pb_fiber->rev, p_fiber->rev);
    p_pb_fiber->sn = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fiber->sn)+1);
    sal_strcpy(p_pb_fiber->sn, p_fiber->sn);
    p_pb_fiber->has_compliance_code = TRUE;
    p_pb_fiber->compliance_code.len = sizeof(p_fiber->compliance_code);
    p_pb_fiber->compliance_code.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_fiber->compliance_code));
    sal_memcpy(p_pb_fiber->compliance_code.data, p_fiber->compliance_code, sizeof(p_fiber->compliance_code));
    p_pb_fiber->has_slot = TRUE;
    p_pb_fiber->slot = p_fiber->slot;
    p_pb_fiber->tmpr = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_tmpr = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->tmpr[i] = p_fiber->tmpr[i];
    }
    p_pb_fiber->voltage = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_voltage = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->voltage[i] = p_fiber->voltage[i];
    }
    p_pb_fiber->bias = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_bias = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->bias[i] = p_fiber->bias[i];
    }
    p_pb_fiber->tx_pwr = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_tx_pwr = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->tx_pwr[i] = p_fiber->tx_pwr[i];
    }
    p_pb_fiber->rx_pwr = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_rx_pwr = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->rx_pwr[i] = p_fiber->rx_pwr[i];
    }
    p_pb_fiber->tmpr2 = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_tmpr2 = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->tmpr2[i] = p_fiber->tmpr2[i];
    }
    p_pb_fiber->voltage2 = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_voltage2 = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->voltage2[i] = p_fiber->voltage2[i];
    }
    p_pb_fiber->bias2 = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_bias2 = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->bias2[i] = p_fiber->bias2[i];
    }
    p_pb_fiber->tx_pwr2 = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_tx_pwr2 = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->tx_pwr2[i] = p_fiber->tx_pwr2[i];
    }
    p_pb_fiber->rx_pwr2 = XCALLOC(MEM_LIB_PROTOBUF, sizeof(double)*4);
    p_pb_fiber->n_rx_pwr2 = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->rx_pwr2[i] = p_fiber->rx_pwr2[i];
    }
    p_pb_fiber->alarm_flag = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*4);
    p_pb_fiber->n_alarm_flag = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->alarm_flag[i] = p_fiber->alarm_flag[i];
    }
    p_pb_fiber->warn_flag = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*4);
    p_pb_fiber->n_warn_flag = 4;
    for (i = 0; i < 4; i++)
    {
        p_pb_fiber->warn_flag[i] = p_fiber->warn_flag[i];
    }
    p_pb_fiber->has_update_cnt = TRUE;
    p_pb_fiber->update_cnt = p_fiber->update_cnt;
    p_pb_fiber->has_channel_num = TRUE;
    p_pb_fiber->channel_num = p_fiber->channel_num;
    p_pb_fiber->has_channel_idx = TRUE;
    p_pb_fiber->channel_idx = p_fiber->channel_idx;
    p_pb_fiber->has_is_detail = TRUE;
    p_pb_fiber->is_detail = p_fiber->is_detail;
    p_pb_fiber->has_fiber_type = TRUE;
    p_pb_fiber->fiber_type = p_fiber->fiber_type;
    p_pb_fiber->has_speed = TRUE;
    p_pb_fiber->speed = p_fiber->speed;
    p_pb_fiber->has_ddm_support = TRUE;
    p_pb_fiber->ddm_support = p_fiber->ddm_support;
    p_pb_fiber->has_externally_calibrated = TRUE;
    p_pb_fiber->externally_calibrated = p_fiber->externally_calibrated;
    p_pb_fiber->has_wavelength = TRUE;
    p_pb_fiber->wavelength.len = sizeof(p_fiber->wavelength);
    p_pb_fiber->wavelength.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_fiber->wavelength));
    sal_memcpy(p_pb_fiber->wavelength.data, p_fiber->wavelength, sizeof(p_fiber->wavelength));
    p_pb_fiber->has_length = TRUE;
    p_pb_fiber->length.len = sizeof(p_fiber->length);
    p_pb_fiber->length.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_fiber->length));
    sal_memcpy(p_pb_fiber->length.data, p_fiber->length, sizeof(p_fiber->length));

    return PM_E_NONE;
}

int32
pb_tbl_fiber_to_pb_free_packed(Cdb__TblFiber *p_pb_fiber)
{
    if (p_pb_fiber->interface_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->interface_name);
        p_pb_fiber->interface_name = NULL;
    }

    if (p_pb_fiber->fiber_type_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->fiber_type_name);
        p_pb_fiber->fiber_type_name = NULL;
    }

    if (p_pb_fiber->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->name);
        p_pb_fiber->name = NULL;
    }

    if (p_pb_fiber->oui.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->oui.data);
        p_pb_fiber->oui.data = NULL;
    }

    if (p_pb_fiber->pn)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->pn);
        p_pb_fiber->pn = NULL;
    }

    if (p_pb_fiber->rev)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->rev);
        p_pb_fiber->rev = NULL;
    }

    if (p_pb_fiber->sn)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->sn);
        p_pb_fiber->sn = NULL;
    }

    if (p_pb_fiber->compliance_code.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->compliance_code.data);
        p_pb_fiber->compliance_code.data = NULL;
    }

    if (p_pb_fiber->tmpr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->tmpr);
        p_pb_fiber->tmpr = NULL;
    }

    if (p_pb_fiber->voltage)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->voltage);
        p_pb_fiber->voltage = NULL;
    }

    if (p_pb_fiber->bias)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->bias);
        p_pb_fiber->bias = NULL;
    }

    if (p_pb_fiber->tx_pwr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->tx_pwr);
        p_pb_fiber->tx_pwr = NULL;
    }

    if (p_pb_fiber->rx_pwr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->rx_pwr);
        p_pb_fiber->rx_pwr = NULL;
    }

    if (p_pb_fiber->tmpr2)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->tmpr2);
        p_pb_fiber->tmpr2 = NULL;
    }

    if (p_pb_fiber->voltage2)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->voltage2);
        p_pb_fiber->voltage2 = NULL;
    }

    if (p_pb_fiber->bias2)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->bias2);
        p_pb_fiber->bias2 = NULL;
    }

    if (p_pb_fiber->tx_pwr2)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->tx_pwr2);
        p_pb_fiber->tx_pwr2 = NULL;
    }

    if (p_pb_fiber->rx_pwr2)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->rx_pwr2);
        p_pb_fiber->rx_pwr2 = NULL;
    }

    if (p_pb_fiber->alarm_flag)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->alarm_flag);
        p_pb_fiber->alarm_flag = NULL;
    }

    if (p_pb_fiber->warn_flag)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->warn_flag);
        p_pb_fiber->warn_flag = NULL;
    }

    if (p_pb_fiber->wavelength.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->wavelength.data);
        p_pb_fiber->wavelength.data = NULL;
    }

    if (p_pb_fiber->length.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fiber->length.data);
        p_pb_fiber->length.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fiber_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFiberKey pb_fiber_key = CDB__TBL_FIBER_KEY__INIT;
    Cdb__TblFiber pb_fiber = CDB__TBL_FIBER__INIT;
    tbl_fiber_t *p_fiber = (tbl_fiber_t*)p_tbl;
    int32 len = 0;

    pb_fiber.key = &pb_fiber_key;
    pb_tbl_fiber_to_pb(only_key, p_fiber, &pb_fiber);
    len = cdb__tbl_fiber__pack(&pb_fiber, buf);
    pb_tbl_fiber_to_pb_free_packed(&pb_fiber);

    return len;
}

int32
pb_tbl_fiber_dump(Cdb__TblFiber *p_pb_fiber, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->port_id=%d", p_pb_fiber->key->port_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/interface_name=%s", p_pb_fiber->interface_name);
    offset += sal_sprintf(out + offset, "/fiber_type_name=%s", p_pb_fiber->fiber_type_name);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_fiber->name);
    offset += sal_sprintf(out + offset, "/oui=");
    offset += pb_uint8_array_dump(p_pb_fiber->oui.data, p_pb_fiber->oui.len, (out + offset));
    offset += sal_sprintf(out + offset, "/pn=%s", p_pb_fiber->pn);
    offset += sal_sprintf(out + offset, "/rev=%s", p_pb_fiber->rev);
    offset += sal_sprintf(out + offset, "/sn=%s", p_pb_fiber->sn);
    offset += sal_sprintf(out + offset, "/compliance_code=");
    offset += pb_uint8_array_dump(p_pb_fiber->compliance_code.data, p_pb_fiber->compliance_code.len, (out + offset));
    offset += sal_sprintf(out + offset, "/slot=%d", p_pb_fiber->slot);
    offset += sal_sprintf(out + offset, "/tmpr=");
    offset += pb_double_array_dump(p_pb_fiber->tmpr, sizeof(p_pb_fiber->tmpr), (out + offset));
    offset += sal_sprintf(out + offset, "/voltage=");
    offset += pb_double_array_dump(p_pb_fiber->voltage, sizeof(p_pb_fiber->voltage), (out + offset));
    offset += sal_sprintf(out + offset, "/bias=");
    offset += pb_double_array_dump(p_pb_fiber->bias, sizeof(p_pb_fiber->bias), (out + offset));
    offset += sal_sprintf(out + offset, "/tx_pwr=");
    offset += pb_double_array_dump(p_pb_fiber->tx_pwr, sizeof(p_pb_fiber->tx_pwr), (out + offset));
    offset += sal_sprintf(out + offset, "/rx_pwr=");
    offset += pb_double_array_dump(p_pb_fiber->rx_pwr, sizeof(p_pb_fiber->rx_pwr), (out + offset));
    offset += sal_sprintf(out + offset, "/tmpr2=");
    offset += pb_double_array_dump(p_pb_fiber->tmpr2, sizeof(p_pb_fiber->tmpr2), (out + offset));
    offset += sal_sprintf(out + offset, "/voltage2=");
    offset += pb_double_array_dump(p_pb_fiber->voltage2, sizeof(p_pb_fiber->voltage2), (out + offset));
    offset += sal_sprintf(out + offset, "/bias2=");
    offset += pb_double_array_dump(p_pb_fiber->bias2, sizeof(p_pb_fiber->bias2), (out + offset));
    offset += sal_sprintf(out + offset, "/tx_pwr2=");
    offset += pb_double_array_dump(p_pb_fiber->tx_pwr2, sizeof(p_pb_fiber->tx_pwr2), (out + offset));
    offset += sal_sprintf(out + offset, "/rx_pwr2=");
    offset += pb_double_array_dump(p_pb_fiber->rx_pwr2, sizeof(p_pb_fiber->rx_pwr2), (out + offset));
    offset += sal_sprintf(out + offset, "/alarm_flag=");
    offset += pb_uint32_array_dump(p_pb_fiber->alarm_flag, sizeof(p_pb_fiber->alarm_flag), (out + offset));
    offset += sal_sprintf(out + offset, "/warn_flag=");
    offset += pb_uint32_array_dump(p_pb_fiber->warn_flag, sizeof(p_pb_fiber->warn_flag), (out + offset));
    offset += sal_sprintf(out + offset, "/update_cnt=%u", p_pb_fiber->update_cnt);
    offset += sal_sprintf(out + offset, "/channel_num=%u", p_pb_fiber->channel_num);
    offset += sal_sprintf(out + offset, "/channel_idx=%u", p_pb_fiber->channel_idx);
    offset += sal_sprintf(out + offset, "/is_detail=%u", p_pb_fiber->is_detail);
    offset += sal_sprintf(out + offset, "/fiber_type=%u", p_pb_fiber->fiber_type);
    offset += sal_sprintf(out + offset, "/speed=%u", p_pb_fiber->speed);
    offset += sal_sprintf(out + offset, "/ddm_support=%u", p_pb_fiber->ddm_support);
    offset += sal_sprintf(out + offset, "/externally_calibrated=%u", p_pb_fiber->externally_calibrated);
    offset += sal_sprintf(out + offset, "/wavelength=");
    offset += pb_uint8_array_dump(p_pb_fiber->wavelength.data, p_pb_fiber->wavelength.len, (out + offset));
    offset += sal_sprintf(out + offset, "/length=");
    offset += pb_uint8_array_dump(p_pb_fiber->length.data, p_pb_fiber->length.len, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SYS_SPEC */
int32
pb_tbl_sys_spec_to_pb(uint32 only_key, tbl_sys_spec_t *p_sys_spec, Cdb__TblSysSpec *p_pb_sys_spec)
{
    p_pb_sys_spec->key->type = p_sys_spec->key.type;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_sys_spec->has_ucast_fdb = TRUE;
    p_pb_sys_spec->ucast_fdb = p_sys_spec->ucast_fdb;
    p_pb_sys_spec->has_static_fdb = TRUE;
    p_pb_sys_spec->static_fdb = p_sys_spec->static_fdb;
    p_pb_sys_spec->has_mstp_instance = TRUE;
    p_pb_sys_spec->mstp_instance = p_sys_spec->mstp_instance;
    p_pb_sys_spec->has_vlan_instance = TRUE;
    p_pb_sys_spec->vlan_instance = p_sys_spec->vlan_instance;
    p_pb_sys_spec->has_mac_filter = TRUE;
    p_pb_sys_spec->mac_filter = p_sys_spec->mac_filter;
    p_pb_sys_spec->has_mac_based_vlan_class = TRUE;
    p_pb_sys_spec->mac_based_vlan_class = p_sys_spec->mac_based_vlan_class;
    p_pb_sys_spec->has_ipv4_based_vlan_class = TRUE;
    p_pb_sys_spec->ipv4_based_vlan_class = p_sys_spec->ipv4_based_vlan_class;
    p_pb_sys_spec->has_ipv4_source_guard = TRUE;
    p_pb_sys_spec->ipv4_source_guard = p_sys_spec->ipv4_source_guard;
    p_pb_sys_spec->has_vlan_mapping_entry_applied_port = TRUE;
    p_pb_sys_spec->vlan_mapping_entry_applied_port = p_sys_spec->vlan_mapping_entry_applied_port;
    p_pb_sys_spec->has_dot1x_mac = TRUE;
    p_pb_sys_spec->dot1x_mac = p_sys_spec->dot1x_mac;
    p_pb_sys_spec->has_remote_routes = TRUE;
    p_pb_sys_spec->remote_routes = p_sys_spec->remote_routes;
    p_pb_sys_spec->has_host_routes = TRUE;
    p_pb_sys_spec->host_routes = p_sys_spec->host_routes;
    p_pb_sys_spec->has_ecmp_routes = TRUE;
    p_pb_sys_spec->ecmp_routes = p_sys_spec->ecmp_routes;
    p_pb_sys_spec->has_pbr_entries = TRUE;
    p_pb_sys_spec->pbr_entries = p_sys_spec->pbr_entries;
    p_pb_sys_spec->has_l2mc_entries = TRUE;
    p_pb_sys_spec->l2mc_entries = p_sys_spec->l2mc_entries;
    p_pb_sys_spec->has_l3mc_entries = TRUE;
    p_pb_sys_spec->l3mc_entries = p_sys_spec->l3mc_entries;
    p_pb_sys_spec->has_l2mc_member_ports = TRUE;
    p_pb_sys_spec->l2mc_member_ports = p_sys_spec->l2mc_member_ports;
    p_pb_sys_spec->has_l3mc_member_ports = TRUE;
    p_pb_sys_spec->l3mc_member_ports = p_sys_spec->l3mc_member_ports;
    p_pb_sys_spec->has_vlan_member_ports = TRUE;
    p_pb_sys_spec->vlan_member_ports = p_sys_spec->vlan_member_ports;
    p_pb_sys_spec->has_voice_vlan = TRUE;
    p_pb_sys_spec->voice_vlan = p_sys_spec->voice_vlan;
    p_pb_sys_spec->has_flow_entries_ingress = TRUE;
    p_pb_sys_spec->flow_entries_ingress = p_sys_spec->flow_entries_ingress;
    p_pb_sys_spec->has_flow_entries_egress = TRUE;
    p_pb_sys_spec->flow_entries_egress = p_sys_spec->flow_entries_egress;
    p_pb_sys_spec->has_cfm_local_and_remote_meps = TRUE;
    p_pb_sys_spec->cfm_local_and_remote_meps = p_sys_spec->cfm_local_and_remote_meps;
    p_pb_sys_spec->has_g8031_groups = TRUE;
    p_pb_sys_spec->g8031_groups = p_sys_spec->g8031_groups;
    p_pb_sys_spec->has_g8032_rings = TRUE;
    p_pb_sys_spec->g8032_rings = p_sys_spec->g8032_rings;
    p_pb_sys_spec->has_g8032_member_ports_per_ring = TRUE;
    p_pb_sys_spec->g8032_member_ports_per_ring = p_sys_spec->g8032_member_ports_per_ring;
    p_pb_sys_spec->has_ftn_entries = TRUE;
    p_pb_sys_spec->ftn_entries = p_sys_spec->ftn_entries;
    p_pb_sys_spec->has_ilm_entries = TRUE;
    p_pb_sys_spec->ilm_entries = p_sys_spec->ilm_entries;
    p_pb_sys_spec->has_mpls_lables = TRUE;
    p_pb_sys_spec->mpls_lables = p_sys_spec->mpls_lables;
    p_pb_sys_spec->has_vpws = TRUE;
    p_pb_sys_spec->vpws = p_sys_spec->vpws;
    p_pb_sys_spec->has_lsp_pe = TRUE;
    p_pb_sys_spec->lsp_pe = p_sys_spec->lsp_pe;
    p_pb_sys_spec->has_lsp_p = TRUE;
    p_pb_sys_spec->lsp_p = p_sys_spec->lsp_p;
    p_pb_sys_spec->has_vpls_peer = TRUE;
    p_pb_sys_spec->vpls_peer = p_sys_spec->vpls_peer;
    p_pb_sys_spec->has_vpls_ac = TRUE;
    p_pb_sys_spec->vpls_ac = p_sys_spec->vpls_ac;
    p_pb_sys_spec->has_vsi = TRUE;
    p_pb_sys_spec->vsi = p_sys_spec->vsi;
    p_pb_sys_spec->has_lsp_oam = TRUE;
    p_pb_sys_spec->lsp_oam = p_sys_spec->lsp_oam;
    p_pb_sys_spec->has_pw_oam = TRUE;
    p_pb_sys_spec->pw_oam = p_sys_spec->pw_oam;
    p_pb_sys_spec->has_mpls_aps_tunnel = TRUE;
    p_pb_sys_spec->mpls_aps_tunnel = p_sys_spec->mpls_aps_tunnel;
    p_pb_sys_spec->has_cfm_lck = TRUE;
    p_pb_sys_spec->cfm_lck = p_sys_spec->cfm_lck;
    p_pb_sys_spec->has_ip_tunnel = TRUE;
    p_pb_sys_spec->ip_tunnel = p_sys_spec->ip_tunnel;
    p_pb_sys_spec->has_ivi_peers = TRUE;
    p_pb_sys_spec->ivi_peers = p_sys_spec->ivi_peers;
    p_pb_sys_spec->has_host_v6_routes = TRUE;
    p_pb_sys_spec->host_v6_routes = p_sys_spec->host_v6_routes;
    p_pb_sys_spec->has_ecmp_v6_routes = TRUE;
    p_pb_sys_spec->ecmp_v6_routes = p_sys_spec->ecmp_v6_routes;
    p_pb_sys_spec->has_pbr_v6_entries = TRUE;
    p_pb_sys_spec->pbr_v6_entries = p_sys_spec->pbr_v6_entries;
    p_pb_sys_spec->has_l3mc_v6_entries = TRUE;
    p_pb_sys_spec->l3mc_v6_entries = p_sys_spec->l3mc_v6_entries;
    p_pb_sys_spec->has_l2mc_v6_entries = TRUE;
    p_pb_sys_spec->l2mc_v6_entries = p_sys_spec->l2mc_v6_entries;
    p_pb_sys_spec->has_flow_v6_entries = TRUE;
    p_pb_sys_spec->flow_v6_entries = p_sys_spec->flow_v6_entries;
    p_pb_sys_spec->has_ipv6_based_vlan_class = TRUE;
    p_pb_sys_spec->ipv6_based_vlan_class = p_sys_spec->ipv6_based_vlan_class;
    p_pb_sys_spec->has_ipv6_source_guard = TRUE;
    p_pb_sys_spec->ipv6_source_guard = p_sys_spec->ipv6_source_guard;
    p_pb_sys_spec->has_remote_v6_routes = TRUE;
    p_pb_sys_spec->remote_v6_routes = p_sys_spec->remote_v6_routes;
    p_pb_sys_spec->has_l3mc_v6_member_ports = TRUE;
    p_pb_sys_spec->l3mc_v6_member_ports = p_sys_spec->l3mc_v6_member_ports;
    p_pb_sys_spec->has_l2mc_v6_member_ports = TRUE;
    p_pb_sys_spec->l2mc_v6_member_ports = p_sys_spec->l2mc_v6_member_ports;
    p_pb_sys_spec->has_vlan_mapping_default_entry = TRUE;
    p_pb_sys_spec->vlan_mapping_default_entry = p_sys_spec->vlan_mapping_default_entry;
    p_pb_sys_spec->has_bfd_sessions = TRUE;
    p_pb_sys_spec->bfd_sessions = p_sys_spec->bfd_sessions;
    p_pb_sys_spec->has_nvgre_tunnel_id_mappings = TRUE;
    p_pb_sys_spec->nvgre_tunnel_id_mappings = p_sys_spec->nvgre_tunnel_id_mappings;
    p_pb_sys_spec->has_nvgre_peers = TRUE;
    p_pb_sys_spec->nvgre_peers = p_sys_spec->nvgre_peers;
    p_pb_sys_spec->has_nvgre_tunnels = TRUE;
    p_pb_sys_spec->nvgre_tunnels = p_sys_spec->nvgre_tunnels;
    p_pb_sys_spec->has_openflow_flow_entries = TRUE;
    p_pb_sys_spec->openflow_flow_entries = p_sys_spec->openflow_flow_entries;
    p_pb_sys_spec->has_policer_profile_num = TRUE;
    p_pb_sys_spec->policer_profile_num = p_sys_spec->policer_profile_num;
    p_pb_sys_spec->has_shape_profile_num = TRUE;
    p_pb_sys_spec->shape_profile_num = p_sys_spec->shape_profile_num;
    p_pb_sys_spec->has_drop_profile_num = TRUE;
    p_pb_sys_spec->drop_profile_num = p_sys_spec->drop_profile_num;
    p_pb_sys_spec->has_lag_group_num = TRUE;
    p_pb_sys_spec->lag_group_num = p_sys_spec->lag_group_num;
    p_pb_sys_spec->has_tap_group_profile_num = TRUE;
    p_pb_sys_spec->tap_group_profile_num = p_sys_spec->tap_group_profile_num;
    p_pb_sys_spec->has_tap_flow_num = TRUE;
    p_pb_sys_spec->tap_flow_num = p_sys_spec->tap_flow_num;
    p_pb_sys_spec->has_tap_flow_entry_num = TRUE;
    p_pb_sys_spec->tap_flow_entry_num = p_sys_spec->tap_flow_entry_num;

    return PM_E_NONE;
}

int32
pb_tbl_sys_spec_to_pb_free_packed(Cdb__TblSysSpec *p_pb_sys_spec)
{
    return PM_E_NONE;
}

int32
pb_tbl_sys_spec_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSysSpecKey pb_sys_spec_key = CDB__TBL_SYS_SPEC_KEY__INIT;
    Cdb__TblSysSpec pb_sys_spec = CDB__TBL_SYS_SPEC__INIT;
    tbl_sys_spec_t *p_sys_spec = (tbl_sys_spec_t*)p_tbl;
    int32 len = 0;

    pb_sys_spec.key = &pb_sys_spec_key;
    pb_tbl_sys_spec_to_pb(only_key, p_sys_spec, &pb_sys_spec);
    len = cdb__tbl_sys_spec__pack(&pb_sys_spec, buf);
    pb_tbl_sys_spec_to_pb_free_packed(&pb_sys_spec);

    return len;
}

int32
pb_tbl_sys_spec_dump(Cdb__TblSysSpec *p_pb_sys_spec, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->type=%u", p_pb_sys_spec->key->type);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ucast_fdb=%u", p_pb_sys_spec->ucast_fdb);
    offset += sal_sprintf(out + offset, "/static_fdb=%u", p_pb_sys_spec->static_fdb);
    offset += sal_sprintf(out + offset, "/mstp_instance=%u", p_pb_sys_spec->mstp_instance);
    offset += sal_sprintf(out + offset, "/vlan_instance=%u", p_pb_sys_spec->vlan_instance);
    offset += sal_sprintf(out + offset, "/mac_filter=%u", p_pb_sys_spec->mac_filter);
    offset += sal_sprintf(out + offset, "/mac_based_vlan_class=%u", p_pb_sys_spec->mac_based_vlan_class);
    offset += sal_sprintf(out + offset, "/ipv4_based_vlan_class=%u", p_pb_sys_spec->ipv4_based_vlan_class);
    offset += sal_sprintf(out + offset, "/ipv4_source_guard=%u", p_pb_sys_spec->ipv4_source_guard);
    offset += sal_sprintf(out + offset, "/vlan_mapping_entry_applied_port=%u", p_pb_sys_spec->vlan_mapping_entry_applied_port);
    offset += sal_sprintf(out + offset, "/dot1x_mac=%u", p_pb_sys_spec->dot1x_mac);
    offset += sal_sprintf(out + offset, "/remote_routes=%u", p_pb_sys_spec->remote_routes);
    offset += sal_sprintf(out + offset, "/host_routes=%u", p_pb_sys_spec->host_routes);
    offset += sal_sprintf(out + offset, "/ecmp_routes=%u", p_pb_sys_spec->ecmp_routes);
    offset += sal_sprintf(out + offset, "/pbr_entries=%u", p_pb_sys_spec->pbr_entries);
    offset += sal_sprintf(out + offset, "/l2mc_entries=%u", p_pb_sys_spec->l2mc_entries);
    offset += sal_sprintf(out + offset, "/l3mc_entries=%u", p_pb_sys_spec->l3mc_entries);
    offset += sal_sprintf(out + offset, "/l2mc_member_ports=%u", p_pb_sys_spec->l2mc_member_ports);
    offset += sal_sprintf(out + offset, "/l3mc_member_ports=%u", p_pb_sys_spec->l3mc_member_ports);
    offset += sal_sprintf(out + offset, "/vlan_member_ports=%u", p_pb_sys_spec->vlan_member_ports);
    offset += sal_sprintf(out + offset, "/voice_vlan=%u", p_pb_sys_spec->voice_vlan);
    offset += sal_sprintf(out + offset, "/flow_entries_ingress=%u", p_pb_sys_spec->flow_entries_ingress);
    offset += sal_sprintf(out + offset, "/flow_entries_egress=%u", p_pb_sys_spec->flow_entries_egress);
    offset += sal_sprintf(out + offset, "/cfm_local_and_remote_meps=%u", p_pb_sys_spec->cfm_local_and_remote_meps);
    offset += sal_sprintf(out + offset, "/g8031_groups=%u", p_pb_sys_spec->g8031_groups);
    offset += sal_sprintf(out + offset, "/g8032_rings=%u", p_pb_sys_spec->g8032_rings);
    offset += sal_sprintf(out + offset, "/g8032_member_ports_per_ring=%u", p_pb_sys_spec->g8032_member_ports_per_ring);
    offset += sal_sprintf(out + offset, "/ftn_entries=%u", p_pb_sys_spec->ftn_entries);
    offset += sal_sprintf(out + offset, "/ilm_entries=%u", p_pb_sys_spec->ilm_entries);
    offset += sal_sprintf(out + offset, "/mpls_lables=%u", p_pb_sys_spec->mpls_lables);
    offset += sal_sprintf(out + offset, "/vpws=%u", p_pb_sys_spec->vpws);
    offset += sal_sprintf(out + offset, "/lsp_pe=%u", p_pb_sys_spec->lsp_pe);
    offset += sal_sprintf(out + offset, "/lsp_p=%u", p_pb_sys_spec->lsp_p);
    offset += sal_sprintf(out + offset, "/vpls_peer=%u", p_pb_sys_spec->vpls_peer);
    offset += sal_sprintf(out + offset, "/vpls_ac=%u", p_pb_sys_spec->vpls_ac);
    offset += sal_sprintf(out + offset, "/vsi=%u", p_pb_sys_spec->vsi);
    offset += sal_sprintf(out + offset, "/lsp_oam=%u", p_pb_sys_spec->lsp_oam);
    offset += sal_sprintf(out + offset, "/pw_oam=%u", p_pb_sys_spec->pw_oam);
    offset += sal_sprintf(out + offset, "/mpls_aps_tunnel=%u", p_pb_sys_spec->mpls_aps_tunnel);
    offset += sal_sprintf(out + offset, "/cfm_lck=%u", p_pb_sys_spec->cfm_lck);
    offset += sal_sprintf(out + offset, "/ip_tunnel=%u", p_pb_sys_spec->ip_tunnel);
    offset += sal_sprintf(out + offset, "/ivi_peers=%u", p_pb_sys_spec->ivi_peers);
    offset += sal_sprintf(out + offset, "/host_v6_routes=%u", p_pb_sys_spec->host_v6_routes);
    offset += sal_sprintf(out + offset, "/ecmp_v6_routes=%u", p_pb_sys_spec->ecmp_v6_routes);
    offset += sal_sprintf(out + offset, "/pbr_v6_entries=%u", p_pb_sys_spec->pbr_v6_entries);
    offset += sal_sprintf(out + offset, "/l3mc_v6_entries=%u", p_pb_sys_spec->l3mc_v6_entries);
    offset += sal_sprintf(out + offset, "/l2mc_v6_entries=%u", p_pb_sys_spec->l2mc_v6_entries);
    offset += sal_sprintf(out + offset, "/flow_v6_entries=%u", p_pb_sys_spec->flow_v6_entries);
    offset += sal_sprintf(out + offset, "/ipv6_based_vlan_class=%u", p_pb_sys_spec->ipv6_based_vlan_class);
    offset += sal_sprintf(out + offset, "/ipv6_source_guard=%u", p_pb_sys_spec->ipv6_source_guard);
    offset += sal_sprintf(out + offset, "/remote_v6_routes=%u", p_pb_sys_spec->remote_v6_routes);
    offset += sal_sprintf(out + offset, "/l3mc_v6_member_ports=%u", p_pb_sys_spec->l3mc_v6_member_ports);
    offset += sal_sprintf(out + offset, "/l2mc_v6_member_ports=%u", p_pb_sys_spec->l2mc_v6_member_ports);
    offset += sal_sprintf(out + offset, "/vlan_mapping_default_entry=%u", p_pb_sys_spec->vlan_mapping_default_entry);
    offset += sal_sprintf(out + offset, "/bfd_sessions=%u", p_pb_sys_spec->bfd_sessions);
    offset += sal_sprintf(out + offset, "/nvgre_tunnel_id_mappings=%u", p_pb_sys_spec->nvgre_tunnel_id_mappings);
    offset += sal_sprintf(out + offset, "/nvgre_peers=%u", p_pb_sys_spec->nvgre_peers);
    offset += sal_sprintf(out + offset, "/nvgre_tunnels=%u", p_pb_sys_spec->nvgre_tunnels);
    offset += sal_sprintf(out + offset, "/openflow_flow_entries=%u", p_pb_sys_spec->openflow_flow_entries);
    offset += sal_sprintf(out + offset, "/policer_profile_num=%u", p_pb_sys_spec->policer_profile_num);
    offset += sal_sprintf(out + offset, "/shape_profile_num=%u", p_pb_sys_spec->shape_profile_num);
    offset += sal_sprintf(out + offset, "/drop_profile_num=%u", p_pb_sys_spec->drop_profile_num);
    offset += sal_sprintf(out + offset, "/lag_group_num=%u", p_pb_sys_spec->lag_group_num);
    offset += sal_sprintf(out + offset, "/tap_group_profile_num=%u", p_pb_sys_spec->tap_group_profile_num);
    offset += sal_sprintf(out + offset, "/tap_flow_num=%u", p_pb_sys_spec->tap_flow_num);
    offset += sal_sprintf(out + offset, "/tap_flow_entry_num=%u", p_pb_sys_spec->tap_flow_entry_num);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FAN */
int32
pb_tbl_fan_to_pb(uint32 only_key, tbl_fan_t *p_fan, Cdb__TblFan *p_pb_fan)
{
    p_pb_fan->key->id = p_fan->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fan->has_slot = TRUE;
    p_pb_fan->slot = p_fan->slot;
    p_pb_fan->has_tray = TRUE;
    p_pb_fan->tray = p_fan->tray;
    p_pb_fan->has_percent = TRUE;
    p_pb_fan->percent = p_fan->percent;
    p_pb_fan->has_absent = TRUE;
    p_pb_fan->absent = p_fan->absent;
    p_pb_fan->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fan->name)+1);
    sal_strcpy(p_pb_fan->name, p_fan->name);
    p_pb_fan->direction = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fan->direction)+1);
    sal_strcpy(p_pb_fan->direction, p_fan->direction);
    p_pb_fan->status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fan->status)+1);
    sal_strcpy(p_pb_fan->status, p_fan->status);
    p_pb_fan->mode = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fan->mode)+1);
    sal_strcpy(p_pb_fan->mode, p_fan->mode);

    return PM_E_NONE;
}

int32
pb_tbl_fan_to_pb_free_packed(Cdb__TblFan *p_pb_fan)
{
    if (p_pb_fan->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fan->name);
        p_pb_fan->name = NULL;
    }

    if (p_pb_fan->direction)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fan->direction);
        p_pb_fan->direction = NULL;
    }

    if (p_pb_fan->status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fan->status);
        p_pb_fan->status = NULL;
    }

    if (p_pb_fan->mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fan->mode);
        p_pb_fan->mode = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fan_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFanKey pb_fan_key = CDB__TBL_FAN_KEY__INIT;
    Cdb__TblFan pb_fan = CDB__TBL_FAN__INIT;
    tbl_fan_t *p_fan = (tbl_fan_t*)p_tbl;
    int32 len = 0;

    pb_fan.key = &pb_fan_key;
    pb_tbl_fan_to_pb(only_key, p_fan, &pb_fan);
    len = cdb__tbl_fan__pack(&pb_fan, buf);
    pb_tbl_fan_to_pb_free_packed(&pb_fan);

    return len;
}

int32
pb_tbl_fan_dump(Cdb__TblFan *p_pb_fan, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%d", p_pb_fan->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot=%d", p_pb_fan->slot);
    offset += sal_sprintf(out + offset, "/tray=%d", p_pb_fan->tray);
    offset += sal_sprintf(out + offset, "/percent=%d", p_pb_fan->percent);
    offset += sal_sprintf(out + offset, "/absent=%d", p_pb_fan->absent);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_fan->name);
    offset += sal_sprintf(out + offset, "/direction=%s", p_pb_fan->direction);
    offset += sal_sprintf(out + offset, "/status=%s", p_pb_fan->status);
    offset += sal_sprintf(out + offset, "/mode=%s", p_pb_fan->mode);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PSU */
int32
pb_tbl_psu_to_pb(uint32 only_key, tbl_psu_t *p_psu, Cdb__TblPsu *p_pb_psu)
{
    p_pb_psu->key->id = p_psu->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_psu->has_slot = TRUE;
    p_pb_psu->slot = p_psu->slot;
    p_pb_psu->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_psu->name)+1);
    sal_strcpy(p_pb_psu->name, p_psu->name);
    p_pb_psu->has_absent = TRUE;
    p_pb_psu->absent = p_psu->absent;
    p_pb_psu->run_status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_psu->run_status)+1);
    sal_strcpy(p_pb_psu->run_status, p_psu->run_status);
    p_pb_psu->alert_status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_psu->alert_status)+1);
    sal_strcpy(p_pb_psu->alert_status, p_psu->alert_status);
    p_pb_psu->mode = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_psu->mode)+1);
    sal_strcpy(p_pb_psu->mode, p_psu->mode);

    return PM_E_NONE;
}

int32
pb_tbl_psu_to_pb_free_packed(Cdb__TblPsu *p_pb_psu)
{
    if (p_pb_psu->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_psu->name);
        p_pb_psu->name = NULL;
    }

    if (p_pb_psu->run_status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_psu->run_status);
        p_pb_psu->run_status = NULL;
    }

    if (p_pb_psu->alert_status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_psu->alert_status);
        p_pb_psu->alert_status = NULL;
    }

    if (p_pb_psu->mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_psu->mode);
        p_pb_psu->mode = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_psu_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPsuKey pb_psu_key = CDB__TBL_PSU_KEY__INIT;
    Cdb__TblPsu pb_psu = CDB__TBL_PSU__INIT;
    tbl_psu_t *p_psu = (tbl_psu_t*)p_tbl;
    int32 len = 0;

    pb_psu.key = &pb_psu_key;
    pb_tbl_psu_to_pb(only_key, p_psu, &pb_psu);
    len = cdb__tbl_psu__pack(&pb_psu, buf);
    pb_tbl_psu_to_pb_free_packed(&pb_psu);

    return len;
}

int32
pb_tbl_psu_dump(Cdb__TblPsu *p_pb_psu, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%d", p_pb_psu->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot=%d", p_pb_psu->slot);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_psu->name);
    offset += sal_sprintf(out + offset, "/absent=%d", p_pb_psu->absent);
    offset += sal_sprintf(out + offset, "/run_status=%s", p_pb_psu->run_status);
    offset += sal_sprintf(out + offset, "/alert_status=%s", p_pb_psu->alert_status);
    offset += sal_sprintf(out + offset, "/mode=%s", p_pb_psu->mode);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LED */
int32
pb_tbl_led_to_pb(uint32 only_key, tbl_led_t *p_led, Cdb__TblLed *p_pb_led)
{
    p_pb_led->key->id = p_led->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_led->has_slot = TRUE;
    p_pb_led->slot = p_led->slot;
    p_pb_led->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_led->name)+1);
    sal_strcpy(p_pb_led->name, p_led->name);
    p_pb_led->status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_led->status)+1);
    sal_strcpy(p_pb_led->status, p_led->status);
    p_pb_led->mode = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_led->mode)+1);
    sal_strcpy(p_pb_led->mode, p_led->mode);

    return PM_E_NONE;
}

int32
pb_tbl_led_to_pb_free_packed(Cdb__TblLed *p_pb_led)
{
    if (p_pb_led->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_led->name);
        p_pb_led->name = NULL;
    }

    if (p_pb_led->status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_led->status);
        p_pb_led->status = NULL;
    }

    if (p_pb_led->mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_led->mode);
        p_pb_led->mode = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_led_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLedKey pb_led_key = CDB__TBL_LED_KEY__INIT;
    Cdb__TblLed pb_led = CDB__TBL_LED__INIT;
    tbl_led_t *p_led = (tbl_led_t*)p_tbl;
    int32 len = 0;

    pb_led.key = &pb_led_key;
    pb_tbl_led_to_pb(only_key, p_led, &pb_led);
    len = cdb__tbl_led__pack(&pb_led, buf);
    pb_tbl_led_to_pb_free_packed(&pb_led);

    return len;
}

int32
pb_tbl_led_dump(Cdb__TblLed *p_pb_led, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%d", p_pb_led->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot=%d", p_pb_led->slot);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_led->name);
    offset += sal_sprintf(out + offset, "/status=%s", p_pb_led->status);
    offset += sal_sprintf(out + offset, "/mode=%s", p_pb_led->mode);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SENSOR */
int32
pb_tbl_sensor_to_pb(uint32 only_key, tbl_sensor_t *p_sensor, Cdb__TblSensor *p_pb_sensor)
{
    p_pb_sensor->key->id = p_sensor->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_sensor->has_slot = TRUE;
    p_pb_sensor->slot = p_sensor->slot;
    p_pb_sensor->has_temperature = TRUE;
    p_pb_sensor->temperature = p_sensor->temperature;
    p_pb_sensor->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_sensor->name)+1);
    sal_strcpy(p_pb_sensor->name, p_sensor->name);
    p_pb_sensor->position = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_sensor->position)+1);
    sal_strcpy(p_pb_sensor->position, p_sensor->position);
    p_pb_sensor->status = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_sensor->status)+1);
    sal_strcpy(p_pb_sensor->status, p_sensor->status);
    p_pb_sensor->has_tmpr_low = TRUE;
    p_pb_sensor->tmpr_low = p_sensor->tmpr_low;
    p_pb_sensor->has_tmpr_high = TRUE;
    p_pb_sensor->tmpr_high = p_sensor->tmpr_high;
    p_pb_sensor->has_tmpr_critical = TRUE;
    p_pb_sensor->tmpr_critical = p_sensor->tmpr_critical;
    p_pb_sensor->has_is_chip = TRUE;
    p_pb_sensor->is_chip = p_sensor->is_chip;

    return PM_E_NONE;
}

int32
pb_tbl_sensor_to_pb_free_packed(Cdb__TblSensor *p_pb_sensor)
{
    if (p_pb_sensor->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sensor->name);
        p_pb_sensor->name = NULL;
    }

    if (p_pb_sensor->position)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sensor->position);
        p_pb_sensor->position = NULL;
    }

    if (p_pb_sensor->status)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sensor->status);
        p_pb_sensor->status = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_sensor_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSensorKey pb_sensor_key = CDB__TBL_SENSOR_KEY__INIT;
    Cdb__TblSensor pb_sensor = CDB__TBL_SENSOR__INIT;
    tbl_sensor_t *p_sensor = (tbl_sensor_t*)p_tbl;
    int32 len = 0;

    pb_sensor.key = &pb_sensor_key;
    pb_tbl_sensor_to_pb(only_key, p_sensor, &pb_sensor);
    len = cdb__tbl_sensor__pack(&pb_sensor, buf);
    pb_tbl_sensor_to_pb_free_packed(&pb_sensor);

    return len;
}

int32
pb_tbl_sensor_dump(Cdb__TblSensor *p_pb_sensor, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%d", p_pb_sensor->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/slot=%d", p_pb_sensor->slot);
    offset += sal_sprintf(out + offset, "/temperature=%d", p_pb_sensor->temperature);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_sensor->name);
    offset += sal_sprintf(out + offset, "/position=%s", p_pb_sensor->position);
    offset += sal_sprintf(out + offset, "/status=%s", p_pb_sensor->status);
    offset += sal_sprintf(out + offset, "/tmpr_low=%d", p_pb_sensor->tmpr_low);
    offset += sal_sprintf(out + offset, "/tmpr_high=%d", p_pb_sensor->tmpr_high);
    offset += sal_sprintf(out + offset, "/tmpr_critical=%d", p_pb_sensor->tmpr_critical);
    offset += sal_sprintf(out + offset, "/is_chip=%u", p_pb_sensor->is_chip);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_REBOOT_INFO */
int32
pb_tbl_reboot_info_to_pb(uint32 only_key, tbl_reboot_info_t *p_reboot_info, Cdb__TblRebootInfo *p_pb_reboot_info)
{
    p_pb_reboot_info->key->index = p_reboot_info->key.index;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_reboot_info->reboot_type = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_reboot_info->reboot_type)+1);
    sal_strcpy(p_pb_reboot_info->reboot_type, p_reboot_info->reboot_type);
    p_pb_reboot_info->reboot_time = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_reboot_info->reboot_time)+1);
    sal_strcpy(p_pb_reboot_info->reboot_time, p_reboot_info->reboot_time);

    return PM_E_NONE;
}

int32
pb_tbl_reboot_info_to_pb_free_packed(Cdb__TblRebootInfo *p_pb_reboot_info)
{
    if (p_pb_reboot_info->reboot_type)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_reboot_info->reboot_type);
        p_pb_reboot_info->reboot_type = NULL;
    }

    if (p_pb_reboot_info->reboot_time)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_reboot_info->reboot_time);
        p_pb_reboot_info->reboot_time = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_reboot_info_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRebootInfoKey pb_reboot_info_key = CDB__TBL_REBOOT_INFO_KEY__INIT;
    Cdb__TblRebootInfo pb_reboot_info = CDB__TBL_REBOOT_INFO__INIT;
    tbl_reboot_info_t *p_reboot_info = (tbl_reboot_info_t*)p_tbl;
    int32 len = 0;

    pb_reboot_info.key = &pb_reboot_info_key;
    pb_tbl_reboot_info_to_pb(only_key, p_reboot_info, &pb_reboot_info);
    len = cdb__tbl_reboot_info__pack(&pb_reboot_info, buf);
    pb_tbl_reboot_info_to_pb_free_packed(&pb_reboot_info);

    return len;
}

int32
pb_tbl_reboot_info_dump(Cdb__TblRebootInfo *p_pb_reboot_info, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->index=%u", p_pb_reboot_info->key->index);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/reboot_type=%s", p_pb_reboot_info->reboot_type);
    offset += sal_sprintf(out + offset, "/reboot_time=%s", p_pb_reboot_info->reboot_time);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ERRDISABLE_FLAP */
int32
pb_tbl_errdisable_flap_to_pb(uint32 only_key, tbl_errdisable_flap_t *p_errdisable_flap, Cdb__TblErrdisableFlap *p_pb_errdisable_flap)
{
    p_pb_errdisable_flap->key->flap_rsn = p_errdisable_flap->key.flap_rsn;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_errdisable_flap->has_errdisable_rsn = TRUE;
    p_pb_errdisable_flap->errdisable_rsn = p_errdisable_flap->errdisable_rsn;
    p_pb_errdisable_flap->has_flap_cnt_threshold = TRUE;
    p_pb_errdisable_flap->flap_cnt_threshold = p_errdisable_flap->flap_cnt_threshold;
    p_pb_errdisable_flap->has_flap_time_threshold = TRUE;
    p_pb_errdisable_flap->flap_time_threshold = p_errdisable_flap->flap_time_threshold;
    p_pb_errdisable_flap->has_flap_time_cnt = TRUE;
    p_pb_errdisable_flap->flap_time_cnt = p_errdisable_flap->flap_time_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_errdisable_flap_to_pb_free_packed(Cdb__TblErrdisableFlap *p_pb_errdisable_flap)
{
    return PM_E_NONE;
}

int32
pb_tbl_errdisable_flap_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblErrdisableFlapKey pb_errdisable_flap_key = CDB__TBL_ERRDISABLE_FLAP_KEY__INIT;
    Cdb__TblErrdisableFlap pb_errdisable_flap = CDB__TBL_ERRDISABLE_FLAP__INIT;
    tbl_errdisable_flap_t *p_errdisable_flap = (tbl_errdisable_flap_t*)p_tbl;
    int32 len = 0;

    pb_errdisable_flap.key = &pb_errdisable_flap_key;
    pb_tbl_errdisable_flap_to_pb(only_key, p_errdisable_flap, &pb_errdisable_flap);
    len = cdb__tbl_errdisable_flap__pack(&pb_errdisable_flap, buf);
    pb_tbl_errdisable_flap_to_pb_free_packed(&pb_errdisable_flap);

    return len;
}

int32
pb_tbl_errdisable_flap_dump(Cdb__TblErrdisableFlap *p_pb_errdisable_flap, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->flap_rsn=%u", p_pb_errdisable_flap->key->flap_rsn);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/errdisable_rsn=%u", p_pb_errdisable_flap->errdisable_rsn);
    offset += sal_sprintf(out + offset, "/flap_cnt_threshold=%u", p_pb_errdisable_flap->flap_cnt_threshold);
    offset += sal_sprintf(out + offset, "/flap_time_threshold=%u", p_pb_errdisable_flap->flap_time_threshold);
    offset += sal_sprintf(out + offset, "/flap_time_cnt=%u", p_pb_errdisable_flap->flap_time_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPM_GLOBAL */
int32
pb_tbl_opm_global_to_pb(uint32 only_key, tbl_opm_global_t *p_opmglb, Cdb__TblOpmGlobal *p_pb_opmglb)
{
    p_pb_opmglb->has_erps_mode = TRUE;
    p_pb_opmglb->erps_mode = GLB_FLAG_ISSET(p_opmglb->erps, OPMGLB_FLAG_ERPS_MODE_HUAWEI) ? TRUE : FALSE;
    p_pb_opmglb->has_erps_unreload = TRUE;
    p_pb_opmglb->erps_unreload = GLB_FLAG_ISSET(p_opmglb->erps, OPMGLB_FLAG_ERPS_MODE_UNRELOAD) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_opm_global_to_pb_free_packed(Cdb__TblOpmGlobal *p_pb_opmglb)
{
    return PM_E_NONE;
}

int32
pb_tbl_opm_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpmGlobal pb_opmglb = CDB__TBL_OPM_GLOBAL__INIT;
    tbl_opm_global_t *p_opmglb = (tbl_opm_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_opm_global_to_pb(only_key, p_opmglb, &pb_opmglb);
    len = cdb__tbl_opm_global__pack(&pb_opmglb, buf);
    pb_tbl_opm_global_to_pb_free_packed(&pb_opmglb);

    return len;
}

int32
pb_tbl_opm_global_dump(Cdb__TblOpmGlobal *p_pb_opmglb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/erps_mode=%u", p_pb_opmglb->erps_mode);
    offset += sal_sprintf(out + offset, "/erps_unreload=%u", p_pb_opmglb->erps_unreload);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ERPS_RING */
int32
pb_tbl_erps_ring_to_pb(uint32 only_key, tbl_erps_ring_t *p_erps_ring, Cdb__TblErpsRing *p_pb_erps_ring)
{
    uint32 i = 0;

    pb_compose_erps_ring_key_t_to_pb(&p_erps_ring->key, p_pb_erps_ring->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_erps_ring->has_erps_ring_state = TRUE;
    p_pb_erps_ring->erps_ring_state = p_erps_ring->erps_ring_state;
    p_pb_erps_ring->has_erps_ring_level = TRUE;
    p_pb_erps_ring->erps_ring_level = p_erps_ring->erps_ring_level;
    p_pb_erps_ring->has_instance_id_num = TRUE;
    p_pb_erps_ring->instance_id_num = p_erps_ring->instance_id_num;
    p_pb_erps_ring->instance_id = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*ERPS_MAX_INSTANCE);
    p_pb_erps_ring->n_instance_id = ERPS_MAX_INSTANCE;
    for (i = 0; i < ERPS_MAX_INSTANCE; i++)
    {
        p_pb_erps_ring->instance_id[i] = p_erps_ring->instance_id[i];
    }
    p_pb_erps_ring->has_node_role = TRUE;
    p_pb_erps_ring->node_role = p_erps_ring->node_role;
    p_pb_erps_ring->has_edge_node_role = TRUE;
    p_pb_erps_ring->edge_node_role = p_erps_ring->edge_node_role;
    p_pb_erps_ring->has_erps_srpt_enable = TRUE;
    p_pb_erps_ring->erps_srpt_enable = p_erps_ring->erps_srpt_enable;
    p_pb_erps_ring->has_primary_port_ifindex = TRUE;
    p_pb_erps_ring->primary_port_ifindex = p_erps_ring->primary_port_ifindex;
    p_pb_erps_ring->has_secondary_port_ifindex = TRUE;
    p_pb_erps_ring->secondary_port_ifindex = p_erps_ring->secondary_port_ifindex;
    p_pb_erps_ring->has_edge_port_ifindex = TRUE;
    p_pb_erps_ring->edge_port_ifindex = p_erps_ring->edge_port_ifindex;
    p_pb_erps_ring->has_common_port_ifindex = TRUE;
    p_pb_erps_ring->common_port_ifindex = p_erps_ring->common_port_ifindex;
    p_pb_erps_ring->has_blocked_port_ifindex = TRUE;
    p_pb_erps_ring->blocked_port_ifindex = p_erps_ring->blocked_port_ifindex;
    p_pb_erps_ring->has_blocked = TRUE;
    p_pb_erps_ring->blocked = p_erps_ring->blocked;
    p_pb_erps_ring->has_hello_seq = TRUE;
    p_pb_erps_ring->hello_seq = p_erps_ring->hello_seq;
    p_pb_erps_ring->has_expect_hello_seq = TRUE;
    p_pb_erps_ring->expect_hello_seq = p_erps_ring->expect_hello_seq;
    p_pb_erps_ring->has_rcv_hello_cnt = TRUE;
    p_pb_erps_ring->rcv_hello_cnt = p_erps_ring->rcv_hello_cnt;
    p_pb_erps_ring->has_rcv_ring_up_flush_fdb_cnt = TRUE;
    p_pb_erps_ring->rcv_ring_up_flush_fdb_cnt = p_erps_ring->rcv_ring_up_flush_fdb_cnt;
    p_pb_erps_ring->has_rcv_ring_down_flush_fdb_cnt = TRUE;
    p_pb_erps_ring->rcv_ring_down_flush_fdb_cnt = p_erps_ring->rcv_ring_down_flush_fdb_cnt;
    p_pb_erps_ring->has_rcv_link_down_cnt = TRUE;
    p_pb_erps_ring->rcv_link_down_cnt = p_erps_ring->rcv_link_down_cnt;
    p_pb_erps_ring->has_rcv_edge_hello_cnt = TRUE;
    p_pb_erps_ring->rcv_edge_hello_cnt = p_erps_ring->rcv_edge_hello_cnt;
    p_pb_erps_ring->has_rcv_major_fault_cnt = TRUE;
    p_pb_erps_ring->rcv_major_fault_cnt = p_erps_ring->rcv_major_fault_cnt;
    p_pb_erps_ring->has_send_hello_cnt = TRUE;
    p_pb_erps_ring->send_hello_cnt = p_erps_ring->send_hello_cnt;
    p_pb_erps_ring->has_send_ring_up_flush_fdb_cnt = TRUE;
    p_pb_erps_ring->send_ring_up_flush_fdb_cnt = p_erps_ring->send_ring_up_flush_fdb_cnt;
    p_pb_erps_ring->has_send_ring_down_flush_fdb_cnt = TRUE;
    p_pb_erps_ring->send_ring_down_flush_fdb_cnt = p_erps_ring->send_ring_down_flush_fdb_cnt;
    p_pb_erps_ring->has_send_link_down_cnt = TRUE;
    p_pb_erps_ring->send_link_down_cnt = p_erps_ring->send_link_down_cnt;
    p_pb_erps_ring->has_send_edge_hello_cnt = TRUE;
    p_pb_erps_ring->send_edge_hello_cnt = p_erps_ring->send_edge_hello_cnt;
    p_pb_erps_ring->has_send_major_fault_cnt = TRUE;
    p_pb_erps_ring->send_major_fault_cnt = p_erps_ring->send_major_fault_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_erps_ring_to_pb_free_packed(Cdb__TblErpsRing *p_pb_erps_ring)
{
    pb_compose_erps_ring_key_t_to_pb_free_packed(p_pb_erps_ring->key);
    if (p_pb_erps_ring->instance_id)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_erps_ring->instance_id);
        p_pb_erps_ring->instance_id = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_erps_ring_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblErpsRingKey pb_erps_ring_key = CDB__TBL_ERPS_RING_KEY__INIT;
    Cdb__TblErpsRing pb_erps_ring = CDB__TBL_ERPS_RING__INIT;
    tbl_erps_ring_t *p_erps_ring = (tbl_erps_ring_t*)p_tbl;
    int32 len = 0;

    pb_erps_ring.key = &pb_erps_ring_key;
    pb_tbl_erps_ring_to_pb(only_key, p_erps_ring, &pb_erps_ring);
    len = cdb__tbl_erps_ring__pack(&pb_erps_ring, buf);
    pb_tbl_erps_ring_to_pb_free_packed(&pb_erps_ring);

    return len;
}

int32
pb_tbl_erps_ring_dump(Cdb__TblErpsRing *p_pb_erps_ring, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_erps_ring_key_t_dump(p_pb_erps_ring->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/erps_ring_state=%u", p_pb_erps_ring->erps_ring_state);
    offset += sal_sprintf(out + offset, "/erps_ring_level=%u", p_pb_erps_ring->erps_ring_level);
    offset += sal_sprintf(out + offset, "/instance_id_num=%u", p_pb_erps_ring->instance_id_num);
    offset += sal_sprintf(out + offset, "/instance_id=");
    offset += pb_uint32_array_dump(p_pb_erps_ring->instance_id, sizeof(p_pb_erps_ring->instance_id), (out + offset));
    offset += sal_sprintf(out + offset, "/node_role=%u", p_pb_erps_ring->node_role);
    offset += sal_sprintf(out + offset, "/edge_node_role=%u", p_pb_erps_ring->edge_node_role);
    offset += sal_sprintf(out + offset, "/erps_srpt_enable=%u", p_pb_erps_ring->erps_srpt_enable);
    offset += sal_sprintf(out + offset, "/primary_port_ifindex=%u", p_pb_erps_ring->primary_port_ifindex);
    offset += sal_sprintf(out + offset, "/secondary_port_ifindex=%u", p_pb_erps_ring->secondary_port_ifindex);
    offset += sal_sprintf(out + offset, "/edge_port_ifindex=%u", p_pb_erps_ring->edge_port_ifindex);
    offset += sal_sprintf(out + offset, "/common_port_ifindex=%u", p_pb_erps_ring->common_port_ifindex);
    offset += sal_sprintf(out + offset, "/blocked_port_ifindex=%u", p_pb_erps_ring->blocked_port_ifindex);
    offset += sal_sprintf(out + offset, "/blocked=%u", p_pb_erps_ring->blocked);
    offset += sal_sprintf(out + offset, "/hello_seq=%u", p_pb_erps_ring->hello_seq);
    offset += sal_sprintf(out + offset, "/expect_hello_seq=%u", p_pb_erps_ring->expect_hello_seq);
    offset += sal_sprintf(out + offset, "/rcv_hello_cnt=%u", p_pb_erps_ring->rcv_hello_cnt);
    offset += sal_sprintf(out + offset, "/rcv_ring_up_flush_fdb_cnt=%u", p_pb_erps_ring->rcv_ring_up_flush_fdb_cnt);
    offset += sal_sprintf(out + offset, "/rcv_ring_down_flush_fdb_cnt=%u", p_pb_erps_ring->rcv_ring_down_flush_fdb_cnt);
    offset += sal_sprintf(out + offset, "/rcv_link_down_cnt=%u", p_pb_erps_ring->rcv_link_down_cnt);
    offset += sal_sprintf(out + offset, "/rcv_edge_hello_cnt=%u", p_pb_erps_ring->rcv_edge_hello_cnt);
    offset += sal_sprintf(out + offset, "/rcv_major_fault_cnt=%u", p_pb_erps_ring->rcv_major_fault_cnt);
    offset += sal_sprintf(out + offset, "/send_hello_cnt=%u", p_pb_erps_ring->send_hello_cnt);
    offset += sal_sprintf(out + offset, "/send_ring_up_flush_fdb_cnt=%u", p_pb_erps_ring->send_ring_up_flush_fdb_cnt);
    offset += sal_sprintf(out + offset, "/send_ring_down_flush_fdb_cnt=%u", p_pb_erps_ring->send_ring_down_flush_fdb_cnt);
    offset += sal_sprintf(out + offset, "/send_link_down_cnt=%u", p_pb_erps_ring->send_link_down_cnt);
    offset += sal_sprintf(out + offset, "/send_edge_hello_cnt=%u", p_pb_erps_ring->send_edge_hello_cnt);
    offset += sal_sprintf(out + offset, "/send_major_fault_cnt=%u", p_pb_erps_ring->send_major_fault_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ERPS_DOMAIN */
int32
pb_tbl_erps_domain_to_pb(uint32 only_key, tbl_erps_domain_t *p_erps_domain, Cdb__TblErpsDomain *p_pb_erps_domain)
{
    uint32 i = 0;

    p_pb_erps_domain->key->domain_id = p_erps_domain->key.domain_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_erps_domain->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_erps_domain->name)+1);
    sal_strcpy(p_pb_erps_domain->name, p_erps_domain->name);
    p_pb_erps_domain->has_instance_id_num = TRUE;
    p_pb_erps_domain->instance_id_num = p_erps_domain->instance_id_num;
    p_pb_erps_domain->instance_id = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*ERPS_MAX_INSTANCE);
    p_pb_erps_domain->n_instance_id = ERPS_MAX_INSTANCE;
    for (i = 0; i < ERPS_MAX_INSTANCE; i++)
    {
        p_pb_erps_domain->instance_id[i] = p_erps_domain->instance_id[i];
    }
    p_pb_erps_domain->has_primary_control_vlan_id = TRUE;
    p_pb_erps_domain->primary_control_vlan_id = p_erps_domain->primary_control_vlan_id;
    p_pb_erps_domain->has_sub_control_vlan_id = TRUE;
    p_pb_erps_domain->sub_control_vlan_id = p_erps_domain->sub_control_vlan_id;
    p_pb_erps_domain->has_hello_timer_interval = TRUE;
    p_pb_erps_domain->hello_timer_interval = p_erps_domain->hello_timer_interval;
    p_pb_erps_domain->has_failure_timer_interval = TRUE;
    p_pb_erps_domain->failure_timer_interval = p_erps_domain->failure_timer_interval;
    p_pb_erps_domain->has_pre_forwarding_timer_interval = TRUE;
    p_pb_erps_domain->pre_forwarding_timer_interval = p_erps_domain->pre_forwarding_timer_interval;
    p_pb_erps_domain->has_flush_timer_interval = TRUE;
    p_pb_erps_domain->flush_timer_interval = p_erps_domain->flush_timer_interval;
    p_pb_erps_domain->has_edge_hello_timer_interval = TRUE;
    p_pb_erps_domain->edge_hello_timer_interval = p_erps_domain->edge_hello_timer_interval;
    p_pb_erps_domain->has_edge_failure_timer_interval = TRUE;
    p_pb_erps_domain->edge_failure_timer_interval = p_erps_domain->edge_failure_timer_interval;
    p_pb_erps_domain->has_erps_enable = TRUE;
    p_pb_erps_domain->erps_enable = p_erps_domain->erps_enable;

    return PM_E_NONE;
}

int32
pb_tbl_erps_domain_to_pb_free_packed(Cdb__TblErpsDomain *p_pb_erps_domain)
{
    if (p_pb_erps_domain->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_erps_domain->name);
        p_pb_erps_domain->name = NULL;
    }

    if (p_pb_erps_domain->instance_id)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_erps_domain->instance_id);
        p_pb_erps_domain->instance_id = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_erps_domain_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblErpsDomainKey pb_erps_domain_key = CDB__TBL_ERPS_DOMAIN_KEY__INIT;
    Cdb__TblErpsDomain pb_erps_domain = CDB__TBL_ERPS_DOMAIN__INIT;
    tbl_erps_domain_t *p_erps_domain = (tbl_erps_domain_t*)p_tbl;
    int32 len = 0;

    pb_erps_domain.key = &pb_erps_domain_key;
    pb_tbl_erps_domain_to_pb(only_key, p_erps_domain, &pb_erps_domain);
    len = cdb__tbl_erps_domain__pack(&pb_erps_domain, buf);
    pb_tbl_erps_domain_to_pb_free_packed(&pb_erps_domain);

    return len;
}

int32
pb_tbl_erps_domain_dump(Cdb__TblErpsDomain *p_pb_erps_domain, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->domain_id=%u", p_pb_erps_domain->key->domain_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_erps_domain->name);
    offset += sal_sprintf(out + offset, "/instance_id_num=%u", p_pb_erps_domain->instance_id_num);
    offset += sal_sprintf(out + offset, "/instance_id=");
    offset += pb_uint32_array_dump(p_pb_erps_domain->instance_id, sizeof(p_pb_erps_domain->instance_id), (out + offset));
    offset += sal_sprintf(out + offset, "/primary_control_vlan_id=%u", p_pb_erps_domain->primary_control_vlan_id);
    offset += sal_sprintf(out + offset, "/sub_control_vlan_id=%u", p_pb_erps_domain->sub_control_vlan_id);
    offset += sal_sprintf(out + offset, "/hello_timer_interval=%u", p_pb_erps_domain->hello_timer_interval);
    offset += sal_sprintf(out + offset, "/failure_timer_interval=%u", p_pb_erps_domain->failure_timer_interval);
    offset += sal_sprintf(out + offset, "/pre_forwarding_timer_interval=%u", p_pb_erps_domain->pre_forwarding_timer_interval);
    offset += sal_sprintf(out + offset, "/flush_timer_interval=%u", p_pb_erps_domain->flush_timer_interval);
    offset += sal_sprintf(out + offset, "/edge_hello_timer_interval=%u", p_pb_erps_domain->edge_hello_timer_interval);
    offset += sal_sprintf(out + offset, "/edge_failure_timer_interval=%u", p_pb_erps_domain->edge_failure_timer_interval);
    offset += sal_sprintf(out + offset, "/erps_enable=%u", p_pb_erps_domain->erps_enable);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPM_DEBUG */
int32
pb_tbl_opm_debug_to_pb(uint32 only_key, tbl_opm_debug_t *p_opmdbg, Cdb__TblOpmDebug *p_pb_opmdbg)
{
    p_pb_opmdbg->has_erps_all = TRUE;
    p_pb_opmdbg->erps_all = GLB_FLAG_ISSET(p_opmdbg->erps, OPMDBG_FLAG_ERPS_ALL) ? TRUE : FALSE;
    p_pb_opmdbg->has_erps_packet = TRUE;
    p_pb_opmdbg->erps_packet = GLB_FLAG_ISSET(p_opmdbg->erps, OPMDBG_FLAG_ERPS_PACKET) ? TRUE : FALSE;
    p_pb_opmdbg->has_erps_timer = TRUE;
    p_pb_opmdbg->erps_timer = GLB_FLAG_ISSET(p_opmdbg->erps, OPMDBG_FLAG_ERPS_TIMER) ? TRUE : FALSE;
    p_pb_opmdbg->has_erps_protocol = TRUE;
    p_pb_opmdbg->erps_protocol = GLB_FLAG_ISSET(p_opmdbg->erps, OPMDBG_FLAG_ERPS_PROTO) ? TRUE : FALSE;
    p_pb_opmdbg->has_erps_event = TRUE;
    p_pb_opmdbg->erps_event = GLB_FLAG_ISSET(p_opmdbg->erps, OPMDBG_FLAG_ERPS_EVENTS) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_opm_debug_to_pb_free_packed(Cdb__TblOpmDebug *p_pb_opmdbg)
{
    return PM_E_NONE;
}

int32
pb_tbl_opm_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpmDebug pb_opmdbg = CDB__TBL_OPM_DEBUG__INIT;
    tbl_opm_debug_t *p_opmdbg = (tbl_opm_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_opm_debug_to_pb(only_key, p_opmdbg, &pb_opmdbg);
    len = cdb__tbl_opm_debug__pack(&pb_opmdbg, buf);
    pb_tbl_opm_debug_to_pb_free_packed(&pb_opmdbg);

    return len;
}

int32
pb_tbl_opm_debug_dump(Cdb__TblOpmDebug *p_pb_opmdbg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/erps_all=%u", p_pb_opmdbg->erps_all);
    offset += sal_sprintf(out + offset, "/erps_packet=%u", p_pb_opmdbg->erps_packet);
    offset += sal_sprintf(out + offset, "/erps_timer=%u", p_pb_opmdbg->erps_timer);
    offset += sal_sprintf(out + offset, "/erps_protocol=%u", p_pb_opmdbg->erps_protocol);
    offset += sal_sprintf(out + offset, "/erps_event=%u", p_pb_opmdbg->erps_event);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_POLICY_MAP_CONFIG */
int32
pb_tbl_policy_map_config_to_pb(uint32 only_key, tbl_policy_map_config_t *p_policy_map_config, Cdb__TblPolicyMapConfig *p_pb_policy_map_config)
{
    p_pb_policy_map_config->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_policy_map_config->key.name)+1);
    sal_strcpy(p_pb_policy_map_config->key->name, p_policy_map_config->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_policy_map_config->has_intf_ref = TRUE;
    p_pb_policy_map_config->intf_ref = p_policy_map_config->intf_ref;
    p_pb_policy_map_config->has_class_ref = TRUE;
    p_pb_policy_map_config->class_ref = p_policy_map_config->class_ref;
    p_pb_policy_map_config->has_max_class_priority = TRUE;
    p_pb_policy_map_config->max_class_priority = p_policy_map_config->max_class_priority;

    return PM_E_NONE;
}

int32
pb_tbl_policy_map_config_to_pb_free_packed(Cdb__TblPolicyMapConfig *p_pb_policy_map_config)
{
    if (p_pb_policy_map_config->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_policy_map_config->key->name);
        p_pb_policy_map_config->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_policy_map_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPolicyMapConfigKey pb_policy_map_config_key = CDB__TBL_POLICY_MAP_CONFIG_KEY__INIT;
    Cdb__TblPolicyMapConfig pb_policy_map_config = CDB__TBL_POLICY_MAP_CONFIG__INIT;
    tbl_policy_map_config_t *p_policy_map_config = (tbl_policy_map_config_t*)p_tbl;
    int32 len = 0;

    pb_policy_map_config.key = &pb_policy_map_config_key;
    pb_tbl_policy_map_config_to_pb(only_key, p_policy_map_config, &pb_policy_map_config);
    len = cdb__tbl_policy_map_config__pack(&pb_policy_map_config, buf);
    pb_tbl_policy_map_config_to_pb_free_packed(&pb_policy_map_config);

    return len;
}

int32
pb_tbl_policy_map_config_dump(Cdb__TblPolicyMapConfig *p_pb_policy_map_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_policy_map_config->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/intf_ref=%u", p_pb_policy_map_config->intf_ref);
    offset += sal_sprintf(out + offset, "/class_ref=%u", p_pb_policy_map_config->class_ref);
    offset += sal_sprintf(out + offset, "/max_class_priority=%llu", p_pb_policy_map_config->max_class_priority);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CLASS_MAP_CONFIG */
int32
pb_tbl_class_map_config_to_pb(uint32 only_key, tbl_class_map_config_t *p_class_map_config, Cdb__TblClassMapConfig *p_pb_class_map_config)
{
    p_pb_class_map_config->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_class_map_config->key.name)+1);
    sal_strcpy(p_pb_class_map_config->key->name, p_class_map_config->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_class_map_config->has_policy_map_ref = TRUE;
    p_pb_class_map_config->policy_map_ref = p_class_map_config->policy_map_ref;
    p_pb_class_map_config->has_acl_ref = TRUE;
    p_pb_class_map_config->acl_ref = p_class_map_config->acl_ref;
    p_pb_class_map_config->has_max_acl_priority = TRUE;
    p_pb_class_map_config->max_acl_priority = p_class_map_config->max_acl_priority;

    return PM_E_NONE;
}

int32
pb_tbl_class_map_config_to_pb_free_packed(Cdb__TblClassMapConfig *p_pb_class_map_config)
{
    if (p_pb_class_map_config->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_class_map_config->key->name);
        p_pb_class_map_config->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_class_map_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblClassMapConfigKey pb_class_map_config_key = CDB__TBL_CLASS_MAP_CONFIG_KEY__INIT;
    Cdb__TblClassMapConfig pb_class_map_config = CDB__TBL_CLASS_MAP_CONFIG__INIT;
    tbl_class_map_config_t *p_class_map_config = (tbl_class_map_config_t*)p_tbl;
    int32 len = 0;

    pb_class_map_config.key = &pb_class_map_config_key;
    pb_tbl_class_map_config_to_pb(only_key, p_class_map_config, &pb_class_map_config);
    len = cdb__tbl_class_map_config__pack(&pb_class_map_config, buf);
    pb_tbl_class_map_config_to_pb_free_packed(&pb_class_map_config);

    return len;
}

int32
pb_tbl_class_map_config_dump(Cdb__TblClassMapConfig *p_pb_class_map_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_class_map_config->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/policy_map_ref=%u", p_pb_class_map_config->policy_map_ref);
    offset += sal_sprintf(out + offset, "/acl_ref=%u", p_pb_class_map_config->acl_ref);
    offset += sal_sprintf(out + offset, "/max_acl_priority=%llu", p_pb_class_map_config->max_acl_priority);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CLASS_IN_POLICY_CONFIG */
int32
pb_tbl_class_in_policy_config_to_pb(uint32 only_key, tbl_class_in_policy_config_t *p_class_in_policy_config, Cdb__TblClassInPolicyConfig *p_pb_class_in_policy_config)
{
    pb_compose_class_in_policy_config_key_t_to_pb(&p_class_in_policy_config->key, p_pb_class_in_policy_config->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_class_in_policy_config->has_class_priority = TRUE;
    p_pb_class_in_policy_config->class_priority = p_class_in_policy_config->class_priority;

    return PM_E_NONE;
}

int32
pb_tbl_class_in_policy_config_to_pb_free_packed(Cdb__TblClassInPolicyConfig *p_pb_class_in_policy_config)
{
    pb_compose_class_in_policy_config_key_t_to_pb_free_packed(p_pb_class_in_policy_config->key);
    return PM_E_NONE;
}

int32
pb_tbl_class_in_policy_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblClassInPolicyConfigKey pb_class_in_policy_config_key = CDB__TBL_CLASS_IN_POLICY_CONFIG_KEY__INIT;
    Cdb__TblClassInPolicyConfig pb_class_in_policy_config = CDB__TBL_CLASS_IN_POLICY_CONFIG__INIT;
    tbl_class_in_policy_config_t *p_class_in_policy_config = (tbl_class_in_policy_config_t*)p_tbl;
    int32 len = 0;

    pb_class_in_policy_config.key = &pb_class_in_policy_config_key;
    pb_tbl_class_in_policy_config_to_pb(only_key, p_class_in_policy_config, &pb_class_in_policy_config);
    len = cdb__tbl_class_in_policy_config__pack(&pb_class_in_policy_config, buf);
    pb_tbl_class_in_policy_config_to_pb_free_packed(&pb_class_in_policy_config);

    return len;
}

int32
pb_tbl_class_in_policy_config_dump(Cdb__TblClassInPolicyConfig *p_pb_class_in_policy_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_class_in_policy_config_key_t_dump(p_pb_class_in_policy_config->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/class_priority=%llu", p_pb_class_in_policy_config->class_priority);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_IN_CLASS_CONFIG */
int32
pb_tbl_acl_in_class_config_to_pb(uint32 only_key, tbl_acl_in_class_config_t *p_acl_in_class_config, Cdb__TblAclInClassConfig *p_pb_acl_in_class_config)
{
    pb_compose_acl_in_class_config_key_t_to_pb(&p_acl_in_class_config->key, p_pb_acl_in_class_config->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_in_class_config->has_acl_priority = TRUE;
    p_pb_acl_in_class_config->acl_priority = p_acl_in_class_config->acl_priority;

    return PM_E_NONE;
}

int32
pb_tbl_acl_in_class_config_to_pb_free_packed(Cdb__TblAclInClassConfig *p_pb_acl_in_class_config)
{
    pb_compose_acl_in_class_config_key_t_to_pb_free_packed(p_pb_acl_in_class_config->key);
    return PM_E_NONE;
}

int32
pb_tbl_acl_in_class_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclInClassConfigKey pb_acl_in_class_config_key = CDB__TBL_ACL_IN_CLASS_CONFIG_KEY__INIT;
    Cdb__TblAclInClassConfig pb_acl_in_class_config = CDB__TBL_ACL_IN_CLASS_CONFIG__INIT;
    tbl_acl_in_class_config_t *p_acl_in_class_config = (tbl_acl_in_class_config_t*)p_tbl;
    int32 len = 0;

    pb_acl_in_class_config.key = &pb_acl_in_class_config_key;
    pb_tbl_acl_in_class_config_to_pb(only_key, p_acl_in_class_config, &pb_acl_in_class_config);
    len = cdb__tbl_acl_in_class_config__pack(&pb_acl_in_class_config, buf);
    pb_tbl_acl_in_class_config_to_pb_free_packed(&pb_acl_in_class_config);

    return len;
}

int32
pb_tbl_acl_in_class_config_dump(Cdb__TblAclInClassConfig *p_pb_acl_in_class_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_acl_in_class_config_key_t_dump(p_pb_acl_in_class_config->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/acl_priority=%llu", p_pb_acl_in_class_config->acl_priority);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CLASS_MAP_ACTION_CONFIG */
int32
pb_tbl_class_map_action_config_to_pb(uint32 only_key, tbl_class_map_action_config_t *p_class_map_action_config, Cdb__TblClassMapActionConfig *p_pb_class_map_action_config)
{
    pb_compose_class_map_action_config_key_t_to_pb(&p_class_map_action_config->key, p_pb_class_map_action_config->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_class_map_action_config->has_action_flag = TRUE;
    p_pb_class_map_action_config->action_flag = p_class_map_action_config->action_flag;
    p_pb_class_map_action_config->has_new_tc = TRUE;
    p_pb_class_map_action_config->new_tc = p_class_map_action_config->new_tc;
    p_pb_class_map_action_config->has_new_color = TRUE;
    p_pb_class_map_action_config->new_color = p_class_map_action_config->new_color;
    p_pb_class_map_action_config->has_new_dscp = TRUE;
    p_pb_class_map_action_config->new_dscp = p_class_map_action_config->new_dscp;
    p_pb_class_map_action_config->has_session_id = TRUE;
    p_pb_class_map_action_config->session_id = p_class_map_action_config->session_id;
    p_pb_class_map_action_config->policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_class_map_action_config->policer)+1);
    sal_strcpy(p_pb_class_map_action_config->policer, p_class_map_action_config->policer);
    p_pb_class_map_action_config->has_new_svlan_id = TRUE;
    p_pb_class_map_action_config->new_svlan_id = p_class_map_action_config->new_svlan_id;
    p_pb_class_map_action_config->has_new_cvlan_id = TRUE;
    p_pb_class_map_action_config->new_cvlan_id = p_class_map_action_config->new_cvlan_id;
    p_pb_class_map_action_config->has_new_scos = TRUE;
    p_pb_class_map_action_config->new_scos = p_class_map_action_config->new_scos;
    p_pb_class_map_action_config->has_new_ccos = TRUE;
    p_pb_class_map_action_config->new_ccos = p_class_map_action_config->new_ccos;
    p_pb_class_map_action_config->has_redirect_port_ifindex = TRUE;
    p_pb_class_map_action_config->redirect_port_ifindex = p_class_map_action_config->redirect_port_ifindex;

    return PM_E_NONE;
}

int32
pb_tbl_class_map_action_config_to_pb_free_packed(Cdb__TblClassMapActionConfig *p_pb_class_map_action_config)
{
    pb_compose_class_map_action_config_key_t_to_pb_free_packed(p_pb_class_map_action_config->key);
    if (p_pb_class_map_action_config->policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_class_map_action_config->policer);
        p_pb_class_map_action_config->policer = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_class_map_action_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblClassMapActionConfigKey pb_class_map_action_config_key = CDB__TBL_CLASS_MAP_ACTION_CONFIG_KEY__INIT;
    Cdb__TblClassMapActionConfig pb_class_map_action_config = CDB__TBL_CLASS_MAP_ACTION_CONFIG__INIT;
    tbl_class_map_action_config_t *p_class_map_action_config = (tbl_class_map_action_config_t*)p_tbl;
    int32 len = 0;

    pb_class_map_action_config.key = &pb_class_map_action_config_key;
    pb_tbl_class_map_action_config_to_pb(only_key, p_class_map_action_config, &pb_class_map_action_config);
    len = cdb__tbl_class_map_action_config__pack(&pb_class_map_action_config, buf);
    pb_tbl_class_map_action_config_to_pb_free_packed(&pb_class_map_action_config);

    return len;
}

int32
pb_tbl_class_map_action_config_dump(Cdb__TblClassMapActionConfig *p_pb_class_map_action_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_class_map_action_config_key_t_dump(p_pb_class_map_action_config->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/action_flag=%u", p_pb_class_map_action_config->action_flag);
    offset += sal_sprintf(out + offset, "/new_tc=%u", p_pb_class_map_action_config->new_tc);
    offset += sal_sprintf(out + offset, "/new_color=%d", p_pb_class_map_action_config->new_color);
    offset += sal_sprintf(out + offset, "/new_dscp=%u", p_pb_class_map_action_config->new_dscp);
    offset += sal_sprintf(out + offset, "/session_id=%u", p_pb_class_map_action_config->session_id);
    offset += sal_sprintf(out + offset, "/policer=%s", p_pb_class_map_action_config->policer);
    offset += sal_sprintf(out + offset, "/new_svlan_id=%u", p_pb_class_map_action_config->new_svlan_id);
    offset += sal_sprintf(out + offset, "/new_cvlan_id=%u", p_pb_class_map_action_config->new_cvlan_id);
    offset += sal_sprintf(out + offset, "/new_scos=%u", p_pb_class_map_action_config->new_scos);
    offset += sal_sprintf(out + offset, "/new_ccos=%u", p_pb_class_map_action_config->new_ccos);
    offset += sal_sprintf(out + offset, "/redirect_port_ifindex=%u", p_pb_class_map_action_config->redirect_port_ifindex);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_ACL_POLICY_ACTION */
int32
pb_tbl_fea_acl_policy_action_to_pb(uint32 only_key, tbl_fea_acl_policy_action_t *p_fea_acl_policy_action, Cdb__TblFeaAclPolicyAction *p_pb_fea_acl_policy_action)
{
    p_pb_fea_acl_policy_action->key->acl_policy_action_id = p_fea_acl_policy_action->key.acl_policy_action_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_fea_acl_policy_action->has_flags_class_get_policer_stats = TRUE;
    p_pb_fea_acl_policy_action->flags_class_get_policer_stats = GLB_FLAG_ISSET(p_fea_acl_policy_action->flags, GLB_ACL_POLICY_POLICY_STATS_FLAGS_GET_STATS) ? TRUE : FALSE;
    p_pb_fea_acl_policy_action->has_flags_calss_clear_policer_stats = TRUE;
    p_pb_fea_acl_policy_action->flags_calss_clear_policer_stats = GLB_FLAG_ISSET(p_fea_acl_policy_action->flags, GLB_ACL_POLICY_POLICY_STATS_FLAGS_CLEAR_STATS) ? TRUE : FALSE;
    p_pb_fea_acl_policy_action->has_policer_id = TRUE;
    p_pb_fea_acl_policy_action->policer_id = p_fea_acl_policy_action->policer_id;
    p_pb_fea_acl_policy_action->policer_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_fea_acl_policy_action->policer_name)+1);
    sal_strcpy(p_pb_fea_acl_policy_action->policer_name, p_fea_acl_policy_action->policer_name);
    p_pb_fea_acl_policy_action->has_policer_id_ref = TRUE;
    p_pb_fea_acl_policy_action->policer_id_ref = p_fea_acl_policy_action->policer_id_ref;
    p_pb_fea_acl_policy_action->has_green_packet = TRUE;
    p_pb_fea_acl_policy_action->green_packet = p_fea_acl_policy_action->green_packet;
    p_pb_fea_acl_policy_action->has_green_byte = TRUE;
    p_pb_fea_acl_policy_action->green_byte = p_fea_acl_policy_action->green_byte;
    p_pb_fea_acl_policy_action->has_yellow_packet = TRUE;
    p_pb_fea_acl_policy_action->yellow_packet = p_fea_acl_policy_action->yellow_packet;
    p_pb_fea_acl_policy_action->has_yellow_byte = TRUE;
    p_pb_fea_acl_policy_action->yellow_byte = p_fea_acl_policy_action->yellow_byte;
    p_pb_fea_acl_policy_action->has_red_packet = TRUE;
    p_pb_fea_acl_policy_action->red_packet = p_fea_acl_policy_action->red_packet;
    p_pb_fea_acl_policy_action->has_red_byte = TRUE;
    p_pb_fea_acl_policy_action->red_byte = p_fea_acl_policy_action->red_byte;

    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_policy_action_to_pb_free_packed(Cdb__TblFeaAclPolicyAction *p_pb_fea_acl_policy_action)
{
    if (p_pb_fea_acl_policy_action->policer_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_fea_acl_policy_action->policer_name);
        p_pb_fea_acl_policy_action->policer_name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_fea_acl_policy_action_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaAclPolicyActionKey pb_fea_acl_policy_action_key = CDB__TBL_FEA_ACL_POLICY_ACTION_KEY__INIT;
    Cdb__TblFeaAclPolicyAction pb_fea_acl_policy_action = CDB__TBL_FEA_ACL_POLICY_ACTION__INIT;
    tbl_fea_acl_policy_action_t *p_fea_acl_policy_action = (tbl_fea_acl_policy_action_t*)p_tbl;
    int32 len = 0;

    pb_fea_acl_policy_action.key = &pb_fea_acl_policy_action_key;
    pb_tbl_fea_acl_policy_action_to_pb(only_key, p_fea_acl_policy_action, &pb_fea_acl_policy_action);
    len = cdb__tbl_fea_acl_policy_action__pack(&pb_fea_acl_policy_action, buf);
    pb_tbl_fea_acl_policy_action_to_pb_free_packed(&pb_fea_acl_policy_action);

    return len;
}

int32
pb_tbl_fea_acl_policy_action_dump(Cdb__TblFeaAclPolicyAction *p_pb_fea_acl_policy_action, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->acl_policy_action_id=%llu", p_pb_fea_acl_policy_action->key->acl_policy_action_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/flags_class_get_policer_stats=%u", p_pb_fea_acl_policy_action->flags_class_get_policer_stats);
    offset += sal_sprintf(out + offset, "/flags_calss_clear_policer_stats=%u", p_pb_fea_acl_policy_action->flags_calss_clear_policer_stats);
    offset += sal_sprintf(out + offset, "/policer_id=%llu", p_pb_fea_acl_policy_action->policer_id);
    offset += sal_sprintf(out + offset, "/policer_name=%s", p_pb_fea_acl_policy_action->policer_name);
    offset += sal_sprintf(out + offset, "/policer_id_ref=%llu", p_pb_fea_acl_policy_action->policer_id_ref);
    offset += sal_sprintf(out + offset, "/green_packet=%llu", p_pb_fea_acl_policy_action->green_packet);
    offset += sal_sprintf(out + offset, "/green_byte=%llu", p_pb_fea_acl_policy_action->green_byte);
    offset += sal_sprintf(out + offset, "/yellow_packet=%llu", p_pb_fea_acl_policy_action->yellow_packet);
    offset += sal_sprintf(out + offset, "/yellow_byte=%llu", p_pb_fea_acl_policy_action->yellow_byte);
    offset += sal_sprintf(out + offset, "/red_packet=%llu", p_pb_fea_acl_policy_action->red_packet);
    offset += sal_sprintf(out + offset, "/red_byte=%llu", p_pb_fea_acl_policy_action->red_byte);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IGSP_GLOBAL */
int32
pb_tbl_igsp_global_to_pb(uint32 only_key, tbl_igsp_global_t *p_glb, Cdb__TblIgspGlobal *p_pb_glb)
{
    p_pb_glb->has_enable = TRUE;
    p_pb_glb->enable = p_glb->enable;
    p_pb_glb->has_fast_leave = TRUE;
    p_pb_glb->fast_leave = p_glb->fast_leave;
    p_pb_glb->has_discard_unknown = TRUE;
    p_pb_glb->discard_unknown = p_glb->discard_unknown;
    p_pb_glb->has_report_suppress = TRUE;
    p_pb_glb->report_suppress = p_glb->report_suppress;
    p_pb_glb->has_version = TRUE;
    p_pb_glb->version = p_glb->version;
    p_pb_glb->has_querier_max_response_time = TRUE;
    p_pb_glb->querier_max_response_time = p_glb->querier_max_response_time;
    p_pb_glb->has_query_interval = TRUE;
    p_pb_glb->query_interval = p_glb->query_interval;
    p_pb_glb->has_lmqi = TRUE;
    p_pb_glb->lmqi = p_glb->lmqi;
    p_pb_glb->has_lmqc = TRUE;
    p_pb_glb->lmqc = p_glb->lmqc;
    p_pb_glb->has_robustness_var = TRUE;
    p_pb_glb->robustness_var = p_glb->robustness_var;
    p_pb_glb->has_max_member_number = TRUE;
    p_pb_glb->max_member_number = p_glb->max_member_number;
    p_pb_glb->has_curr_group_member = TRUE;
    p_pb_glb->curr_group_member = p_glb->curr_group_member;
    p_pb_glb->has_tcn_enable = TRUE;
    p_pb_glb->tcn_enable = p_glb->tcn_enable;
    p_pb_glb->has_tcn_query_count = TRUE;
    p_pb_glb->tcn_query_count = p_glb->tcn_query_count;
    p_pb_glb->has_tcn_query_interval = TRUE;
    p_pb_glb->tcn_query_interval = p_glb->tcn_query_interval;
    p_pb_glb->has_tcn_query_current_count = TRUE;
    p_pb_glb->tcn_query_current_count = p_glb->tcn_query_current_count;
    p_pb_glb->has_tcn_query_max_response_time = TRUE;
    p_pb_glb->tcn_query_max_response_time = p_glb->tcn_query_max_response_time;
    pb_compose_addr_ipv4_t_to_pb(&p_glb->global_src, p_pb_glb->global_src);
    pb_compose_addr_ipv4_t_to_pb(&p_glb->all_hosts, p_pb_glb->all_hosts);
    pb_compose_addr_ipv4_t_to_pb(&p_glb->all_routers, p_pb_glb->all_routers);
    pb_compose_addr_ipv4_t_to_pb(&p_glb->v3_routers, p_pb_glb->v3_routers);

    return PM_E_NONE;
}

int32
pb_tbl_igsp_global_to_pb_free_packed(Cdb__TblIgspGlobal *p_pb_glb)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_glb->global_src);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_glb->all_hosts);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_glb->all_routers);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_glb->v3_routers);
    return PM_E_NONE;
}

int32
pb_tbl_igsp_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIgspGlobal pb_glb = CDB__TBL_IGSP_GLOBAL__INIT;
    tbl_igsp_global_t *p_glb = (tbl_igsp_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T global_src = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T all_hosts = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T all_routers = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T v3_routers = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_glb.global_src = &global_src;
    pb_glb.all_hosts = &all_hosts;
    pb_glb.all_routers = &all_routers;
    pb_glb.v3_routers = &v3_routers;
    pb_tbl_igsp_global_to_pb(only_key, p_glb, &pb_glb);
    len = cdb__tbl_igsp_global__pack(&pb_glb, buf);
    pb_tbl_igsp_global_to_pb_free_packed(&pb_glb);

    return len;
}

int32
pb_tbl_igsp_global_dump(Cdb__TblIgspGlobal *p_pb_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_glb->enable);
    offset += sal_sprintf(out + offset, "/fast_leave=%u", p_pb_glb->fast_leave);
    offset += sal_sprintf(out + offset, "/discard_unknown=%u", p_pb_glb->discard_unknown);
    offset += sal_sprintf(out + offset, "/report_suppress=%u", p_pb_glb->report_suppress);
    offset += sal_sprintf(out + offset, "/version=%u", p_pb_glb->version);
    offset += sal_sprintf(out + offset, "/querier_max_response_time=%u", p_pb_glb->querier_max_response_time);
    offset += sal_sprintf(out + offset, "/query_interval=%u", p_pb_glb->query_interval);
    offset += sal_sprintf(out + offset, "/lmqi=%u", p_pb_glb->lmqi);
    offset += sal_sprintf(out + offset, "/lmqc=%u", p_pb_glb->lmqc);
    offset += sal_sprintf(out + offset, "/robustness_var=%u", p_pb_glb->robustness_var);
    offset += sal_sprintf(out + offset, "/max_member_number=%u", p_pb_glb->max_member_number);
    offset += sal_sprintf(out + offset, "/curr_group_member=%u", p_pb_glb->curr_group_member);
    offset += sal_sprintf(out + offset, "/tcn_enable=%u", p_pb_glb->tcn_enable);
    offset += sal_sprintf(out + offset, "/tcn_query_count=%u", p_pb_glb->tcn_query_count);
    offset += sal_sprintf(out + offset, "/tcn_query_interval=%u", p_pb_glb->tcn_query_interval);
    offset += sal_sprintf(out + offset, "/tcn_query_current_count=%u", p_pb_glb->tcn_query_current_count);
    offset += sal_sprintf(out + offset, "/tcn_query_max_response_time=%u", p_pb_glb->tcn_query_max_response_time);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_glb->global_src, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_glb->all_hosts, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_glb->all_routers, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_glb->v3_routers, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IGSP_INTF */
int32
pb_tbl_igsp_intf_to_pb(uint32 only_key, tbl_igsp_intf_t *p_if, Cdb__TblIgspIntf *p_pb_if)
{
    p_pb_if->key->vid = p_if->key.vid;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_if->acl_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->acl_name)+1);
    sal_strcpy(p_pb_if->acl_name, p_if->acl_name);
    p_pb_if->has_enable = TRUE;
    p_pb_if->enable = p_if->enable;
    p_pb_if->has_fast_leave = TRUE;
    p_pb_if->fast_leave = p_if->fast_leave;
    p_pb_if->has_discard_unknown = TRUE;
    p_pb_if->discard_unknown = p_if->discard_unknown;
    p_pb_if->has_report_suppress = TRUE;
    p_pb_if->report_suppress = p_if->report_suppress;
    p_pb_if->has_version = TRUE;
    p_pb_if->version = p_if->version;
    p_pb_if->has_querier_enable = TRUE;
    p_pb_if->querier_enable = p_if->querier_enable;
    p_pb_if->has_querier_operate = TRUE;
    p_pb_if->querier_operate = p_if->querier_operate;
    p_pb_if->has_query_interval = TRUE;
    p_pb_if->query_interval = p_if->query_interval;
    p_pb_if->has_admin_other_query_interval = TRUE;
    p_pb_if->admin_other_query_interval = p_if->admin_other_query_interval;
    p_pb_if->has_other_query_interval = TRUE;
    p_pb_if->other_query_interval = p_if->other_query_interval;
    p_pb_if->has_querier_max_response_time = TRUE;
    p_pb_if->querier_max_response_time = p_if->querier_max_response_time;
    pb_compose_addr_ipv4_t_to_pb(&p_if->querier_config_address, p_pb_if->querier_config_address);
    pb_compose_addr_ipv4_t_to_pb(&p_if->querier_oper_address, p_pb_if->querier_oper_address);
    pb_compose_addr_ipv4_t_to_pb(&p_if->other_querier_address, p_pb_if->other_querier_address);
    pb_compose_addr_ipv4_t_to_pb(&p_if->vlan_if_address, p_pb_if->vlan_if_address);
    p_pb_if->has_lmqi = TRUE;
    p_pb_if->lmqi = p_if->lmqi;
    p_pb_if->has_lmqc = TRUE;
    p_pb_if->lmqc = p_if->lmqc;
    p_pb_if->has_max_member_number = TRUE;
    p_pb_if->max_member_number = p_if->max_member_number;
    p_pb_if->has_curr_group_member = TRUE;
    p_pb_if->curr_group_member = p_if->curr_group_member;
    p_pb_if->has_group_member_interval = TRUE;
    p_pb_if->group_member_interval = p_if->group_member_interval;
    p_pb_if->has_robustness_var = TRUE;
    p_pb_if->robustness_var = p_if->robustness_var;
    p_pb_if->has_mrouter_aging_interval = TRUE;
    p_pb_if->mrouter_aging_interval = p_if->mrouter_aging_interval;
    p_pb_if->has_startup_query_count = TRUE;
    p_pb_if->startup_query_count = p_if->startup_query_count;

    return PM_E_NONE;
}

int32
pb_tbl_igsp_intf_to_pb_free_packed(Cdb__TblIgspIntf *p_pb_if)
{
    if (p_pb_if->acl_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->acl_name);
        p_pb_if->acl_name = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_if->querier_config_address);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_if->querier_oper_address);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_if->other_querier_address);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_if->vlan_if_address);
    return PM_E_NONE;
}

int32
pb_tbl_igsp_intf_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIgspIntfKey pb_if_key = CDB__TBL_IGSP_INTF_KEY__INIT;
    Cdb__TblIgspIntf pb_if = CDB__TBL_IGSP_INTF__INIT;
    tbl_igsp_intf_t *p_if = (tbl_igsp_intf_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T querier_config_address = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T querier_oper_address = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T other_querier_address = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T vlan_if_address = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_if.key = &pb_if_key;
    pb_if.querier_config_address = &querier_config_address;
    pb_if.querier_oper_address = &querier_oper_address;
    pb_if.other_querier_address = &other_querier_address;
    pb_if.vlan_if_address = &vlan_if_address;
    pb_tbl_igsp_intf_to_pb(only_key, p_if, &pb_if);
    len = cdb__tbl_igsp_intf__pack(&pb_if, buf);
    pb_tbl_igsp_intf_to_pb_free_packed(&pb_if);

    return len;
}

int32
pb_tbl_igsp_intf_dump(Cdb__TblIgspIntf *p_pb_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->vid=%u", p_pb_if->key->vid);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/acl_name=%s", p_pb_if->acl_name);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_if->enable);
    offset += sal_sprintf(out + offset, "/fast_leave=%u", p_pb_if->fast_leave);
    offset += sal_sprintf(out + offset, "/discard_unknown=%u", p_pb_if->discard_unknown);
    offset += sal_sprintf(out + offset, "/report_suppress=%u", p_pb_if->report_suppress);
    offset += sal_sprintf(out + offset, "/version=%u", p_pb_if->version);
    offset += sal_sprintf(out + offset, "/querier_enable=%u", p_pb_if->querier_enable);
    offset += sal_sprintf(out + offset, "/querier_operate=%u", p_pb_if->querier_operate);
    offset += sal_sprintf(out + offset, "/query_interval=%u", p_pb_if->query_interval);
    offset += sal_sprintf(out + offset, "/admin_other_query_interval=%u", p_pb_if->admin_other_query_interval);
    offset += sal_sprintf(out + offset, "/other_query_interval=%u", p_pb_if->other_query_interval);
    offset += sal_sprintf(out + offset, "/querier_max_response_time=%u", p_pb_if->querier_max_response_time);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_if->querier_config_address, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_if->querier_oper_address, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_if->other_querier_address, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_if->vlan_if_address, (out + offset));
    offset += sal_sprintf(out + offset, "/lmqi=%u", p_pb_if->lmqi);
    offset += sal_sprintf(out + offset, "/lmqc=%u", p_pb_if->lmqc);
    offset += sal_sprintf(out + offset, "/max_member_number=%u", p_pb_if->max_member_number);
    offset += sal_sprintf(out + offset, "/curr_group_member=%u", p_pb_if->curr_group_member);
    offset += sal_sprintf(out + offset, "/group_member_interval=%u", p_pb_if->group_member_interval);
    offset += sal_sprintf(out + offset, "/robustness_var=%u", p_pb_if->robustness_var);
    offset += sal_sprintf(out + offset, "/mrouter_aging_interval=%u", p_pb_if->mrouter_aging_interval);
    offset += sal_sprintf(out + offset, "/startup_query_count=%u", p_pb_if->startup_query_count);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IGSP_GROUP */
int32
pb_tbl_igsp_group_to_pb(uint32 only_key, tbl_igsp_group_t *p_group, Cdb__TblIgspGroup *p_pb_group)
{
    pb_compose_igsp_group_key_t_to_pb(&p_group->key, p_pb_group->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_group->has_retx_group_lmqc = TRUE;
    p_pb_group->retx_group_lmqc = p_group->retx_group_lmqc;
    p_pb_group->has_retx_group_source_lmqc = TRUE;
    p_pb_group->retx_group_source_lmqc = p_group->retx_group_source_lmqc;
    p_pb_group->has_liveness = TRUE;
    p_pb_group->liveness = p_group->liveness;
    pb_compose_addr_ipv4_t_to_pb(&p_group->last_reporter_address, p_pb_group->last_reporter_address);
    pb_compose_sal_time_t_to_pb(&p_group->uptime, p_pb_group->uptime);
    pb_compose_sal_time_t_to_pb(&p_group->update_time, p_pb_group->update_time);
    p_pb_group->has_type = TRUE;
    p_pb_group->type = p_group->type;
    p_pb_group->has_inactive = TRUE;
    p_pb_group->inactive = p_group->inactive;
    p_pb_group->has_is_v3_leave = TRUE;
    p_pb_group->is_v3_leave = p_group->is_v3_leave;

    return PM_E_NONE;
}

int32
pb_tbl_igsp_group_to_pb_free_packed(Cdb__TblIgspGroup *p_pb_group)
{
    pb_compose_igsp_group_key_t_to_pb_free_packed(p_pb_group->key);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_group->last_reporter_address);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_group->uptime);
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_group->update_time);
    return PM_E_NONE;
}

int32
pb_tbl_igsp_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIgspGroupKey pb_group_key = CDB__TBL_IGSP_GROUP_KEY__INIT;
    Cdb__TblIgspGroup pb_group = CDB__TBL_IGSP_GROUP__INIT;
    tbl_igsp_group_t *p_group = (tbl_igsp_group_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T last_reporter_address = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeSalTimeT uptime = CDB__COMPOSE_SAL_TIME_T__INIT;
    Cdb__ComposeSalTimeT update_time = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_group.key = &pb_group_key;
    pb_group.last_reporter_address = &last_reporter_address;
    pb_group.uptime = &uptime;
    pb_group.update_time = &update_time;
    pb_tbl_igsp_group_to_pb(only_key, p_group, &pb_group);
    len = cdb__tbl_igsp_group__pack(&pb_group, buf);
    pb_tbl_igsp_group_to_pb_free_packed(&pb_group);

    return len;
}

int32
pb_tbl_igsp_group_dump(Cdb__TblIgspGroup *p_pb_group, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_igsp_group_key_t_dump(p_pb_group->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/retx_group_lmqc=%u", p_pb_group->retx_group_lmqc);
    offset += sal_sprintf(out + offset, "/retx_group_source_lmqc=%u", p_pb_group->retx_group_source_lmqc);
    offset += sal_sprintf(out + offset, "/liveness=%u", p_pb_group->liveness);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_group->last_reporter_address, (out + offset));
    offset += pb_compose_sal_time_t_dump(p_pb_group->uptime, (out + offset));
    offset += pb_compose_sal_time_t_dump(p_pb_group->update_time, (out + offset));
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_group->type);
    offset += sal_sprintf(out + offset, "/inactive=%u", p_pb_group->inactive);
    offset += sal_sprintf(out + offset, "/is_v3_leave=%u", p_pb_group->is_v3_leave);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTH_CFG */
int32
pb_tbl_auth_cfg_to_pb(uint32 only_key, tbl_auth_cfg_t *p_auth_cfg, Cdb__TblAuthCfg *p_pb_auth_cfg)
{
    p_pb_auth_cfg->secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_auth_cfg->secret)+1);
    sal_strcpy(p_pb_auth_cfg->secret, p_auth_cfg->secret);
    p_pb_auth_cfg->enc_secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_auth_cfg->enc_secret)+1);
    sal_strcpy(p_pb_auth_cfg->enc_secret, p_auth_cfg->enc_secret);
    p_pb_auth_cfg->has_timeout = TRUE;
    p_pb_auth_cfg->timeout = p_auth_cfg->timeout;
    p_pb_auth_cfg->has_retries = TRUE;
    p_pb_auth_cfg->retries = p_auth_cfg->retries;
    p_pb_auth_cfg->has_deadtime = TRUE;
    p_pb_auth_cfg->deadtime = p_auth_cfg->deadtime;

    return PM_E_NONE;
}

int32
pb_tbl_auth_cfg_to_pb_free_packed(Cdb__TblAuthCfg *p_pb_auth_cfg)
{
    if (p_pb_auth_cfg->secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_cfg->secret);
        p_pb_auth_cfg->secret = NULL;
    }

    if (p_pb_auth_cfg->enc_secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_cfg->enc_secret);
        p_pb_auth_cfg->enc_secret = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_auth_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthCfg pb_auth_cfg = CDB__TBL_AUTH_CFG__INIT;
    tbl_auth_cfg_t *p_auth_cfg = (tbl_auth_cfg_t*)p_tbl;
    int32 len = 0;

    pb_tbl_auth_cfg_to_pb(only_key, p_auth_cfg, &pb_auth_cfg);
    len = cdb__tbl_auth_cfg__pack(&pb_auth_cfg, buf);
    pb_tbl_auth_cfg_to_pb_free_packed(&pb_auth_cfg);

    return len;
}

int32
pb_tbl_auth_cfg_dump(Cdb__TblAuthCfg *p_pb_auth_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/secret=%s", p_pb_auth_cfg->secret);
    offset += sal_sprintf(out + offset, "/enc_secret=%s", p_pb_auth_cfg->enc_secret);
    offset += sal_sprintf(out + offset, "/timeout=%u", p_pb_auth_cfg->timeout);
    offset += sal_sprintf(out + offset, "/retries=%u", p_pb_auth_cfg->retries);
    offset += sal_sprintf(out + offset, "/deadtime=%u", p_pb_auth_cfg->deadtime);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTH_SERVER */
int32
pb_tbl_auth_server_to_pb(uint32 only_key, tbl_auth_server_t *p_auth_server, Cdb__TblAuthServer *p_pb_auth_server)
{
    pb_compose_auth_server_key_t_to_pb(&p_auth_server->key, p_pb_auth_server->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_auth_server->secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_auth_server->secret)+1);
    sal_strcpy(p_pb_auth_server->secret, p_auth_server->secret);
    p_pb_auth_server->enc_secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_auth_server->enc_secret)+1);
    sal_strcpy(p_pb_auth_server->enc_secret, p_auth_server->enc_secret);
    p_pb_auth_server->has_port = TRUE;
    p_pb_auth_server->port = p_auth_server->port;
    p_pb_auth_server->has_timeout = TRUE;
    p_pb_auth_server->timeout = p_auth_server->timeout;
    p_pb_auth_server->has_retries = TRUE;
    p_pb_auth_server->retries = p_auth_server->retries;
    p_pb_auth_server->has_dead = TRUE;
    p_pb_auth_server->dead = p_auth_server->dead;
    p_pb_auth_server->has_is_inband = TRUE;
    p_pb_auth_server->is_inband = p_auth_server->is_inband;
    p_pb_auth_server->has_reawake_time = TRUE;
    p_pb_auth_server->reawake_time = p_auth_server->reawake_time;

    return PM_E_NONE;
}

int32
pb_tbl_auth_server_to_pb_free_packed(Cdb__TblAuthServer *p_pb_auth_server)
{
    pb_compose_auth_server_key_t_to_pb_free_packed(p_pb_auth_server->key);
    if (p_pb_auth_server->secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_server->secret);
        p_pb_auth_server->secret = NULL;
    }

    if (p_pb_auth_server->enc_secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_server->enc_secret);
        p_pb_auth_server->enc_secret = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_auth_server_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthServerKey pb_auth_server_key = CDB__TBL_AUTH_SERVER_KEY__INIT;
    Cdb__TblAuthServer pb_auth_server = CDB__TBL_AUTH_SERVER__INIT;
    tbl_auth_server_t *p_auth_server = (tbl_auth_server_t*)p_tbl;
    int32 len = 0;

    pb_auth_server.key = &pb_auth_server_key;
    pb_tbl_auth_server_to_pb(only_key, p_auth_server, &pb_auth_server);
    len = cdb__tbl_auth_server__pack(&pb_auth_server, buf);
    pb_tbl_auth_server_to_pb_free_packed(&pb_auth_server);

    return len;
}

int32
pb_tbl_auth_server_dump(Cdb__TblAuthServer *p_pb_auth_server, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_auth_server_key_t_dump(p_pb_auth_server->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/secret=%s", p_pb_auth_server->secret);
    offset += sal_sprintf(out + offset, "/enc_secret=%s", p_pb_auth_server->enc_secret);
    offset += sal_sprintf(out + offset, "/port=%u", p_pb_auth_server->port);
    offset += sal_sprintf(out + offset, "/timeout=%u", p_pb_auth_server->timeout);
    offset += sal_sprintf(out + offset, "/retries=%u", p_pb_auth_server->retries);
    offset += sal_sprintf(out + offset, "/dead=%u", p_pb_auth_server->dead);
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_auth_server->is_inband);
    offset += sal_sprintf(out + offset, "/reawake_time=%u", p_pb_auth_server->reawake_time);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTH_SESSION */
int32
pb_tbl_auth_session_to_pb(uint32 only_key, tbl_auth_session_t *p_auth_session, Cdb__TblAuthSession *p_pb_auth_session)
{
    pb_compose_auth_session_key_t_to_pb(&p_auth_session->key, p_pb_auth_session->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_user_t_to_pb(&p_auth_session->user, p_pb_auth_session->user);
    p_pb_auth_session->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_auth_session->passwd)+1);
    sal_strcpy(p_pb_auth_session->passwd, p_auth_session->passwd);
    p_pb_auth_session->has_status = TRUE;
    p_pb_auth_session->status = p_auth_session->status;
    p_pb_auth_session->has_authenticator = TRUE;
    p_pb_auth_session->authenticator.len = sizeof(p_auth_session->authenticator);
    p_pb_auth_session->authenticator.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_auth_session->authenticator));
    sal_memcpy(p_pb_auth_session->authenticator.data, p_auth_session->authenticator, sizeof(p_auth_session->authenticator));
    p_pb_auth_session->has_oauthenticator = TRUE;
    p_pb_auth_session->oauthenticator.len = sizeof(p_auth_session->oauthenticator);
    p_pb_auth_session->oauthenticator.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_auth_session->oauthenticator));
    sal_memcpy(p_pb_auth_session->oauthenticator.data, p_auth_session->oauthenticator, sizeof(p_auth_session->oauthenticator));
    p_pb_auth_session->has_dot1x_mac_ifindex = TRUE;
    p_pb_auth_session->dot1x_mac_ifindex = p_auth_session->dot1x_mac_ifindex;
    pb_compose_mac_addr_t_to_pb(p_auth_session->dot1x_mac_addr, p_pb_auth_session->dot1x_mac_addr);
    p_pb_auth_session->has_is_auth_bypass = TRUE;
    p_pb_auth_session->is_auth_bypass = p_auth_session->is_auth_bypass;
    p_pb_auth_session->has_author_start = TRUE;
    p_pb_auth_session->author_start = p_auth_session->author_start;
    p_pb_auth_session->has_acct_start = TRUE;
    p_pb_auth_session->acct_start = p_auth_session->acct_start;
    p_pb_auth_session->has_acct_stop = TRUE;
    p_pb_auth_session->acct_stop = p_auth_session->acct_stop;
    p_pb_auth_session->has_acctcmd_start = TRUE;
    p_pb_auth_session->acctcmd_start = p_auth_session->acctcmd_start;

    return PM_E_NONE;
}

int32
pb_tbl_auth_session_to_pb_free_packed(Cdb__TblAuthSession *p_pb_auth_session)
{
    pb_compose_auth_session_key_t_to_pb_free_packed(p_pb_auth_session->key);
    pb_compose_user_t_to_pb_free_packed(p_pb_auth_session->user);
    if (p_pb_auth_session->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_session->passwd);
        p_pb_auth_session->passwd = NULL;
    }

    if (p_pb_auth_session->authenticator.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_session->authenticator.data);
        p_pb_auth_session->authenticator.data = NULL;
    }

    if (p_pb_auth_session->oauthenticator.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_auth_session->oauthenticator.data);
        p_pb_auth_session->oauthenticator.data = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_auth_session->dot1x_mac_addr);
    return PM_E_NONE;
}

int32
pb_tbl_auth_session_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthSessionKey pb_auth_session_key = CDB__TBL_AUTH_SESSION_KEY__INIT;
    Cdb__TblAuthSession pb_auth_session = CDB__TBL_AUTH_SESSION__INIT;
    tbl_auth_session_t *p_auth_session = (tbl_auth_session_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeUserT user = CDB__COMPOSE_USER_T__INIT;
    Cdb__ComposeMacAddrT dot1x_mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_auth_session.key = &pb_auth_session_key;
    pb_auth_session.user = &user;
    pb_auth_session.dot1x_mac_addr = &dot1x_mac_addr;
    pb_tbl_auth_session_to_pb(only_key, p_auth_session, &pb_auth_session);
    len = cdb__tbl_auth_session__pack(&pb_auth_session, buf);
    pb_tbl_auth_session_to_pb_free_packed(&pb_auth_session);

    return len;
}

int32
pb_tbl_auth_session_dump(Cdb__TblAuthSession *p_pb_auth_session, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_auth_session_key_t_dump(p_pb_auth_session->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_user_t_dump(p_pb_auth_session->user, (out + offset));
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_auth_session->passwd);
    offset += sal_sprintf(out + offset, "/status=%u", p_pb_auth_session->status);
    offset += sal_sprintf(out + offset, "/authenticator=");
    offset += pb_uint8_array_dump(p_pb_auth_session->authenticator.data, p_pb_auth_session->authenticator.len, (out + offset));
    offset += sal_sprintf(out + offset, "/oauthenticator=");
    offset += pb_uint8_array_dump(p_pb_auth_session->oauthenticator.data, p_pb_auth_session->oauthenticator.len, (out + offset));
    offset += sal_sprintf(out + offset, "/dot1x_mac_ifindex=%u", p_pb_auth_session->dot1x_mac_ifindex);
    offset += pb_compose_mac_addr_t_dump(p_pb_auth_session->dot1x_mac_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/is_auth_bypass=%u", p_pb_auth_session->is_auth_bypass);
    offset += sal_sprintf(out + offset, "/author_start=%u", p_pb_auth_session->author_start);
    offset += sal_sprintf(out + offset, "/acct_start=%u", p_pb_auth_session->acct_start);
    offset += sal_sprintf(out + offset, "/acct_stop=%u", p_pb_auth_session->acct_stop);
    offset += sal_sprintf(out + offset, "/acctcmd_start=%u", p_pb_auth_session->acctcmd_start);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTHD_DEBUG */
int32
pb_tbl_authd_debug_to_pb(uint32 only_key, tbl_authd_debug_t *p_authd_debug, Cdb__TblAuthdDebug *p_pb_authd_debug)
{
    p_pb_authd_debug->has_auth_event = TRUE;
    p_pb_authd_debug->auth_event = GLB_FLAG_ISSET(p_authd_debug->flags, AUTHD_DBG_FLAG_EVENT) ? TRUE : FALSE;
    p_pb_authd_debug->has_auth_packet = TRUE;
    p_pb_authd_debug->auth_packet = GLB_FLAG_ISSET(p_authd_debug->flags, AUTHD_DBG_FLAG_PACKET) ? TRUE : FALSE;
    p_pb_authd_debug->has_auth_protocol = TRUE;
    p_pb_authd_debug->auth_protocol = GLB_FLAG_ISSET(p_authd_debug->flags, AUTHD_DBG_FLAG_PROTO) ? TRUE : FALSE;
    p_pb_authd_debug->has_auth_timer = TRUE;
    p_pb_authd_debug->auth_timer = GLB_FLAG_ISSET(p_authd_debug->flags, AUTHD_DBG_FLAG_TIMER) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_authd_debug_to_pb_free_packed(Cdb__TblAuthdDebug *p_pb_authd_debug)
{
    return PM_E_NONE;
}

int32
pb_tbl_authd_debug_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthdDebug pb_authd_debug = CDB__TBL_AUTHD_DEBUG__INIT;
    tbl_authd_debug_t *p_authd_debug = (tbl_authd_debug_t*)p_tbl;
    int32 len = 0;

    pb_tbl_authd_debug_to_pb(only_key, p_authd_debug, &pb_authd_debug);
    len = cdb__tbl_authd_debug__pack(&pb_authd_debug, buf);
    pb_tbl_authd_debug_to_pb_free_packed(&pb_authd_debug);

    return len;
}

int32
pb_tbl_authd_debug_dump(Cdb__TblAuthdDebug *p_pb_authd_debug, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/auth_event=%u", p_pb_authd_debug->auth_event);
    offset += sal_sprintf(out + offset, "/auth_packet=%u", p_pb_authd_debug->auth_packet);
    offset += sal_sprintf(out + offset, "/auth_protocol=%u", p_pb_authd_debug->auth_protocol);
    offset += sal_sprintf(out + offset, "/auth_timer=%u", p_pb_authd_debug->auth_timer);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DOT1X_GLOBAL */
int32
pb_tbl_dot1x_global_to_pb(uint32 only_key, tbl_dot1x_global_t *p_dot1x_global, Cdb__TblDot1xGlobal *p_pb_dot1x_global)
{
    p_pb_dot1x_global->has_global_auth_enable = TRUE;
    p_pb_dot1x_global->global_auth_enable = p_dot1x_global->global_auth_enable;
    pb_compose_mac_addr_t_to_pb(p_dot1x_global->eapol_group_address, p_pb_dot1x_global->eapol_group_address);
    p_pb_dot1x_global->has_radius_default_retry = TRUE;
    p_pb_dot1x_global->radius_default_retry = p_dot1x_global->radius_default_retry;
    p_pb_dot1x_global->has_radius_default_timeout = TRUE;
    p_pb_dot1x_global->radius_default_timeout = p_dot1x_global->radius_default_timeout;
    p_pb_dot1x_global->has_radius_default_deadtime = TRUE;
    p_pb_dot1x_global->radius_default_deadtime = p_dot1x_global->radius_default_deadtime;
    p_pb_dot1x_global->has_mac_user_count_max = TRUE;
    p_pb_dot1x_global->mac_user_count_max = p_dot1x_global->mac_user_count_max;
    p_pb_dot1x_global->has_mac_user_count_current = TRUE;
    p_pb_dot1x_global->mac_user_count_current = p_dot1x_global->mac_user_count_current;
    p_pb_dot1x_global->has_mac_user_count_db = TRUE;
    p_pb_dot1x_global->mac_user_count_db = p_dot1x_global->mac_user_count_db;
    p_pb_dot1x_global->has_mac_port_count_current = TRUE;
    p_pb_dot1x_global->mac_port_count_current = p_dot1x_global->mac_port_count_current;
    p_pb_dot1x_global->has_radius_default_shared_secret_valid = TRUE;
    p_pb_dot1x_global->radius_default_shared_secret_valid = p_dot1x_global->radius_default_shared_secret_valid;
    p_pb_dot1x_global->has_radius_default_shared_secret = TRUE;
    p_pb_dot1x_global->radius_default_shared_secret.len = sizeof(p_dot1x_global->radius_default_shared_secret);
    p_pb_dot1x_global->radius_default_shared_secret.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_global->radius_default_shared_secret));
    sal_memcpy(p_pb_dot1x_global->radius_default_shared_secret.data, p_dot1x_global->radius_default_shared_secret, sizeof(p_dot1x_global->radius_default_shared_secret));
    p_pb_dot1x_global->radius_default_shared_enc_secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dot1x_global->radius_default_shared_enc_secret)+1);
    sal_strcpy(p_pb_dot1x_global->radius_default_shared_enc_secret, p_dot1x_global->radius_default_shared_enc_secret);
    p_pb_dot1x_global->has_last_session_id = TRUE;
    p_pb_dot1x_global->last_session_id = p_dot1x_global->last_session_id;
    p_pb_dot1x_global->has_session_id_allocated = TRUE;
    p_pb_dot1x_global->session_id_allocated.len = sizeof(p_dot1x_global->session_id_allocated);
    p_pb_dot1x_global->session_id_allocated.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_global->session_id_allocated));
    sal_memcpy(p_pb_dot1x_global->session_id_allocated.data, p_dot1x_global->session_id_allocated, sizeof(p_dot1x_global->session_id_allocated));
    p_pb_dot1x_global->has_dot1x_all = TRUE;
    p_pb_dot1x_global->dot1x_all = GLB_FLAG_ISSET(p_dot1x_global->dot1x, DOT1X_FLAG_ALL) ? TRUE : FALSE;
    p_pb_dot1x_global->has_dot1x_packet = TRUE;
    p_pb_dot1x_global->dot1x_packet = GLB_FLAG_ISSET(p_dot1x_global->dot1x, DOT1X_FLAG_PACKET) ? TRUE : FALSE;
    p_pb_dot1x_global->has_dot1x_timer = TRUE;
    p_pb_dot1x_global->dot1x_timer = GLB_FLAG_ISSET(p_dot1x_global->dot1x, DOT1X_FLAG_TIMER) ? TRUE : FALSE;
    p_pb_dot1x_global->has_dot1x_protocol = TRUE;
    p_pb_dot1x_global->dot1x_protocol = GLB_FLAG_ISSET(p_dot1x_global->dot1x, DOT1X_FLAG_PROTO) ? TRUE : FALSE;
    p_pb_dot1x_global->has_dot1x_event = TRUE;
    p_pb_dot1x_global->dot1x_event = GLB_FLAG_ISSET(p_dot1x_global->dot1x, DOT1X_FLAG_EVENTS) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_global_to_pb_free_packed(Cdb__TblDot1xGlobal *p_pb_dot1x_global)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_dot1x_global->eapol_group_address);
    if (p_pb_dot1x_global->radius_default_shared_secret.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_global->radius_default_shared_secret.data);
        p_pb_dot1x_global->radius_default_shared_secret.data = NULL;
    }

    if (p_pb_dot1x_global->radius_default_shared_enc_secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_global->radius_default_shared_enc_secret);
        p_pb_dot1x_global->radius_default_shared_enc_secret = NULL;
    }

    if (p_pb_dot1x_global->session_id_allocated.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_global->session_id_allocated.data);
        p_pb_dot1x_global->session_id_allocated.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDot1xGlobal pb_dot1x_global = CDB__TBL_DOT1X_GLOBAL__INIT;
    tbl_dot1x_global_t *p_dot1x_global = (tbl_dot1x_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT eapol_group_address = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_dot1x_global.eapol_group_address = &eapol_group_address;
    pb_tbl_dot1x_global_to_pb(only_key, p_dot1x_global, &pb_dot1x_global);
    len = cdb__tbl_dot1x_global__pack(&pb_dot1x_global, buf);
    pb_tbl_dot1x_global_to_pb_free_packed(&pb_dot1x_global);

    return len;
}

int32
pb_tbl_dot1x_global_dump(Cdb__TblDot1xGlobal *p_pb_dot1x_global, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/global_auth_enable=%u", p_pb_dot1x_global->global_auth_enable);
    offset += pb_compose_mac_addr_t_dump(p_pb_dot1x_global->eapol_group_address, (out + offset));
    offset += sal_sprintf(out + offset, "/radius_default_retry=%u", p_pb_dot1x_global->radius_default_retry);
    offset += sal_sprintf(out + offset, "/radius_default_timeout=%u", p_pb_dot1x_global->radius_default_timeout);
    offset += sal_sprintf(out + offset, "/radius_default_deadtime=%u", p_pb_dot1x_global->radius_default_deadtime);
    offset += sal_sprintf(out + offset, "/mac_user_count_max=%u", p_pb_dot1x_global->mac_user_count_max);
    offset += sal_sprintf(out + offset, "/mac_user_count_current=%u", p_pb_dot1x_global->mac_user_count_current);
    offset += sal_sprintf(out + offset, "/mac_user_count_db=%u", p_pb_dot1x_global->mac_user_count_db);
    offset += sal_sprintf(out + offset, "/mac_port_count_current=%u", p_pb_dot1x_global->mac_port_count_current);
    offset += sal_sprintf(out + offset, "/radius_default_shared_secret_valid=%u", p_pb_dot1x_global->radius_default_shared_secret_valid);
    offset += sal_sprintf(out + offset, "/radius_default_shared_secret=");
    offset += pb_uint8_array_dump(p_pb_dot1x_global->radius_default_shared_secret.data, p_pb_dot1x_global->radius_default_shared_secret.len, (out + offset));
    offset += sal_sprintf(out + offset, "/radius_default_shared_enc_secret=%s", p_pb_dot1x_global->radius_default_shared_enc_secret);
    offset += sal_sprintf(out + offset, "/last_session_id=%u", p_pb_dot1x_global->last_session_id);
    offset += sal_sprintf(out + offset, "/session_id_allocated=");
    offset += pb_uint8_array_dump(p_pb_dot1x_global->session_id_allocated.data, p_pb_dot1x_global->session_id_allocated.len, (out + offset));
    offset += sal_sprintf(out + offset, "/dot1x_all=%u", p_pb_dot1x_global->dot1x_all);
    offset += sal_sprintf(out + offset, "/dot1x_packet=%u", p_pb_dot1x_global->dot1x_packet);
    offset += sal_sprintf(out + offset, "/dot1x_timer=%u", p_pb_dot1x_global->dot1x_timer);
    offset += sal_sprintf(out + offset, "/dot1x_protocol=%u", p_pb_dot1x_global->dot1x_protocol);
    offset += sal_sprintf(out + offset, "/dot1x_event=%u", p_pb_dot1x_global->dot1x_event);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DOT1X_PORT */
int32
pb_tbl_dot1x_port_to_pb(uint32 only_key, tbl_dot1x_port_t *p_dot1x_port, Cdb__TblDot1xPort *p_pb_dot1x_port)
{
    p_pb_dot1x_port->key->ifindex = p_dot1x_port->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_dot1x_port->has_radius_msg_id = TRUE;
    p_pb_dot1x_port->radius_msg_id = p_dot1x_port->radius_msg_id;
    p_pb_dot1x_port->has_retry = TRUE;
    p_pb_dot1x_port->retry = p_dot1x_port->retry;
    p_pb_dot1x_port->has_sessiontype = TRUE;
    p_pb_dot1x_port->sessiontype = p_dot1x_port->sessiontype;
    p_pb_dot1x_port->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dot1x_port->name)+1);
    sal_strcpy(p_pb_dot1x_port->name, p_dot1x_port->name);
    p_pb_dot1x_port->has_buf = TRUE;
    p_pb_dot1x_port->buf.len = sizeof(p_dot1x_port->buf);
    p_pb_dot1x_port->buf.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_port->buf));
    sal_memcpy(p_pb_dot1x_port->buf.data, p_dot1x_port->buf, sizeof(p_dot1x_port->buf));
    pb_compose_mac_addr_t_to_pb(p_dot1x_port->dest_mac, p_pb_dot1x_port->dest_mac);
    pb_compose_mac_addr_t_to_pb(p_dot1x_port->src_mac, p_pb_dot1x_port->src_mac);
    p_pb_dot1x_port->has_user_name = TRUE;
    p_pb_dot1x_port->user_name.len = sizeof(p_dot1x_port->user_name);
    p_pb_dot1x_port->user_name.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_port->user_name));
    sal_memcpy(p_pb_dot1x_port->user_name.data, p_dot1x_port->user_name, sizeof(p_dot1x_port->user_name));
    p_pb_dot1x_port->has_authcontrolledportcontrol = TRUE;
    p_pb_dot1x_port->authcontrolledportcontrol = p_dot1x_port->authControlledPortControl;
    p_pb_dot1x_port->has_protocol_version = TRUE;
    p_pb_dot1x_port->protocol_version = p_dot1x_port->protocol_version;
    p_pb_dot1x_port->has_guest_vlan_valid = TRUE;
    p_pb_dot1x_port->guest_vlan_valid = p_dot1x_port->guest_vlan_valid;
    p_pb_dot1x_port->has_guest_vlan = TRUE;
    p_pb_dot1x_port->guest_vlan = p_dot1x_port->guest_vlan;
    p_pb_dot1x_port->has_current_user = TRUE;
    p_pb_dot1x_port->current_user = p_dot1x_port->current_user;
    p_pb_dot1x_port->has_current_user_count_db = TRUE;
    p_pb_dot1x_port->current_user_count_db = p_dot1x_port->current_user_count_db;
    p_pb_dot1x_port->has_max_user = TRUE;
    p_pb_dot1x_port->max_user = p_dot1x_port->max_user;
    p_pb_dot1x_port->has_auth_mode = TRUE;
    p_pb_dot1x_port->auth_mode = p_dot1x_port->auth_mode;
    p_pb_dot1x_port->has_mac_auth_bypass = TRUE;
    p_pb_dot1x_port->mac_auth_bypass = p_dot1x_port->mac_auth_bypass;
    p_pb_dot1x_port->has_share_reauth = TRUE;
    p_pb_dot1x_port->share_reauth = p_dot1x_port->share_reauth;
    p_pb_dot1x_port->has_authwhile = TRUE;
    p_pb_dot1x_port->authwhile = p_dot1x_port->authWhile;
    p_pb_dot1x_port->has_awhile = TRUE;
    p_pb_dot1x_port->awhile = p_dot1x_port->aWhile;
    p_pb_dot1x_port->has_quietwhile = TRUE;
    p_pb_dot1x_port->quietwhile = p_dot1x_port->quietWhile;
    p_pb_dot1x_port->has_reauthwhen = TRUE;
    p_pb_dot1x_port->reauthwhen = p_dot1x_port->reAuthWhen;
    p_pb_dot1x_port->has_txwhen = TRUE;
    p_pb_dot1x_port->txwhen = p_dot1x_port->txWhen;
    p_pb_dot1x_port->has_authabort = TRUE;
    p_pb_dot1x_port->authabort = p_dot1x_port->authAbort;
    p_pb_dot1x_port->has_authfail = TRUE;
    p_pb_dot1x_port->authfail = p_dot1x_port->authFail;
    p_pb_dot1x_port->has_authstart = TRUE;
    p_pb_dot1x_port->authstart = p_dot1x_port->authStart;
    p_pb_dot1x_port->has_authtimeout = TRUE;
    p_pb_dot1x_port->authtimeout = p_dot1x_port->authTimeout;
    p_pb_dot1x_port->has_authsuccess = TRUE;
    p_pb_dot1x_port->authsuccess = p_dot1x_port->authSuccess;
    p_pb_dot1x_port->has_initialize = TRUE;
    p_pb_dot1x_port->initialize = p_dot1x_port->initialize;
    p_pb_dot1x_port->has_portenabled = TRUE;
    p_pb_dot1x_port->portenabled = p_dot1x_port->portEnabled;
    p_pb_dot1x_port->has_reauthenticate = TRUE;
    p_pb_dot1x_port->reauthenticate = p_dot1x_port->reAuthenticate;
    p_pb_dot1x_port->has_eapnoreq = TRUE;
    p_pb_dot1x_port->eapnoreq = p_dot1x_port->eapNoReq;
    p_pb_dot1x_port->has_eaprestart = TRUE;
    p_pb_dot1x_port->eaprestart = p_dot1x_port->eaprestart;
    p_pb_dot1x_port->has_eapresp = TRUE;
    p_pb_dot1x_port->eapresp = p_dot1x_port->eapResp;
    p_pb_dot1x_port->has_eapreq = TRUE;
    p_pb_dot1x_port->eapreq = p_dot1x_port->eapReq;
    p_pb_dot1x_port->has_eapsuccess = TRUE;
    p_pb_dot1x_port->eapsuccess = p_dot1x_port->eapSuccess;
    p_pb_dot1x_port->has_eapfail = TRUE;
    p_pb_dot1x_port->eapfail = p_dot1x_port->eapFail;
    p_pb_dot1x_port->has_retransmit = TRUE;
    p_pb_dot1x_port->retransmit = p_dot1x_port->retransmit;
    p_pb_dot1x_port->has_currentid = TRUE;
    p_pb_dot1x_port->currentid = p_dot1x_port->currentId;
    p_pb_dot1x_port->has_portcontrol = TRUE;
    p_pb_dot1x_port->portcontrol = p_dot1x_port->portControl;
    p_pb_dot1x_port->has_portstatus = TRUE;
    p_pb_dot1x_port->portstatus = p_dot1x_port->portStatus;
    p_pb_dot1x_port->has_auth_pae_eaplogoff = TRUE;
    p_pb_dot1x_port->auth_pae_eaplogoff = p_dot1x_port->auth_pae_eapLogoff;
    p_pb_dot1x_port->has_auth_pae_eapstart = TRUE;
    p_pb_dot1x_port->auth_pae_eapstart = p_dot1x_port->auth_pae_eapStart;
    p_pb_dot1x_port->has_auth_pae_portmode = TRUE;
    p_pb_dot1x_port->auth_pae_portmode = p_dot1x_port->auth_pae_portMode;
    p_pb_dot1x_port->has_auth_pae_reauthcount = TRUE;
    p_pb_dot1x_port->auth_pae_reauthcount = p_dot1x_port->auth_pae_reAuthCount;
    p_pb_dot1x_port->has_auth_pae_rxrespid = TRUE;
    p_pb_dot1x_port->auth_pae_rxrespid = p_dot1x_port->auth_pae_rxRespId;
    p_pb_dot1x_port->has_auth_pae_state = TRUE;
    p_pb_dot1x_port->auth_pae_state = p_dot1x_port->auth_pae_state;
    p_pb_dot1x_port->has_auth_pae_quietperiod = TRUE;
    p_pb_dot1x_port->auth_pae_quietperiod = p_dot1x_port->auth_pae_quietPeriod;
    p_pb_dot1x_port->has_auth_pae_reauthmax = TRUE;
    p_pb_dot1x_port->auth_pae_reauthmax = p_dot1x_port->auth_pae_reAuthMax;
    p_pb_dot1x_port->has_auth_pae_txperiod = TRUE;
    p_pb_dot1x_port->auth_pae_txperiod = p_dot1x_port->auth_pae_txPeriod;
    p_pb_dot1x_port->has_auth_pae_enter_connecting = TRUE;
    p_pb_dot1x_port->auth_pae_enter_connecting = p_dot1x_port->auth_pae_enter_connecting;
    p_pb_dot1x_port->has_auth_pae_eaplogoff_while_connecting = TRUE;
    p_pb_dot1x_port->auth_pae_eaplogoff_while_connecting = p_dot1x_port->auth_pae_eaplogoff_while_connecting;
    p_pb_dot1x_port->has_auth_pae_enter_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_enter_authenticating = p_dot1x_port->auth_pae_enter_authenticating;
    p_pb_dot1x_port->has_auth_pae_success_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_success_while_authenticating = p_dot1x_port->auth_pae_success_while_authenticating;
    p_pb_dot1x_port->has_auth_pae_timeout_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_timeout_while_authenticating = p_dot1x_port->auth_pae_timeout_while_authenticating;
    p_pb_dot1x_port->has_auth_pae_fail_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_fail_while_authenticating = p_dot1x_port->auth_pae_fail_while_authenticating;
    p_pb_dot1x_port->has_auth_pae_eapstart_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_eapstart_while_authenticating = p_dot1x_port->auth_pae_eapstart_while_authenticating;
    p_pb_dot1x_port->has_auth_pae_eaplogoff_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_eaplogoff_while_authenticating = p_dot1x_port->auth_pae_eaplogoff_while_authenticating;
    p_pb_dot1x_port->has_auth_pae_reauths_while_authenticated = TRUE;
    p_pb_dot1x_port->auth_pae_reauths_while_authenticated = p_dot1x_port->auth_pae_reauths_while_authenticated;
    p_pb_dot1x_port->has_auth_pae_eapstart_while_authenticated = TRUE;
    p_pb_dot1x_port->auth_pae_eapstart_while_authenticated = p_dot1x_port->auth_pae_eapstart_while_authenticated;
    p_pb_dot1x_port->has_auth_pae_eaplogoff_while_authenticated = TRUE;
    p_pb_dot1x_port->auth_pae_eaplogoff_while_authenticated = p_dot1x_port->auth_pae_eaplogoff_while_authenticated;
    p_pb_dot1x_port->has_auth_pae_reauths_while_authenticating = TRUE;
    p_pb_dot1x_port->auth_pae_reauths_while_authenticating = p_dot1x_port->auth_pae_reauths_while_authenticating;
    p_pb_dot1x_port->has_auth_key_xmit_keyavailable = TRUE;
    p_pb_dot1x_port->auth_key_xmit_keyavailable = p_dot1x_port->auth_key_xmit_keyAvailable;
    p_pb_dot1x_port->has_auth_key_xmit_keytxenabled = TRUE;
    p_pb_dot1x_port->auth_key_xmit_keytxenabled = p_dot1x_port->auth_key_xmit_keyTxEnabled;
    p_pb_dot1x_port->has_auth_key_xmit_keyrun = TRUE;
    p_pb_dot1x_port->auth_key_xmit_keyrun = p_dot1x_port->auth_key_xmit_KeyRun;
    p_pb_dot1x_port->has_auth_key_xmit_keydone = TRUE;
    p_pb_dot1x_port->auth_key_xmit_keydone = p_dot1x_port->auth_key_xmit_KeyDone;
    p_pb_dot1x_port->has_auth_key_xmit_state = TRUE;
    p_pb_dot1x_port->auth_key_xmit_state = p_dot1x_port->auth_key_xmit_state;
    p_pb_dot1x_port->has_reauthperiod = TRUE;
    p_pb_dot1x_port->reauthperiod = p_dot1x_port->reAuthPeriod;
    p_pb_dot1x_port->has_reauthenabled = TRUE;
    p_pb_dot1x_port->reauthenabled = p_dot1x_port->reAuthEnabled;
    p_pb_dot1x_port->has_auth_be_state = TRUE;
    p_pb_dot1x_port->auth_be_state = p_dot1x_port->auth_be_state;
    p_pb_dot1x_port->has_auth_be_reqcount = TRUE;
    p_pb_dot1x_port->auth_be_reqcount = p_dot1x_port->auth_be_reqCount;
    p_pb_dot1x_port->has_auth_be_idfromserver = TRUE;
    p_pb_dot1x_port->auth_be_idfromserver = p_dot1x_port->auth_be_idFromServer;
    p_pb_dot1x_port->has_auth_be_supptimeout = TRUE;
    p_pb_dot1x_port->auth_be_supptimeout = p_dot1x_port->auth_be_suppTimeout;
    p_pb_dot1x_port->has_auth_be_servertimeout = TRUE;
    p_pb_dot1x_port->auth_be_servertimeout = p_dot1x_port->auth_be_serverTimeout;
    p_pb_dot1x_port->has_auth_be_maxreq = TRUE;
    p_pb_dot1x_port->auth_be_maxreq = p_dot1x_port->auth_be_maxReq;
    p_pb_dot1x_port->has_auth_be_backend_responses = TRUE;
    p_pb_dot1x_port->auth_be_backend_responses = p_dot1x_port->auth_be_backend_responses;
    p_pb_dot1x_port->has_auth_be_backend_access_challenges = TRUE;
    p_pb_dot1x_port->auth_be_backend_access_challenges = p_dot1x_port->auth_be_backend_access_challenges;
    p_pb_dot1x_port->has_auth_be_backend_otherrequest_to_supplicant = TRUE;
    p_pb_dot1x_port->auth_be_backend_otherrequest_to_supplicant = p_dot1x_port->auth_be_backend_otherrequest_to_supplicant;
    p_pb_dot1x_port->has_auth_be_backend_auth_success = TRUE;
    p_pb_dot1x_port->auth_be_backend_auth_success = p_dot1x_port->auth_be_backend_auth_success;
    p_pb_dot1x_port->has_auth_be_backend_auth_fails = TRUE;
    p_pb_dot1x_port->auth_be_backend_auth_fails = p_dot1x_port->auth_be_backend_auth_fails;
    p_pb_dot1x_port->has_auth_be_backend_nonnak_responses_from_supplicant = TRUE;
    p_pb_dot1x_port->auth_be_backend_nonnak_responses_from_supplicant = p_dot1x_port->auth_be_backend_nonnak_responses_from_supplicant;
    p_pb_dot1x_port->has_auth_ctrl_dir_state = TRUE;
    p_pb_dot1x_port->auth_ctrl_dir_state = p_dot1x_port->auth_ctrl_dir_state;
    p_pb_dot1x_port->has_auth_ctrl_dir_admincontrolleddirections = TRUE;
    p_pb_dot1x_port->auth_ctrl_dir_admincontrolleddirections = p_dot1x_port->auth_ctrl_dir_adminControlledDirections;
    p_pb_dot1x_port->has_auth_ctrl_dir_opercontrolleddirections = TRUE;
    p_pb_dot1x_port->auth_ctrl_dir_opercontrolleddirections = p_dot1x_port->auth_ctrl_dir_operControlledDirections;
    p_pb_dot1x_port->has_auth_ctrl_dir_bridgedetected = TRUE;
    p_pb_dot1x_port->auth_ctrl_dir_bridgedetected = p_dot1x_port->auth_ctrl_dir_bridgeDetected;
    p_pb_dot1x_port->has_auth_key_recv_rxkey = TRUE;
    p_pb_dot1x_port->auth_key_recv_rxkey = p_dot1x_port->auth_key_recv_rxKey;
    p_pb_dot1x_port->has_eapol_frames_rx = TRUE;
    p_pb_dot1x_port->eapol_frames_rx = p_dot1x_port->eapol_frames_rx;
    p_pb_dot1x_port->has_eapol_frames_tx = TRUE;
    p_pb_dot1x_port->eapol_frames_tx = p_dot1x_port->eapol_frames_tx;
    p_pb_dot1x_port->has_eapol_start_frames_rx = TRUE;
    p_pb_dot1x_port->eapol_start_frames_rx = p_dot1x_port->eapol_start_frames_rx;
    p_pb_dot1x_port->has_eapol_logoff_frames_rx = TRUE;
    p_pb_dot1x_port->eapol_logoff_frames_rx = p_dot1x_port->eapol_logoff_frames_rx;
    p_pb_dot1x_port->has_eap_respid_frames_rx = TRUE;
    p_pb_dot1x_port->eap_respid_frames_rx = p_dot1x_port->eap_respid_frames_rx;
    p_pb_dot1x_port->has_eap_resp_frames_rx = TRUE;
    p_pb_dot1x_port->eap_resp_frames_rx = p_dot1x_port->eap_resp_frames_rx;
    p_pb_dot1x_port->has_eap_reqid_frames_tx = TRUE;
    p_pb_dot1x_port->eap_reqid_frames_tx = p_dot1x_port->eap_reqid_frames_tx;
    p_pb_dot1x_port->has_eap_req_frames_tx = TRUE;
    p_pb_dot1x_port->eap_req_frames_tx = p_dot1x_port->eap_req_frames_tx;
    p_pb_dot1x_port->has_eapol_invalid_frames_rx = TRUE;
    p_pb_dot1x_port->eapol_invalid_frames_rx = p_dot1x_port->eapol_invalid_frames_rx;
    p_pb_dot1x_port->has_eap_len_error_frames_rx = TRUE;
    p_pb_dot1x_port->eap_len_error_frames_rx = p_dot1x_port->eap_len_error_frames_rx;
    p_pb_dot1x_port->has_eapol_last_frame_version = TRUE;
    p_pb_dot1x_port->eapol_last_frame_version = p_dot1x_port->eapol_last_frame_version;
    p_pb_dot1x_port->has_eapol_last_frame_source = TRUE;
    p_pb_dot1x_port->eapol_last_frame_source.len = sizeof(p_dot1x_port->eapol_last_frame_source);
    p_pb_dot1x_port->eapol_last_frame_source.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_port->eapol_last_frame_source));
    sal_memcpy(p_pb_dot1x_port->eapol_last_frame_source.data, p_dot1x_port->eapol_last_frame_source, sizeof(p_dot1x_port->eapol_last_frame_source));
    p_pb_dot1x_port->has_session_time = TRUE;
    p_pb_dot1x_port->session_time = p_dot1x_port->session_time;
    p_pb_dot1x_port->has_session_authentication_method = TRUE;
    p_pb_dot1x_port->session_authentication_method = p_dot1x_port->session_authentication_method;
    p_pb_dot1x_port->has_session_terminate_cause = TRUE;
    p_pb_dot1x_port->session_terminate_cause = p_dot1x_port->session_terminate_cause;
    p_pb_dot1x_port->has_session_user_name = TRUE;
    p_pb_dot1x_port->session_user_name.len = sizeof(p_dot1x_port->session_user_name);
    p_pb_dot1x_port->session_user_name.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_port->session_user_name));
    sal_memcpy(p_pb_dot1x_port->session_user_name.data, p_dot1x_port->session_user_name, sizeof(p_dot1x_port->session_user_name));
    p_pb_dot1x_port->has_class_id = TRUE;
    p_pb_dot1x_port->class_id = p_dot1x_port->class_id;

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_port_to_pb_free_packed(Cdb__TblDot1xPort *p_pb_dot1x_port)
{
    if (p_pb_dot1x_port->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_port->name);
        p_pb_dot1x_port->name = NULL;
    }

    if (p_pb_dot1x_port->buf.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_port->buf.data);
        p_pb_dot1x_port->buf.data = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_dot1x_port->dest_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_dot1x_port->src_mac);
    if (p_pb_dot1x_port->user_name.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_port->user_name.data);
        p_pb_dot1x_port->user_name.data = NULL;
    }

    if (p_pb_dot1x_port->eapol_last_frame_source.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_port->eapol_last_frame_source.data);
        p_pb_dot1x_port->eapol_last_frame_source.data = NULL;
    }

    if (p_pb_dot1x_port->session_user_name.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_port->session_user_name.data);
        p_pb_dot1x_port->session_user_name.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDot1xPortKey pb_dot1x_port_key = CDB__TBL_DOT1X_PORT_KEY__INIT;
    Cdb__TblDot1xPort pb_dot1x_port = CDB__TBL_DOT1X_PORT__INIT;
    tbl_dot1x_port_t *p_dot1x_port = (tbl_dot1x_port_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT dest_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_dot1x_port.key = &pb_dot1x_port_key;
    pb_dot1x_port.dest_mac = &dest_mac;
    pb_dot1x_port.src_mac = &src_mac;
    pb_tbl_dot1x_port_to_pb(only_key, p_dot1x_port, &pb_dot1x_port);
    len = cdb__tbl_dot1x_port__pack(&pb_dot1x_port, buf);
    pb_tbl_dot1x_port_to_pb_free_packed(&pb_dot1x_port);

    return len;
}

int32
pb_tbl_dot1x_port_dump(Cdb__TblDot1xPort *p_pb_dot1x_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_dot1x_port->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/radius_msg_id=%u", p_pb_dot1x_port->radius_msg_id);
    offset += sal_sprintf(out + offset, "/retry=%u", p_pb_dot1x_port->retry);
    offset += sal_sprintf(out + offset, "/sessiontype=%u", p_pb_dot1x_port->sessiontype);
    offset += sal_sprintf(out + offset, "/name=%s", p_pb_dot1x_port->name);
    offset += sal_sprintf(out + offset, "/buf=");
    offset += pb_uint8_array_dump(p_pb_dot1x_port->buf.data, p_pb_dot1x_port->buf.len, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_dot1x_port->dest_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_dot1x_port->src_mac, (out + offset));
    offset += sal_sprintf(out + offset, "/user_name=");
    offset += pb_uint8_array_dump(p_pb_dot1x_port->user_name.data, p_pb_dot1x_port->user_name.len, (out + offset));
    offset += sal_sprintf(out + offset, "/authControlledPortControl=%u", p_pb_dot1x_port->authcontrolledportcontrol);
    offset += sal_sprintf(out + offset, "/protocol_version=%u", p_pb_dot1x_port->protocol_version);
    offset += sal_sprintf(out + offset, "/guest_vlan_valid=%u", p_pb_dot1x_port->guest_vlan_valid);
    offset += sal_sprintf(out + offset, "/guest_vlan=%u", p_pb_dot1x_port->guest_vlan);
    offset += sal_sprintf(out + offset, "/current_user=%u", p_pb_dot1x_port->current_user);
    offset += sal_sprintf(out + offset, "/current_user_count_db=%u", p_pb_dot1x_port->current_user_count_db);
    offset += sal_sprintf(out + offset, "/max_user=%u", p_pb_dot1x_port->max_user);
    offset += sal_sprintf(out + offset, "/auth_mode=%u", p_pb_dot1x_port->auth_mode);
    offset += sal_sprintf(out + offset, "/mac_auth_bypass=%u", p_pb_dot1x_port->mac_auth_bypass);
    offset += sal_sprintf(out + offset, "/share_reauth=%u", p_pb_dot1x_port->share_reauth);
    offset += sal_sprintf(out + offset, "/authWhile=%u", p_pb_dot1x_port->authwhile);
    offset += sal_sprintf(out + offset, "/aWhile=%u", p_pb_dot1x_port->awhile);
    offset += sal_sprintf(out + offset, "/quietWhile=%u", p_pb_dot1x_port->quietwhile);
    offset += sal_sprintf(out + offset, "/reAuthWhen=%u", p_pb_dot1x_port->reauthwhen);
    offset += sal_sprintf(out + offset, "/txWhen=%u", p_pb_dot1x_port->txwhen);
    offset += sal_sprintf(out + offset, "/authAbort=%u", p_pb_dot1x_port->authabort);
    offset += sal_sprintf(out + offset, "/authFail=%u", p_pb_dot1x_port->authfail);
    offset += sal_sprintf(out + offset, "/authStart=%u", p_pb_dot1x_port->authstart);
    offset += sal_sprintf(out + offset, "/authTimeout=%u", p_pb_dot1x_port->authtimeout);
    offset += sal_sprintf(out + offset, "/authSuccess=%u", p_pb_dot1x_port->authsuccess);
    offset += sal_sprintf(out + offset, "/initialize=%u", p_pb_dot1x_port->initialize);
    offset += sal_sprintf(out + offset, "/portEnabled=%u", p_pb_dot1x_port->portenabled);
    offset += sal_sprintf(out + offset, "/reAuthenticate=%u", p_pb_dot1x_port->reauthenticate);
    offset += sal_sprintf(out + offset, "/eapNoReq=%u", p_pb_dot1x_port->eapnoreq);
    offset += sal_sprintf(out + offset, "/eaprestart=%u", p_pb_dot1x_port->eaprestart);
    offset += sal_sprintf(out + offset, "/eapResp=%u", p_pb_dot1x_port->eapresp);
    offset += sal_sprintf(out + offset, "/eapReq=%u", p_pb_dot1x_port->eapreq);
    offset += sal_sprintf(out + offset, "/eapSuccess=%u", p_pb_dot1x_port->eapsuccess);
    offset += sal_sprintf(out + offset, "/eapFail=%u", p_pb_dot1x_port->eapfail);
    offset += sal_sprintf(out + offset, "/retransmit=%u", p_pb_dot1x_port->retransmit);
    offset += sal_sprintf(out + offset, "/currentId=%u", p_pb_dot1x_port->currentid);
    offset += sal_sprintf(out + offset, "/portControl=%u", p_pb_dot1x_port->portcontrol);
    offset += sal_sprintf(out + offset, "/portStatus=%u", p_pb_dot1x_port->portstatus);
    offset += sal_sprintf(out + offset, "/auth_pae_eapLogoff=%u", p_pb_dot1x_port->auth_pae_eaplogoff);
    offset += sal_sprintf(out + offset, "/auth_pae_eapStart=%u", p_pb_dot1x_port->auth_pae_eapstart);
    offset += sal_sprintf(out + offset, "/auth_pae_portMode=%u", p_pb_dot1x_port->auth_pae_portmode);
    offset += sal_sprintf(out + offset, "/auth_pae_reAuthCount=%u", p_pb_dot1x_port->auth_pae_reauthcount);
    offset += sal_sprintf(out + offset, "/auth_pae_rxRespId=%u", p_pb_dot1x_port->auth_pae_rxrespid);
    offset += sal_sprintf(out + offset, "/auth_pae_state=%u", p_pb_dot1x_port->auth_pae_state);
    offset += sal_sprintf(out + offset, "/auth_pae_quietPeriod=%u", p_pb_dot1x_port->auth_pae_quietperiod);
    offset += sal_sprintf(out + offset, "/auth_pae_reAuthMax=%u", p_pb_dot1x_port->auth_pae_reauthmax);
    offset += sal_sprintf(out + offset, "/auth_pae_txPeriod=%u", p_pb_dot1x_port->auth_pae_txperiod);
    offset += sal_sprintf(out + offset, "/auth_pae_enter_connecting=%u", p_pb_dot1x_port->auth_pae_enter_connecting);
    offset += sal_sprintf(out + offset, "/auth_pae_eaplogoff_while_connecting=%u", p_pb_dot1x_port->auth_pae_eaplogoff_while_connecting);
    offset += sal_sprintf(out + offset, "/auth_pae_enter_authenticating=%u", p_pb_dot1x_port->auth_pae_enter_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_success_while_authenticating=%u", p_pb_dot1x_port->auth_pae_success_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_timeout_while_authenticating=%u", p_pb_dot1x_port->auth_pae_timeout_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_fail_while_authenticating=%u", p_pb_dot1x_port->auth_pae_fail_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_eapstart_while_authenticating=%u", p_pb_dot1x_port->auth_pae_eapstart_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_eaplogoff_while_authenticating=%u", p_pb_dot1x_port->auth_pae_eaplogoff_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_pae_reauths_while_authenticated=%u", p_pb_dot1x_port->auth_pae_reauths_while_authenticated);
    offset += sal_sprintf(out + offset, "/auth_pae_eapstart_while_authenticated=%u", p_pb_dot1x_port->auth_pae_eapstart_while_authenticated);
    offset += sal_sprintf(out + offset, "/auth_pae_eaplogoff_while_authenticated=%u", p_pb_dot1x_port->auth_pae_eaplogoff_while_authenticated);
    offset += sal_sprintf(out + offset, "/auth_pae_reauths_while_authenticating=%u", p_pb_dot1x_port->auth_pae_reauths_while_authenticating);
    offset += sal_sprintf(out + offset, "/auth_key_xmit_keyAvailable=%u", p_pb_dot1x_port->auth_key_xmit_keyavailable);
    offset += sal_sprintf(out + offset, "/auth_key_xmit_keyTxEnabled=%u", p_pb_dot1x_port->auth_key_xmit_keytxenabled);
    offset += sal_sprintf(out + offset, "/auth_key_xmit_KeyRun=%u", p_pb_dot1x_port->auth_key_xmit_keyrun);
    offset += sal_sprintf(out + offset, "/auth_key_xmit_KeyDone=%u", p_pb_dot1x_port->auth_key_xmit_keydone);
    offset += sal_sprintf(out + offset, "/auth_key_xmit_state=%u", p_pb_dot1x_port->auth_key_xmit_state);
    offset += sal_sprintf(out + offset, "/reAuthPeriod=%u", p_pb_dot1x_port->reauthperiod);
    offset += sal_sprintf(out + offset, "/reAuthEnabled=%u", p_pb_dot1x_port->reauthenabled);
    offset += sal_sprintf(out + offset, "/auth_be_state=%u", p_pb_dot1x_port->auth_be_state);
    offset += sal_sprintf(out + offset, "/auth_be_reqCount=%u", p_pb_dot1x_port->auth_be_reqcount);
    offset += sal_sprintf(out + offset, "/auth_be_idFromServer=%u", p_pb_dot1x_port->auth_be_idfromserver);
    offset += sal_sprintf(out + offset, "/auth_be_suppTimeout=%u", p_pb_dot1x_port->auth_be_supptimeout);
    offset += sal_sprintf(out + offset, "/auth_be_serverTimeout=%u", p_pb_dot1x_port->auth_be_servertimeout);
    offset += sal_sprintf(out + offset, "/auth_be_maxReq=%u", p_pb_dot1x_port->auth_be_maxreq);
    offset += sal_sprintf(out + offset, "/auth_be_backend_responses=%u", p_pb_dot1x_port->auth_be_backend_responses);
    offset += sal_sprintf(out + offset, "/auth_be_backend_access_challenges=%u", p_pb_dot1x_port->auth_be_backend_access_challenges);
    offset += sal_sprintf(out + offset, "/auth_be_backend_otherrequest_to_supplicant=%u", p_pb_dot1x_port->auth_be_backend_otherrequest_to_supplicant);
    offset += sal_sprintf(out + offset, "/auth_be_backend_auth_success=%u", p_pb_dot1x_port->auth_be_backend_auth_success);
    offset += sal_sprintf(out + offset, "/auth_be_backend_auth_fails=%u", p_pb_dot1x_port->auth_be_backend_auth_fails);
    offset += sal_sprintf(out + offset, "/auth_be_backend_nonnak_responses_from_supplicant=%u", p_pb_dot1x_port->auth_be_backend_nonnak_responses_from_supplicant);
    offset += sal_sprintf(out + offset, "/auth_ctrl_dir_state=%u", p_pb_dot1x_port->auth_ctrl_dir_state);
    offset += sal_sprintf(out + offset, "/auth_ctrl_dir_adminControlledDirections=%u", p_pb_dot1x_port->auth_ctrl_dir_admincontrolleddirections);
    offset += sal_sprintf(out + offset, "/auth_ctrl_dir_operControlledDirections=%u", p_pb_dot1x_port->auth_ctrl_dir_opercontrolleddirections);
    offset += sal_sprintf(out + offset, "/auth_ctrl_dir_bridgeDetected=%u", p_pb_dot1x_port->auth_ctrl_dir_bridgedetected);
    offset += sal_sprintf(out + offset, "/auth_key_recv_rxKey=%u", p_pb_dot1x_port->auth_key_recv_rxkey);
    offset += sal_sprintf(out + offset, "/eapol_frames_rx=%u", p_pb_dot1x_port->eapol_frames_rx);
    offset += sal_sprintf(out + offset, "/eapol_frames_tx=%u", p_pb_dot1x_port->eapol_frames_tx);
    offset += sal_sprintf(out + offset, "/eapol_start_frames_rx=%u", p_pb_dot1x_port->eapol_start_frames_rx);
    offset += sal_sprintf(out + offset, "/eapol_logoff_frames_rx=%u", p_pb_dot1x_port->eapol_logoff_frames_rx);
    offset += sal_sprintf(out + offset, "/eap_respid_frames_rx=%u", p_pb_dot1x_port->eap_respid_frames_rx);
    offset += sal_sprintf(out + offset, "/eap_resp_frames_rx=%u", p_pb_dot1x_port->eap_resp_frames_rx);
    offset += sal_sprintf(out + offset, "/eap_reqid_frames_tx=%u", p_pb_dot1x_port->eap_reqid_frames_tx);
    offset += sal_sprintf(out + offset, "/eap_req_frames_tx=%u", p_pb_dot1x_port->eap_req_frames_tx);
    offset += sal_sprintf(out + offset, "/eapol_invalid_frames_rx=%u", p_pb_dot1x_port->eapol_invalid_frames_rx);
    offset += sal_sprintf(out + offset, "/eap_len_error_frames_rx=%u", p_pb_dot1x_port->eap_len_error_frames_rx);
    offset += sal_sprintf(out + offset, "/eapol_last_frame_version=%u", p_pb_dot1x_port->eapol_last_frame_version);
    offset += sal_sprintf(out + offset, "/eapol_last_frame_source=");
    offset += pb_uint8_array_dump(p_pb_dot1x_port->eapol_last_frame_source.data, p_pb_dot1x_port->eapol_last_frame_source.len, (out + offset));
    offset += sal_sprintf(out + offset, "/session_time=%u", p_pb_dot1x_port->session_time);
    offset += sal_sprintf(out + offset, "/session_authentication_method=%u", p_pb_dot1x_port->session_authentication_method);
    offset += sal_sprintf(out + offset, "/session_terminate_cause=%u", p_pb_dot1x_port->session_terminate_cause);
    offset += sal_sprintf(out + offset, "/session_user_name=");
    offset += pb_uint8_array_dump(p_pb_dot1x_port->session_user_name.data, p_pb_dot1x_port->session_user_name.len, (out + offset));
    offset += sal_sprintf(out + offset, "/class_id=%u", p_pb_dot1x_port->class_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DOT1X_RADIUS */
int32
pb_tbl_dot1x_radius_to_pb(uint32 only_key, tbl_dot1x_radius_t *p_dot1x_radius, Cdb__TblDot1xRadius *p_pb_dot1x_radius)
{
    uint32 i = 0;

    pb_compose_dot1x_radius_key_t_to_pb(&p_dot1x_radius->key, p_pb_dot1x_radius->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_dot1x_radius->has_identifier = TRUE;
    p_pb_dot1x_radius->identifier = p_dot1x_radius->identifier;
    p_pb_dot1x_radius->has_server_string = TRUE;
    p_pb_dot1x_radius->server_string.len = sizeof(p_dot1x_radius->server_string);
    p_pb_dot1x_radius->server_string.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_radius->server_string));
    sal_memcpy(p_pb_dot1x_radius->server_string.data, p_dot1x_radius->server_string, sizeof(p_dot1x_radius->server_string));
    pb_compose_addr_ipv4_t_to_pb(&p_dot1x_radius->server_addr, p_pb_dot1x_radius->server_addr);
    p_pb_dot1x_radius->has_radius_state_len = TRUE;
    p_pb_dot1x_radius->radius_state_len = p_dot1x_radius->radius_state_len;
    p_pb_dot1x_radius->has_radius_state = TRUE;
    p_pb_dot1x_radius->radius_state.len = sizeof(p_dot1x_radius->radius_state);
    p_pb_dot1x_radius->radius_state.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_radius->radius_state));
    sal_memcpy(p_pb_dot1x_radius->radius_state.data, p_dot1x_radius->radius_state, sizeof(p_dot1x_radius->radius_state));
    p_pb_dot1x_radius->has_max_retry = TRUE;
    p_pb_dot1x_radius->max_retry = p_dot1x_radius->max_retry;
    p_pb_dot1x_radius->has_radius_defalt_timeout = TRUE;
    p_pb_dot1x_radius->radius_defalt_timeout = GLB_FLAG_ISSET(p_dot1x_radius->radius_config, AUTH_RADIUS_CONFIG_DEFAULT_TIMEOUT) ? TRUE : FALSE;
    p_pb_dot1x_radius->has_radius_defalt_retransmit = TRUE;
    p_pb_dot1x_radius->radius_defalt_retransmit = GLB_FLAG_ISSET(p_dot1x_radius->radius_config, AUTH_RADIUS_CONFIG_DEFAULT_RETRANSMIT) ? TRUE : FALSE;
    p_pb_dot1x_radius->has_radius_defalt_key = TRUE;
    p_pb_dot1x_radius->radius_defalt_key = GLB_FLAG_ISSET(p_dot1x_radius->radius_config, AUTH_RADIUS_CONFIG_DEFAULT_KEY) ? TRUE : FALSE;
    p_pb_dot1x_radius->has_timeout = TRUE;
    p_pb_dot1x_radius->timeout = p_dot1x_radius->timeout;
    p_pb_dot1x_radius->has_shared_secret_valid = TRUE;
    p_pb_dot1x_radius->shared_secret_valid = p_dot1x_radius->shared_secret_valid;
    p_pb_dot1x_radius->has_shared_secret = TRUE;
    p_pb_dot1x_radius->shared_secret.len = sizeof(p_dot1x_radius->shared_secret);
    p_pb_dot1x_radius->shared_secret.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_radius->shared_secret));
    sal_memcpy(p_pb_dot1x_radius->shared_secret.data, p_dot1x_radius->shared_secret, sizeof(p_dot1x_radius->shared_secret));
    p_pb_dot1x_radius->shared_enc_secret = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dot1x_radius->shared_enc_secret)+1);
    sal_strcpy(p_pb_dot1x_radius->shared_enc_secret, p_dot1x_radius->shared_enc_secret);
    p_pb_dot1x_radius->has_authenticator = TRUE;
    p_pb_dot1x_radius->authenticator.len = sizeof(p_dot1x_radius->authenticator);
    p_pb_dot1x_radius->authenticator.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_radius->authenticator));
    sal_memcpy(p_pb_dot1x_radius->authenticator.data, p_dot1x_radius->authenticator, sizeof(p_dot1x_radius->authenticator));
    p_pb_dot1x_radius->has_oauthenticator = TRUE;
    p_pb_dot1x_radius->oauthenticator.len = sizeof(p_dot1x_radius->oauthenticator);
    p_pb_dot1x_radius->oauthenticator.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_radius->oauthenticator));
    sal_memcpy(p_pb_dot1x_radius->oauthenticator.data, p_dot1x_radius->oauthenticator, sizeof(p_dot1x_radius->oauthenticator));
    p_pb_dot1x_radius->has_session_number = TRUE;
    p_pb_dot1x_radius->session_number = p_dot1x_radius->session_number;
    p_pb_dot1x_radius->session_ifindex = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*RADIUS_SESSION_BUFFER);
    p_pb_dot1x_radius->n_session_ifindex = RADIUS_SESSION_BUFFER;
    for (i = 0; i < RADIUS_SESSION_BUFFER; i++)
    {
        p_pb_dot1x_radius->session_ifindex[i] = p_dot1x_radius->session_ifindex[i];
    }
    p_pb_dot1x_radius->has_reactivate = TRUE;
    p_pb_dot1x_radius->reactivate = p_dot1x_radius->reactivate;
    p_pb_dot1x_radius->has_is_inband = TRUE;
    p_pb_dot1x_radius->is_inband = p_dot1x_radius->is_inband;

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_radius_to_pb_free_packed(Cdb__TblDot1xRadius *p_pb_dot1x_radius)
{
    pb_compose_dot1x_radius_key_t_to_pb_free_packed(p_pb_dot1x_radius->key);
    if (p_pb_dot1x_radius->server_string.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->server_string.data);
        p_pb_dot1x_radius->server_string.data = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_dot1x_radius->server_addr);
    if (p_pb_dot1x_radius->radius_state.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->radius_state.data);
        p_pb_dot1x_radius->radius_state.data = NULL;
    }

    if (p_pb_dot1x_radius->shared_secret.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->shared_secret.data);
        p_pb_dot1x_radius->shared_secret.data = NULL;
    }

    if (p_pb_dot1x_radius->shared_enc_secret)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->shared_enc_secret);
        p_pb_dot1x_radius->shared_enc_secret = NULL;
    }

    if (p_pb_dot1x_radius->authenticator.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->authenticator.data);
        p_pb_dot1x_radius->authenticator.data = NULL;
    }

    if (p_pb_dot1x_radius->oauthenticator.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->oauthenticator.data);
        p_pb_dot1x_radius->oauthenticator.data = NULL;
    }

    if (p_pb_dot1x_radius->session_ifindex)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_radius->session_ifindex);
        p_pb_dot1x_radius->session_ifindex = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_radius_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDot1xRadiusKey pb_dot1x_radius_key = CDB__TBL_DOT1X_RADIUS_KEY__INIT;
    Cdb__TblDot1xRadius pb_dot1x_radius = CDB__TBL_DOT1X_RADIUS__INIT;
    tbl_dot1x_radius_t *p_dot1x_radius = (tbl_dot1x_radius_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T server_addr = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_dot1x_radius.key = &pb_dot1x_radius_key;
    pb_dot1x_radius.server_addr = &server_addr;
    pb_tbl_dot1x_radius_to_pb(only_key, p_dot1x_radius, &pb_dot1x_radius);
    len = cdb__tbl_dot1x_radius__pack(&pb_dot1x_radius, buf);
    pb_tbl_dot1x_radius_to_pb_free_packed(&pb_dot1x_radius);

    return len;
}

int32
pb_tbl_dot1x_radius_dump(Cdb__TblDot1xRadius *p_pb_dot1x_radius, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_dot1x_radius_key_t_dump(p_pb_dot1x_radius->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/identifier=%u", p_pb_dot1x_radius->identifier);
    offset += sal_sprintf(out + offset, "/server_string=");
    offset += pb_uint8_array_dump(p_pb_dot1x_radius->server_string.data, p_pb_dot1x_radius->server_string.len, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_dot1x_radius->server_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/radius_state_len=%u", p_pb_dot1x_radius->radius_state_len);
    offset += sal_sprintf(out + offset, "/radius_state=");
    offset += pb_uint8_array_dump(p_pb_dot1x_radius->radius_state.data, p_pb_dot1x_radius->radius_state.len, (out + offset));
    offset += sal_sprintf(out + offset, "/max_retry=%u", p_pb_dot1x_radius->max_retry);
    offset += sal_sprintf(out + offset, "/radius_defalt_timeout=%u", p_pb_dot1x_radius->radius_defalt_timeout);
    offset += sal_sprintf(out + offset, "/radius_defalt_retransmit=%u", p_pb_dot1x_radius->radius_defalt_retransmit);
    offset += sal_sprintf(out + offset, "/radius_defalt_key=%u", p_pb_dot1x_radius->radius_defalt_key);
    offset += sal_sprintf(out + offset, "/timeout=%u", p_pb_dot1x_radius->timeout);
    offset += sal_sprintf(out + offset, "/shared_secret_valid=%u", p_pb_dot1x_radius->shared_secret_valid);
    offset += sal_sprintf(out + offset, "/shared_secret=");
    offset += pb_uint8_array_dump(p_pb_dot1x_radius->shared_secret.data, p_pb_dot1x_radius->shared_secret.len, (out + offset));
    offset += sal_sprintf(out + offset, "/shared_enc_secret=%s", p_pb_dot1x_radius->shared_enc_secret);
    offset += sal_sprintf(out + offset, "/authenticator=");
    offset += pb_uint8_array_dump(p_pb_dot1x_radius->authenticator.data, p_pb_dot1x_radius->authenticator.len, (out + offset));
    offset += sal_sprintf(out + offset, "/oauthenticator=");
    offset += pb_uint8_array_dump(p_pb_dot1x_radius->oauthenticator.data, p_pb_dot1x_radius->oauthenticator.len, (out + offset));
    offset += sal_sprintf(out + offset, "/session_number=%u", p_pb_dot1x_radius->session_number);
    offset += sal_sprintf(out + offset, "/session_ifindex=");
    offset += pb_uint32_array_dump(p_pb_dot1x_radius->session_ifindex, sizeof(p_pb_dot1x_radius->session_ifindex), (out + offset));
    offset += sal_sprintf(out + offset, "/reactivate=%u", p_pb_dot1x_radius->reactivate);
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_dot1x_radius->is_inband);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_DOT1X_MAC */
int32
pb_tbl_dot1x_mac_to_pb(uint32 only_key, tbl_dot1x_mac_t *p_dot1x_mac, Cdb__TblDot1xMac *p_pb_dot1x_mac)
{
    pb_compose_dot1x_mac_key_t_to_pb(&p_dot1x_mac->key, p_pb_dot1x_mac->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_dot1x_mac->has_user_name = TRUE;
    p_pb_dot1x_mac->user_name.len = sizeof(p_dot1x_mac->user_name);
    p_pb_dot1x_mac->user_name.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_dot1x_mac->user_name));
    sal_memcpy(p_pb_dot1x_mac->user_name.data, p_dot1x_mac->user_name, sizeof(p_dot1x_mac->user_name));
    p_pb_dot1x_mac->has_session_id = TRUE;
    p_pb_dot1x_mac->session_id = p_dot1x_mac->session_id;
    p_pb_dot1x_mac->has_entry_id = TRUE;
    p_pb_dot1x_mac->entry_id = p_dot1x_mac->entry_id;
    p_pb_dot1x_mac->has_is_auth_bypass = TRUE;
    p_pb_dot1x_mac->is_auth_bypass = p_dot1x_mac->is_auth_bypass;
    p_pb_dot1x_mac->has_auth_mac_reject = TRUE;
    p_pb_dot1x_mac->auth_mac_reject = GLB_FLAG_ISSET(p_dot1x_mac->auth_mac_flag, AUTH_MAC_REJECT) ? TRUE : FALSE;
    p_pb_dot1x_mac->has_auth_mac_accept = TRUE;
    p_pb_dot1x_mac->auth_mac_accept = GLB_FLAG_ISSET(p_dot1x_mac->auth_mac_flag, AUTH_MAC_ACCEPT) ? TRUE : FALSE;
    p_pb_dot1x_mac->has_auth_mac_bypass = TRUE;
    p_pb_dot1x_mac->auth_mac_bypass = GLB_FLAG_ISSET(p_dot1x_mac->auth_mac_flag, AUTH_MAC_BYPASS) ? TRUE : FALSE;
    p_pb_dot1x_mac->has_auth_mac_reauth_accept = TRUE;
    p_pb_dot1x_mac->auth_mac_reauth_accept = GLB_FLAG_ISSET(p_dot1x_mac->auth_mac_flag, AUTH_MAC_REAUTH_ACCEPT) ? TRUE : FALSE;
    p_pb_dot1x_mac->has_auth_mac_eapol_reauth = TRUE;
    p_pb_dot1x_mac->auth_mac_eapol_reauth = GLB_FLAG_ISSET(p_dot1x_mac->auth_mac_flag, AUTH_MAC_EAPOL_REAUTH) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_mac_to_pb_free_packed(Cdb__TblDot1xMac *p_pb_dot1x_mac)
{
    pb_compose_dot1x_mac_key_t_to_pb_free_packed(p_pb_dot1x_mac->key);
    if (p_pb_dot1x_mac->user_name.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dot1x_mac->user_name.data);
        p_pb_dot1x_mac->user_name.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_dot1x_mac_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblDot1xMacKey pb_dot1x_mac_key = CDB__TBL_DOT1X_MAC_KEY__INIT;
    Cdb__TblDot1xMac pb_dot1x_mac = CDB__TBL_DOT1X_MAC__INIT;
    tbl_dot1x_mac_t *p_dot1x_mac = (tbl_dot1x_mac_t*)p_tbl;
    int32 len = 0;

    pb_dot1x_mac.key = &pb_dot1x_mac_key;
    pb_tbl_dot1x_mac_to_pb(only_key, p_dot1x_mac, &pb_dot1x_mac);
    len = cdb__tbl_dot1x_mac__pack(&pb_dot1x_mac, buf);
    pb_tbl_dot1x_mac_to_pb_free_packed(&pb_dot1x_mac);

    return len;
}

int32
pb_tbl_dot1x_mac_dump(Cdb__TblDot1xMac *p_pb_dot1x_mac, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_dot1x_mac_key_t_dump(p_pb_dot1x_mac->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/user_name=");
    offset += pb_uint8_array_dump(p_pb_dot1x_mac->user_name.data, p_pb_dot1x_mac->user_name.len, (out + offset));
    offset += sal_sprintf(out + offset, "/session_id=%u", p_pb_dot1x_mac->session_id);
    offset += sal_sprintf(out + offset, "/entry_id=%u", p_pb_dot1x_mac->entry_id);
    offset += sal_sprintf(out + offset, "/is_auth_bypass=%u", p_pb_dot1x_mac->is_auth_bypass);
    offset += sal_sprintf(out + offset, "/auth_mac_reject=%u", p_pb_dot1x_mac->auth_mac_reject);
    offset += sal_sprintf(out + offset, "/auth_mac_accept=%u", p_pb_dot1x_mac->auth_mac_accept);
    offset += sal_sprintf(out + offset, "/auth_mac_bypass=%u", p_pb_dot1x_mac->auth_mac_bypass);
    offset += sal_sprintf(out + offset, "/auth_mac_reauth_accept=%u", p_pb_dot1x_mac->auth_mac_reauth_accept);
    offset += sal_sprintf(out + offset, "/auth_mac_eapol_reauth=%u", p_pb_dot1x_mac->auth_mac_eapol_reauth);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ENABLE */
int32
pb_tbl_enable_to_pb(uint32 only_key, tbl_enable_t *p_enable, Cdb__TblEnable *p_pb_enable)
{
    p_pb_enable->key->id = p_enable->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_enable->enc_passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_enable->enc_passwd)+1);
    sal_strcpy(p_pb_enable->enc_passwd, p_enable->enc_passwd);
    p_pb_enable->passwd = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_enable->passwd)+1);
    sal_strcpy(p_pb_enable->passwd, p_enable->passwd);

    return PM_E_NONE;
}

int32
pb_tbl_enable_to_pb_free_packed(Cdb__TblEnable *p_pb_enable)
{
    if (p_pb_enable->enc_passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_enable->enc_passwd);
        p_pb_enable->enc_passwd = NULL;
    }

    if (p_pb_enable->passwd)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_enable->passwd);
        p_pb_enable->passwd = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_enable_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblEnableKey pb_enable_key = CDB__TBL_ENABLE_KEY__INIT;
    Cdb__TblEnable pb_enable = CDB__TBL_ENABLE__INIT;
    tbl_enable_t *p_enable = (tbl_enable_t*)p_tbl;
    int32 len = 0;

    pb_enable.key = &pb_enable_key;
    pb_tbl_enable_to_pb(only_key, p_enable, &pb_enable);
    len = cdb__tbl_enable__pack(&pb_enable, buf);
    pb_tbl_enable_to_pb_free_packed(&pb_enable);

    return len;
}

int32
pb_tbl_enable_dump(Cdb__TblEnable *p_pb_enable, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_enable->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/enc_passwd=%s", p_pb_enable->enc_passwd);
    offset += sal_sprintf(out + offset, "/passwd=%s", p_pb_enable->passwd);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CHIP */
int32
pb_tbl_chip_to_pb(uint32 only_key, tbl_chip_t *p_chip, Cdb__TblChip *p_pb_chip)
{
    p_pb_chip->has_type = TRUE;
    p_pb_chip->type = p_chip->type;

    return PM_E_NONE;
}

int32
pb_tbl_chip_to_pb_free_packed(Cdb__TblChip *p_pb_chip)
{
    return PM_E_NONE;
}

int32
pb_tbl_chip_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblChip pb_chip = CDB__TBL_CHIP__INIT;
    tbl_chip_t *p_chip = (tbl_chip_t*)p_tbl;
    int32 len = 0;

    pb_tbl_chip_to_pb(only_key, p_chip, &pb_chip);
    len = cdb__tbl_chip__pack(&pb_chip, buf);
    pb_tbl_chip_to_pb_free_packed(&pb_chip);

    return len;
}

int32
pb_tbl_chip_dump(Cdb__TblChip *p_pb_chip, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_chip->type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CLEAR_ACL_POLICY */
int32
pb_tbl_clear_acl_policy_to_pb(uint32 only_key, tbl_clear_acl_policy_t *p_clear_acl_policy, Cdb__TblClearAclPolicy *p_pb_clear_acl_policy)
{
    p_pb_clear_acl_policy->has_counter_id = TRUE;
    p_pb_clear_acl_policy->counter_id = p_clear_acl_policy->counter_id;
    p_pb_clear_acl_policy->has_acl_id = TRUE;
    p_pb_clear_acl_policy->acl_id = p_clear_acl_policy->acl_id;

    return PM_E_NONE;
}

int32
pb_tbl_clear_acl_policy_to_pb_free_packed(Cdb__TblClearAclPolicy *p_pb_clear_acl_policy)
{
    return PM_E_NONE;
}

int32
pb_tbl_clear_acl_policy_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblClearAclPolicy pb_clear_acl_policy = CDB__TBL_CLEAR_ACL_POLICY__INIT;
    tbl_clear_acl_policy_t *p_clear_acl_policy = (tbl_clear_acl_policy_t*)p_tbl;
    int32 len = 0;

    pb_tbl_clear_acl_policy_to_pb(only_key, p_clear_acl_policy, &pb_clear_acl_policy);
    len = cdb__tbl_clear_acl_policy__pack(&pb_clear_acl_policy, buf);
    pb_tbl_clear_acl_policy_to_pb_free_packed(&pb_clear_acl_policy);

    return len;
}

int32
pb_tbl_clear_acl_policy_dump(Cdb__TblClearAclPolicy *p_pb_clear_acl_policy, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/counter_id=%llu", p_pb_clear_acl_policy->counter_id);
    offset += sal_sprintf(out + offset, "/acl_id=%llu", p_pb_clear_acl_policy->acl_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_AUTHOR */
int32
pb_tbl_author_to_pb(uint32 only_key, tbl_author_t *p_author, Cdb__TblAuthor *p_pb_author)
{
    p_pb_author->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_author->key.name)+1);
    sal_strcpy(p_pb_author->key->name, p_author->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_author->methods = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_author->methods)+1);
    sal_strcpy(p_pb_author->methods, p_author->methods);

    return PM_E_NONE;
}

int32
pb_tbl_author_to_pb_free_packed(Cdb__TblAuthor *p_pb_author)
{
    if (p_pb_author->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_author->key->name);
        p_pb_author->key->name = NULL;
    }

    if (p_pb_author->methods)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_author->methods);
        p_pb_author->methods = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_author_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAuthorKey pb_author_key = CDB__TBL_AUTHOR_KEY__INIT;
    Cdb__TblAuthor pb_author = CDB__TBL_AUTHOR__INIT;
    tbl_author_t *p_author = (tbl_author_t*)p_tbl;
    int32 len = 0;

    pb_author.key = &pb_author_key;
    pb_tbl_author_to_pb(only_key, p_author, &pb_author);
    len = cdb__tbl_author__pack(&pb_author, buf);
    pb_tbl_author_to_pb_free_packed(&pb_author);

    return len;
}

int32
pb_tbl_author_dump(Cdb__TblAuthor *p_pb_author, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_author->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/methods=%s", p_pb_author->methods);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACCOUNT */
int32
pb_tbl_account_to_pb(uint32 only_key, tbl_account_t *p_account, Cdb__TblAccount *p_pb_account)
{
    p_pb_account->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_account->key.name)+1);
    sal_strcpy(p_pb_account->key->name, p_account->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_account->has_start_stop = TRUE;
    p_pb_account->start_stop = p_account->start_stop;
    p_pb_account->has_stop_only = TRUE;
    p_pb_account->stop_only = p_account->stop_only;
    p_pb_account->methods = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_account->methods)+1);
    sal_strcpy(p_pb_account->methods, p_account->methods);

    return PM_E_NONE;
}

int32
pb_tbl_account_to_pb_free_packed(Cdb__TblAccount *p_pb_account)
{
    if (p_pb_account->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_account->key->name);
        p_pb_account->key->name = NULL;
    }

    if (p_pb_account->methods)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_account->methods);
        p_pb_account->methods = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_account_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAccountKey pb_account_key = CDB__TBL_ACCOUNT_KEY__INIT;
    Cdb__TblAccount pb_account = CDB__TBL_ACCOUNT__INIT;
    tbl_account_t *p_account = (tbl_account_t*)p_tbl;
    int32 len = 0;

    pb_account.key = &pb_account_key;
    pb_tbl_account_to_pb(only_key, p_account, &pb_account);
    len = cdb__tbl_account__pack(&pb_account, buf);
    pb_tbl_account_to_pb_free_packed(&pb_account);

    return len;
}

int32
pb_tbl_account_dump(Cdb__TblAccount *p_pb_account, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_account->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/start_stop=%u", p_pb_account->start_stop);
    offset += sal_sprintf(out + offset, "/stop_only=%u", p_pb_account->stop_only);
    offset += sal_sprintf(out + offset, "/methods=%s", p_pb_account->methods);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACCOUNTCMD */
int32
pb_tbl_accountcmd_to_pb(uint32 only_key, tbl_accountcmd_t *p_accountcmd, Cdb__TblAccountcmd *p_pb_accountcmd)
{
    p_pb_accountcmd->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_accountcmd->key.name)+1);
    sal_strcpy(p_pb_accountcmd->key->name, p_accountcmd->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_accountcmd->methods = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_accountcmd->methods)+1);
    sal_strcpy(p_pb_accountcmd->methods, p_accountcmd->methods);

    return PM_E_NONE;
}

int32
pb_tbl_accountcmd_to_pb_free_packed(Cdb__TblAccountcmd *p_pb_accountcmd)
{
    if (p_pb_accountcmd->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_accountcmd->key->name);
        p_pb_accountcmd->key->name = NULL;
    }

    if (p_pb_accountcmd->methods)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_accountcmd->methods);
        p_pb_accountcmd->methods = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_accountcmd_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAccountcmdKey pb_accountcmd_key = CDB__TBL_ACCOUNTCMD_KEY__INIT;
    Cdb__TblAccountcmd pb_accountcmd = CDB__TBL_ACCOUNTCMD__INIT;
    tbl_accountcmd_t *p_accountcmd = (tbl_accountcmd_t*)p_tbl;
    int32 len = 0;

    pb_accountcmd.key = &pb_accountcmd_key;
    pb_tbl_accountcmd_to_pb(only_key, p_accountcmd, &pb_accountcmd);
    len = cdb__tbl_accountcmd__pack(&pb_accountcmd, buf);
    pb_tbl_accountcmd_to_pb_free_packed(&pb_accountcmd);

    return len;
}

int32
pb_tbl_accountcmd_dump(Cdb__TblAccountcmd *p_pb_accountcmd, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_accountcmd->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/methods=%s", p_pb_accountcmd->methods);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_VLANCLASS_RULE */
int32
pb_tbl_vlanclass_rule_to_pb(uint32 only_key, tbl_vlanclass_rule_t *p_vlanclass_rule, Cdb__TblVlanclassRule *p_pb_vlanclass_rule)
{
    p_pb_vlanclass_rule->key->rule_id = p_vlanclass_rule->key.rule_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_vlanclass_rule->has_rule_type = TRUE;
    p_pb_vlanclass_rule->rule_type = p_vlanclass_rule->rule_type;
    p_pb_vlanclass_rule->has_vlan_id = TRUE;
    p_pb_vlanclass_rule->vlan_id = p_vlanclass_rule->vlan_id;
    pb_compose_mac_addr_t_to_pb(p_vlanclass_rule->mac, p_pb_vlanclass_rule->mac);
    pb_compose_addr_t_to_pb(&p_vlanclass_rule->ip_address, p_pb_vlanclass_rule->ip_address);
    p_pb_vlanclass_rule->has_protocol_type = TRUE;
    p_pb_vlanclass_rule->protocol_type = p_vlanclass_rule->protocol_type;
    p_pb_vlanclass_rule->has_protocol_action = TRUE;
    p_pb_vlanclass_rule->protocol_action = p_vlanclass_rule->protocol_action;
    p_pb_vlanclass_rule->has_rule_oid = TRUE;
    p_pb_vlanclass_rule->rule_oid = p_vlanclass_rule->rule_oid;

    return PM_E_NONE;
}

int32
pb_tbl_vlanclass_rule_to_pb_free_packed(Cdb__TblVlanclassRule *p_pb_vlanclass_rule)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_vlanclass_rule->mac);
    pb_compose_addr_t_to_pb_free_packed(p_pb_vlanclass_rule->ip_address);
    return PM_E_NONE;
}

int32
pb_tbl_vlanclass_rule_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblVlanclassRuleKey pb_vlanclass_rule_key = CDB__TBL_VLANCLASS_RULE_KEY__INIT;
    Cdb__TblVlanclassRule pb_vlanclass_rule = CDB__TBL_VLANCLASS_RULE__INIT;
    tbl_vlanclass_rule_t *p_vlanclass_rule = (tbl_vlanclass_rule_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrT ip_address = CDB__COMPOSE_ADDR_T__INIT;

    pb_vlanclass_rule.key = &pb_vlanclass_rule_key;
    pb_vlanclass_rule.mac = &mac;
    pb_vlanclass_rule.ip_address = &ip_address;
    pb_tbl_vlanclass_rule_to_pb(only_key, p_vlanclass_rule, &pb_vlanclass_rule);
    len = cdb__tbl_vlanclass_rule__pack(&pb_vlanclass_rule, buf);
    pb_tbl_vlanclass_rule_to_pb_free_packed(&pb_vlanclass_rule);

    return len;
}

int32
pb_tbl_vlanclass_rule_dump(Cdb__TblVlanclassRule *p_pb_vlanclass_rule, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->rule_id=%u", p_pb_vlanclass_rule->key->rule_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/rule_type=%u", p_pb_vlanclass_rule->rule_type);
    offset += sal_sprintf(out + offset, "/vlan_id=%u", p_pb_vlanclass_rule->vlan_id);
    offset += pb_compose_mac_addr_t_dump(p_pb_vlanclass_rule->mac, (out + offset));
    offset += pb_compose_addr_t_dump(p_pb_vlanclass_rule->ip_address, (out + offset));
    offset += sal_sprintf(out + offset, "/protocol_type=%u", p_pb_vlanclass_rule->protocol_type);
    offset += sal_sprintf(out + offset, "/protocol_action=%u", p_pb_vlanclass_rule->protocol_action);
    offset += sal_sprintf(out + offset, "/rule_oid=%llu", p_pb_vlanclass_rule->rule_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_VLANCLASS_GROUP */
int32
pb_tbl_vlanclass_group_to_pb(uint32 only_key, tbl_vlanclass_group_t *p_vlanclass_group, Cdb__TblVlanclassGroup *p_pb_vlanclass_group)
{
    p_pb_vlanclass_group->key->group_id = p_vlanclass_group->key.group_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_vlanclass_group->has_rule_id = TRUE;
    p_pb_vlanclass_group->rule_id.len = sizeof(p_vlanclass_group->rule_id);
    p_pb_vlanclass_group->rule_id.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_vlanclass_group->rule_id));
    sal_memcpy(p_pb_vlanclass_group->rule_id.data, p_vlanclass_group->rule_id, sizeof(p_vlanclass_group->rule_id));
    p_pb_vlanclass_group->has_action_rule_id = TRUE;
    p_pb_vlanclass_group->action_rule_id = p_vlanclass_group->action_rule_id;
    p_pb_vlanclass_group->has_group_oid = TRUE;
    p_pb_vlanclass_group->group_oid = p_vlanclass_group->group_oid;

    return PM_E_NONE;
}

int32
pb_tbl_vlanclass_group_to_pb_free_packed(Cdb__TblVlanclassGroup *p_pb_vlanclass_group)
{
    if (p_pb_vlanclass_group->rule_id.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_vlanclass_group->rule_id.data);
        p_pb_vlanclass_group->rule_id.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_vlanclass_group_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblVlanclassGroupKey pb_vlanclass_group_key = CDB__TBL_VLANCLASS_GROUP_KEY__INIT;
    Cdb__TblVlanclassGroup pb_vlanclass_group = CDB__TBL_VLANCLASS_GROUP__INIT;
    tbl_vlanclass_group_t *p_vlanclass_group = (tbl_vlanclass_group_t*)p_tbl;
    int32 len = 0;

    pb_vlanclass_group.key = &pb_vlanclass_group_key;
    pb_tbl_vlanclass_group_to_pb(only_key, p_vlanclass_group, &pb_vlanclass_group);
    len = cdb__tbl_vlanclass_group__pack(&pb_vlanclass_group, buf);
    pb_tbl_vlanclass_group_to_pb_free_packed(&pb_vlanclass_group);

    return len;
}

int32
pb_tbl_vlanclass_group_dump(Cdb__TblVlanclassGroup *p_pb_vlanclass_group, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->group_id=%u", p_pb_vlanclass_group->key->group_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/rule_id=");
    offset += pb_bitmap_array_dump(p_pb_vlanclass_group->rule_id.data, p_pb_vlanclass_group->rule_id.len, (out + offset));
    offset += sal_sprintf(out + offset, "/action_rule_id=%llu", p_pb_vlanclass_group->action_rule_id);
    offset += sal_sprintf(out + offset, "/group_oid=%llu", p_pb_vlanclass_group->group_oid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL_L4_PORT_RANGE */
int32
pb_tbl_acl_l4_port_range_to_pb(uint32 only_key, tbl_acl_l4_port_range_t *p_acl_l4_port_range, Cdb__TblAclL4PortRange *p_pb_acl_l4_port_range)
{
    p_pb_acl_l4_port_range->key->id = p_acl_l4_port_range->key.id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_acl_l4_port_range->has_port_min = TRUE;
    p_pb_acl_l4_port_range->port_min = p_acl_l4_port_range->port_min;
    p_pb_acl_l4_port_range->has_port_max = TRUE;
    p_pb_acl_l4_port_range->port_max = p_acl_l4_port_range->port_max;
    p_pb_acl_l4_port_range->has_cnt = TRUE;
    p_pb_acl_l4_port_range->cnt = p_acl_l4_port_range->cnt;
    p_pb_acl_l4_port_range->has_is_src = TRUE;
    p_pb_acl_l4_port_range->is_src = p_acl_l4_port_range->is_src;

    return PM_E_NONE;
}

int32
pb_tbl_acl_l4_port_range_to_pb_free_packed(Cdb__TblAclL4PortRange *p_pb_acl_l4_port_range)
{
    return PM_E_NONE;
}

int32
pb_tbl_acl_l4_port_range_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclL4PortRangeKey pb_acl_l4_port_range_key = CDB__TBL_ACL_L4_PORT_RANGE_KEY__INIT;
    Cdb__TblAclL4PortRange pb_acl_l4_port_range = CDB__TBL_ACL_L4_PORT_RANGE__INIT;
    tbl_acl_l4_port_range_t *p_acl_l4_port_range = (tbl_acl_l4_port_range_t*)p_tbl;
    int32 len = 0;

    pb_acl_l4_port_range.key = &pb_acl_l4_port_range_key;
    pb_tbl_acl_l4_port_range_to_pb(only_key, p_acl_l4_port_range, &pb_acl_l4_port_range);
    len = cdb__tbl_acl_l4_port_range__pack(&pb_acl_l4_port_range, buf);
    pb_tbl_acl_l4_port_range_to_pb_free_packed(&pb_acl_l4_port_range);

    return len;
}

int32
pb_tbl_acl_l4_port_range_dump(Cdb__TblAclL4PortRange *p_pb_acl_l4_port_range, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_acl_l4_port_range->key->id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/port_min=%u", p_pb_acl_l4_port_range->port_min);
    offset += sal_sprintf(out + offset, "/port_max=%u", p_pb_acl_l4_port_range->port_max);
    offset += sal_sprintf(out + offset, "/cnt=%u", p_pb_acl_l4_port_range->cnt);
    offset += sal_sprintf(out + offset, "/is_src=%u", p_pb_acl_l4_port_range->is_src);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_PCAP */
int32
pb_tbl_fea_pcap_to_pb(uint32 only_key, tbl_fea_pcap_t *p_pcap, Cdb__TblFeaPcap *p_pb_pcap)
{
    p_pb_pcap->has_tx_en = TRUE;
    p_pb_pcap->tx_en = p_pcap->tx_en;
    p_pb_pcap->has_rx_en = TRUE;
    p_pb_pcap->rx_en = p_pcap->rx_en;
    p_pb_pcap->has_ifindex = TRUE;
    p_pb_pcap->ifindex = p_pcap->ifindex;

    return PM_E_NONE;
}

int32
pb_tbl_fea_pcap_to_pb_free_packed(Cdb__TblFeaPcap *p_pb_pcap)
{
    return PM_E_NONE;
}

int32
pb_tbl_fea_pcap_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaPcap pb_pcap = CDB__TBL_FEA_PCAP__INIT;
    tbl_fea_pcap_t *p_pcap = (tbl_fea_pcap_t*)p_tbl;
    int32 len = 0;

    pb_tbl_fea_pcap_to_pb(only_key, p_pcap, &pb_pcap);
    len = cdb__tbl_fea_pcap__pack(&pb_pcap, buf);
    pb_tbl_fea_pcap_to_pb_free_packed(&pb_pcap);

    return len;
}

int32
pb_tbl_fea_pcap_dump(Cdb__TblFeaPcap *p_pb_pcap, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/tx_en=%u", p_pb_pcap->tx_en);
    offset += sal_sprintf(out + offset, "/rx_en=%u", p_pb_pcap->rx_en);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_pcap->ifindex);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CONTROLLER */
int32
pb_tbl_controller_to_pb(uint32 only_key, tbl_controller_t *p_controller, Cdb__TblController *p_pb_controller)
{
    p_pb_controller->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_controller->key.name)+1);
    sal_strcpy(p_pb_controller->key->name, p_controller->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    pb_compose_addr_ipv4_t_to_pb(&p_controller->ip, p_pb_controller->ip);
    p_pb_controller->has_port = TRUE;
    p_pb_controller->port = p_controller->port;

    return PM_E_NONE;
}

int32
pb_tbl_controller_to_pb_free_packed(Cdb__TblController *p_pb_controller)
{
    if (p_pb_controller->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_controller->key->name);
        p_pb_controller->key->name = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_controller->ip);
    return PM_E_NONE;
}

int32
pb_tbl_controller_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblControllerKey pb_controller_key = CDB__TBL_CONTROLLER_KEY__INIT;
    Cdb__TblController pb_controller = CDB__TBL_CONTROLLER__INIT;
    tbl_controller_t *p_controller = (tbl_controller_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_controller.key = &pb_controller_key;
    pb_controller.ip = &ip;
    pb_tbl_controller_to_pb(only_key, p_controller, &pb_controller);
    len = cdb__tbl_controller__pack(&pb_controller, buf);
    pb_tbl_controller_to_pb_free_packed(&pb_controller);

    return len;
}

int32
pb_tbl_controller_dump(Cdb__TblController *p_pb_controller, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_controller->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += pb_compose_addr_ipv4_t_dump(p_pb_controller->ip, (out + offset));
    offset += sal_sprintf(out + offset, "/port=%u", p_pb_controller->port);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_CPU_PACKETS */
int32
pb_tbl_cpu_packets_to_pb(uint32 only_key, tbl_cpu_packets_t *p_cpu_packets, Cdb__TblCpuPackets *p_pb_cpu_packets)
{
    p_pb_cpu_packets->has_total = TRUE;
    p_pb_cpu_packets->total = p_cpu_packets->total;
    p_pb_cpu_packets->has_rx = TRUE;
    p_pb_cpu_packets->rx = p_cpu_packets->rx;
    p_pb_cpu_packets->has_tx = TRUE;
    p_pb_cpu_packets->tx = p_cpu_packets->tx;
    p_pb_cpu_packets->has_rx_bpdu = TRUE;
    p_pb_cpu_packets->rx_bpdu = p_cpu_packets->rx_bpdu;
    p_pb_cpu_packets->has_rx_slow_proto = TRUE;
    p_pb_cpu_packets->rx_slow_proto = p_cpu_packets->rx_slow_proto;
    p_pb_cpu_packets->has_rx_eapol = TRUE;
    p_pb_cpu_packets->rx_eapol = p_cpu_packets->rx_eapol;
    p_pb_cpu_packets->has_rx_lldp = TRUE;
    p_pb_cpu_packets->rx_lldp = p_cpu_packets->rx_lldp;
    p_pb_cpu_packets->has_rx_erps = TRUE;
    p_pb_cpu_packets->rx_erps = p_cpu_packets->rx_erps;
    p_pb_cpu_packets->has_rx_macda = TRUE;
    p_pb_cpu_packets->rx_macda = p_cpu_packets->rx_macda;
    p_pb_cpu_packets->has_rx_rip = TRUE;
    p_pb_cpu_packets->rx_rip = p_cpu_packets->rx_rip;
    p_pb_cpu_packets->has_rx_ospf = TRUE;
    p_pb_cpu_packets->rx_ospf = p_cpu_packets->rx_ospf;
    p_pb_cpu_packets->has_rx_bgp = TRUE;
    p_pb_cpu_packets->rx_bgp = p_cpu_packets->rx_bgp;
    p_pb_cpu_packets->has_rx_arp = TRUE;
    p_pb_cpu_packets->rx_arp = p_cpu_packets->rx_arp;
    p_pb_cpu_packets->has_rx_dhcp = TRUE;
    p_pb_cpu_packets->rx_dhcp = p_cpu_packets->rx_dhcp;
    p_pb_cpu_packets->has_rx_ipda = TRUE;
    p_pb_cpu_packets->rx_ipda = p_cpu_packets->rx_ipda;
    p_pb_cpu_packets->has_rx_igmp = TRUE;
    p_pb_cpu_packets->rx_igmp = p_cpu_packets->rx_igmp;
    p_pb_cpu_packets->has_rx_mac_limit = TRUE;
    p_pb_cpu_packets->rx_mac_limit = p_cpu_packets->rx_mac_limit;
    p_pb_cpu_packets->has_rx_mac_mismatch = TRUE;
    p_pb_cpu_packets->rx_mac_mismatch = p_cpu_packets->rx_mac_mismatch;
    p_pb_cpu_packets->has_rx_l3copy_cpu = TRUE;
    p_pb_cpu_packets->rx_l3copy_cpu = p_cpu_packets->rx_l3copy_cpu;
    p_pb_cpu_packets->has_rx_ttl_error = TRUE;
    p_pb_cpu_packets->rx_ttl_error = p_cpu_packets->rx_ttl_error;
    p_pb_cpu_packets->has_rx_other = TRUE;
    p_pb_cpu_packets->rx_other = p_cpu_packets->rx_other;
    p_pb_cpu_packets->has_tx_igmp = TRUE;
    p_pb_cpu_packets->tx_igmp = p_cpu_packets->tx_igmp;
    p_pb_cpu_packets->has_tx_bpdu = TRUE;
    p_pb_cpu_packets->tx_bpdu = p_cpu_packets->tx_bpdu;
    p_pb_cpu_packets->has_tx_slow_proto = TRUE;
    p_pb_cpu_packets->tx_slow_proto = p_cpu_packets->tx_slow_proto;
    p_pb_cpu_packets->has_tx_arp = TRUE;
    p_pb_cpu_packets->tx_arp = p_cpu_packets->tx_arp;
    p_pb_cpu_packets->has_tx_dhcp = TRUE;
    p_pb_cpu_packets->tx_dhcp = p_cpu_packets->tx_dhcp;
    p_pb_cpu_packets->has_tx_lldp = TRUE;
    p_pb_cpu_packets->tx_lldp = p_cpu_packets->tx_lldp;
    p_pb_cpu_packets->has_tx_erps = TRUE;
    p_pb_cpu_packets->tx_erps = p_cpu_packets->tx_erps;
    p_pb_cpu_packets->has_tx_eapol = TRUE;
    p_pb_cpu_packets->tx_eapol = p_cpu_packets->tx_eapol;
    p_pb_cpu_packets->has_tx_other = TRUE;
    p_pb_cpu_packets->tx_other = p_cpu_packets->tx_other;

    return PM_E_NONE;
}

int32
pb_tbl_cpu_packets_to_pb_free_packed(Cdb__TblCpuPackets *p_pb_cpu_packets)
{
    return PM_E_NONE;
}

int32
pb_tbl_cpu_packets_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCpuPackets pb_cpu_packets = CDB__TBL_CPU_PACKETS__INIT;
    tbl_cpu_packets_t *p_cpu_packets = (tbl_cpu_packets_t*)p_tbl;
    int32 len = 0;

    pb_tbl_cpu_packets_to_pb(only_key, p_cpu_packets, &pb_cpu_packets);
    len = cdb__tbl_cpu_packets__pack(&pb_cpu_packets, buf);
    pb_tbl_cpu_packets_to_pb_free_packed(&pb_cpu_packets);

    return len;
}

int32
pb_tbl_cpu_packets_dump(Cdb__TblCpuPackets *p_pb_cpu_packets, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/total=%llu", p_pb_cpu_packets->total);
    offset += sal_sprintf(out + offset, "/rx=%llu", p_pb_cpu_packets->rx);
    offset += sal_sprintf(out + offset, "/tx=%llu", p_pb_cpu_packets->tx);
    offset += sal_sprintf(out + offset, "/rx_bpdu=%llu", p_pb_cpu_packets->rx_bpdu);
    offset += sal_sprintf(out + offset, "/rx_slow_proto=%llu", p_pb_cpu_packets->rx_slow_proto);
    offset += sal_sprintf(out + offset, "/rx_eapol=%llu", p_pb_cpu_packets->rx_eapol);
    offset += sal_sprintf(out + offset, "/rx_lldp=%llu", p_pb_cpu_packets->rx_lldp);
    offset += sal_sprintf(out + offset, "/rx_erps=%llu", p_pb_cpu_packets->rx_erps);
    offset += sal_sprintf(out + offset, "/rx_macda=%llu", p_pb_cpu_packets->rx_macda);
    offset += sal_sprintf(out + offset, "/rx_rip=%llu", p_pb_cpu_packets->rx_rip);
    offset += sal_sprintf(out + offset, "/rx_ospf=%llu", p_pb_cpu_packets->rx_ospf);
    offset += sal_sprintf(out + offset, "/rx_bgp=%llu", p_pb_cpu_packets->rx_bgp);
    offset += sal_sprintf(out + offset, "/rx_arp=%llu", p_pb_cpu_packets->rx_arp);
    offset += sal_sprintf(out + offset, "/rx_dhcp=%llu", p_pb_cpu_packets->rx_dhcp);
    offset += sal_sprintf(out + offset, "/rx_ipda=%llu", p_pb_cpu_packets->rx_ipda);
    offset += sal_sprintf(out + offset, "/rx_igmp=%llu", p_pb_cpu_packets->rx_igmp);
    offset += sal_sprintf(out + offset, "/rx_mac_limit=%llu", p_pb_cpu_packets->rx_mac_limit);
    offset += sal_sprintf(out + offset, "/rx_mac_mismatch=%llu", p_pb_cpu_packets->rx_mac_mismatch);
    offset += sal_sprintf(out + offset, "/rx_l3copy_cpu=%llu", p_pb_cpu_packets->rx_l3copy_cpu);
    offset += sal_sprintf(out + offset, "/rx_ttl_error=%llu", p_pb_cpu_packets->rx_ttl_error);
    offset += sal_sprintf(out + offset, "/rx_other=%llu", p_pb_cpu_packets->rx_other);
    offset += sal_sprintf(out + offset, "/tx_igmp=%llu", p_pb_cpu_packets->tx_igmp);
    offset += sal_sprintf(out + offset, "/tx_bpdu=%llu", p_pb_cpu_packets->tx_bpdu);
    offset += sal_sprintf(out + offset, "/tx_slow_proto=%llu", p_pb_cpu_packets->tx_slow_proto);
    offset += sal_sprintf(out + offset, "/tx_arp=%llu", p_pb_cpu_packets->tx_arp);
    offset += sal_sprintf(out + offset, "/tx_dhcp=%llu", p_pb_cpu_packets->tx_dhcp);
    offset += sal_sprintf(out + offset, "/tx_lldp=%llu", p_pb_cpu_packets->tx_lldp);
    offset += sal_sprintf(out + offset, "/tx_erps=%llu", p_pb_cpu_packets->tx_erps);
    offset += sal_sprintf(out + offset, "/tx_eapol=%llu", p_pb_cpu_packets->tx_eapol);
    offset += sal_sprintf(out + offset, "/tx_other=%llu", p_pb_cpu_packets->tx_other);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NS_ROUTE */
int32
pb_tbl_ns_route_to_pb(uint32 only_key, tbl_ns_route_t *p_ns_route, Cdb__TblNsRoute *p_pb_ns_route)
{
    pb_compose_ns_route_key_t_to_pb(&p_ns_route->key, p_pb_ns_route->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ns_route->has_flag = TRUE;
    p_pb_ns_route->flag = p_ns_route->flag;
    p_pb_ns_route->has_is_inband = TRUE;
    p_pb_ns_route->is_inband = p_ns_route->is_inband;
    p_pb_ns_route->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ns_route->ifname)+1);
    sal_strcpy(p_pb_ns_route->ifname, p_ns_route->ifname);

    return PM_E_NONE;
}

int32
pb_tbl_ns_route_to_pb_free_packed(Cdb__TblNsRoute *p_pb_ns_route)
{
    pb_compose_ns_route_key_t_to_pb_free_packed(p_pb_ns_route->key);
    if (p_pb_ns_route->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ns_route->ifname);
        p_pb_ns_route->ifname = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ns_route_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblNsRouteKey pb_ns_route_key = CDB__TBL_NS_ROUTE_KEY__INIT;
    Cdb__TblNsRoute pb_ns_route = CDB__TBL_NS_ROUTE__INIT;
    tbl_ns_route_t *p_ns_route = (tbl_ns_route_t*)p_tbl;
    int32 len = 0;

    pb_ns_route.key = &pb_ns_route_key;
    pb_tbl_ns_route_to_pb(only_key, p_ns_route, &pb_ns_route);
    len = cdb__tbl_ns_route__pack(&pb_ns_route, buf);
    pb_tbl_ns_route_to_pb_free_packed(&pb_ns_route);

    return len;
}

int32
pb_tbl_ns_route_dump(Cdb__TblNsRoute *p_pb_ns_route, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_ns_route_key_t_dump(p_pb_ns_route->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/flag=%u", p_pb_ns_route->flag);
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_ns_route->is_inband);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_ns_route->ifname);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_NS_ROUTE_IP */
int32
pb_tbl_ns_route_ip_to_pb(uint32 only_key, tbl_ns_route_ip_t *p_ns_route_ip, Cdb__TblNsRouteIp *p_pb_ns_route_ip)
{
    pb_compose_addr_ipv4_t_to_pb(&p_ns_route_ip->key.ip, p_pb_ns_route_ip->key->ip);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_ns_route_ip->has_is_inband = TRUE;
    p_pb_ns_route_ip->is_inband = p_ns_route_ip->is_inband;
    p_pb_ns_route_ip->has_cnt = TRUE;
    p_pb_ns_route_ip->cnt = p_ns_route_ip->cnt;

    return PM_E_NONE;
}

int32
pb_tbl_ns_route_ip_to_pb_free_packed(Cdb__TblNsRouteIp *p_pb_ns_route_ip)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ns_route_ip->key->ip);
    return PM_E_NONE;
}

int32
pb_tbl_ns_route_ip_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__TblNsRouteIpKey pb_ns_route_ip_key = CDB__TBL_NS_ROUTE_IP_KEY__INIT;
    Cdb__TblNsRouteIp pb_ns_route_ip = CDB__TBL_NS_ROUTE_IP__INIT;
    tbl_ns_route_ip_t *p_ns_route_ip = (tbl_ns_route_ip_t*)p_tbl;
    int32 len = 0;

    pb_ns_route_ip_key.ip = &ip;
    pb_ns_route_ip.key = &pb_ns_route_ip_key;
    pb_tbl_ns_route_ip_to_pb(only_key, p_ns_route_ip, &pb_ns_route_ip);
    len = cdb__tbl_ns_route_ip__pack(&pb_ns_route_ip, buf);
    pb_tbl_ns_route_ip_to_pb_free_packed(&pb_ns_route_ip);

    return len;
}

int32
pb_tbl_ns_route_ip_dump(Cdb__TblNsRouteIp *p_pb_ns_route_ip, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ns_route_ip->key->ip, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_ns_route_ip->is_inband);
    offset += sal_sprintf(out + offset, "/cnt=%d", p_pb_ns_route_ip->cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPENFLOW_INTERFACE */
int32
pb_tbl_openflow_interface_to_pb(uint32 only_key, tbl_openflow_interface_t *p_if, Cdb__TblOpenflowInterface *p_pb_if)
{
    uint32 i = 0;

    p_pb_if->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if->key.name)+1);
    sal_strcpy(p_pb_if->key->name, p_if->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_if->has_openflow_enable = TRUE;
    p_pb_if->openflow_enable = p_if->openflow_enable;
    p_pb_if->has_obey_vlan_filter = TRUE;
    p_pb_if->obey_vlan_filter = p_if->obey_vlan_filter;
    p_pb_if->has_openflow_instance_enable = TRUE;
    p_pb_if->openflow_instance_enable = p_if->openflow_instance_enable;
    p_pb_if->has_is_add_to_br0 = TRUE;
    p_pb_if->is_add_to_br0 = p_if->is_add_to_br0;
    p_pb_if->protected_vlan = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*OPENFLOW_PROTECTED_VLAN);
    p_pb_if->n_protected_vlan = OPENFLOW_PROTECTED_VLAN;
    for (i = 0; i < OPENFLOW_PROTECTED_VLAN; i++)
    {
        p_pb_if->protected_vlan[i] = p_if->protected_vlan[i];
    }
    p_pb_if->action = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*OPENFLOW_PACKET_ACTION);
    p_pb_if->n_action = OPENFLOW_PACKET_ACTION;
    for (i = 0; i < OPENFLOW_PACKET_ACTION; i++)
    {
        p_pb_if->action[i] = p_if->action[i];
    }
    p_pb_if->has_ingress_add_native_vlan_enable = TRUE;
    p_pb_if->ingress_add_native_vlan_enable = p_if->ingress_add_native_vlan_enable;
    p_pb_if->has_egress_remove_native_vlan_enable = TRUE;
    p_pb_if->egress_remove_native_vlan_enable = p_if->egress_remove_native_vlan_enable;
    p_pb_if->has_ifindex = TRUE;
    p_pb_if->ifindex = p_if->ifindex;
    p_pb_if->has_bind_tunnel_type = TRUE;
    p_pb_if->bind_tunnel_type = p_if->bind_tunnel_type;
    p_pb_if->has_bind_tunnel_cnt = TRUE;
    p_pb_if->bind_tunnel_cnt = p_if->bind_tunnel_cnt;

    return PM_E_NONE;
}

int32
pb_tbl_openflow_interface_to_pb_free_packed(Cdb__TblOpenflowInterface *p_pb_if)
{
    if (p_pb_if->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->key->name);
        p_pb_if->key->name = NULL;
    }

    if (p_pb_if->protected_vlan)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->protected_vlan);
        p_pb_if->protected_vlan = NULL;
    }

    if (p_pb_if->action)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_if->action);
        p_pb_if->action = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_openflow_interface_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpenflowInterfaceKey pb_if_key = CDB__TBL_OPENFLOW_INTERFACE_KEY__INIT;
    Cdb__TblOpenflowInterface pb_if = CDB__TBL_OPENFLOW_INTERFACE__INIT;
    tbl_openflow_interface_t *p_if = (tbl_openflow_interface_t*)p_tbl;
    int32 len = 0;

    pb_if.key = &pb_if_key;
    pb_tbl_openflow_interface_to_pb(only_key, p_if, &pb_if);
    len = cdb__tbl_openflow_interface__pack(&pb_if, buf);
    pb_tbl_openflow_interface_to_pb_free_packed(&pb_if);

    return len;
}

int32
pb_tbl_openflow_interface_dump(Cdb__TblOpenflowInterface *p_pb_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_if->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/openflow_enable=%u", p_pb_if->openflow_enable);
    offset += sal_sprintf(out + offset, "/obey_vlan_filter=%u", p_pb_if->obey_vlan_filter);
    offset += sal_sprintf(out + offset, "/openflow_instance_enable=%u", p_pb_if->openflow_instance_enable);
    offset += sal_sprintf(out + offset, "/is_add_to_br0=%u", p_pb_if->is_add_to_br0);
    offset += sal_sprintf(out + offset, "/protected_vlan=");
    offset += pb_uint32_array_dump(p_pb_if->protected_vlan, sizeof(p_pb_if->protected_vlan), (out + offset));
    offset += sal_sprintf(out + offset, "/action=");
    offset += pb_uint32_array_dump(p_pb_if->action, sizeof(p_pb_if->action), (out + offset));
    offset += sal_sprintf(out + offset, "/ingress_add_native_vlan_enable=%u", p_pb_if->ingress_add_native_vlan_enable);
    offset += sal_sprintf(out + offset, "/egress_remove_native_vlan_enable=%u", p_pb_if->egress_remove_native_vlan_enable);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_if->ifindex);
    offset += sal_sprintf(out + offset, "/bind_tunnel_type=%u", p_pb_if->bind_tunnel_type);
    offset += sal_sprintf(out + offset, "/bind_tunnel_cnt=%u", p_pb_if->bind_tunnel_cnt);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPENFLOW_MANAGER */
int32
pb_tbl_openflow_manager_to_pb(uint32 only_key, tbl_openflow_manager_t *p_openflow_manager, Cdb__TblOpenflowManager *p_pb_openflow_manager)
{
    pb_compose_openflow_manager_key_t_to_pb(&p_openflow_manager->key, p_pb_openflow_manager->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_openflow_manager->has_mode = TRUE;
    p_pb_openflow_manager->mode = p_openflow_manager->mode;
    p_pb_openflow_manager->has_is_inband = TRUE;
    p_pb_openflow_manager->is_inband = p_openflow_manager->is_inband;

    return PM_E_NONE;
}

int32
pb_tbl_openflow_manager_to_pb_free_packed(Cdb__TblOpenflowManager *p_pb_openflow_manager)
{
    pb_compose_openflow_manager_key_t_to_pb_free_packed(p_pb_openflow_manager->key);
    return PM_E_NONE;
}

int32
pb_tbl_openflow_manager_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpenflowManagerKey pb_openflow_manager_key = CDB__TBL_OPENFLOW_MANAGER_KEY__INIT;
    Cdb__TblOpenflowManager pb_openflow_manager = CDB__TBL_OPENFLOW_MANAGER__INIT;
    tbl_openflow_manager_t *p_openflow_manager = (tbl_openflow_manager_t*)p_tbl;
    int32 len = 0;

    pb_openflow_manager.key = &pb_openflow_manager_key;
    pb_tbl_openflow_manager_to_pb(only_key, p_openflow_manager, &pb_openflow_manager);
    len = cdb__tbl_openflow_manager__pack(&pb_openflow_manager, buf);
    pb_tbl_openflow_manager_to_pb_free_packed(&pb_openflow_manager);

    return len;
}

int32
pb_tbl_openflow_manager_dump(Cdb__TblOpenflowManager *p_pb_openflow_manager, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_openflow_manager_key_t_dump(p_pb_openflow_manager->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_openflow_manager->mode);
    offset += sal_sprintf(out + offset, "/is_inband=%u", p_pb_openflow_manager->is_inband);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PTP_GLOBAL */
int32
pb_tbl_ptp_global_to_pb(uint32 only_key, tbl_ptp_global_t *p_global, Cdb__TblPtpGlobal *p_pb_global)
{
    p_pb_global->has_enable = TRUE;
    p_pb_global->enable = p_global->enable;

    return PM_E_NONE;
}

int32
pb_tbl_ptp_global_to_pb_free_packed(Cdb__TblPtpGlobal *p_pb_global)
{
    return PM_E_NONE;
}

int32
pb_tbl_ptp_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPtpGlobal pb_global = CDB__TBL_PTP_GLOBAL__INIT;
    tbl_ptp_global_t *p_global = (tbl_ptp_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_ptp_global_to_pb(only_key, p_global, &pb_global);
    len = cdb__tbl_ptp_global__pack(&pb_global, buf);
    pb_tbl_ptp_global_to_pb_free_packed(&pb_global);

    return len;
}

int32
pb_tbl_ptp_global_dump(Cdb__TblPtpGlobal *p_pb_global, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_global->enable);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PTP_PORT */
int32
pb_tbl_ptp_port_to_pb(uint32 only_key, tbl_ptp_port_t *p_port, Cdb__TblPtpPort *p_pb_port)
{
    p_pb_port->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_port->key.name)+1);
    sal_strcpy(p_pb_port->key->name, p_port->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_port->has_ifindex = TRUE;
    p_pb_port->ifindex = p_port->ifindex;
    p_pb_port->has_enable = TRUE;
    p_pb_port->enable = p_port->enable;

    return PM_E_NONE;
}

int32
pb_tbl_ptp_port_to_pb_free_packed(Cdb__TblPtpPort *p_pb_port)
{
    if (p_pb_port->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_port->key->name);
        p_pb_port->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_ptp_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPtpPortKey pb_port_key = CDB__TBL_PTP_PORT_KEY__INIT;
    Cdb__TblPtpPort pb_port = CDB__TBL_PTP_PORT__INIT;
    tbl_ptp_port_t *p_port = (tbl_ptp_port_t*)p_tbl;
    int32 len = 0;

    pb_port.key = &pb_port_key;
    pb_tbl_ptp_port_to_pb(only_key, p_port, &pb_port);
    len = cdb__tbl_ptp_port__pack(&pb_port, buf);
    pb_tbl_ptp_port_to_pb_free_packed(&pb_port);

    return len;
}

int32
pb_tbl_ptp_port_dump(Cdb__TblPtpPort *p_pb_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_port->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_port->ifindex);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_port->enable);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PTP_FOREIGN */
int32
pb_tbl_ptp_foreign_to_pb(uint32 only_key, tbl_ptp_foreign_t *p_foreign, Cdb__TblPtpForeign *p_pb_foreign)
{
    pb_compose_glb_ptp_port_id_t_to_pb(&p_foreign->key, p_pb_foreign->key);

    if (only_key)
    {
        return PM_E_NONE;
    }


    return PM_E_NONE;
}

int32
pb_tbl_ptp_foreign_to_pb_free_packed(Cdb__TblPtpForeign *p_pb_foreign)
{
    pb_compose_glb_ptp_port_id_t_to_pb_free_packed(p_pb_foreign->key);
    return PM_E_NONE;
}

int32
pb_tbl_ptp_foreign_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPtpForeignKey pb_foreign_key = CDB__TBL_PTP_FOREIGN_KEY__INIT;
    Cdb__TblPtpForeign pb_foreign = CDB__TBL_PTP_FOREIGN__INIT;
    tbl_ptp_foreign_t *p_foreign = (tbl_ptp_foreign_t*)p_tbl;
    int32 len = 0;

    pb_foreign.key = &pb_foreign_key;
    pb_tbl_ptp_foreign_to_pb(only_key, p_foreign, &pb_foreign);
    len = cdb__tbl_ptp_foreign__pack(&pb_foreign, buf);
    pb_tbl_ptp_foreign_to_pb_free_packed(&pb_foreign);

    return len;
}

int32
pb_tbl_ptp_foreign_dump(Cdb__TblPtpForeign *p_pb_foreign, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_glb_ptp_port_id_t_dump(p_pb_foreign->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_FEA_TIME */
int32
pb_tbl_fea_time_to_pb(uint32 only_key, tbl_fea_time_t *p_fea_time, Cdb__TblFeaTime *p_pb_fea_time)
{
    p_pb_fea_time->has_sync_type = TRUE;
    p_pb_fea_time->sync_type = p_fea_time->sync_type;
    p_pb_fea_time->has_sync_count = TRUE;
    p_pb_fea_time->sync_count = p_fea_time->sync_count;
    pb_compose_sal_time_t_to_pb(&p_fea_time->last_sync_time, p_pb_fea_time->last_sync_time);

    return PM_E_NONE;
}

int32
pb_tbl_fea_time_to_pb_free_packed(Cdb__TblFeaTime *p_pb_fea_time)
{
    pb_compose_sal_time_t_to_pb_free_packed(p_pb_fea_time->last_sync_time);
    return PM_E_NONE;
}

int32
pb_tbl_fea_time_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblFeaTime pb_fea_time = CDB__TBL_FEA_TIME__INIT;
    tbl_fea_time_t *p_fea_time = (tbl_fea_time_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeSalTimeT last_sync_time = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_fea_time.last_sync_time = &last_sync_time;
    pb_tbl_fea_time_to_pb(only_key, p_fea_time, &pb_fea_time);
    len = cdb__tbl_fea_time__pack(&pb_fea_time, buf);
    pb_tbl_fea_time_to_pb_free_packed(&pb_fea_time);

    return len;
}

int32
pb_tbl_fea_time_dump(Cdb__TblFeaTime *p_pb_fea_time, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/sync_type=%u", p_pb_fea_time->sync_type);
    offset += sal_sprintf(out + offset, "/sync_count=%u", p_pb_fea_time->sync_count);
    offset += pb_compose_sal_time_t_dump(p_pb_fea_time->last_sync_time, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_BHM_GLOBAL */
int32
pb_tbl_bhm_global_to_pb(uint32 only_key, tbl_bhm_global_t *p_bhm_glb, Cdb__TblBhmGlobal *p_pb_bhm_glb)
{
    p_pb_bhm_glb->has_hw_watchdog_fd = TRUE;
    p_pb_bhm_glb->hw_watchdog_fd = p_bhm_glb->hw_watchdog_fd;
    p_pb_bhm_glb->has_hw_watchdog_feed_en = TRUE;
    p_pb_bhm_glb->hw_watchdog_feed_en = p_bhm_glb->hw_watchdog_feed_en;
    p_pb_bhm_glb->has_hw_watchdog_enable = TRUE;
    p_pb_bhm_glb->hw_watchdog_enable = p_bhm_glb->hw_watchdog_enable;
    p_pb_bhm_glb->has_sw_watchdog_enable = TRUE;
    p_pb_bhm_glb->sw_watchdog_enable = p_bhm_glb->sw_watchdog_enable;
    p_pb_bhm_glb->has_reactive = TRUE;
    p_pb_bhm_glb->reactive = p_bhm_glb->reactive;
    p_pb_bhm_glb->has_is_reload = TRUE;
    p_pb_bhm_glb->is_reload = p_bhm_glb->is_reload;
    p_pb_bhm_glb->has_is_shutdown = TRUE;
    p_pb_bhm_glb->is_shutdown = p_bhm_glb->is_shutdown;
    p_pb_bhm_glb->has_is_warning = TRUE;
    p_pb_bhm_glb->is_warning = p_bhm_glb->is_warning;

    return PM_E_NONE;
}

int32
pb_tbl_bhm_global_to_pb_free_packed(Cdb__TblBhmGlobal *p_pb_bhm_glb)
{
    return PM_E_NONE;
}

int32
pb_tbl_bhm_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblBhmGlobal pb_bhm_glb = CDB__TBL_BHM_GLOBAL__INIT;
    tbl_bhm_global_t *p_bhm_glb = (tbl_bhm_global_t*)p_tbl;
    int32 len = 0;

    pb_tbl_bhm_global_to_pb(only_key, p_bhm_glb, &pb_bhm_glb);
    len = cdb__tbl_bhm_global__pack(&pb_bhm_glb, buf);
    pb_tbl_bhm_global_to_pb_free_packed(&pb_bhm_glb);

    return len;
}

int32
pb_tbl_bhm_global_dump(Cdb__TblBhmGlobal *p_pb_bhm_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/hw_watchdog_fd=%d", p_pb_bhm_glb->hw_watchdog_fd);
    offset += sal_sprintf(out + offset, "/hw_watchdog_feed_en=%u", p_pb_bhm_glb->hw_watchdog_feed_en);
    offset += sal_sprintf(out + offset, "/hw_watchdog_enable=%u", p_pb_bhm_glb->hw_watchdog_enable);
    offset += sal_sprintf(out + offset, "/sw_watchdog_enable=%u", p_pb_bhm_glb->sw_watchdog_enable);
    offset += sal_sprintf(out + offset, "/reactive=%u", p_pb_bhm_glb->reactive);
    offset += sal_sprintf(out + offset, "/is_reload=%u", p_pb_bhm_glb->is_reload);
    offset += sal_sprintf(out + offset, "/is_shutdown=%u", p_pb_bhm_glb->is_shutdown);
    offset += sal_sprintf(out + offset, "/is_warning=%u", p_pb_bhm_glb->is_warning);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_BHM_MODULE */
int32
pb_tbl_bhm_module_to_pb(uint32 only_key, tbl_bhm_module_t *p_bhm_module, Cdb__TblBhmModule *p_pb_bhm_module)
{
    p_pb_bhm_module->key->pm_id = p_bhm_module->key.pm_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_bhm_module->has_running = TRUE;
    p_pb_bhm_module->running = p_bhm_module->running;
    p_pb_bhm_module->has_pid = TRUE;
    p_pb_bhm_module->pid = p_bhm_module->pid;
    p_pb_bhm_module->has_death_count = TRUE;
    p_pb_bhm_module->death_count = p_bhm_module->death_count;

    return PM_E_NONE;
}

int32
pb_tbl_bhm_module_to_pb_free_packed(Cdb__TblBhmModule *p_pb_bhm_module)
{
    return PM_E_NONE;
}

int32
pb_tbl_bhm_module_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblBhmModuleKey pb_bhm_module_key = CDB__TBL_BHM_MODULE_KEY__INIT;
    Cdb__TblBhmModule pb_bhm_module = CDB__TBL_BHM_MODULE__INIT;
    tbl_bhm_module_t *p_bhm_module = (tbl_bhm_module_t*)p_tbl;
    int32 len = 0;

    pb_bhm_module.key = &pb_bhm_module_key;
    pb_tbl_bhm_module_to_pb(only_key, p_bhm_module, &pb_bhm_module);
    len = cdb__tbl_bhm_module__pack(&pb_bhm_module, buf);
    pb_tbl_bhm_module_to_pb_free_packed(&pb_bhm_module);

    return len;
}

int32
pb_tbl_bhm_module_dump(Cdb__TblBhmModule *p_pb_bhm_module, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->pm_id=%u", p_pb_bhm_module->key->pm_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/running=%u", p_pb_bhm_module->running);
    offset += sal_sprintf(out + offset, "/pid=%u", p_pb_bhm_module->pid);
    offset += sal_sprintf(out + offset, "/death_count=%u", p_pb_bhm_module->death_count);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPENFLOW_TUNNEL_INTERFACE */
int32
pb_tbl_openflow_tunnel_interface_to_pb(uint32 only_key, tbl_openflow_tunnel_interface_t *p_tunnel_if, Cdb__TblOpenflowTunnelInterface *p_pb_tunnel_if)
{
    p_pb_tunnel_if->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tunnel_if->key.name)+1);
    sal_strcpy(p_pb_tunnel_if->key->name, p_tunnel_if->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_tunnel_if->has_openflow_enable = TRUE;
    p_pb_tunnel_if->openflow_enable = p_tunnel_if->openflow_enable;
    p_pb_tunnel_if->source_ip = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tunnel_if->source_ip)+1);
    sal_strcpy(p_pb_tunnel_if->source_ip, p_tunnel_if->source_ip);
    p_pb_tunnel_if->remote_ip = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tunnel_if->remote_ip)+1);
    sal_strcpy(p_pb_tunnel_if->remote_ip, p_tunnel_if->remote_ip);
    p_pb_tunnel_if->bind_port_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tunnel_if->bind_port_name)+1);
    sal_strcpy(p_pb_tunnel_if->bind_port_name, p_tunnel_if->bind_port_name);
    p_pb_tunnel_if->bind_mac = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_tunnel_if->bind_mac)+1);
    sal_strcpy(p_pb_tunnel_if->bind_mac, p_tunnel_if->bind_mac);
    p_pb_tunnel_if->has_bind_vlan = TRUE;
    p_pb_tunnel_if->bind_vlan = p_tunnel_if->bind_vlan;
    p_pb_tunnel_if->has_flag = TRUE;
    p_pb_tunnel_if->flag = p_tunnel_if->flag;

    return PM_E_NONE;
}

int32
pb_tbl_openflow_tunnel_interface_to_pb_free_packed(Cdb__TblOpenflowTunnelInterface *p_pb_tunnel_if)
{
    if (p_pb_tunnel_if->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tunnel_if->key->name);
        p_pb_tunnel_if->key->name = NULL;
    }

    if (p_pb_tunnel_if->source_ip)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tunnel_if->source_ip);
        p_pb_tunnel_if->source_ip = NULL;
    }

    if (p_pb_tunnel_if->remote_ip)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tunnel_if->remote_ip);
        p_pb_tunnel_if->remote_ip = NULL;
    }

    if (p_pb_tunnel_if->bind_port_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tunnel_if->bind_port_name);
        p_pb_tunnel_if->bind_port_name = NULL;
    }

    if (p_pb_tunnel_if->bind_mac)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_tunnel_if->bind_mac);
        p_pb_tunnel_if->bind_mac = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_openflow_tunnel_interface_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpenflowTunnelInterfaceKey pb_tunnel_if_key = CDB__TBL_OPENFLOW_TUNNEL_INTERFACE_KEY__INIT;
    Cdb__TblOpenflowTunnelInterface pb_tunnel_if = CDB__TBL_OPENFLOW_TUNNEL_INTERFACE__INIT;
    tbl_openflow_tunnel_interface_t *p_tunnel_if = (tbl_openflow_tunnel_interface_t*)p_tbl;
    int32 len = 0;

    pb_tunnel_if.key = &pb_tunnel_if_key;
    pb_tbl_openflow_tunnel_interface_to_pb(only_key, p_tunnel_if, &pb_tunnel_if);
    len = cdb__tbl_openflow_tunnel_interface__pack(&pb_tunnel_if, buf);
    pb_tbl_openflow_tunnel_interface_to_pb_free_packed(&pb_tunnel_if);

    return len;
}

int32
pb_tbl_openflow_tunnel_interface_dump(Cdb__TblOpenflowTunnelInterface *p_pb_tunnel_if, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_tunnel_if->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/openflow_enable=%u", p_pb_tunnel_if->openflow_enable);
    offset += sal_sprintf(out + offset, "/source_ip=%s", p_pb_tunnel_if->source_ip);
    offset += sal_sprintf(out + offset, "/remote_ip=%s", p_pb_tunnel_if->remote_ip);
    offset += sal_sprintf(out + offset, "/bind_port_name=%s", p_pb_tunnel_if->bind_port_name);
    offset += sal_sprintf(out + offset, "/bind_mac=%s", p_pb_tunnel_if->bind_mac);
    offset += sal_sprintf(out + offset, "/bind_vlan=%u", p_pb_tunnel_if->bind_vlan);
    offset += sal_sprintf(out + offset, "/flag=%u", p_pb_tunnel_if->flag);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_OPENFLOW_TUNNEL_LOCAL_IP_CNT */
int32
pb_tbl_openflow_tunnel_local_ip_cnt_to_pb(uint32 only_key, tbl_openflow_tunnel_local_ip_cnt_t *p_openflow_tunnel_local_ip, Cdb__TblOpenflowTunnelLocalIpCnt *p_pb_openflow_tunnel_local_ip)
{
    p_pb_openflow_tunnel_local_ip->key->local_ip = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_openflow_tunnel_local_ip->key.local_ip)+1);
    sal_strcpy(p_pb_openflow_tunnel_local_ip->key->local_ip, p_openflow_tunnel_local_ip->key.local_ip);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_openflow_tunnel_local_ip->has_local_ip_ref = TRUE;
    p_pb_openflow_tunnel_local_ip->local_ip_ref = p_openflow_tunnel_local_ip->local_ip_ref;

    return PM_E_NONE;
}

int32
pb_tbl_openflow_tunnel_local_ip_cnt_to_pb_free_packed(Cdb__TblOpenflowTunnelLocalIpCnt *p_pb_openflow_tunnel_local_ip)
{
    if (p_pb_openflow_tunnel_local_ip->key->local_ip)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_openflow_tunnel_local_ip->key->local_ip);
        p_pb_openflow_tunnel_local_ip->key->local_ip = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_openflow_tunnel_local_ip_cnt_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblOpenflowTunnelLocalIpCntKey pb_openflow_tunnel_local_ip_key = CDB__TBL_OPENFLOW_TUNNEL_LOCAL_IP_CNT_KEY__INIT;
    Cdb__TblOpenflowTunnelLocalIpCnt pb_openflow_tunnel_local_ip = CDB__TBL_OPENFLOW_TUNNEL_LOCAL_IP_CNT__INIT;
    tbl_openflow_tunnel_local_ip_cnt_t *p_openflow_tunnel_local_ip = (tbl_openflow_tunnel_local_ip_cnt_t*)p_tbl;
    int32 len = 0;

    pb_openflow_tunnel_local_ip.key = &pb_openflow_tunnel_local_ip_key;
    pb_tbl_openflow_tunnel_local_ip_cnt_to_pb(only_key, p_openflow_tunnel_local_ip, &pb_openflow_tunnel_local_ip);
    len = cdb__tbl_openflow_tunnel_local_ip_cnt__pack(&pb_openflow_tunnel_local_ip, buf);
    pb_tbl_openflow_tunnel_local_ip_cnt_to_pb_free_packed(&pb_openflow_tunnel_local_ip);

    return len;
}

int32
pb_tbl_openflow_tunnel_local_ip_cnt_dump(Cdb__TblOpenflowTunnelLocalIpCnt *p_pb_openflow_tunnel_local_ip, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->local_ip=%s", p_pb_openflow_tunnel_local_ip->key->local_ip);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/local_ip_ref=%u", p_pb_openflow_tunnel_local_ip->local_ip_ref);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INBAND_SNAT */
int32
pb_tbl_inband_snat_to_pb(uint32 only_key, tbl_inband_snat_t *p_inband_snat, Cdb__TblInbandSnat *p_pb_inband_snat)
{
    pb_compose_inband_snat_key_t_to_pb(&p_inband_snat->key, p_pb_inband_snat->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_inband_snat->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_inband_snat->ifname)+1);
    sal_strcpy(p_pb_inband_snat->ifname, p_inband_snat->ifname);
    pb_compose_addr_ipv4_t_to_pb(&p_inband_snat->ip, p_pb_inband_snat->ip);
    p_pb_inband_snat->has_type = TRUE;
    p_pb_inband_snat->type = p_inband_snat->type;

    return PM_E_NONE;
}

int32
pb_tbl_inband_snat_to_pb_free_packed(Cdb__TblInbandSnat *p_pb_inband_snat)
{
    pb_compose_inband_snat_key_t_to_pb_free_packed(p_pb_inband_snat->key);
    if (p_pb_inband_snat->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_inband_snat->ifname);
        p_pb_inband_snat->ifname = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_inband_snat->ip);
    return PM_E_NONE;
}

int32
pb_tbl_inband_snat_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInbandSnatKey pb_inband_snat_key = CDB__TBL_INBAND_SNAT_KEY__INIT;
    Cdb__TblInbandSnat pb_inband_snat = CDB__TBL_INBAND_SNAT__INIT;
    tbl_inband_snat_t *p_inband_snat = (tbl_inband_snat_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_inband_snat.key = &pb_inband_snat_key;
    pb_inband_snat.ip = &ip;
    pb_tbl_inband_snat_to_pb(only_key, p_inband_snat, &pb_inband_snat);
    len = cdb__tbl_inband_snat__pack(&pb_inband_snat, buf);
    pb_tbl_inband_snat_to_pb_free_packed(&pb_inband_snat);

    return len;
}

int32
pb_tbl_inband_snat_dump(Cdb__TblInbandSnat *p_pb_inband_snat, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_inband_snat_key_t_dump(p_pb_inband_snat->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_inband_snat->ifname);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_inband_snat->ip, (out + offset));
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_inband_snat->type);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ARPINSP */
int32
pb_tbl_arpinsp_to_pb(uint32 only_key, tbl_arpinsp_t *p_arpinsp, Cdb__TblArpinsp *p_pb_arpinsp)
{
    p_pb_arpinsp->key->vlan_id = p_arpinsp->key.vlan_id;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_arpinsp->has_acllog_filter = TRUE;
    p_pb_arpinsp->acllog_filter = p_arpinsp->acllog_filter;
    p_pb_arpinsp->has_dhcplog_filter = TRUE;
    p_pb_arpinsp->dhcplog_filter = p_arpinsp->dhcplog_filter;
    p_pb_arpinsp->has_filter_state = TRUE;
    p_pb_arpinsp->filter_state = p_arpinsp->filter_state;
    p_pb_arpinsp->has_enable_state = TRUE;
    p_pb_arpinsp->enable_state = p_arpinsp->enable_state;
    p_pb_arpinsp->has_forwarded = TRUE;
    p_pb_arpinsp->forwarded = p_arpinsp->forwarded;
    p_pb_arpinsp->has_dropped = TRUE;
    p_pb_arpinsp->dropped = p_arpinsp->dropped;
    p_pb_arpinsp->has_dhcp_dropped = TRUE;
    p_pb_arpinsp->dhcp_dropped = p_arpinsp->dhcp_dropped;
    p_pb_arpinsp->has_acl_dropped = TRUE;
    p_pb_arpinsp->acl_dropped = p_arpinsp->acl_dropped;
    p_pb_arpinsp->has_dhcp_permit = TRUE;
    p_pb_arpinsp->dhcp_permit = p_arpinsp->dhcp_permit;
    p_pb_arpinsp->has_acl_permit = TRUE;
    p_pb_arpinsp->acl_permit = p_arpinsp->acl_permit;
    p_pb_arpinsp->has_srcmac_failure = TRUE;
    p_pb_arpinsp->srcmac_failure = p_arpinsp->srcmac_failure;
    p_pb_arpinsp->has_dstmac_failure = TRUE;
    p_pb_arpinsp->dstmac_failure = p_arpinsp->dstmac_failure;
    p_pb_arpinsp->has_ip_failure = TRUE;
    p_pb_arpinsp->ip_failure = p_arpinsp->ip_failure;
    p_pb_arpinsp->has_invalid_protocol = TRUE;
    p_pb_arpinsp->invalid_protocol = p_arpinsp->invalid_protocol;
    p_pb_arpinsp->filter = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_arpinsp->filter)+1);
    sal_strcpy(p_pb_arpinsp->filter, p_arpinsp->filter);

    return PM_E_NONE;
}

int32
pb_tbl_arpinsp_to_pb_free_packed(Cdb__TblArpinsp *p_pb_arpinsp)
{
    if (p_pb_arpinsp->filter)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_arpinsp->filter);
        p_pb_arpinsp->filter = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_arpinsp_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblArpinspKey pb_arpinsp_key = CDB__TBL_ARPINSP_KEY__INIT;
    Cdb__TblArpinsp pb_arpinsp = CDB__TBL_ARPINSP__INIT;
    tbl_arpinsp_t *p_arpinsp = (tbl_arpinsp_t*)p_tbl;
    int32 len = 0;

    pb_arpinsp.key = &pb_arpinsp_key;
    pb_tbl_arpinsp_to_pb(only_key, p_arpinsp, &pb_arpinsp);
    len = cdb__tbl_arpinsp__pack(&pb_arpinsp, buf);
    pb_tbl_arpinsp_to_pb_free_packed(&pb_arpinsp);

    return len;
}

int32
pb_tbl_arpinsp_dump(Cdb__TblArpinsp *p_pb_arpinsp, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->vlan_id=%u", p_pb_arpinsp->key->vlan_id);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/acllog_filter=%u", p_pb_arpinsp->acllog_filter);
    offset += sal_sprintf(out + offset, "/dhcplog_filter=%u", p_pb_arpinsp->dhcplog_filter);
    offset += sal_sprintf(out + offset, "/filter_state=%u", p_pb_arpinsp->filter_state);
    offset += sal_sprintf(out + offset, "/enable_state=%u", p_pb_arpinsp->enable_state);
    offset += sal_sprintf(out + offset, "/forwarded=%llu", p_pb_arpinsp->forwarded);
    offset += sal_sprintf(out + offset, "/dropped=%llu", p_pb_arpinsp->dropped);
    offset += sal_sprintf(out + offset, "/dhcp_dropped=%llu", p_pb_arpinsp->dhcp_dropped);
    offset += sal_sprintf(out + offset, "/acl_dropped=%llu", p_pb_arpinsp->acl_dropped);
    offset += sal_sprintf(out + offset, "/dhcp_permit=%llu", p_pb_arpinsp->dhcp_permit);
    offset += sal_sprintf(out + offset, "/acl_permit=%llu", p_pb_arpinsp->acl_permit);
    offset += sal_sprintf(out + offset, "/srcmac_failure=%llu", p_pb_arpinsp->srcmac_failure);
    offset += sal_sprintf(out + offset, "/dstmac_failure=%llu", p_pb_arpinsp->dstmac_failure);
    offset += sal_sprintf(out + offset, "/ip_failure=%llu", p_pb_arpinsp->ip_failure);
    offset += sal_sprintf(out + offset, "/invalid_protocol=%llu", p_pb_arpinsp->invalid_protocol);
    offset += sal_sprintf(out + offset, "/filter=%s", p_pb_arpinsp->filter);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ARPACL_CONFIG */
int32
pb_tbl_arpacl_config_to_pb(uint32 only_key, tbl_arpacl_config_t *p_arpacl_config, Cdb__TblArpaclConfig *p_pb_arpacl_config)
{
    p_pb_arpacl_config->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_arpacl_config->key.name)+1);
    sal_strcpy(p_pb_arpacl_config->key->name, p_arpacl_config->key.name);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_arpacl_config->has_seq_ref = TRUE;
    p_pb_arpacl_config->seq_ref = p_arpacl_config->seq_ref;

    return PM_E_NONE;
}

int32
pb_tbl_arpacl_config_to_pb_free_packed(Cdb__TblArpaclConfig *p_pb_arpacl_config)
{
    if (p_pb_arpacl_config->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_arpacl_config->key->name);
        p_pb_arpacl_config->key->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_arpacl_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblArpaclConfigKey pb_arpacl_config_key = CDB__TBL_ARPACL_CONFIG_KEY__INIT;
    Cdb__TblArpaclConfig pb_arpacl_config = CDB__TBL_ARPACL_CONFIG__INIT;
    tbl_arpacl_config_t *p_arpacl_config = (tbl_arpacl_config_t*)p_tbl;
    int32 len = 0;

    pb_arpacl_config.key = &pb_arpacl_config_key;
    pb_tbl_arpacl_config_to_pb(only_key, p_arpacl_config, &pb_arpacl_config);
    len = cdb__tbl_arpacl_config__pack(&pb_arpacl_config, buf);
    pb_tbl_arpacl_config_to_pb_free_packed(&pb_arpacl_config);

    return len;
}

int32
pb_tbl_arpacl_config_dump(Cdb__TblArpaclConfig *p_pb_arpacl_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_arpacl_config->key->name);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/seq_ref=%u", p_pb_arpacl_config->seq_ref);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ARPACE_CONFIG */
int32
pb_tbl_arpace_config_to_pb(uint32 only_key, tbl_arpace_config_t *p_arpace_config, Cdb__TblArpaceConfig *p_pb_arpace_config)
{
    pb_compose_arpace_config_key_t_to_pb(&p_arpace_config->key, p_pb_arpace_config->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_arpace_config->has_arp_type = TRUE;
    p_pb_arpace_config->arp_type = p_arpace_config->arp_type;
    pb_compose_mac_addr_t_to_pb(p_arpace_config->src_mac, p_pb_arpace_config->src_mac);
    pb_compose_mac_addr_t_to_pb(p_arpace_config->src_mac_mask, p_pb_arpace_config->src_mac_mask);
    pb_compose_addr_ipv4_t_to_pb(&p_arpace_config->src_ip, p_pb_arpace_config->src_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_arpace_config->src_ip_mask, p_pb_arpace_config->src_ip_mask);
    p_pb_arpace_config->has_arp_deny = TRUE;
    p_pb_arpace_config->arp_deny = p_arpace_config->arp_deny;
    p_pb_arpace_config->has_arp_log = TRUE;
    p_pb_arpace_config->arp_log = p_arpace_config->arp_log;

    return PM_E_NONE;
}

int32
pb_tbl_arpace_config_to_pb_free_packed(Cdb__TblArpaceConfig *p_pb_arpace_config)
{
    pb_compose_arpace_config_key_t_to_pb_free_packed(p_pb_arpace_config->key);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_arpace_config->src_mac);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_arpace_config->src_mac_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_arpace_config->src_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_arpace_config->src_ip_mask);
    return PM_E_NONE;
}

int32
pb_tbl_arpace_config_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblArpaceConfigKey pb_arpace_config_key = CDB__TBL_ARPACE_CONFIG_KEY__INIT;
    Cdb__TblArpaceConfig pb_arpace_config = CDB__TBL_ARPACE_CONFIG__INIT;
    tbl_arpace_config_t *p_arpace_config = (tbl_arpace_config_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeMacAddrT src_mac = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT src_mac_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T src_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;

    pb_arpace_config.key = &pb_arpace_config_key;
    pb_arpace_config.src_mac = &src_mac;
    pb_arpace_config.src_mac_mask = &src_mac_mask;
    pb_arpace_config.src_ip = &src_ip;
    pb_arpace_config.src_ip_mask = &src_ip_mask;
    pb_tbl_arpace_config_to_pb(only_key, p_arpace_config, &pb_arpace_config);
    len = cdb__tbl_arpace_config__pack(&pb_arpace_config, buf);
    pb_tbl_arpace_config_to_pb_free_packed(&pb_arpace_config);

    return len;
}

int32
pb_tbl_arpace_config_dump(Cdb__TblArpaceConfig *p_pb_arpace_config, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_arpace_config_key_t_dump(p_pb_arpace_config->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/arp_type=%u", p_pb_arpace_config->arp_type);
    offset += pb_compose_mac_addr_t_dump(p_pb_arpace_config->src_mac, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_arpace_config->src_mac_mask, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_arpace_config->src_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_arpace_config->src_ip_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/arp_deny=%u", p_pb_arpace_config->arp_deny);
    offset += sal_sprintf(out + offset, "/arp_log=%u", p_pb_arpace_config->arp_log);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_COPP_CFG */
int32
pb_tbl_copp_cfg_to_pb(uint32 only_key, tbl_copp_cfg_t *p_copp_cfg, Cdb__TblCoppCfg *p_pb_copp_cfg)
{
    p_pb_copp_cfg->copp_pname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_copp_cfg->copp_pname)+1);
    sal_strcpy(p_pb_copp_cfg->copp_pname, p_copp_cfg->copp_pname);
    p_pb_copp_cfg->has_copp_ifidx = TRUE;
    p_pb_copp_cfg->copp_ifidx = p_copp_cfg->copp_ifidx;
    p_pb_copp_cfg->has_copp_total_rate = TRUE;
    p_pb_copp_cfg->copp_total_rate = p_copp_cfg->copp_total_rate;

    return PM_E_NONE;
}

int32
pb_tbl_copp_cfg_to_pb_free_packed(Cdb__TblCoppCfg *p_pb_copp_cfg)
{
    if (p_pb_copp_cfg->copp_pname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_copp_cfg->copp_pname);
        p_pb_copp_cfg->copp_pname = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_copp_cfg_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblCoppCfg pb_copp_cfg = CDB__TBL_COPP_CFG__INIT;
    tbl_copp_cfg_t *p_copp_cfg = (tbl_copp_cfg_t*)p_tbl;
    int32 len = 0;

    pb_tbl_copp_cfg_to_pb(only_key, p_copp_cfg, &pb_copp_cfg);
    len = cdb__tbl_copp_cfg__pack(&pb_copp_cfg, buf);
    pb_tbl_copp_cfg_to_pb_free_packed(&pb_copp_cfg);

    return len;
}

int32
pb_tbl_copp_cfg_dump(Cdb__TblCoppCfg *p_pb_copp_cfg, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/copp_pname=%s", p_pb_copp_cfg->copp_pname);
    offset += sal_sprintf(out + offset, "/copp_ifidx=%u", p_pb_copp_cfg->copp_ifidx);
    offset += sal_sprintf(out + offset, "/copp_total_rate=%u", p_pb_copp_cfg->copp_total_rate);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SFLOW_GLOBAL */
int32
pb_tbl_sflow_global_to_pb(uint32 only_key, tbl_sflow_global_t *p_sflow_glb, Cdb__TblSflowGlobal *p_pb_sflow_glb)
{
    p_pb_sflow_glb->has_enable = TRUE;
    p_pb_sflow_glb->enable = p_sflow_glb->enable;
    pb_compose_addr_t_to_pb(&p_sflow_glb->agent, p_pb_sflow_glb->agent);
    p_pb_sflow_glb->has_counter_interval = TRUE;
    p_pb_sflow_glb->counter_interval = p_sflow_glb->counter_interval;
    p_pb_sflow_glb->has_counter_port_num = TRUE;
    p_pb_sflow_glb->counter_port_num = p_sflow_glb->counter_port_num;
    p_pb_sflow_glb->has_counter_next_port = TRUE;
    p_pb_sflow_glb->counter_next_port = p_sflow_glb->counter_next_port;
    p_pb_sflow_glb->has_sflow_all = TRUE;
    p_pb_sflow_glb->sflow_all = GLB_FLAG_ISSET(p_sflow_glb->sflow, SFLOW_FLAG_ALL) ? TRUE : FALSE;
    p_pb_sflow_glb->has_sflow_counter = TRUE;
    p_pb_sflow_glb->sflow_counter = GLB_FLAG_ISSET(p_sflow_glb->sflow, SFLOW_FLAG_COUNTER) ? TRUE : FALSE;
    p_pb_sflow_glb->has_sflow_sample = TRUE;
    p_pb_sflow_glb->sflow_sample = GLB_FLAG_ISSET(p_sflow_glb->sflow, SFLOW_FLAG_SAMPLE) ? TRUE : FALSE;
    p_pb_sflow_glb->has_sflow_packet = TRUE;
    p_pb_sflow_glb->sflow_packet = GLB_FLAG_ISSET(p_sflow_glb->sflow, SFLOW_FLAG_PACKET) ? TRUE : FALSE;

    return PM_E_NONE;
}

int32
pb_tbl_sflow_global_to_pb_free_packed(Cdb__TblSflowGlobal *p_pb_sflow_glb)
{
    pb_compose_addr_t_to_pb_free_packed(p_pb_sflow_glb->agent);
    return PM_E_NONE;
}

int32
pb_tbl_sflow_global_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSflowGlobal pb_sflow_glb = CDB__TBL_SFLOW_GLOBAL__INIT;
    tbl_sflow_global_t *p_sflow_glb = (tbl_sflow_global_t*)p_tbl;
    int32 len = 0;
    Cdb__ComposeAddrT agent = CDB__COMPOSE_ADDR_T__INIT;

    pb_sflow_glb.agent = &agent;
    pb_tbl_sflow_global_to_pb(only_key, p_sflow_glb, &pb_sflow_glb);
    len = cdb__tbl_sflow_global__pack(&pb_sflow_glb, buf);
    pb_tbl_sflow_global_to_pb_free_packed(&pb_sflow_glb);

    return len;
}

int32
pb_tbl_sflow_global_dump(Cdb__TblSflowGlobal *p_pb_sflow_glb, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_sflow_glb->enable);
    offset += pb_compose_addr_t_dump(p_pb_sflow_glb->agent, (out + offset));
    offset += sal_sprintf(out + offset, "/counter_interval=%u", p_pb_sflow_glb->counter_interval);
    offset += sal_sprintf(out + offset, "/counter_port_num=%u", p_pb_sflow_glb->counter_port_num);
    offset += sal_sprintf(out + offset, "/counter_next_port=%u", p_pb_sflow_glb->counter_next_port);
    offset += sal_sprintf(out + offset, "/sflow_all=%u", p_pb_sflow_glb->sflow_all);
    offset += sal_sprintf(out + offset, "/sflow_counter=%u", p_pb_sflow_glb->sflow_counter);
    offset += sal_sprintf(out + offset, "/sflow_sample=%u", p_pb_sflow_glb->sflow_sample);
    offset += sal_sprintf(out + offset, "/sflow_packet=%u", p_pb_sflow_glb->sflow_packet);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SFLOW_COLLECTOR */
int32
pb_tbl_sflow_collector_to_pb(uint32 only_key, tbl_sflow_collector_t *p_sflow_collector, Cdb__TblSflowCollector *p_pb_sflow_collector)
{
    pb_compose_sflow_collector_key_t_to_pb(&p_sflow_collector->key, p_pb_sflow_collector->key);

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_sflow_collector->has_buf = TRUE;
    p_pb_sflow_collector->buf.len = sizeof(p_sflow_collector->buf);
    p_pb_sflow_collector->buf.data = XCALLOC(MEM_LIB_PROTOBUF, sizeof(p_sflow_collector->buf));
    sal_memcpy(p_pb_sflow_collector->buf.data, p_sflow_collector->buf, sizeof(p_sflow_collector->buf));
    p_pb_sflow_collector->has_pkt_len = TRUE;
    p_pb_sflow_collector->pkt_len = p_sflow_collector->pkt_len;
    p_pb_sflow_collector->has_sendfd = TRUE;
    p_pb_sflow_collector->sendfd = p_sflow_collector->sendfd;
    p_pb_sflow_collector->has_sequence = TRUE;
    p_pb_sflow_collector->sequence = p_sflow_collector->sequence;

    return PM_E_NONE;
}

int32
pb_tbl_sflow_collector_to_pb_free_packed(Cdb__TblSflowCollector *p_pb_sflow_collector)
{
    pb_compose_sflow_collector_key_t_to_pb_free_packed(p_pb_sflow_collector->key);
    if (p_pb_sflow_collector->buf.data)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_sflow_collector->buf.data);
        p_pb_sflow_collector->buf.data = NULL;
    }

    return PM_E_NONE;
}

int32
pb_tbl_sflow_collector_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSflowCollectorKey pb_sflow_collector_key = CDB__TBL_SFLOW_COLLECTOR_KEY__INIT;
    Cdb__TblSflowCollector pb_sflow_collector = CDB__TBL_SFLOW_COLLECTOR__INIT;
    tbl_sflow_collector_t *p_sflow_collector = (tbl_sflow_collector_t*)p_tbl;
    int32 len = 0;

    pb_sflow_collector.key = &pb_sflow_collector_key;
    pb_tbl_sflow_collector_to_pb(only_key, p_sflow_collector, &pb_sflow_collector);
    len = cdb__tbl_sflow_collector__pack(&pb_sflow_collector, buf);
    pb_tbl_sflow_collector_to_pb_free_packed(&pb_sflow_collector);

    return len;
}

int32
pb_tbl_sflow_collector_dump(Cdb__TblSflowCollector *p_pb_sflow_collector, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += pb_compose_sflow_collector_key_t_dump(p_pb_sflow_collector->key, (out + offset));
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/buf=");
    offset += pb_uint8_array_dump(p_pb_sflow_collector->buf.data, p_pb_sflow_collector->buf.len, (out + offset));
    offset += sal_sprintf(out + offset, "/pkt_len=%u", p_pb_sflow_collector->pkt_len);
    offset += sal_sprintf(out + offset, "/sendfd=%u", p_pb_sflow_collector->sendfd);
    offset += sal_sprintf(out + offset, "/sequence=%u", p_pb_sflow_collector->sequence);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_SFLOW_COUNTER_PORT */
int32
pb_tbl_sflow_counter_port_to_pb(uint32 only_key, tbl_sflow_counter_port_t *p_sflow_counter_port, Cdb__TblSflowCounterPort *p_pb_sflow_counter_port)
{
    p_pb_sflow_counter_port->key->ifindex = p_sflow_counter_port->key.ifindex;

    if (only_key)
    {
        return PM_E_NONE;
    }

    p_pb_sflow_counter_port->has_left_interval = TRUE;
    p_pb_sflow_counter_port->left_interval = p_sflow_counter_port->left_interval;
    p_pb_sflow_counter_port->has_sequence = TRUE;
    p_pb_sflow_counter_port->sequence = p_sflow_counter_port->sequence;

    return PM_E_NONE;
}

int32
pb_tbl_sflow_counter_port_to_pb_free_packed(Cdb__TblSflowCounterPort *p_pb_sflow_counter_port)
{
    return PM_E_NONE;
}

int32
pb_tbl_sflow_counter_port_pack(void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    Cdb__TblSflowCounterPortKey pb_sflow_counter_port_key = CDB__TBL_SFLOW_COUNTER_PORT_KEY__INIT;
    Cdb__TblSflowCounterPort pb_sflow_counter_port = CDB__TBL_SFLOW_COUNTER_PORT__INIT;
    tbl_sflow_counter_port_t *p_sflow_counter_port = (tbl_sflow_counter_port_t*)p_tbl;
    int32 len = 0;

    pb_sflow_counter_port.key = &pb_sflow_counter_port_key;
    pb_tbl_sflow_counter_port_to_pb(only_key, p_sflow_counter_port, &pb_sflow_counter_port);
    len = cdb__tbl_sflow_counter_port__pack(&pb_sflow_counter_port, buf);
    pb_tbl_sflow_counter_port_to_pb_free_packed(&pb_sflow_counter_port);

    return len;
}

int32
pb_tbl_sflow_counter_port_dump(Cdb__TblSflowCounterPort *p_pb_sflow_counter_port, uint32 only_key, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/key->ifindex=%u", p_pb_sflow_counter_port->key->ifindex);
    if (only_key)
    {
        offset += sal_sprintf(out + offset, "\n");
        return PM_E_NONE;
    }
    
    offset += sal_sprintf(out + offset, "/left_interval=%u", p_pb_sflow_counter_port->left_interval);
    offset += sal_sprintf(out + offset, "/sequence=%u", p_pb_sflow_counter_port->sequence);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

PB_TBL_PACK_FUNC g_pb_pack_tbl_func[TBL_MAX] =
{
    pb_tbl_interface_pack,
    pb_tbl_route_if_pack,
    pb_tbl_kernel_if_pack,
    pb_tbl_fea_port_if_pack,
    pb_tbl_vlan_pack,
    pb_tbl_pvlan_pack,
    pb_tbl_fdb_pack,
    pb_tbl_mcfdb_pack,
    pb_tbl_macfilter_pack,
    pb_tbl_psfdb_pack,
    pb_tbl_ipsg_s_ip_pack,
    pb_tbl_ipsg_s_mac_pack,
    pb_tbl_ipsg_fib_pack,
    pb_tbl_brg_global_pack,
    pb_tbl_mstp_port_pack,
    pb_tbl_msti_port_pack,
    pb_tbl_mstp_instance_pack,
    pb_tbl_mstp_global_pack,
    pb_tbl_lldp_global_pack,
    pb_tbl_lldp_if_pack,
    pb_tbl_mlag_pack,
    pb_tbl_mlag_peer_pack,
    pb_tbl_mlag_port_pack,
    pb_tbl_isolation_pack,
    pb_tbl_route_global_pack,
    pb_tbl_ospf_pack,
    pb_tbl_ospf_network_pack,
    pb_tbl_ospf_area_auth_pack,
    pb_tbl_iproute_node_pack,
    pb_tbl_static_route_cfg_pack,
    pb_tbl_static_rt_cnt_pack,
    pb_tbl_arp_fib_pack,
    pb_tbl_arp_pack,
    pb_tbl_nexthop_pack,
    pb_tbl_nexthop_group_pack,
    pb_tbl_fea_nexthop_pack,
    pb_tbl_sys_global_pack,
    pb_tbl_lag_global_pack,
    pb_tbl_mem_summary_pack,
    pb_tbl_chsm_debug_pack,
    pb_tbl_switch_debug_pack,
    pb_tbl_route_debug_pack,
    pb_tbl_quagga_debug_pack,
    pb_tbl_lsrv_debug_pack,
    pb_tbl_hsrv_debug_pack,
    pb_tbl_rif_pack,
    pb_tbl_fea_lag_pack,
    pb_tbl_fea_global_pack,
    pb_tbl_fea_acl_table_pack,
    pb_tbl_fea_acl_pack,
    pb_tbl_fea_fdb_pack,
    pb_tbl_fea_brg_if_pack,
    pb_tbl_acl_worm_filter_pack,
    pb_tbl_acl_config_pack,
    pb_tbl_ace_config_pack,
    pb_tbl_acl_entry_pack,
    pb_tbl_acl_entry_action_pack,
    pb_tbl_acl_nexthop_group_pack,
    pb_tbl_acl_nexthop_pack,
    pb_tbl_pmap_pack,
    pb_tbl_cmap_pack,
    pb_tbl_acl_pack,
    pb_tbl_time_range_pack,
    pb_tbl_ssh_cfg_pack,
    pb_tbl_snmp_cfg_pack,
    pb_tbl_snmp_view_pack,
    pb_tbl_snmp_community_pack,
    pb_tbl_snmp_trap_pack,
    pb_tbl_snmp_inform_pack,
    pb_tbl_syslog_cfg_pack,
    pb_tbl_ntp_server_pack,
    pb_tbl_ntp_ace_pack,
    pb_tbl_ntp_key_pack,
    pb_tbl_ntp_cfg_pack,
    pb_tbl_ntp_if_pack,
    pb_tbl_ntp_syncstatus_pack,
    pb_tbl_static_dns_pack,
    pb_tbl_dynamic_dns_domain_pack,
    pb_tbl_dynamic_dns_server_pack,
    pb_tbl_qos_domain_pack,
    pb_tbl_qos_policer_profile_pack,
    pb_tbl_qos_drop_profile_pack,
    pb_tbl_qos_queue_shape_profile_pack,
    pb_tbl_qos_port_shape_profile_pack,
    pb_tbl_qos_global_pack,
    pb_tbl_mirror_pack,
    pb_tbl_mirror_mac_escape_pack,
    pb_tbl_tap_group_ingress_pack,
    pb_tbl_tap_group_ingress_flow_pack,
    pb_tbl_tap_group_egress_pack,
    pb_tbl_tap_group_pack,
    pb_tbl_user_pack,
    pb_tbl_vty_pack,
    pb_tbl_console_pack,
    pb_tbl_authen_pack,
    pb_tbl_login_pack,
    pb_tbl_rsa_pack,
    pb_tbl_openflow_pack,
    pb_tbl_cpu_traffic_pack,
    pb_tbl_cpu_traffic_group_pack,
    pb_tbl_cpu_utilization_pack,
    pb_tbl_cpu_limit_pack,
    pb_tbl_dhcrelay_pack,
    pb_tbl_dhcsrvgrp_pack,
    pb_tbl_dhcp_debug_pack,
    pb_tbl_dhclient_pack,
    pb_tbl_dhcsnooping_pack,
    pb_tbl_dhcbinding_pack,
    pb_tbl_iptables_prevent_pack,
    pb_tbl_errdisable_pack,
    pb_tbl_ns_port_forwarding_pack,
    pb_tbl_log_global_pack,
    pb_tbl_log_pack,
    pb_tbl_sys_load_pack,
    pb_tbl_cem_pack,
    pb_tbl_clock_pack,
    pb_tbl_port_stats_pack,
    pb_tbl_port_stats_rate_pack,
    pb_tbl_aclqos_if_pack,
    pb_tbl_l2_action_pack,
    pb_tbl_fea_qos_drop_profile_pack,
    pb_tbl_fea_qos_domain_pack,
    pb_tbl_fea_qos_queue_shape_profile_pack,
    pb_tbl_fea_qos_port_shape_profile_pack,
    pb_tbl_fea_port_policer_apply_pack,
    pb_tbl_aclqos_if_stats_pack,
    pb_tbl_version_pack,
    pb_tbl_manage_if_pack,
    pb_tbl_bootimage_pack,
    pb_tbl_chassis_pack,
    pb_tbl_ifname_info_pack,
    pb_tbl_card_pack,
    pb_tbl_port_pack,
    pb_tbl_fiber_pack,
    pb_tbl_sys_spec_pack,
    pb_tbl_fan_pack,
    pb_tbl_psu_pack,
    pb_tbl_led_pack,
    pb_tbl_sensor_pack,
    pb_tbl_reboot_info_pack,
    pb_tbl_errdisable_flap_pack,
    pb_tbl_opm_global_pack,
    pb_tbl_erps_ring_pack,
    pb_tbl_erps_domain_pack,
    pb_tbl_opm_debug_pack,
    pb_tbl_policy_map_config_pack,
    pb_tbl_class_map_config_pack,
    pb_tbl_class_in_policy_config_pack,
    pb_tbl_acl_in_class_config_pack,
    pb_tbl_class_map_action_config_pack,
    pb_tbl_fea_acl_policy_action_pack,
    pb_tbl_igsp_global_pack,
    pb_tbl_igsp_intf_pack,
    pb_tbl_igsp_group_pack,
    pb_tbl_auth_cfg_pack,
    pb_tbl_auth_server_pack,
    pb_tbl_auth_session_pack,
    pb_tbl_authd_debug_pack,
    pb_tbl_dot1x_global_pack,
    pb_tbl_dot1x_port_pack,
    pb_tbl_dot1x_radius_pack,
    pb_tbl_dot1x_mac_pack,
    pb_tbl_enable_pack,
    pb_tbl_chip_pack,
    pb_tbl_clear_acl_policy_pack,
    pb_tbl_author_pack,
    pb_tbl_account_pack,
    pb_tbl_accountcmd_pack,
    pb_tbl_vlanclass_rule_pack,
    pb_tbl_vlanclass_group_pack,
    pb_tbl_acl_l4_port_range_pack,
    pb_tbl_fea_pcap_pack,
    pb_tbl_controller_pack,
    pb_tbl_cpu_packets_pack,
    pb_tbl_ns_route_pack,
    pb_tbl_ns_route_ip_pack,
    pb_tbl_openflow_interface_pack,
    pb_tbl_openflow_manager_pack,
    pb_tbl_ptp_global_pack,
    pb_tbl_ptp_port_pack,
    pb_tbl_ptp_foreign_pack,
    pb_tbl_fea_time_pack,
    pb_tbl_bhm_global_pack,
    pb_tbl_bhm_module_pack,
    pb_tbl_openflow_tunnel_interface_pack,
    pb_tbl_openflow_tunnel_local_ip_cnt_pack,
    pb_tbl_inband_snat_pack,
    pb_tbl_arpinsp_pack,
    pb_tbl_arpacl_config_pack,
    pb_tbl_arpace_config_pack,
    pb_tbl_copp_cfg_pack,
    pb_tbl_sflow_global_pack,
    pb_tbl_sflow_collector_pack,
    pb_tbl_sflow_counter_port_pack,
};

PB_TBL_UNPACK_FUNC g_pb_unpack_tbl_func[TBL_MAX] =
{
    (PB_TBL_UNPACK_FUNC)cdb__tbl_interface__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_route_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_kernel_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_port_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_vlan__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_pvlan__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fdb__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mcfdb__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_macfilter__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_psfdb__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ipsg_s_ip__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ipsg_s_mac__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ipsg_fib__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_brg_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mstp_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_msti_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mstp_instance__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mstp_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_lldp_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_lldp_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mlag__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mlag_peer__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mlag_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_isolation__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_route_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ospf__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ospf_network__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ospf_area_auth__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_iproute_node__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_static_route_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_static_rt_cnt__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_arp_fib__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_arp__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_nexthop__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_nexthop_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_nexthop__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sys_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_lag_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mem_summary__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_chsm_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_switch_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_route_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_quagga_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_lsrv_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_hsrv_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_rif__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_lag__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_acl_table__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_acl__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_fdb__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_brg_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_worm_filter__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ace_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_entry__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_entry_action__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_nexthop_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_nexthop__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_pmap__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cmap__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_time_range__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ssh_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_snmp_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_snmp_view__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_snmp_community__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_snmp_trap__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_snmp_inform__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_syslog_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_server__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_ace__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_key__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ntp_syncstatus__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_static_dns__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dynamic_dns_domain__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dynamic_dns_server__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_domain__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_policer_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_drop_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_queue_shape_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_port_shape_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_qos_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mirror__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_mirror_mac_escape__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_tap_group_ingress__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_tap_group_ingress_flow__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_tap_group_egress__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_tap_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_user__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_vty__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_console__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_authen__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_login__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_rsa__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_openflow__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cpu_traffic__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cpu_traffic_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cpu_utilization__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cpu_limit__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhcrelay__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhcsrvgrp__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhcp_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhclient__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhcsnooping__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dhcbinding__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_iptables_prevent__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_errdisable__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ns_port_forwarding__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_log_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_log__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sys_load__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cem__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_clock__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_port_stats__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_port_stats_rate__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_aclqos_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_l2_action__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_qos_drop_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_qos_domain__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_qos_queue_shape_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_qos_port_shape_profile__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_port_policer_apply__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_aclqos_if_stats__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_version__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_manage_if__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_bootimage__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_chassis__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ifname_info__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_card__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fiber__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sys_spec__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fan__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_psu__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_led__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sensor__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_reboot_info__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_errdisable_flap__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_opm_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_erps_ring__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_erps_domain__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_opm_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_policy_map_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_class_map_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_class_in_policy_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_in_class_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_class_map_action_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_acl_policy_action__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_igsp_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_igsp_intf__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_igsp_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_auth_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_auth_server__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_auth_session__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_authd_debug__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dot1x_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dot1x_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dot1x_radius__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_dot1x_mac__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_enable__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_chip__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_clear_acl_policy__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_author__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_account__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_accountcmd__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_vlanclass_rule__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_vlanclass_group__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_acl_l4_port_range__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_pcap__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_controller__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_cpu_packets__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ns_route__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ns_route_ip__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_openflow_interface__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_openflow_manager__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ptp_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ptp_port__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_ptp_foreign__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_fea_time__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_bhm_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_bhm_module__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_openflow_tunnel_interface__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_openflow_tunnel_local_ip_cnt__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_inband_snat__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_arpinsp__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_arpacl_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_arpace_config__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_copp_cfg__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sflow_global__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sflow_collector__unpack,
    (PB_TBL_UNPACK_FUNC)cdb__tbl_sflow_counter_port__unpack,
};

PB_TBL_DUMP_FUNC g_pb_dump_tbl_func[TBL_MAX] =
{
    (PB_TBL_DUMP_FUNC)pb_tbl_interface_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_route_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_kernel_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_port_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_vlan_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_pvlan_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fdb_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mcfdb_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_macfilter_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_psfdb_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ipsg_s_ip_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ipsg_s_mac_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ipsg_fib_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_brg_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mstp_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_msti_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mstp_instance_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mstp_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_lldp_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_lldp_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mlag_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mlag_peer_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mlag_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_isolation_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_route_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ospf_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ospf_network_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ospf_area_auth_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_iproute_node_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_static_route_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_static_rt_cnt_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_arp_fib_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_arp_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_nexthop_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_nexthop_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_nexthop_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sys_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_lag_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mem_summary_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_chsm_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_switch_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_route_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_quagga_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_lsrv_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_hsrv_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_rif_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_lag_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_acl_table_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_acl_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_fdb_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_brg_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_worm_filter_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ace_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_entry_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_entry_action_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_nexthop_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_nexthop_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_pmap_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cmap_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_time_range_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ssh_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_snmp_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_snmp_view_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_snmp_community_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_snmp_trap_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_snmp_inform_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_syslog_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_server_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_ace_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_key_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ntp_syncstatus_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_static_dns_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dynamic_dns_domain_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dynamic_dns_server_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_domain_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_policer_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_drop_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_queue_shape_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_port_shape_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_qos_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mirror_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_mirror_mac_escape_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_tap_group_ingress_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_tap_group_ingress_flow_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_tap_group_egress_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_tap_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_user_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_vty_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_console_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_authen_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_login_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_rsa_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_openflow_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cpu_traffic_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cpu_traffic_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cpu_utilization_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cpu_limit_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhcrelay_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhcsrvgrp_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhcp_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhclient_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhcsnooping_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dhcbinding_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_iptables_prevent_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_errdisable_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ns_port_forwarding_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_log_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_log_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sys_load_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cem_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_clock_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_port_stats_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_port_stats_rate_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_aclqos_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_l2_action_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_qos_drop_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_qos_domain_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_qos_queue_shape_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_qos_port_shape_profile_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_port_policer_apply_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_aclqos_if_stats_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_version_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_manage_if_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_bootimage_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_chassis_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ifname_info_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_card_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fiber_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sys_spec_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fan_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_psu_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_led_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sensor_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_reboot_info_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_errdisable_flap_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_opm_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_erps_ring_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_erps_domain_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_opm_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_policy_map_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_class_map_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_class_in_policy_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_in_class_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_class_map_action_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_acl_policy_action_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_igsp_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_igsp_intf_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_igsp_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_auth_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_auth_server_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_auth_session_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_authd_debug_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dot1x_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dot1x_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dot1x_radius_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_dot1x_mac_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_enable_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_chip_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_clear_acl_policy_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_author_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_account_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_accountcmd_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_vlanclass_rule_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_vlanclass_group_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_acl_l4_port_range_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_pcap_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_controller_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_cpu_packets_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ns_route_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ns_route_ip_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_openflow_interface_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_openflow_manager_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ptp_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ptp_port_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_ptp_foreign_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_fea_time_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_bhm_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_bhm_module_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_openflow_tunnel_interface_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_openflow_tunnel_local_ip_cnt_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_inband_snat_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_arpinsp_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_arpacl_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_arpace_config_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_copp_cfg_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sflow_global_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sflow_collector_dump,
    (PB_TBL_DUMP_FUNC)pb_tbl_sflow_counter_port_dump,
};

PB_TBL_FREE_UNPACKED_FUNC g_pb_free_unpacked_tbl_func[TBL_MAX] =
{
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_interface__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_route_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_kernel_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_port_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_vlan__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_pvlan__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fdb__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mcfdb__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_macfilter__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_psfdb__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ipsg_s_ip__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ipsg_s_mac__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ipsg_fib__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_brg_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mstp_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_msti_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mstp_instance__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mstp_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_lldp_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_lldp_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mlag__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mlag_peer__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mlag_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_isolation__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_route_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ospf__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ospf_network__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ospf_area_auth__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_iproute_node__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_static_route_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_static_rt_cnt__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_arp_fib__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_arp__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_nexthop__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_nexthop_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_nexthop__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sys_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_lag_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mem_summary__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_chsm_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_switch_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_route_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_quagga_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_lsrv_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_hsrv_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_rif__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_lag__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_acl_table__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_acl__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_fdb__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_brg_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_worm_filter__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ace_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_entry__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_entry_action__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_nexthop_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_nexthop__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_pmap__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cmap__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_time_range__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ssh_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_snmp_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_snmp_view__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_snmp_community__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_snmp_trap__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_snmp_inform__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_syslog_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_server__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_ace__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_key__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ntp_syncstatus__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_static_dns__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dynamic_dns_domain__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dynamic_dns_server__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_domain__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_policer_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_drop_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_queue_shape_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_port_shape_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_qos_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mirror__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_mirror_mac_escape__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_tap_group_ingress__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_tap_group_ingress_flow__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_tap_group_egress__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_tap_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_user__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_vty__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_console__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_authen__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_login__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_rsa__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_openflow__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cpu_traffic__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cpu_traffic_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cpu_utilization__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cpu_limit__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhcrelay__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhcsrvgrp__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhcp_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhclient__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhcsnooping__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dhcbinding__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_iptables_prevent__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_errdisable__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ns_port_forwarding__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_log_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_log__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sys_load__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cem__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_clock__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_port_stats__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_port_stats_rate__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_aclqos_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_l2_action__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_qos_drop_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_qos_domain__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_qos_queue_shape_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_qos_port_shape_profile__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_port_policer_apply__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_aclqos_if_stats__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_version__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_manage_if__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_bootimage__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_chassis__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ifname_info__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_card__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fiber__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sys_spec__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fan__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_psu__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_led__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sensor__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_reboot_info__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_errdisable_flap__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_opm_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_erps_ring__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_erps_domain__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_opm_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_policy_map_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_class_map_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_class_in_policy_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_in_class_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_class_map_action_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_acl_policy_action__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_igsp_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_igsp_intf__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_igsp_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_auth_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_auth_server__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_auth_session__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_authd_debug__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dot1x_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dot1x_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dot1x_radius__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_dot1x_mac__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_enable__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_chip__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_clear_acl_policy__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_author__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_account__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_accountcmd__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_vlanclass_rule__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_vlanclass_group__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_acl_l4_port_range__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_pcap__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_controller__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_cpu_packets__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ns_route__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ns_route_ip__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_openflow_interface__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_openflow_manager__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ptp_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ptp_port__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_ptp_foreign__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_fea_time__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_bhm_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_bhm_module__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_openflow_tunnel_interface__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_openflow_tunnel_local_ip_cnt__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_inband_snat__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_arpinsp__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_arpacl_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_arpace_config__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_copp_cfg__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sflow_global__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sflow_collector__free_unpacked,
    (PB_TBL_FREE_UNPACKED_FUNC)cdb__tbl_sflow_counter_port__free_unpacked,
};

int32
pb_tbl_pack(uint32 tbl_id, void *p_tbl, uint32 only_key, uint8 *buf, uint32 buf_len)
{
    if (tbl_id >= TBL_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_pack_tbl_func[tbl_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    return g_pb_pack_tbl_func[tbl_id](p_tbl, only_key, buf, buf_len);
}

void*
pb_tbl_unpack(uint32 tbl_id, ProtobufCAllocator *allocator, uint32 len, uint8 *data)
{
    if (tbl_id >= TBL_MAX)
    {
        return NULL;
    }

    if (NULL == g_pb_unpack_tbl_func[tbl_id])
    {
        return NULL;
    }

    return g_pb_unpack_tbl_func[tbl_id](allocator, len, data);
}

int32
pb_tbl_dump(uint32 tbl_id, void *object, uint32 only_key, char *out)
{
    if (tbl_id >= TBL_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_dump_tbl_func[tbl_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    return g_pb_dump_tbl_func[tbl_id](object, only_key, out);
}

int32
pb_tbl_free_unpacked(uint32 tbl_id, void *object, ProtobufCAllocator *allocator)
{
    if (tbl_id >= TBL_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_free_unpacked_tbl_func[tbl_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    g_pb_free_unpacked_tbl_func[tbl_id](object, allocator);

    return PM_E_NONE;
}


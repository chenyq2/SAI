
#include "proto.h"
#include "pb_cdb_inc.h"
#include "tbl.pb-c.h"
#include "ds.pb-c.h"
#include "pb_tbl.h"
#include "pb_ds.h"
#include "pb_common.h"

/* pb functions for TBL_INTERFACE DS_BRGIF */
int32
pb_ds_brgif_to_pb(tbl_interface_key_t *p_if_key, ds_brgif_t *p_brgif, Cdb__DsBrgif *p_pb_brgif)
{
    p_pb_brgif->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_brgif->parent_if->name, p_if_key->name);

    p_pb_brgif->pvid = p_brgif->pvid;
    pb_compose_brg_allowed_vlan_t_to_pb(&p_brgif->allowed_vlan, p_pb_brgif->allowed_vlan);
    p_pb_brgif->ingress_filter = p_brgif->ingress_filter;
    p_pb_brgif->egress_filter = p_brgif->egress_filter;
    p_pb_brgif->tpid_type = p_brgif->tpid_type;
    p_pb_brgif->mac_learning_en = p_brgif->mac_learning_en;
    p_pb_brgif->oper_mac_learning_en = p_brgif->oper_mac_learning_en;
    p_pb_brgif->port_security_en = p_brgif->port_security_en;
    p_pb_brgif->violate_mode = p_brgif->violate_mode;
    p_pb_brgif->mlag_is_peer_link = p_brgif->mlag_is_peer_link;
    p_pb_brgif->mlag_is_port_block = p_brgif->mlag_is_port_block;
    p_pb_brgif->mlag_is_group = p_brgif->mlag_is_group;
    p_pb_brgif->max_mac = p_brgif->max_mac;

    return PM_E_NONE;
}

int32
pb_ds_brgif_to_pb_free_packed(Cdb__DsBrgif *p_pb_brgif)
{
    if (p_pb_brgif->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_brgif->parent_if->name);
        p_pb_brgif->parent_if->name = NULL;
    }

    pb_compose_brg_allowed_vlan_t_to_pb_free_packed(p_pb_brgif->allowed_vlan);
    return PM_E_NONE;
}

int32
pb_ds_brgif_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsBrgif pb_brgif = CDB__DS_BRGIF__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_brgif_t *p_brgif = (ds_brgif_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeBrgAllowedVlanT allowed_vlan = CDB__COMPOSE_BRG_ALLOWED_VLAN_T__INIT;

    pb_brgif.allowed_vlan = &allowed_vlan;
    pb_brgif.parent_if = &pb_if_key;
    pb_ds_brgif_to_pb(p_if_key, p_brgif, &pb_brgif);
    len = cdb__ds_brgif__pack(&pb_brgif, buf);
    pb_ds_brgif_to_pb_free_packed(&pb_brgif);

    return len;
}

int32
pb_ds_brgif_dump(Cdb__DsBrgif *p_pb_brgif, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_brgif->parent_if->name);
    offset += sal_sprintf(out + offset, "/pvid=%u", p_pb_brgif->pvid);
    offset += pb_compose_brg_allowed_vlan_t_dump(p_pb_brgif->allowed_vlan, (out + offset));
    offset += sal_sprintf(out + offset, "/ingress_filter=%u", p_pb_brgif->ingress_filter);
    offset += sal_sprintf(out + offset, "/egress_filter=%u", p_pb_brgif->egress_filter);
    offset += sal_sprintf(out + offset, "/tpid_type=%u", p_pb_brgif->tpid_type);
    offset += sal_sprintf(out + offset, "/mac_learning_en=%u", p_pb_brgif->mac_learning_en);
    offset += sal_sprintf(out + offset, "/oper_mac_learning_en=%u", p_pb_brgif->oper_mac_learning_en);
    offset += sal_sprintf(out + offset, "/port_security_en=%u", p_pb_brgif->port_security_en);
    offset += sal_sprintf(out + offset, "/violate_mode=%u", p_pb_brgif->violate_mode);
    offset += sal_sprintf(out + offset, "/mlag_is_peer_link=%u", p_pb_brgif->mlag_is_peer_link);
    offset += sal_sprintf(out + offset, "/mlag_is_port_block=%u", p_pb_brgif->mlag_is_port_block);
    offset += sal_sprintf(out + offset, "/mlag_is_group=%u", p_pb_brgif->mlag_is_group);
    offset += sal_sprintf(out + offset, "/max_mac=%u", p_pb_brgif->max_mac);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_ACLQOS_IF */
int32
pb_ds_aclqos_if_to_pb(tbl_interface_key_t *p_if_key, ds_aclqos_if_t *p_aclqos_if, Cdb__DsAclqosIf *p_pb_aclqos_if)
{
    uint32 i = 0;

    p_pb_aclqos_if->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_aclqos_if->parent_if->name, p_if_key->name);

    p_pb_aclqos_if->default_cos = p_aclqos_if->default_cos;
    p_pb_aclqos_if->domain = p_aclqos_if->domain;
    p_pb_aclqos_if->trust = p_aclqos_if->trust;
    p_pb_aclqos_if->replace = p_aclqos_if->replace;
    p_pb_aclqos_if->shape_pir = p_aclqos_if->shape_pir;
    p_pb_aclqos_if->queue_stats_enable = p_aclqos_if->queue_stats_enable;
    p_pb_aclqos_if->input_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->input_policy_map)+1);
    sal_strcpy(p_pb_aclqos_if->input_policy_map, p_aclqos_if->input_policy_map);
    p_pb_aclqos_if->output_policy_map = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->output_policy_map)+1);
    sal_strcpy(p_pb_aclqos_if->output_policy_map, p_aclqos_if->output_policy_map);
    p_pb_aclqos_if->input_policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->input_policer)+1);
    sal_strcpy(p_pb_aclqos_if->input_policer, p_aclqos_if->input_policer);
    p_pb_aclqos_if->output_policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->output_policer)+1);
    sal_strcpy(p_pb_aclqos_if->output_policer, p_aclqos_if->output_policer);
    p_pb_aclqos_if->queue_shape_profile = XCALLOC(MEM_LIB_PROTOBUF, sizeof(char*)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_shape_profile = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_shape_profile[i] = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->queue_shape_profile[i])+1);
        sal_strcpy(p_pb_aclqos_if->queue_shape_profile[i], p_aclqos_if->queue_shape_profile[i]);
    }
    p_pb_aclqos_if->queue_drop_profile = XCALLOC(MEM_LIB_PROTOBUF, sizeof(char*)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_profile = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_profile[i] = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_aclqos_if->queue_drop_profile[i])+1);
        sal_strcpy(p_pb_aclqos_if->queue_drop_profile[i], p_aclqos_if->queue_drop_profile[i]);
    }
    p_pb_aclqos_if->queue_class = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_class = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_class[i] = p_aclqos_if->queue_class[i];
    }
    p_pb_aclqos_if->queue_weight = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_weight = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_weight[i] = p_aclqos_if->queue_weight[i];
    }
    p_pb_aclqos_if->queue_drop_mode = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_mode = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_mode[i] = p_aclqos_if->queue_drop_mode[i];
    }
    p_pb_aclqos_if->queue_ecn_enable = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_ecn_enable = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_ecn_enable[i] = p_aclqos_if->queue_ecn_enable[i];
    }
    p_pb_aclqos_if->queue_transimt_pkt = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_transimt_pkt = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_transimt_pkt[i] = p_aclqos_if->queue_transimt_pkt[i];
    }
    p_pb_aclqos_if->queue_transimt_byte = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_transimt_byte = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_transimt_byte[i] = p_aclqos_if->queue_transimt_byte[i];
    }
    p_pb_aclqos_if->queue_drop_pkt = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_pkt = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_pkt[i] = p_aclqos_if->queue_drop_pkt[i];
    }
    p_pb_aclqos_if->queue_drop_byte = XCALLOC(MEM_LIB_PROTOBUF, sizeof(uint32_t)*GLB_QOS_PORT_QUEUE_NUM);
    p_pb_aclqos_if->n_queue_drop_byte = GLB_QOS_PORT_QUEUE_NUM;
    for (i = 0; i < GLB_QOS_PORT_QUEUE_NUM; i++)
    {
        p_pb_aclqos_if->queue_drop_byte[i] = p_aclqos_if->queue_drop_byte[i];
    }
    p_pb_aclqos_if->queue0_transimt_pkt = p_aclqos_if->queue0_transimt_pkt;
    p_pb_aclqos_if->queue0_transimt_byte = p_aclqos_if->queue0_transimt_byte;
    p_pb_aclqos_if->queue0_drop_pkt = p_aclqos_if->queue0_drop_pkt;
    p_pb_aclqos_if->queue0_drop_byte = p_aclqos_if->queue0_drop_byte;
    p_pb_aclqos_if->queue1_transimt_pkt = p_aclqos_if->queue1_transimt_pkt;
    p_pb_aclqos_if->queue1_transimt_byte = p_aclqos_if->queue1_transimt_byte;
    p_pb_aclqos_if->queue1_drop_pkt = p_aclqos_if->queue1_drop_pkt;
    p_pb_aclqos_if->queue1_drop_byte = p_aclqos_if->queue1_drop_byte;
    p_pb_aclqos_if->queue2_transimt_pkt = p_aclqos_if->queue2_transimt_pkt;
    p_pb_aclqos_if->queue2_transimt_byte = p_aclqos_if->queue2_transimt_byte;
    p_pb_aclqos_if->queue2_drop_pkt = p_aclqos_if->queue2_drop_pkt;
    p_pb_aclqos_if->queue2_drop_byte = p_aclqos_if->queue2_drop_byte;
    p_pb_aclqos_if->queue3_transimt_pkt = p_aclqos_if->queue3_transimt_pkt;
    p_pb_aclqos_if->queue3_transimt_byte = p_aclqos_if->queue3_transimt_byte;
    p_pb_aclqos_if->queue3_drop_pkt = p_aclqos_if->queue3_drop_pkt;
    p_pb_aclqos_if->queue3_drop_byte = p_aclqos_if->queue3_drop_byte;
    p_pb_aclqos_if->queue4_transimt_pkt = p_aclqos_if->queue4_transimt_pkt;
    p_pb_aclqos_if->queue4_transimt_byte = p_aclqos_if->queue4_transimt_byte;
    p_pb_aclqos_if->queue4_drop_pkt = p_aclqos_if->queue4_drop_pkt;
    p_pb_aclqos_if->queue4_drop_byte = p_aclqos_if->queue4_drop_byte;
    p_pb_aclqos_if->queue5_transimt_pkt = p_aclqos_if->queue5_transimt_pkt;
    p_pb_aclqos_if->queue5_transimt_byte = p_aclqos_if->queue5_transimt_byte;
    p_pb_aclqos_if->queue5_drop_pkt = p_aclqos_if->queue5_drop_pkt;
    p_pb_aclqos_if->queue5_drop_byte = p_aclqos_if->queue5_drop_byte;
    p_pb_aclqos_if->queue6_transimt_pkt = p_aclqos_if->queue6_transimt_pkt;
    p_pb_aclqos_if->queue6_transimt_byte = p_aclqos_if->queue6_transimt_byte;
    p_pb_aclqos_if->queue6_drop_pkt = p_aclqos_if->queue6_drop_pkt;
    p_pb_aclqos_if->queue6_drop_byte = p_aclqos_if->queue6_drop_byte;
    p_pb_aclqos_if->queue7_transimt_pkt = p_aclqos_if->queue7_transimt_pkt;
    p_pb_aclqos_if->queue7_transimt_byte = p_aclqos_if->queue7_transimt_byte;
    p_pb_aclqos_if->queue7_drop_pkt = p_aclqos_if->queue7_drop_pkt;
    p_pb_aclqos_if->queue7_drop_byte = p_aclqos_if->queue7_drop_byte;
    p_pb_aclqos_if->phb_enable = p_aclqos_if->phb_enable;

    return PM_E_NONE;
}

int32
pb_ds_aclqos_if_to_pb_free_packed(Cdb__DsAclqosIf *p_pb_aclqos_if)
{
    uint32 i = 0;

    if (p_pb_aclqos_if->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->parent_if->name);
        p_pb_aclqos_if->parent_if->name = NULL;
    }

    if (p_pb_aclqos_if->input_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->input_policy_map);
        p_pb_aclqos_if->input_policy_map = NULL;
    }

    if (p_pb_aclqos_if->output_policy_map)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->output_policy_map);
        p_pb_aclqos_if->output_policy_map = NULL;
    }

    if (p_pb_aclqos_if->input_policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->input_policer);
        p_pb_aclqos_if->input_policer = NULL;
    }

    if (p_pb_aclqos_if->output_policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->output_policer);
        p_pb_aclqos_if->output_policer = NULL;
    }

    if (p_pb_aclqos_if->queue_shape_profile)
    {
        for (i = 0; i < p_pb_aclqos_if->n_queue_shape_profile; i++)
        {
            if (p_pb_aclqos_if->queue_shape_profile[i])
            {
                XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_shape_profile[i]);
                p_pb_aclqos_if->queue_shape_profile[i] = NULL;
            }
        }
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_shape_profile);
        p_pb_aclqos_if->queue_shape_profile = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_profile)
    {
        for (i = 0; i < p_pb_aclqos_if->n_queue_drop_profile; i++)
        {
            if (p_pb_aclqos_if->queue_drop_profile[i])
            {
                XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_profile[i]);
                p_pb_aclqos_if->queue_drop_profile[i] = NULL;
            }
        }
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_profile);
        p_pb_aclqos_if->queue_drop_profile = NULL;
    }

    if (p_pb_aclqos_if->queue_class)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_class);
        p_pb_aclqos_if->queue_class = NULL;
    }

    if (p_pb_aclqos_if->queue_weight)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_weight);
        p_pb_aclqos_if->queue_weight = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_mode)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_mode);
        p_pb_aclqos_if->queue_drop_mode = NULL;
    }

    if (p_pb_aclqos_if->queue_ecn_enable)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_ecn_enable);
        p_pb_aclqos_if->queue_ecn_enable = NULL;
    }

    if (p_pb_aclqos_if->queue_transimt_pkt)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_transimt_pkt);
        p_pb_aclqos_if->queue_transimt_pkt = NULL;
    }

    if (p_pb_aclqos_if->queue_transimt_byte)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_transimt_byte);
        p_pb_aclqos_if->queue_transimt_byte = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_pkt)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_pkt);
        p_pb_aclqos_if->queue_drop_pkt = NULL;
    }

    if (p_pb_aclqos_if->queue_drop_byte)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_aclqos_if->queue_drop_byte);
        p_pb_aclqos_if->queue_drop_byte = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_aclqos_if_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsAclqosIf pb_aclqos_if = CDB__DS_ACLQOS_IF__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_aclqos_if_t *p_aclqos_if = (ds_aclqos_if_t*)p_ds;
    int32 len = 0;

    pb_aclqos_if.parent_if = &pb_if_key;
    pb_ds_aclqos_if_to_pb(p_if_key, p_aclqos_if, &pb_aclqos_if);
    len = cdb__ds_aclqos_if__pack(&pb_aclqos_if, buf);
    pb_ds_aclqos_if_to_pb_free_packed(&pb_aclqos_if);

    return len;
}

int32
pb_ds_aclqos_if_dump(Cdb__DsAclqosIf *p_pb_aclqos_if, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_aclqos_if->parent_if->name);
    offset += sal_sprintf(out + offset, "/default_cos=%u", p_pb_aclqos_if->default_cos);
    offset += sal_sprintf(out + offset, "/domain=%u", p_pb_aclqos_if->domain);
    offset += sal_sprintf(out + offset, "/trust=%u", p_pb_aclqos_if->trust);
    offset += sal_sprintf(out + offset, "/replace=%u", p_pb_aclqos_if->replace);
    offset += sal_sprintf(out + offset, "/shape_pir=%u", p_pb_aclqos_if->shape_pir);
    offset += sal_sprintf(out + offset, "/queue_stats_enable=%u", p_pb_aclqos_if->queue_stats_enable);
    offset += sal_sprintf(out + offset, "/input_policy_map=%s", p_pb_aclqos_if->input_policy_map);
    offset += sal_sprintf(out + offset, "/output_policy_map=%s", p_pb_aclqos_if->output_policy_map);
    offset += sal_sprintf(out + offset, "/input_policer=%s", p_pb_aclqos_if->input_policer);
    offset += sal_sprintf(out + offset, "/output_policer=%s", p_pb_aclqos_if->output_policer);
    offset += sal_sprintf(out + offset, "/queue_shape_profile=");
    offset += pb_string_array_dump(p_pb_aclqos_if->queue_shape_profile, p_pb_aclqos_if->n_queue_shape_profile, (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_profile=");
    offset += pb_string_array_dump(p_pb_aclqos_if->queue_drop_profile, p_pb_aclqos_if->n_queue_drop_profile, (out + offset));
    offset += sal_sprintf(out + offset, "/queue_class=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_class, sizeof(p_pb_aclqos_if->queue_class), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_weight=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_weight, sizeof(p_pb_aclqos_if->queue_weight), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_mode=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_drop_mode, sizeof(p_pb_aclqos_if->queue_drop_mode), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_ecn_enable=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_ecn_enable, sizeof(p_pb_aclqos_if->queue_ecn_enable), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_transimt_pkt=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_transimt_pkt, sizeof(p_pb_aclqos_if->queue_transimt_pkt), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_transimt_byte=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_transimt_byte, sizeof(p_pb_aclqos_if->queue_transimt_byte), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_pkt=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_drop_pkt, sizeof(p_pb_aclqos_if->queue_drop_pkt), (out + offset));
    offset += sal_sprintf(out + offset, "/queue_drop_byte=");
    offset += pb_uint32_array_dump(p_pb_aclqos_if->queue_drop_byte, sizeof(p_pb_aclqos_if->queue_drop_byte), (out + offset));
    offset += sal_sprintf(out + offset, "/queue0_transimt_pkt=%llu", p_pb_aclqos_if->queue0_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue0_transimt_byte=%llu", p_pb_aclqos_if->queue0_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue0_drop_pkt=%llu", p_pb_aclqos_if->queue0_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue0_drop_byte=%llu", p_pb_aclqos_if->queue0_drop_byte);
    offset += sal_sprintf(out + offset, "/queue1_transimt_pkt=%llu", p_pb_aclqos_if->queue1_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue1_transimt_byte=%llu", p_pb_aclqos_if->queue1_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue1_drop_pkt=%llu", p_pb_aclqos_if->queue1_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue1_drop_byte=%llu", p_pb_aclqos_if->queue1_drop_byte);
    offset += sal_sprintf(out + offset, "/queue2_transimt_pkt=%llu", p_pb_aclqos_if->queue2_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue2_transimt_byte=%llu", p_pb_aclqos_if->queue2_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue2_drop_pkt=%llu", p_pb_aclqos_if->queue2_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue2_drop_byte=%llu", p_pb_aclqos_if->queue2_drop_byte);
    offset += sal_sprintf(out + offset, "/queue3_transimt_pkt=%llu", p_pb_aclqos_if->queue3_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue3_transimt_byte=%llu", p_pb_aclqos_if->queue3_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue3_drop_pkt=%llu", p_pb_aclqos_if->queue3_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue3_drop_byte=%llu", p_pb_aclqos_if->queue3_drop_byte);
    offset += sal_sprintf(out + offset, "/queue4_transimt_pkt=%llu", p_pb_aclqos_if->queue4_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue4_transimt_byte=%llu", p_pb_aclqos_if->queue4_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue4_drop_pkt=%llu", p_pb_aclqos_if->queue4_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue4_drop_byte=%llu", p_pb_aclqos_if->queue4_drop_byte);
    offset += sal_sprintf(out + offset, "/queue5_transimt_pkt=%llu", p_pb_aclqos_if->queue5_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue5_transimt_byte=%llu", p_pb_aclqos_if->queue5_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue5_drop_pkt=%llu", p_pb_aclqos_if->queue5_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue5_drop_byte=%llu", p_pb_aclqos_if->queue5_drop_byte);
    offset += sal_sprintf(out + offset, "/queue6_transimt_pkt=%llu", p_pb_aclqos_if->queue6_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue6_transimt_byte=%llu", p_pb_aclqos_if->queue6_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue6_drop_pkt=%llu", p_pb_aclqos_if->queue6_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue6_drop_byte=%llu", p_pb_aclqos_if->queue6_drop_byte);
    offset += sal_sprintf(out + offset, "/queue7_transimt_pkt=%llu", p_pb_aclqos_if->queue7_transimt_pkt);
    offset += sal_sprintf(out + offset, "/queue7_transimt_byte=%llu", p_pb_aclqos_if->queue7_transimt_byte);
    offset += sal_sprintf(out + offset, "/queue7_drop_pkt=%llu", p_pb_aclqos_if->queue7_drop_pkt);
    offset += sal_sprintf(out + offset, "/queue7_drop_byte=%llu", p_pb_aclqos_if->queue7_drop_byte);
    offset += sal_sprintf(out + offset, "/phb_enable=%u", p_pb_aclqos_if->phb_enable);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_LAG */
int32
pb_ds_lag_to_pb(tbl_interface_key_t *p_if_key, ds_lag_t *p_lag, Cdb__DsLag *p_pb_lag)
{
    p_pb_lag->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_lag->parent_if->name, p_if_key->name);

    p_pb_lag->mode = p_lag->mode;
    p_pb_lag->lag_id = p_lag->lag_id;
    p_pb_lag->oper_state = p_lag->oper_state;
    p_pb_lag->bundle_ports_count = p_lag->bundle_ports_count;
    p_pb_lag->load_balance_mode = p_lag->load_balance_mode;

    return PM_E_NONE;
}

int32
pb_ds_lag_to_pb_free_packed(Cdb__DsLag *p_pb_lag)
{
    if (p_pb_lag->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lag->parent_if->name);
        p_pb_lag->parent_if->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_lag_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsLag pb_lag = CDB__DS_LAG__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_lag_t *p_lag = (ds_lag_t*)p_ds;
    int32 len = 0;

    pb_lag.parent_if = &pb_if_key;
    pb_ds_lag_to_pb(p_if_key, p_lag, &pb_lag);
    len = cdb__ds_lag__pack(&pb_lag, buf);
    pb_ds_lag_to_pb_free_packed(&pb_lag);

    return len;
}

int32
pb_ds_lag_dump(Cdb__DsLag *p_pb_lag, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_lag->parent_if->name);
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_lag->mode);
    offset += sal_sprintf(out + offset, "/lag_id=%u", p_pb_lag->lag_id);
    offset += sal_sprintf(out + offset, "/oper_state=%u", p_pb_lag->oper_state);
    offset += sal_sprintf(out + offset, "/bundle_ports_count=%d", p_pb_lag->bundle_ports_count);
    offset += sal_sprintf(out + offset, "/load_balance_mode=%u", p_pb_lag->load_balance_mode);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_LACP */
int32
pb_ds_lacp_to_pb(tbl_interface_key_t *p_if_key, ds_lacp_t *p_lacp, Cdb__DsLacp *p_pb_lacp)
{
    p_pb_lacp->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_lacp->parent_if->name, p_if_key->name);

    p_pb_lacp->actor_port_priority = p_lacp->actor_port_priority;
    p_pb_lacp->actor_oper_port_key = p_lacp->actor_oper_port_key;
    p_pb_lacp->actor_port_number = p_lacp->actor_port_number;
    p_pb_lacp->short_timeout = p_lacp->short_timeout;
    p_pb_lacp->actor_oper_port_state = p_lacp->actor_oper_port_state;
    p_pb_lacp->partner_admin_system_priority = p_lacp->partner_admin_system_priority;
    pb_compose_mac_addr_t_to_pb(p_lacp->partner_admin_system, p_pb_lacp->partner_admin_system);
    p_pb_lacp->partner_admin_key = p_lacp->partner_admin_key;
    p_pb_lacp->partner_admin_port_priority = p_lacp->partner_admin_port_priority;
    p_pb_lacp->partner_admin_port_number = p_lacp->partner_admin_port_number;
    p_pb_lacp->partner_admin_port_state = p_lacp->partner_admin_port_state;
    p_pb_lacp->partner_oper_system_priority = p_lacp->partner_oper_system_priority;
    pb_compose_mac_addr_t_to_pb(p_lacp->partner_oper_system, p_pb_lacp->partner_oper_system);
    p_pb_lacp->partner_oper_key = p_lacp->partner_oper_key;
    p_pb_lacp->partner_oper_port_priority = p_lacp->partner_oper_port_priority;
    p_pb_lacp->partner_oper_port_number = p_lacp->partner_oper_port_number;
    p_pb_lacp->partner_oper_port_state = p_lacp->partner_oper_port_state;
    p_pb_lacp->tx_lacp_count = p_lacp->tx_lacp_count;
    p_pb_lacp->tx_error_count = p_lacp->tx_error_count;
    p_pb_lacp->rx_lacp_count = p_lacp->rx_lacp_count;
    p_pb_lacp->rx_error_count = p_lacp->rx_error_count;
    p_pb_lacp->mlag_id = p_lacp->mlag_id;
    p_pb_lacp->ntt = p_lacp->ntt;
    p_pb_lacp->lacp_enabled = p_lacp->lacp_enabled;
    p_pb_lacp->ready_n = p_lacp->ready_n;
    p_pb_lacp->port_moved = p_lacp->port_moved;
    p_pb_lacp->periodic_tx_state = p_lacp->periodic_tx_state;
    p_pb_lacp->receive_state = p_lacp->receive_state;
    p_pb_lacp->mux_state = p_lacp->mux_state;
    p_pb_lacp->selected = p_lacp->selected;

    return PM_E_NONE;
}

int32
pb_ds_lacp_to_pb_free_packed(Cdb__DsLacp *p_pb_lacp)
{
    if (p_pb_lacp->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_lacp->parent_if->name);
        p_pb_lacp->parent_if->name = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_lacp->partner_admin_system);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_lacp->partner_oper_system);
    return PM_E_NONE;
}

int32
pb_ds_lacp_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsLacp pb_lacp = CDB__DS_LACP__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_lacp_t *p_lacp = (ds_lacp_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeMacAddrT partner_admin_system = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT partner_oper_system = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_lacp.partner_admin_system = &partner_admin_system;
    pb_lacp.partner_oper_system = &partner_oper_system;
    pb_lacp.parent_if = &pb_if_key;
    pb_ds_lacp_to_pb(p_if_key, p_lacp, &pb_lacp);
    len = cdb__ds_lacp__pack(&pb_lacp, buf);
    pb_ds_lacp_to_pb_free_packed(&pb_lacp);

    return len;
}

int32
pb_ds_lacp_dump(Cdb__DsLacp *p_pb_lacp, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_lacp->parent_if->name);
    offset += sal_sprintf(out + offset, "/actor_port_priority=%u", p_pb_lacp->actor_port_priority);
    offset += sal_sprintf(out + offset, "/actor_oper_port_key=%u", p_pb_lacp->actor_oper_port_key);
    offset += sal_sprintf(out + offset, "/actor_port_number=%u", p_pb_lacp->actor_port_number);
    offset += sal_sprintf(out + offset, "/short_timeout=%u", p_pb_lacp->short_timeout);
    offset += sal_sprintf(out + offset, "/actor_oper_port_state=%u", p_pb_lacp->actor_oper_port_state);
    offset += sal_sprintf(out + offset, "/partner_admin_system_priority=%u", p_pb_lacp->partner_admin_system_priority);
    offset += pb_compose_mac_addr_t_dump(p_pb_lacp->partner_admin_system, (out + offset));
    offset += sal_sprintf(out + offset, "/partner_admin_key=%u", p_pb_lacp->partner_admin_key);
    offset += sal_sprintf(out + offset, "/partner_admin_port_priority=%u", p_pb_lacp->partner_admin_port_priority);
    offset += sal_sprintf(out + offset, "/partner_admin_port_number=%u", p_pb_lacp->partner_admin_port_number);
    offset += sal_sprintf(out + offset, "/partner_admin_port_state=%u", p_pb_lacp->partner_admin_port_state);
    offset += sal_sprintf(out + offset, "/partner_oper_system_priority=%u", p_pb_lacp->partner_oper_system_priority);
    offset += pb_compose_mac_addr_t_dump(p_pb_lacp->partner_oper_system, (out + offset));
    offset += sal_sprintf(out + offset, "/partner_oper_key=%u", p_pb_lacp->partner_oper_key);
    offset += sal_sprintf(out + offset, "/partner_oper_port_priority=%u", p_pb_lacp->partner_oper_port_priority);
    offset += sal_sprintf(out + offset, "/partner_oper_port_number=%u", p_pb_lacp->partner_oper_port_number);
    offset += sal_sprintf(out + offset, "/partner_oper_port_state=%u", p_pb_lacp->partner_oper_port_state);
    offset += sal_sprintf(out + offset, "/tx_lacp_count=%u", p_pb_lacp->tx_lacp_count);
    offset += sal_sprintf(out + offset, "/tx_error_count=%u", p_pb_lacp->tx_error_count);
    offset += sal_sprintf(out + offset, "/rx_lacp_count=%u", p_pb_lacp->rx_lacp_count);
    offset += sal_sprintf(out + offset, "/rx_error_count=%u", p_pb_lacp->rx_error_count);
    offset += sal_sprintf(out + offset, "/mlag_id=%u", p_pb_lacp->mlag_id);
    offset += sal_sprintf(out + offset, "/ntt=%u", p_pb_lacp->ntt);
    offset += sal_sprintf(out + offset, "/lacp_enabled=%u", p_pb_lacp->lacp_enabled);
    offset += sal_sprintf(out + offset, "/ready_n=%u", p_pb_lacp->ready_n);
    offset += sal_sprintf(out + offset, "/port_moved=%u", p_pb_lacp->port_moved);
    offset += sal_sprintf(out + offset, "/periodic_tx_state=%u", p_pb_lacp->periodic_tx_state);
    offset += sal_sprintf(out + offset, "/receive_state=%u", p_pb_lacp->receive_state);
    offset += sal_sprintf(out + offset, "/mux_state=%u", p_pb_lacp->mux_state);
    offset += sal_sprintf(out + offset, "/selected=%u", p_pb_lacp->selected);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PMAP DS_PMAP_CLASS */
int32
pb_ds_pmap_class_to_pb(tbl_pmap_key_t *p_pmap_key, ds_pmap_class_t *p_pmap_class, Cdb__DsPmapClass *p_pb_pmap_class)
{
    p_pb_pmap_class->parent_pmap->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_key->name)+1);
    sal_strcpy(p_pb_pmap_class->parent_pmap->name, p_pmap_key->name);

    p_pb_pmap_class->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_class->key.name)+1);
    sal_strcpy(p_pb_pmap_class->key->name, p_pmap_class->key.name);

    p_pb_pmap_class->flags_priority = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_PRIORITY) ? TRUE : FALSE;
    p_pb_pmap_class->flags_color = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_COLOR) ? TRUE : FALSE;
    p_pb_pmap_class->flags_trust = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_TRUST) ? TRUE : FALSE;
    p_pb_pmap_class->flags_redirect = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_REDIRECT) ? TRUE : FALSE;
    p_pb_pmap_class->flags_tap = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_TAP) ? TRUE : FALSE;
    p_pb_pmap_class->flags_monitor = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_MONITOR) ? TRUE : FALSE;
    p_pb_pmap_class->flags_stats = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_STATS) ? TRUE : FALSE;
    p_pb_pmap_class->flags_domain = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_DOMAIN) ? TRUE : FALSE;
    p_pb_pmap_class->flags_cos = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_COS) ? TRUE : FALSE;
    p_pb_pmap_class->flags_dscp = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_DSCP) ? TRUE : FALSE;
    p_pb_pmap_class->flags_ctag_cos = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_CTAG_COS) ? TRUE : FALSE;
    p_pb_pmap_class->flags_stag_cos = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_STAG_COS) ? TRUE : FALSE;
    p_pb_pmap_class->flags_policer = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_POLICER) ? TRUE : FALSE;
    p_pb_pmap_class->flags_aggreate_policer = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_AGGREGATE_POLICER) ? TRUE : FALSE;
    p_pb_pmap_class->flags_phb = GLB_FLAG_ISSET(p_pmap_class->flags, GLB_PMAP_CLASS_PHB) ? TRUE : FALSE;
    p_pb_pmap_class->trust = p_pmap_class->trust;
    p_pb_pmap_class->priority = p_pmap_class->priority;
    p_pb_pmap_class->color = p_pmap_class->color;
    p_pb_pmap_class->domain = p_pmap_class->domain;
    p_pb_pmap_class->dscp = p_pmap_class->dscp;
    p_pb_pmap_class->cos = p_pmap_class->cos;
    p_pb_pmap_class->monitor_session = p_pmap_class->monitor_session;
    p_pb_pmap_class->phb = p_pmap_class->phb;
    p_pb_pmap_class->redirect_ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_class->redirect_ifname)+1);
    sal_strcpy(p_pb_pmap_class->redirect_ifname, p_pmap_class->redirect_ifname);
    p_pb_pmap_class->tapname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_class->tapname)+1);
    sal_strcpy(p_pb_pmap_class->tapname, p_pmap_class->tapname);
    p_pb_pmap_class->tapvlan = p_pmap_class->tapvlan;
    p_pb_pmap_class->policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_class->policer)+1);
    sal_strcpy(p_pb_pmap_class->policer, p_pmap_class->policer);
    p_pb_pmap_class->aggregate_policer = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_pmap_class->aggregate_policer)+1);
    sal_strcpy(p_pb_pmap_class->aggregate_policer, p_pmap_class->aggregate_policer);

    return PM_E_NONE;
}

int32
pb_ds_pmap_class_to_pb_free_packed(Cdb__DsPmapClass *p_pb_pmap_class)
{
    if (p_pb_pmap_class->parent_pmap->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->parent_pmap->name);
        p_pb_pmap_class->parent_pmap->name = NULL;
    }

    if (p_pb_pmap_class->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->key->name);
        p_pb_pmap_class->key->name = NULL;
    }

    if (p_pb_pmap_class->redirect_ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->redirect_ifname);
        p_pb_pmap_class->redirect_ifname = NULL;
    }

    if (p_pb_pmap_class->tapname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->tapname);
        p_pb_pmap_class->tapname = NULL;
    }

    if (p_pb_pmap_class->policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->policer);
        p_pb_pmap_class->policer = NULL;
    }

    if (p_pb_pmap_class->aggregate_policer)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_pmap_class->aggregate_policer);
        p_pb_pmap_class->aggregate_policer = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_pmap_class_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPmapKey pb_pmap_key = CDB__TBL_PMAP_KEY__INIT;
    Cdb__DsPmapClassKey pb_pmap_class_key = CDB__DS_PMAP_CLASS_KEY__INIT;
    Cdb__DsPmapClass pb_pmap_class = CDB__DS_PMAP_CLASS__INIT;
    tbl_pmap_key_t *p_pmap_key = (tbl_pmap_key_t*)p_tbl;
    ds_pmap_class_t *p_pmap_class = (ds_pmap_class_t*)p_ds;
    int32 len = 0;

    pb_pmap_class.key = &pb_pmap_class_key;
    pb_pmap_class.parent_pmap = &pb_pmap_key;
    pb_ds_pmap_class_to_pb(p_pmap_key, p_pmap_class, &pb_pmap_class);
    len = cdb__ds_pmap_class__pack(&pb_pmap_class, buf);
    pb_ds_pmap_class_to_pb_free_packed(&pb_pmap_class);

    return len;
}

int32
pb_ds_pmap_class_dump(Cdb__DsPmapClass *p_pb_pmap_class, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_pmap->name=%s", p_pb_pmap_class->parent_pmap->name);
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_pmap_class->key->name);
    offset += sal_sprintf(out + offset, "/flags_priority=%u", p_pb_pmap_class->flags_priority);
    offset += sal_sprintf(out + offset, "/flags_color=%u", p_pb_pmap_class->flags_color);
    offset += sal_sprintf(out + offset, "/flags_trust=%u", p_pb_pmap_class->flags_trust);
    offset += sal_sprintf(out + offset, "/flags_redirect=%u", p_pb_pmap_class->flags_redirect);
    offset += sal_sprintf(out + offset, "/flags_tap=%u", p_pb_pmap_class->flags_tap);
    offset += sal_sprintf(out + offset, "/flags_monitor=%u", p_pb_pmap_class->flags_monitor);
    offset += sal_sprintf(out + offset, "/flags_stats=%u", p_pb_pmap_class->flags_stats);
    offset += sal_sprintf(out + offset, "/flags_domain=%u", p_pb_pmap_class->flags_domain);
    offset += sal_sprintf(out + offset, "/flags_cos=%u", p_pb_pmap_class->flags_cos);
    offset += sal_sprintf(out + offset, "/flags_dscp=%u", p_pb_pmap_class->flags_dscp);
    offset += sal_sprintf(out + offset, "/flags_ctag_cos=%u", p_pb_pmap_class->flags_ctag_cos);
    offset += sal_sprintf(out + offset, "/flags_stag_cos=%u", p_pb_pmap_class->flags_stag_cos);
    offset += sal_sprintf(out + offset, "/flags_policer=%u", p_pb_pmap_class->flags_policer);
    offset += sal_sprintf(out + offset, "/flags_aggreate_policer=%u", p_pb_pmap_class->flags_aggreate_policer);
    offset += sal_sprintf(out + offset, "/flags_phb=%u", p_pb_pmap_class->flags_phb);
    offset += sal_sprintf(out + offset, "/trust=%u", p_pb_pmap_class->trust);
    offset += sal_sprintf(out + offset, "/priority=%u", p_pb_pmap_class->priority);
    offset += sal_sprintf(out + offset, "/color=%u", p_pb_pmap_class->color);
    offset += sal_sprintf(out + offset, "/domain=%u", p_pb_pmap_class->domain);
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_pmap_class->dscp);
    offset += sal_sprintf(out + offset, "/cos=%u", p_pb_pmap_class->cos);
    offset += sal_sprintf(out + offset, "/monitor_session=%u", p_pb_pmap_class->monitor_session);
    offset += sal_sprintf(out + offset, "/phb=%u", p_pb_pmap_class->phb);
    offset += sal_sprintf(out + offset, "/redirect_ifname=%s", p_pb_pmap_class->redirect_ifname);
    offset += sal_sprintf(out + offset, "/tapname=%s", p_pb_pmap_class->tapname);
    offset += sal_sprintf(out + offset, "/tapvlan=%u", p_pb_pmap_class->tapvlan);
    offset += sal_sprintf(out + offset, "/policer=%s", p_pb_pmap_class->policer);
    offset += sal_sprintf(out + offset, "/aggregate_policer=%s", p_pb_pmap_class->aggregate_policer);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL DS_MAC_ACE */
int32
pb_ds_mac_ace_to_pb(tbl_acl_key_t *p_acl_key, ds_mac_ace_t *p_mac_ace, Cdb__DsMacAce *p_pb_mac_ace)
{
    p_pb_mac_ace->parent_acl->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_key->name)+1);
    sal_strcpy(p_pb_mac_ace->parent_acl->name, p_acl_key->name);

    p_pb_mac_ace->key->seqno = p_mac_ace->key.seqno;

    p_pb_mac_ace->time_range = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_mac_ace->time_range)+1);
    sal_strcpy(p_pb_mac_ace->time_range, p_mac_ace->time_range);
    pb_compose_mac_addr_t_to_pb(p_mac_ace->mac_sa, p_pb_mac_ace->mac_sa);
    pb_compose_mac_addr_t_to_pb(p_mac_ace->mac_sa_mask, p_pb_mac_ace->mac_sa_mask);
    pb_compose_mac_addr_t_to_pb(p_mac_ace->mac_da, p_pb_mac_ace->mac_da);
    pb_compose_mac_addr_t_to_pb(p_mac_ace->mac_da_mask, p_pb_mac_ace->mac_da_mask);
    p_pb_mac_ace->vlan = p_mac_ace->vlan;
    p_pb_mac_ace->inner_vlan = p_mac_ace->inner_vlan;
    p_pb_mac_ace->cos = p_mac_ace->cos;
    p_pb_mac_ace->inner_cos = p_mac_ace->inner_cos;
    p_pb_mac_ace->ether_type = p_mac_ace->ether_type;
    p_pb_mac_ace->ether_type_mask = p_mac_ace->ether_type_mask;
    p_pb_mac_ace->arp_op_code = p_mac_ace->arp_op_code;
    p_pb_mac_ace->apply_cnt = p_mac_ace->apply_cnt;
    pb_compose_addr_ipv4_t_to_pb(&p_mac_ace->sender_ip, p_pb_mac_ace->sender_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_mac_ace->sender_ip_mask, p_pb_mac_ace->sender_ip_mask);
    pb_compose_addr_ipv4_t_to_pb(&p_mac_ace->target_ip, p_pb_mac_ace->target_ip);
    pb_compose_addr_ipv4_t_to_pb(&p_mac_ace->target_ip_mask, p_pb_mac_ace->target_ip_mask);
    pb_compose_glb_stats_t_to_pb(&p_mac_ace->stats, p_pb_mac_ace->stats);

    return PM_E_NONE;
}

int32
pb_ds_mac_ace_to_pb_free_packed(Cdb__DsMacAce *p_pb_mac_ace)
{
    if (p_pb_mac_ace->parent_acl->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mac_ace->parent_acl->name);
        p_pb_mac_ace->parent_acl->name = NULL;
    }

    if (p_pb_mac_ace->time_range)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mac_ace->time_range);
        p_pb_mac_ace->time_range = NULL;
    }

    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mac_ace->mac_sa);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mac_ace->mac_sa_mask);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mac_ace->mac_da);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_mac_ace->mac_da_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_mac_ace->sender_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_mac_ace->sender_ip_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_mac_ace->target_ip);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_mac_ace->target_ip_mask);
    pb_compose_glb_stats_t_to_pb_free_packed(p_pb_mac_ace->stats);
    return PM_E_NONE;
}

int32
pb_ds_mac_ace_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclKey pb_acl_key = CDB__TBL_ACL_KEY__INIT;
    Cdb__DsMacAceKey pb_mac_ace_key = CDB__DS_MAC_ACE_KEY__INIT;
    Cdb__DsMacAce pb_mac_ace = CDB__DS_MAC_ACE__INIT;
    tbl_acl_key_t *p_acl_key = (tbl_acl_key_t*)p_tbl;
    ds_mac_ace_t *p_mac_ace = (ds_mac_ace_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_sa = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT mac_sa_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT mac_da = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeMacAddrT mac_da_mask = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeAddrIpv4T sender_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T sender_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T target_ip = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T target_ip_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeGlbStatsT stats = CDB__COMPOSE_GLB_STATS_T__INIT;

    pb_mac_ace.key = &pb_mac_ace_key;
    pb_mac_ace.mac_sa = &mac_sa;
    pb_mac_ace.mac_sa_mask = &mac_sa_mask;
    pb_mac_ace.mac_da = &mac_da;
    pb_mac_ace.mac_da_mask = &mac_da_mask;
    pb_mac_ace.sender_ip = &sender_ip;
    pb_mac_ace.sender_ip_mask = &sender_ip_mask;
    pb_mac_ace.target_ip = &target_ip;
    pb_mac_ace.target_ip_mask = &target_ip_mask;
    pb_mac_ace.stats = &stats;
    pb_mac_ace.parent_acl = &pb_acl_key;
    pb_ds_mac_ace_to_pb(p_acl_key, p_mac_ace, &pb_mac_ace);
    len = cdb__ds_mac_ace__pack(&pb_mac_ace, buf);
    pb_ds_mac_ace_to_pb_free_packed(&pb_mac_ace);

    return len;
}

int32
pb_ds_mac_ace_dump(Cdb__DsMacAce *p_pb_mac_ace, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_acl->name=%s", p_pb_mac_ace->parent_acl->name);
    offset += sal_sprintf(out + offset, "/key->seqno=%u", p_pb_mac_ace->key->seqno);
    offset += sal_sprintf(out + offset, "/time_range=%s", p_pb_mac_ace->time_range);
    offset += pb_compose_mac_addr_t_dump(p_pb_mac_ace->mac_sa, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mac_ace->mac_sa_mask, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mac_ace->mac_da, (out + offset));
    offset += pb_compose_mac_addr_t_dump(p_pb_mac_ace->mac_da_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/vlan=%u", p_pb_mac_ace->vlan);
    offset += sal_sprintf(out + offset, "/inner_vlan=%u", p_pb_mac_ace->inner_vlan);
    offset += sal_sprintf(out + offset, "/cos=%u", p_pb_mac_ace->cos);
    offset += sal_sprintf(out + offset, "/inner_cos=%u", p_pb_mac_ace->inner_cos);
    offset += sal_sprintf(out + offset, "/ether_type=%u", p_pb_mac_ace->ether_type);
    offset += sal_sprintf(out + offset, "/ether_type_mask=%u", p_pb_mac_ace->ether_type_mask);
    offset += sal_sprintf(out + offset, "/arp_op_code=%u", p_pb_mac_ace->arp_op_code);
    offset += sal_sprintf(out + offset, "/apply_cnt=%u", p_pb_mac_ace->apply_cnt);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_mac_ace->sender_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_mac_ace->sender_ip_mask, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_mac_ace->target_ip, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_mac_ace->target_ip_mask, (out + offset));
    offset += pb_compose_glb_stats_t_dump(p_pb_mac_ace->stats, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ACL DS_IP_ACE */
int32
pb_ds_ip_ace_to_pb(tbl_acl_key_t *p_acl_key, ds_ip_ace_t *p_ip_ace, Cdb__DsIpAce *p_pb_ip_ace)
{
    p_pb_ip_ace->parent_acl->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_acl_key->name)+1);
    sal_strcpy(p_pb_ip_ace->parent_acl->name, p_acl_key->name);

    p_pb_ip_ace->key->seqno = p_ip_ace->key.seqno;

    p_pb_ip_ace->time_range = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ip_ace->time_range)+1);
    sal_strcpy(p_pb_ip_ace->time_range, p_ip_ace->time_range);
    pb_compose_addr_ipv4_t_to_pb(&p_ip_ace->ip_sa, p_pb_ip_ace->ip_sa);
    pb_compose_addr_ipv4_t_to_pb(&p_ip_ace->ip_sa_mask, p_pb_ip_ace->ip_sa_mask);
    pb_compose_addr_ipv4_t_to_pb(&p_ip_ace->ip_da, p_pb_ip_ace->ip_da);
    pb_compose_addr_ipv4_t_to_pb(&p_ip_ace->ip_da_mask, p_pb_ip_ace->ip_da_mask);
    p_pb_ip_ace->l4_protocol = p_ip_ace->l4_protocol;
    pb_compose_glb_flow_l4_port_t_to_pb(&p_ip_ace->l4_src_port, p_pb_ip_ace->l4_src_port);
    pb_compose_glb_flow_l4_port_t_to_pb(&p_ip_ace->l4_dst_port, p_pb_ip_ace->l4_dst_port);
    p_pb_ip_ace->ip_frag = p_ip_ace->ip_frag;
    pb_compose_glb_flow_tcp_flag_t_to_pb(&p_ip_ace->tcp_flag, p_pb_ip_ace->tcp_flag);
    p_pb_ip_ace->ip_options = p_ip_ace->ip_options;
    p_pb_ip_ace->dscp = p_ip_ace->dscp;
    p_pb_ip_ace->prec = p_ip_ace->prec;
    p_pb_ip_ace->icmp_code = p_ip_ace->icmp_code;
    p_pb_ip_ace->icmp_type = p_ip_ace->icmp_type;
    p_pb_ip_ace->igmp_type = p_ip_ace->igmp_type;
    p_pb_ip_ace->apply_cnt = p_ip_ace->apply_cnt;
    pb_compose_glb_stats_t_to_pb(&p_ip_ace->stats, p_pb_ip_ace->stats);

    return PM_E_NONE;
}

int32
pb_ds_ip_ace_to_pb_free_packed(Cdb__DsIpAce *p_pb_ip_ace)
{
    if (p_pb_ip_ace->parent_acl->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ip_ace->parent_acl->name);
        p_pb_ip_ace->parent_acl->name = NULL;
    }

    if (p_pb_ip_ace->time_range)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ip_ace->time_range);
        p_pb_ip_ace->time_range = NULL;
    }

    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ip_ace->ip_sa);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ip_ace->ip_sa_mask);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ip_ace->ip_da);
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_ip_ace->ip_da_mask);
    pb_compose_glb_flow_l4_port_t_to_pb_free_packed(p_pb_ip_ace->l4_src_port);
    pb_compose_glb_flow_l4_port_t_to_pb_free_packed(p_pb_ip_ace->l4_dst_port);
    pb_compose_glb_flow_tcp_flag_t_to_pb_free_packed(p_pb_ip_ace->tcp_flag);
    pb_compose_glb_stats_t_to_pb_free_packed(p_pb_ip_ace->stats);
    return PM_E_NONE;
}

int32
pb_ds_ip_ace_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblAclKey pb_acl_key = CDB__TBL_ACL_KEY__INIT;
    Cdb__DsIpAceKey pb_ip_ace_key = CDB__DS_IP_ACE_KEY__INIT;
    Cdb__DsIpAce pb_ip_ace = CDB__DS_IP_ACE__INIT;
    tbl_acl_key_t *p_acl_key = (tbl_acl_key_t*)p_tbl;
    ds_ip_ace_t *p_ip_ace = (ds_ip_ace_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeAddrIpv4T ip_sa = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T ip_sa_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T ip_da = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeAddrIpv4T ip_da_mask = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__ComposeGlbFlowL4PortT l4_src_port = CDB__COMPOSE_GLB_FLOW_L4_PORT_T__INIT;
    Cdb__ComposeGlbFlowL4PortT l4_dst_port = CDB__COMPOSE_GLB_FLOW_L4_PORT_T__INIT;
    Cdb__ComposeGlbFlowTcpFlagT tcp_flag = CDB__COMPOSE_GLB_FLOW_TCP_FLAG_T__INIT;
    Cdb__ComposeGlbStatsT stats = CDB__COMPOSE_GLB_STATS_T__INIT;

    pb_ip_ace.key = &pb_ip_ace_key;
    pb_ip_ace.ip_sa = &ip_sa;
    pb_ip_ace.ip_sa_mask = &ip_sa_mask;
    pb_ip_ace.ip_da = &ip_da;
    pb_ip_ace.ip_da_mask = &ip_da_mask;
    pb_ip_ace.l4_src_port = &l4_src_port;
    pb_ip_ace.l4_dst_port = &l4_dst_port;
    pb_ip_ace.tcp_flag = &tcp_flag;
    pb_ip_ace.stats = &stats;
    pb_ip_ace.parent_acl = &pb_acl_key;
    pb_ds_ip_ace_to_pb(p_acl_key, p_ip_ace, &pb_ip_ace);
    len = cdb__ds_ip_ace__pack(&pb_ip_ace, buf);
    pb_ds_ip_ace_to_pb_free_packed(&pb_ip_ace);

    return len;
}

int32
pb_ds_ip_ace_dump(Cdb__DsIpAce *p_pb_ip_ace, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_acl->name=%s", p_pb_ip_ace->parent_acl->name);
    offset += sal_sprintf(out + offset, "/key->seqno=%u", p_pb_ip_ace->key->seqno);
    offset += sal_sprintf(out + offset, "/time_range=%s", p_pb_ip_ace->time_range);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ip_ace->ip_sa, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ip_ace->ip_sa_mask, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ip_ace->ip_da, (out + offset));
    offset += pb_compose_addr_ipv4_t_dump(p_pb_ip_ace->ip_da_mask, (out + offset));
    offset += sal_sprintf(out + offset, "/l4_protocol=%u", p_pb_ip_ace->l4_protocol);
    offset += pb_compose_glb_flow_l4_port_t_dump(p_pb_ip_ace->l4_src_port, (out + offset));
    offset += pb_compose_glb_flow_l4_port_t_dump(p_pb_ip_ace->l4_dst_port, (out + offset));
    offset += sal_sprintf(out + offset, "/ip_frag=%u", p_pb_ip_ace->ip_frag);
    offset += pb_compose_glb_flow_tcp_flag_t_dump(p_pb_ip_ace->tcp_flag, (out + offset));
    offset += sal_sprintf(out + offset, "/ip_options=%u", p_pb_ip_ace->ip_options);
    offset += sal_sprintf(out + offset, "/dscp=%u", p_pb_ip_ace->dscp);
    offset += sal_sprintf(out + offset, "/prec=%u", p_pb_ip_ace->prec);
    offset += sal_sprintf(out + offset, "/icmp_code=%u", p_pb_ip_ace->icmp_code);
    offset += sal_sprintf(out + offset, "/icmp_type=%u", p_pb_ip_ace->icmp_type);
    offset += sal_sprintf(out + offset, "/igmp_type=%u", p_pb_ip_ace->igmp_type);
    offset += sal_sprintf(out + offset, "/apply_cnt=%u", p_pb_ip_ace->apply_cnt);
    offset += pb_compose_glb_stats_t_dump(p_pb_ip_ace->stats, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ROUTE_IF DS_CONNECTED */
int32
pb_ds_connected_to_pb(tbl_route_if_key_t *p_rtif_key, ds_connected_t *p_connect, Cdb__DsConnected *p_pb_connect)
{
    p_pb_connect->parent_rtif->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif_key->name)+1);
    sal_strcpy(p_pb_connect->parent_rtif->name, p_rtif_key->name);

    pb_compose_prefix_t_to_pb(&p_connect->key.address, p_pb_connect->key->address);

    pb_compose_prefix_t_to_pb(&p_connect->destination, p_pb_connect->destination);
    p_pb_connect->flags_secondary = GLB_FLAG_ISSET(p_connect->flags, RT_IF_ADDR_SECONDARY) ? TRUE : FALSE;
    p_pb_connect->flags_anycast = GLB_FLAG_ISSET(p_connect->flags, RT_IF_ADDR_ANYCAST) ? TRUE : FALSE;
    p_pb_connect->flags_virtual = GLB_FLAG_ISSET(p_connect->flags, RT_IF_ADDR_VIRTUAL) ? TRUE : FALSE;
    p_pb_connect->flags_duplicate = GLB_FLAG_ISSET(p_connect->flags, RT_IF_ADDR_DUPLICATE) ? TRUE : FALSE;
    p_pb_connect->installed = p_connect->installed;

    return PM_E_NONE;
}

int32
pb_ds_connected_to_pb_free_packed(Cdb__DsConnected *p_pb_connect)
{
    if (p_pb_connect->parent_rtif->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_connect->parent_rtif->name);
        p_pb_connect->parent_rtif->name = NULL;
    }

    pb_compose_prefix_t_to_pb_free_packed(p_pb_connect->key->address);
    pb_compose_prefix_t_to_pb_free_packed(p_pb_connect->destination);
    return PM_E_NONE;
}

int32
pb_ds_connected_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRouteIfKey pb_rtif_key = CDB__TBL_ROUTE_IF_KEY__INIT;
    Cdb__ComposePrefixT address = CDB__COMPOSE_PREFIX_T__INIT;
    Cdb__DsConnectedKey pb_connect_key = CDB__DS_CONNECTED_KEY__INIT;
    Cdb__DsConnected pb_connect = CDB__DS_CONNECTED__INIT;
    tbl_route_if_key_t *p_rtif_key = (tbl_route_if_key_t*)p_tbl;
    ds_connected_t *p_connect = (ds_connected_t*)p_ds;
    int32 len = 0;
    Cdb__ComposePrefixT destination = CDB__COMPOSE_PREFIX_T__INIT;

    pb_connect_key.address = &address;
    pb_connect.key = &pb_connect_key;
    pb_connect.destination = &destination;
    pb_connect.parent_rtif = &pb_rtif_key;
    pb_ds_connected_to_pb(p_rtif_key, p_connect, &pb_connect);
    len = cdb__ds_connected__pack(&pb_connect, buf);
    pb_ds_connected_to_pb_free_packed(&pb_connect);

    return len;
}

int32
pb_ds_connected_dump(Cdb__DsConnected *p_pb_connect, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_rtif->name=%s", p_pb_connect->parent_rtif->name);
    offset += pb_compose_prefix_t_dump(p_pb_connect->key->address, (out + offset));
    offset += pb_compose_prefix_t_dump(p_pb_connect->destination, (out + offset));
    offset += sal_sprintf(out + offset, "/flags_secondary=%u", p_pb_connect->flags_secondary);
    offset += sal_sprintf(out + offset, "/flags_anycast=%u", p_pb_connect->flags_anycast);
    offset += sal_sprintf(out + offset, "/flags_virtual=%u", p_pb_connect->flags_virtual);
    offset += sal_sprintf(out + offset, "/flags_duplicate=%u", p_pb_connect->flags_duplicate);
    offset += sal_sprintf(out + offset, "/installed=%u", p_pb_connect->installed);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_ROUTE_IF DS_OSPF_AUTH */
int32
pb_ds_ospf_auth_to_pb(tbl_route_if_key_t *p_rtif_key, ds_ospf_auth_t *p_ospf_auth, Cdb__DsOspfAuth *p_pb_ospf_auth)
{
    p_pb_ospf_auth->parent_rtif->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_rtif_key->name)+1);
    sal_strcpy(p_pb_ospf_auth->parent_rtif->name, p_rtif_key->name);

    p_pb_ospf_auth->key->id = p_ospf_auth->key.id;

    p_pb_ospf_auth->ospf_auth_md5_key = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_ospf_auth->ospf_auth_md5_key)+1);
    sal_strcpy(p_pb_ospf_auth->ospf_auth_md5_key, p_ospf_auth->ospf_auth_md5_key);

    return PM_E_NONE;
}

int32
pb_ds_ospf_auth_to_pb_free_packed(Cdb__DsOspfAuth *p_pb_ospf_auth)
{
    if (p_pb_ospf_auth->parent_rtif->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ospf_auth->parent_rtif->name);
        p_pb_ospf_auth->parent_rtif->name = NULL;
    }

    if (p_pb_ospf_auth->ospf_auth_md5_key)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_ospf_auth->ospf_auth_md5_key);
        p_pb_ospf_auth->ospf_auth_md5_key = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_ospf_auth_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblRouteIfKey pb_rtif_key = CDB__TBL_ROUTE_IF_KEY__INIT;
    Cdb__DsOspfAuthKey pb_ospf_auth_key = CDB__DS_OSPF_AUTH_KEY__INIT;
    Cdb__DsOspfAuth pb_ospf_auth = CDB__DS_OSPF_AUTH__INIT;
    tbl_route_if_key_t *p_rtif_key = (tbl_route_if_key_t*)p_tbl;
    ds_ospf_auth_t *p_ospf_auth = (ds_ospf_auth_t*)p_ds;
    int32 len = 0;

    pb_ospf_auth.key = &pb_ospf_auth_key;
    pb_ospf_auth.parent_rtif = &pb_rtif_key;
    pb_ds_ospf_auth_to_pb(p_rtif_key, p_ospf_auth, &pb_ospf_auth);
    len = cdb__ds_ospf_auth__pack(&pb_ospf_auth, buf);
    pb_ds_ospf_auth_to_pb_free_packed(&pb_ospf_auth);

    return len;
}

int32
pb_ds_ospf_auth_dump(Cdb__DsOspfAuth *p_pb_ospf_auth, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_rtif->name=%s", p_pb_ospf_auth->parent_rtif->name);
    offset += sal_sprintf(out + offset, "/key->id=%u", p_pb_ospf_auth->key->id);
    offset += sal_sprintf(out + offset, "/ospf_auth_md5_key=%s", p_pb_ospf_auth->ospf_auth_md5_key);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_STORM_CONTROL */
int32
pb_ds_storm_control_to_pb(tbl_interface_key_t *p_if_key, ds_storm_control_t *p_storm_control, Cdb__DsStormControl *p_pb_storm_control)
{
    p_pb_storm_control->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_storm_control->parent_if->name, p_if_key->name);

    p_pb_storm_control->bcast_mode = p_storm_control->bcast_mode;
    p_pb_storm_control->mcast_mode = p_storm_control->mcast_mode;
    p_pb_storm_control->ucast_mode = p_storm_control->ucast_mode;
    p_pb_storm_control->bcast_rate = p_storm_control->bcast_rate;
    p_pb_storm_control->mcast_rate = p_storm_control->mcast_rate;
    p_pb_storm_control->ucast_rate = p_storm_control->ucast_rate;

    return PM_E_NONE;
}

int32
pb_ds_storm_control_to_pb_free_packed(Cdb__DsStormControl *p_pb_storm_control)
{
    if (p_pb_storm_control->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_storm_control->parent_if->name);
        p_pb_storm_control->parent_if->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_storm_control_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsStormControl pb_storm_control = CDB__DS_STORM_CONTROL__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_storm_control_t *p_storm_control = (ds_storm_control_t*)p_ds;
    int32 len = 0;

    pb_storm_control.parent_if = &pb_if_key;
    pb_ds_storm_control_to_pb(p_if_key, p_storm_control, &pb_storm_control);
    len = cdb__ds_storm_control__pack(&pb_storm_control, buf);
    pb_ds_storm_control_to_pb_free_packed(&pb_storm_control);

    return len;
}

int32
pb_ds_storm_control_dump(Cdb__DsStormControl *p_pb_storm_control, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_storm_control->parent_if->name);
    offset += sal_sprintf(out + offset, "/bcast_mode=%u", p_pb_storm_control->bcast_mode);
    offset += sal_sprintf(out + offset, "/mcast_mode=%u", p_pb_storm_control->mcast_mode);
    offset += sal_sprintf(out + offset, "/ucast_mode=%u", p_pb_storm_control->ucast_mode);
    offset += sal_sprintf(out + offset, "/bcast_rate=%u", p_pb_storm_control->bcast_rate);
    offset += sal_sprintf(out + offset, "/mcast_rate=%u", p_pb_storm_control->mcast_rate);
    offset += sal_sprintf(out + offset, "/ucast_rate=%u", p_pb_storm_control->ucast_rate);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_OPENFLOW_IF */
int32
pb_ds_openflow_if_to_pb(tbl_interface_key_t *p_if_key, ds_openflow_if_t *p_openflow, Cdb__DsOpenflowIf *p_pb_openflow)
{
    p_pb_openflow->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_openflow->parent_if->name, p_if_key->name);

    p_pb_openflow->enable = p_openflow->enable;
    p_pb_openflow->obey_vlan_filter = p_openflow->obey_vlan_filter;

    return PM_E_NONE;
}

int32
pb_ds_openflow_if_to_pb_free_packed(Cdb__DsOpenflowIf *p_pb_openflow)
{
    if (p_pb_openflow->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_openflow->parent_if->name);
        p_pb_openflow->parent_if->name = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_openflow_if_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsOpenflowIf pb_openflow = CDB__DS_OPENFLOW_IF__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_openflow_if_t *p_openflow = (ds_openflow_if_t*)p_ds;
    int32 len = 0;

    pb_openflow.parent_if = &pb_if_key;
    pb_ds_openflow_if_to_pb(p_if_key, p_openflow, &pb_openflow);
    len = cdb__ds_openflow_if__pack(&pb_openflow, buf);
    pb_ds_openflow_if_to_pb_free_packed(&pb_openflow);

    return len;
}

int32
pb_ds_openflow_if_dump(Cdb__DsOpenflowIf *p_pb_openflow, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_openflow->parent_if->name);
    offset += sal_sprintf(out + offset, "/enable=%u", p_pb_openflow->enable);
    offset += sal_sprintf(out + offset, "/obey_vlan_filter=%u", p_pb_openflow->obey_vlan_filter);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_DHCLIENT_IF */
int32
pb_ds_dhclient_if_to_pb(tbl_interface_key_t *p_if_key, ds_dhclient_if_t *p_dhclient, Cdb__DsDhclientIf *p_pb_dhclient)
{
    p_pb_dhclient->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_dhclient->parent_if->name, p_if_key->name);

    p_pb_dhclient->requested_flags = p_dhclient->requested_flags;
    p_pb_dhclient->lease = p_dhclient->lease;
    p_pb_dhclient->status = p_dhclient->status;
    p_pb_dhclient->option = p_dhclient->option;
    p_pb_dhclient->client_flags = p_dhclient->client_flags;
    p_pb_dhclient->client_id = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhclient->client_id)+1);
    sal_strcpy(p_pb_dhclient->client_id, p_dhclient->client_id);
    p_pb_dhclient->class_flags = p_dhclient->class_flags;
    p_pb_dhclient->class_id = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhclient->class_id)+1);
    sal_strcpy(p_pb_dhclient->class_id, p_dhclient->class_id);
    p_pb_dhclient->hostname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_dhclient->hostname)+1);
    sal_strcpy(p_pb_dhclient->hostname, p_dhclient->hostname);

    return PM_E_NONE;
}

int32
pb_ds_dhclient_if_to_pb_free_packed(Cdb__DsDhclientIf *p_pb_dhclient)
{
    if (p_pb_dhclient->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhclient->parent_if->name);
        p_pb_dhclient->parent_if->name = NULL;
    }

    if (p_pb_dhclient->client_id)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhclient->client_id);
        p_pb_dhclient->client_id = NULL;
    }

    if (p_pb_dhclient->class_id)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhclient->class_id);
        p_pb_dhclient->class_id = NULL;
    }

    if (p_pb_dhclient->hostname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_dhclient->hostname);
        p_pb_dhclient->hostname = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_dhclient_if_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsDhclientIf pb_dhclient = CDB__DS_DHCLIENT_IF__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_dhclient_if_t *p_dhclient = (ds_dhclient_if_t*)p_ds;
    int32 len = 0;

    pb_dhclient.parent_if = &pb_if_key;
    pb_ds_dhclient_if_to_pb(p_if_key, p_dhclient, &pb_dhclient);
    len = cdb__ds_dhclient_if__pack(&pb_dhclient, buf);
    pb_ds_dhclient_if_to_pb_free_packed(&pb_dhclient);

    return len;
}

int32
pb_ds_dhclient_if_dump(Cdb__DsDhclientIf *p_pb_dhclient, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_dhclient->parent_if->name);
    offset += sal_sprintf(out + offset, "/requested_flags=%u", p_pb_dhclient->requested_flags);
    offset += sal_sprintf(out + offset, "/lease=%u", p_pb_dhclient->lease);
    offset += sal_sprintf(out + offset, "/status=%u", p_pb_dhclient->status);
    offset += sal_sprintf(out + offset, "/option=%u", p_pb_dhclient->option);
    offset += sal_sprintf(out + offset, "/client_flags=%u", p_pb_dhclient->client_flags);
    offset += sal_sprintf(out + offset, "/client_id=%s", p_pb_dhclient->client_id);
    offset += sal_sprintf(out + offset, "/class_flags=%u", p_pb_dhclient->class_flags);
    offset += sal_sprintf(out + offset, "/class_id=%s", p_pb_dhclient->class_id);
    offset += sal_sprintf(out + offset, "/hostname=%s", p_pb_dhclient->hostname);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_PVLAN DS_PVLAN_COMMUNITY */
int32
pb_ds_pvlan_community_to_pb(tbl_pvlan_key_t *p_pvlan_key, ds_pvlan_community_t *p_community, Cdb__DsPvlanCommunity *p_pb_community)
{
    p_pb_community->parent_pvlan->primary_vid = p_pvlan_key->primary_vid;

    p_pb_community->key->community_vid = p_community->key.community_vid;

    p_pb_community->group_id = p_community->group_id;

    return PM_E_NONE;
}

int32
pb_ds_pvlan_community_to_pb_free_packed(Cdb__DsPvlanCommunity *p_pb_community)
{
    return PM_E_NONE;
}

int32
pb_ds_pvlan_community_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblPvlanKey pb_pvlan_key = CDB__TBL_PVLAN_KEY__INIT;
    Cdb__DsPvlanCommunityKey pb_community_key = CDB__DS_PVLAN_COMMUNITY_KEY__INIT;
    Cdb__DsPvlanCommunity pb_community = CDB__DS_PVLAN_COMMUNITY__INIT;
    tbl_pvlan_key_t *p_pvlan_key = (tbl_pvlan_key_t*)p_tbl;
    ds_pvlan_community_t *p_community = (ds_pvlan_community_t*)p_ds;
    int32 len = 0;

    pb_community.key = &pb_community_key;
    pb_community.parent_pvlan = &pb_pvlan_key;
    pb_ds_pvlan_community_to_pb(p_pvlan_key, p_community, &pb_community);
    len = cdb__ds_pvlan_community__pack(&pb_community, buf);
    pb_ds_pvlan_community_to_pb_free_packed(&pb_community);

    return len;
}

int32
pb_ds_pvlan_community_dump(Cdb__DsPvlanCommunity *p_pb_community, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_pvlan->primary_vid=%u", p_pb_community->parent_pvlan->primary_vid);
    offset += sal_sprintf(out + offset, "/key->community_vid=%u", p_pb_community->key->community_vid);
    offset += sal_sprintf(out + offset, "/group_id=%u", p_pb_community->group_id);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_INTERFACE DS_CIRCUIT_ID */
int32
pb_ds_circuit_id_to_pb(tbl_interface_key_t *p_if_key, ds_circuit_id_t *p_circuit_id, Cdb__DsCircuitId *p_pb_circuit_id)
{
    p_pb_circuit_id->parent_if->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_if_key->name)+1);
    sal_strcpy(p_pb_circuit_id->parent_if->name, p_if_key->name);

    p_pb_circuit_id->key->vid = p_circuit_id->key.vid;

    p_pb_circuit_id->circuit = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_circuit_id->circuit)+1);
    sal_strcpy(p_pb_circuit_id->circuit, p_circuit_id->circuit);

    return PM_E_NONE;
}

int32
pb_ds_circuit_id_to_pb_free_packed(Cdb__DsCircuitId *p_pb_circuit_id)
{
    if (p_pb_circuit_id->parent_if->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_circuit_id->parent_if->name);
        p_pb_circuit_id->parent_if->name = NULL;
    }

    if (p_pb_circuit_id->circuit)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_circuit_id->circuit);
        p_pb_circuit_id->circuit = NULL;
    }

    return PM_E_NONE;
}

int32
pb_ds_circuit_id_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblInterfaceKey pb_if_key = CDB__TBL_INTERFACE_KEY__INIT;
    Cdb__DsCircuitIdKey pb_circuit_id_key = CDB__DS_CIRCUIT_ID_KEY__INIT;
    Cdb__DsCircuitId pb_circuit_id = CDB__DS_CIRCUIT_ID__INIT;
    tbl_interface_key_t *p_if_key = (tbl_interface_key_t*)p_tbl;
    ds_circuit_id_t *p_circuit_id = (ds_circuit_id_t*)p_ds;
    int32 len = 0;

    pb_circuit_id.key = &pb_circuit_id_key;
    pb_circuit_id.parent_if = &pb_if_key;
    pb_ds_circuit_id_to_pb(p_if_key, p_circuit_id, &pb_circuit_id);
    len = cdb__ds_circuit_id__pack(&pb_circuit_id, buf);
    pb_ds_circuit_id_to_pb_free_packed(&pb_circuit_id);

    return len;
}

int32
pb_ds_circuit_id_dump(Cdb__DsCircuitId *p_pb_circuit_id, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->name=%s", p_pb_circuit_id->parent_if->name);
    offset += sal_sprintf(out + offset, "/key->vid=%u", p_pb_circuit_id->key->vid);
    offset += sal_sprintf(out + offset, "/circuit=%s", p_pb_circuit_id->circuit);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_L2_ACTION DS_FLUSH_FDB */
int32
pb_ds_flush_fdb_to_pb(ds_flush_fdb_t *p_flush_fdb, Cdb__DsFlushFdb *p_pb_flush_fdb)
{
    p_pb_flush_fdb->type = p_flush_fdb->type;
    p_pb_flush_fdb->subtype = p_flush_fdb->subtype;
    p_pb_flush_fdb->mode = p_flush_fdb->mode;
    p_pb_flush_fdb->ifindex = p_flush_fdb->ifindex;
    p_pb_flush_fdb->vid = p_flush_fdb->vid;
    pb_compose_mac_addr_t_to_pb(p_flush_fdb->mac, p_pb_flush_fdb->mac);

    return PM_E_NONE;
}

int32
pb_ds_flush_fdb_to_pb_free_packed(Cdb__DsFlushFdb *p_pb_flush_fdb)
{
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_flush_fdb->mac);
    return PM_E_NONE;
}

int32
pb_ds_flush_fdb_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__DsFlushFdb pb_flush_fdb = CDB__DS_FLUSH_FDB__INIT;
    ds_flush_fdb_t *p_flush_fdb = (ds_flush_fdb_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac = CDB__COMPOSE_MAC_ADDR_T__INIT;

    pb_flush_fdb.mac = &mac;
    pb_ds_flush_fdb_to_pb(p_flush_fdb, &pb_flush_fdb);
    len = cdb__ds_flush_fdb__pack(&pb_flush_fdb, buf);
    pb_ds_flush_fdb_to_pb_free_packed(&pb_flush_fdb);

    return len;
}

int32
pb_ds_flush_fdb_dump(Cdb__DsFlushFdb *p_pb_flush_fdb, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_flush_fdb->type);
    offset += sal_sprintf(out + offset, "/subtype=%u", p_pb_flush_fdb->subtype);
    offset += sal_sprintf(out + offset, "/mode=%u", p_pb_flush_fdb->mode);
    offset += sal_sprintf(out + offset, "/ifindex=%u", p_pb_flush_fdb->ifindex);
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_flush_fdb->vid);
    offset += pb_compose_mac_addr_t_dump(p_pb_flush_fdb->mac, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_LLDP_IF DS_LLDP_NEIGHBOUR */
int32
pb_ds_lldp_neighbour_to_pb(tbl_lldp_if_key_t *p_lldp_if_key, ds_lldp_neighbour_t *p_neigh, Cdb__DsLldpNeighbour *p_pb_neigh)
{
    p_pb_neigh->parent_lldp_if->ifindex = p_lldp_if_key->ifindex;

    pb_compose_lldp_msap_id_t_to_pb(&p_neigh->key, p_pb_neigh->key);

    p_pb_neigh->rx_ifindex = p_neigh->rx_ifindex;
    pb_compose_mac_addr_t_to_pb(p_neigh->mac_addr, p_pb_neigh->mac_addr);
    p_pb_neigh->rx_ttl = p_neigh->rx_ttl;
    p_pb_neigh->chassis_id_sub_type = p_neigh->chassis_id_sub_type;
    p_pb_neigh->port_id_sub_type = p_neigh->port_id_sub_type;
    p_pb_neigh->system_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->system_name)+1);
    sal_strcpy(p_pb_neigh->system_name, p_neigh->system_name);
    p_pb_neigh->system_desc = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->system_desc)+1);
    sal_strcpy(p_pb_neigh->system_desc, p_neigh->system_desc);
    p_pb_neigh->port_desc = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->port_desc)+1);
    sal_strcpy(p_pb_neigh->port_desc, p_neigh->port_desc);
    p_pb_neigh->ifname = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->ifname)+1);
    sal_strcpy(p_pb_neigh->ifname, p_neigh->ifname);
    p_pb_neigh->vlan_name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->vlan_name)+1);
    sal_strcpy(p_pb_neigh->vlan_name, p_neigh->vlan_name);
    p_pb_neigh->vlan_id = p_neigh->vlan_id;
    p_pb_neigh->sys_cap = p_neigh->sys_cap;
    p_pb_neigh->sys_cap_en = p_neigh->sys_cap_en;
    p_pb_neigh->mant_addr = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->mant_addr)+1);
    sal_strcpy(p_pb_neigh->mant_addr, p_neigh->mant_addr);
    p_pb_neigh->oid = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->oid)+1);
    sal_strcpy(p_pb_neigh->oid, p_neigh->oid);
    p_pb_neigh->oid_len = p_neigh->oid_len;
    p_pb_neigh->mgmt_addr_sub_type = p_neigh->mgmt_addr_sub_type;
    p_pb_neigh->if_numbering = p_neigh->if_numbering;
    p_pb_neigh->if_number = p_neigh->if_number;
    p_pb_neigh->pvid = p_neigh->pvid;
    p_pb_neigh->ppvid_flag = p_neigh->ppvid_flag;
    p_pb_neigh->ppvid = p_neigh->ppvid;
    p_pb_neigh->protocol_id = p_neigh->protocol_id;
    p_pb_neigh->autonego_support = p_neigh->autonego_support;
    p_pb_neigh->autonego_cap = p_neigh->autonego_cap;
    p_pb_neigh->oper_mau_type = p_neigh->oper_mau_type;
    p_pb_neigh->link_aggr_status = p_neigh->link_aggr_status;
    p_pb_neigh->link_aggr_id = p_neigh->link_aggr_id;
    p_pb_neigh->max_frame_size = p_neigh->max_frame_size;
    p_pb_neigh->power_flag = p_neigh->power_flag;
    p_pb_neigh->power_pair = p_neigh->power_pair;
    p_pb_neigh->power_class = p_neigh->power_class;
    p_pb_neigh->med_capbility = p_neigh->med_capbility;
    p_pb_neigh->med_dev_type = p_neigh->med_dev_type;
    p_pb_neigh->med_policy_flag = p_neigh->med_policy_flag;
    p_pb_neigh->med_power_flag = p_neigh->med_power_flag;
    p_pb_neigh->med_power_value = p_neigh->med_power_value;
    p_pb_neigh->med_lci_format = p_neigh->med_lci_format;
    p_pb_neigh->med_hard_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_hard_ver)+1);
    sal_strcpy(p_pb_neigh->med_hard_ver, p_neigh->med_hard_ver);
    p_pb_neigh->med_firm_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_firm_ver)+1);
    sal_strcpy(p_pb_neigh->med_firm_ver, p_neigh->med_firm_ver);
    p_pb_neigh->med_soft_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_soft_ver)+1);
    sal_strcpy(p_pb_neigh->med_soft_ver, p_neigh->med_soft_ver);
    p_pb_neigh->med_serial_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_serial_ver)+1);
    sal_strcpy(p_pb_neigh->med_serial_ver, p_neigh->med_serial_ver);
    p_pb_neigh->med_manufac_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_manufac_ver)+1);
    sal_strcpy(p_pb_neigh->med_manufac_ver, p_neigh->med_manufac_ver);
    p_pb_neigh->med_moname_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_moname_ver)+1);
    sal_strcpy(p_pb_neigh->med_moname_ver, p_neigh->med_moname_ver);
    p_pb_neigh->med_asset_ver = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_asset_ver)+1);
    sal_strcpy(p_pb_neigh->med_asset_ver, p_neigh->med_asset_ver);
    p_pb_neigh->med_lci_coordinate = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_lci_coordinate)+1);
    sal_strcpy(p_pb_neigh->med_lci_coordinate, p_neigh->med_lci_coordinate);
    p_pb_neigh->med_lci_elin = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_neigh->med_lci_elin)+1);
    sal_strcpy(p_pb_neigh->med_lci_elin, p_neigh->med_lci_elin);
    pb_compose_lldp_civic_address_t_to_pb(&p_neigh->med_lci_civic, p_pb_neigh->med_lci_civic);

    return PM_E_NONE;
}

int32
pb_ds_lldp_neighbour_to_pb_free_packed(Cdb__DsLldpNeighbour *p_pb_neigh)
{
    pb_compose_lldp_msap_id_t_to_pb_free_packed(p_pb_neigh->key);
    pb_compose_mac_addr_t_to_pb_free_packed(p_pb_neigh->mac_addr);
    if (p_pb_neigh->system_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->system_name);
        p_pb_neigh->system_name = NULL;
    }

    if (p_pb_neigh->system_desc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->system_desc);
        p_pb_neigh->system_desc = NULL;
    }

    if (p_pb_neigh->port_desc)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->port_desc);
        p_pb_neigh->port_desc = NULL;
    }

    if (p_pb_neigh->ifname)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->ifname);
        p_pb_neigh->ifname = NULL;
    }

    if (p_pb_neigh->vlan_name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->vlan_name);
        p_pb_neigh->vlan_name = NULL;
    }

    if (p_pb_neigh->mant_addr)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->mant_addr);
        p_pb_neigh->mant_addr = NULL;
    }

    if (p_pb_neigh->oid)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->oid);
        p_pb_neigh->oid = NULL;
    }

    if (p_pb_neigh->med_hard_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_hard_ver);
        p_pb_neigh->med_hard_ver = NULL;
    }

    if (p_pb_neigh->med_firm_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_firm_ver);
        p_pb_neigh->med_firm_ver = NULL;
    }

    if (p_pb_neigh->med_soft_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_soft_ver);
        p_pb_neigh->med_soft_ver = NULL;
    }

    if (p_pb_neigh->med_serial_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_serial_ver);
        p_pb_neigh->med_serial_ver = NULL;
    }

    if (p_pb_neigh->med_manufac_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_manufac_ver);
        p_pb_neigh->med_manufac_ver = NULL;
    }

    if (p_pb_neigh->med_moname_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_moname_ver);
        p_pb_neigh->med_moname_ver = NULL;
    }

    if (p_pb_neigh->med_asset_ver)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_asset_ver);
        p_pb_neigh->med_asset_ver = NULL;
    }

    if (p_pb_neigh->med_lci_coordinate)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_lci_coordinate);
        p_pb_neigh->med_lci_coordinate = NULL;
    }

    if (p_pb_neigh->med_lci_elin)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_neigh->med_lci_elin);
        p_pb_neigh->med_lci_elin = NULL;
    }

    pb_compose_lldp_civic_address_t_to_pb_free_packed(p_pb_neigh->med_lci_civic);
    return PM_E_NONE;
}

int32
pb_ds_lldp_neighbour_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblLldpIfKey pb_lldp_if_key = CDB__TBL_LLDP_IF_KEY__INIT;
    Cdb__DsLldpNeighbourKey pb_neigh_key = CDB__DS_LLDP_NEIGHBOUR_KEY__INIT;
    Cdb__DsLldpNeighbour pb_neigh = CDB__DS_LLDP_NEIGHBOUR__INIT;
    tbl_lldp_if_key_t *p_lldp_if_key = (tbl_lldp_if_key_t*)p_tbl;
    ds_lldp_neighbour_t *p_neigh = (ds_lldp_neighbour_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeMacAddrT mac_addr = CDB__COMPOSE_MAC_ADDR_T__INIT;
    Cdb__ComposeLldpCivicAddressT med_lci_civic = CDB__COMPOSE_LLDP_CIVIC_ADDRESS_T__INIT;

    pb_neigh.key = &pb_neigh_key;
    pb_neigh.mac_addr = &mac_addr;
    pb_neigh.med_lci_civic = &med_lci_civic;
    pb_neigh.parent_lldp_if = &pb_lldp_if_key;
    pb_ds_lldp_neighbour_to_pb(p_lldp_if_key, p_neigh, &pb_neigh);
    len = cdb__ds_lldp_neighbour__pack(&pb_neigh, buf);
    pb_ds_lldp_neighbour_to_pb_free_packed(&pb_neigh);

    return len;
}

int32
pb_ds_lldp_neighbour_dump(Cdb__DsLldpNeighbour *p_pb_neigh, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_lldp_if->ifindex=%u", p_pb_neigh->parent_lldp_if->ifindex);
    offset += pb_compose_lldp_msap_id_t_dump(p_pb_neigh->key, (out + offset));
    offset += sal_sprintf(out + offset, "/rx_ifindex=%u", p_pb_neigh->rx_ifindex);
    offset += pb_compose_mac_addr_t_dump(p_pb_neigh->mac_addr, (out + offset));
    offset += sal_sprintf(out + offset, "/rx_ttl=%u", p_pb_neigh->rx_ttl);
    offset += sal_sprintf(out + offset, "/chassis_id_sub_type=%u", p_pb_neigh->chassis_id_sub_type);
    offset += sal_sprintf(out + offset, "/port_id_sub_type=%u", p_pb_neigh->port_id_sub_type);
    offset += sal_sprintf(out + offset, "/system_name=%s", p_pb_neigh->system_name);
    offset += sal_sprintf(out + offset, "/system_desc=%s", p_pb_neigh->system_desc);
    offset += sal_sprintf(out + offset, "/port_desc=%s", p_pb_neigh->port_desc);
    offset += sal_sprintf(out + offset, "/ifname=%s", p_pb_neigh->ifname);
    offset += sal_sprintf(out + offset, "/vlan_name=%s", p_pb_neigh->vlan_name);
    offset += sal_sprintf(out + offset, "/vlan_id=%u", p_pb_neigh->vlan_id);
    offset += sal_sprintf(out + offset, "/sys_cap=%u", p_pb_neigh->sys_cap);
    offset += sal_sprintf(out + offset, "/sys_cap_en=%u", p_pb_neigh->sys_cap_en);
    offset += sal_sprintf(out + offset, "/mant_addr=%s", p_pb_neigh->mant_addr);
    offset += sal_sprintf(out + offset, "/oid=%s", p_pb_neigh->oid);
    offset += sal_sprintf(out + offset, "/oid_len=%u", p_pb_neigh->oid_len);
    offset += sal_sprintf(out + offset, "/mgmt_addr_sub_type=%u", p_pb_neigh->mgmt_addr_sub_type);
    offset += sal_sprintf(out + offset, "/if_numbering=%u", p_pb_neigh->if_numbering);
    offset += sal_sprintf(out + offset, "/if_number=%u", p_pb_neigh->if_number);
    offset += sal_sprintf(out + offset, "/pvid=%u", p_pb_neigh->pvid);
    offset += sal_sprintf(out + offset, "/ppvid_flag=%u", p_pb_neigh->ppvid_flag);
    offset += sal_sprintf(out + offset, "/ppvid=%u", p_pb_neigh->ppvid);
    offset += sal_sprintf(out + offset, "/protocol_id=%u", p_pb_neigh->protocol_id);
    offset += sal_sprintf(out + offset, "/autonego_support=%u", p_pb_neigh->autonego_support);
    offset += sal_sprintf(out + offset, "/autonego_cap=%u", p_pb_neigh->autonego_cap);
    offset += sal_sprintf(out + offset, "/oper_mau_type=%u", p_pb_neigh->oper_mau_type);
    offset += sal_sprintf(out + offset, "/link_aggr_status=%u", p_pb_neigh->link_aggr_status);
    offset += sal_sprintf(out + offset, "/link_aggr_id=%u", p_pb_neigh->link_aggr_id);
    offset += sal_sprintf(out + offset, "/max_frame_size=%u", p_pb_neigh->max_frame_size);
    offset += sal_sprintf(out + offset, "/power_flag=%u", p_pb_neigh->power_flag);
    offset += sal_sprintf(out + offset, "/power_pair=%u", p_pb_neigh->power_pair);
    offset += sal_sprintf(out + offset, "/power_class=%u", p_pb_neigh->power_class);
    offset += sal_sprintf(out + offset, "/med_capbility=%u", p_pb_neigh->med_capbility);
    offset += sal_sprintf(out + offset, "/med_dev_type=%u", p_pb_neigh->med_dev_type);
    offset += sal_sprintf(out + offset, "/med_policy_flag=%u", p_pb_neigh->med_policy_flag);
    offset += sal_sprintf(out + offset, "/med_power_flag=%u", p_pb_neigh->med_power_flag);
    offset += sal_sprintf(out + offset, "/med_power_value=%u", p_pb_neigh->med_power_value);
    offset += sal_sprintf(out + offset, "/med_lci_format=%u", p_pb_neigh->med_lci_format);
    offset += sal_sprintf(out + offset, "/med_hard_ver=%s", p_pb_neigh->med_hard_ver);
    offset += sal_sprintf(out + offset, "/med_firm_ver=%s", p_pb_neigh->med_firm_ver);
    offset += sal_sprintf(out + offset, "/med_soft_ver=%s", p_pb_neigh->med_soft_ver);
    offset += sal_sprintf(out + offset, "/med_serial_ver=%s", p_pb_neigh->med_serial_ver);
    offset += sal_sprintf(out + offset, "/med_manufac_ver=%s", p_pb_neigh->med_manufac_ver);
    offset += sal_sprintf(out + offset, "/med_moname_ver=%s", p_pb_neigh->med_moname_ver);
    offset += sal_sprintf(out + offset, "/med_asset_ver=%s", p_pb_neigh->med_asset_ver);
    offset += sal_sprintf(out + offset, "/med_lci_coordinate=%s", p_pb_neigh->med_lci_coordinate);
    offset += sal_sprintf(out + offset, "/med_lci_elin=%s", p_pb_neigh->med_lci_elin);
    offset += pb_compose_lldp_civic_address_t_dump(p_pb_neigh->med_lci_civic, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IGSP_INTF DS_MROUTER_PORT */
int32
pb_ds_mrouter_port_to_pb(tbl_igsp_intf_key_t *p_if_key, ds_mrouter_port_t *p_mr_port, Cdb__DsMrouterPort *p_pb_mr_port)
{
    p_pb_mr_port->parent_if->vid = p_if_key->vid;

    p_pb_mr_port->key->name = XCALLOC(MEM_LIB_PROTOBUF, sal_strlen(p_mr_port->key.name)+1);
    sal_strcpy(p_pb_mr_port->key->name, p_mr_port->key.name);

    p_pb_mr_port->type = p_mr_port->type;
    pb_compose_sal_time_t_to_pb(&p_mr_port->uptime, p_pb_mr_port->uptime);

    return PM_E_NONE;
}

int32
pb_ds_mrouter_port_to_pb_free_packed(Cdb__DsMrouterPort *p_pb_mr_port)
{
    if (p_pb_mr_port->key->name)
    {
        XFREE(MEM_LIB_PROTOBUF, p_pb_mr_port->key->name);
        p_pb_mr_port->key->name = NULL;
    }

    pb_compose_sal_time_t_to_pb_free_packed(p_pb_mr_port->uptime);
    return PM_E_NONE;
}

int32
pb_ds_mrouter_port_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIgspIntfKey pb_if_key = CDB__TBL_IGSP_INTF_KEY__INIT;
    Cdb__DsMrouterPortKey pb_mr_port_key = CDB__DS_MROUTER_PORT_KEY__INIT;
    Cdb__DsMrouterPort pb_mr_port = CDB__DS_MROUTER_PORT__INIT;
    tbl_igsp_intf_key_t *p_if_key = (tbl_igsp_intf_key_t*)p_tbl;
    ds_mrouter_port_t *p_mr_port = (ds_mrouter_port_t*)p_ds;
    int32 len = 0;
    Cdb__ComposeSalTimeT uptime = CDB__COMPOSE_SAL_TIME_T__INIT;

    pb_mr_port.key = &pb_mr_port_key;
    pb_mr_port.uptime = &uptime;
    pb_mr_port.parent_if = &pb_if_key;
    pb_ds_mrouter_port_to_pb(p_if_key, p_mr_port, &pb_mr_port);
    len = cdb__ds_mrouter_port__pack(&pb_mr_port, buf);
    pb_ds_mrouter_port_to_pb_free_packed(&pb_mr_port);

    return len;
}

int32
pb_ds_mrouter_port_dump(Cdb__DsMrouterPort *p_pb_mr_port, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->vid=%u", p_pb_mr_port->parent_if->vid);
    offset += sal_sprintf(out + offset, "/key->name=%s", p_pb_mr_port->key->name);
    offset += sal_sprintf(out + offset, "/type=%u", p_pb_mr_port->type);
    offset += pb_compose_sal_time_t_dump(p_pb_mr_port->uptime, (out + offset));
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

/* pb functions for TBL_IGSP_INTF DS_QUERY */
int32
pb_ds_query_to_pb(tbl_igsp_intf_key_t *p_if_key, ds_query_t *p_query, Cdb__DsQuery *p_pb_query)
{
    p_pb_query->parent_if->vid = p_if_key->vid;

    pb_compose_addr_ipv4_t_to_pb(&p_query->key.group, p_pb_query->key->group);

    p_pb_query->max_resp_time = p_query->max_resp_time;
    p_pb_query->vid = p_query->vid;

    return PM_E_NONE;
}

int32
pb_ds_query_to_pb_free_packed(Cdb__DsQuery *p_pb_query)
{
    pb_compose_addr_ipv4_t_to_pb_free_packed(p_pb_query->key->group);
    return PM_E_NONE;
}

int32
pb_ds_query_pack(void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    Cdb__TblIgspIntfKey pb_if_key = CDB__TBL_IGSP_INTF_KEY__INIT;
    Cdb__ComposeAddrIpv4T group = CDB__COMPOSE_ADDR_IPV4_T__INIT;
    Cdb__DsQueryKey pb_query_key = CDB__DS_QUERY_KEY__INIT;
    Cdb__DsQuery pb_query = CDB__DS_QUERY__INIT;
    tbl_igsp_intf_key_t *p_if_key = (tbl_igsp_intf_key_t*)p_tbl;
    ds_query_t *p_query = (ds_query_t*)p_ds;
    int32 len = 0;

    pb_query_key.group = &group;
    pb_query.key = &pb_query_key;
    pb_query.parent_if = &pb_if_key;
    pb_ds_query_to_pb(p_if_key, p_query, &pb_query);
    len = cdb__ds_query__pack(&pb_query, buf);
    pb_ds_query_to_pb_free_packed(&pb_query);

    return len;
}

int32
pb_ds_query_dump(Cdb__DsQuery *p_pb_query, char *out)
{
    int32 offset = 0;

    out[0] = CMD_ZERO_CHAR;
    offset += sal_sprintf(out + offset, "/parent_if->vid=%u", p_pb_query->parent_if->vid);
    offset += pb_compose_addr_ipv4_t_dump(p_pb_query->key->group, (out + offset));
    offset += sal_sprintf(out + offset, "/max_resp_time=%u", p_pb_query->max_resp_time);
    offset += sal_sprintf(out + offset, "/vid=%u", p_pb_query->vid);
    offset += sal_sprintf(out + offset, "\n");

    return PM_E_NONE;
}

PB_DS_PACK_FUNC g_pb_pack_ds_func[DS_MAX] =
{
    pb_ds_brgif_pack,
    pb_ds_aclqos_if_pack,
    pb_ds_lag_pack,
    pb_ds_lacp_pack,
    pb_ds_pmap_class_pack,
    pb_ds_mac_ace_pack,
    pb_ds_ip_ace_pack,
    pb_ds_connected_pack,
    pb_ds_ospf_auth_pack,
    pb_ds_storm_control_pack,
    pb_ds_openflow_if_pack,
    pb_ds_dhclient_if_pack,
    pb_ds_pvlan_community_pack,
    pb_ds_circuit_id_pack,
    pb_ds_flush_fdb_pack,
    pb_ds_lldp_neighbour_pack,
    pb_ds_mrouter_port_pack,
    pb_ds_query_pack,
};

PB_DS_UNPACK_FUNC g_pb_unpack_ds_func[DS_MAX] =
{
    (PB_DS_UNPACK_FUNC)cdb__ds_brgif__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_aclqos_if__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_lag__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_lacp__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_pmap_class__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_mac_ace__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_ip_ace__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_connected__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_ospf_auth__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_storm_control__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_openflow_if__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_dhclient_if__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_pvlan_community__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_circuit_id__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_flush_fdb__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_lldp_neighbour__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_mrouter_port__unpack,
    (PB_DS_UNPACK_FUNC)cdb__ds_query__unpack,
};

PB_DS_DUMP_FUNC g_pb_dump_ds_func[DS_MAX] =
{
    (PB_DS_DUMP_FUNC)pb_ds_brgif_dump,
    (PB_DS_DUMP_FUNC)pb_ds_aclqos_if_dump,
    (PB_DS_DUMP_FUNC)pb_ds_lag_dump,
    (PB_DS_DUMP_FUNC)pb_ds_lacp_dump,
    (PB_DS_DUMP_FUNC)pb_ds_pmap_class_dump,
    (PB_DS_DUMP_FUNC)pb_ds_mac_ace_dump,
    (PB_DS_DUMP_FUNC)pb_ds_ip_ace_dump,
    (PB_DS_DUMP_FUNC)pb_ds_connected_dump,
    (PB_DS_DUMP_FUNC)pb_ds_ospf_auth_dump,
    (PB_DS_DUMP_FUNC)pb_ds_storm_control_dump,
    (PB_DS_DUMP_FUNC)pb_ds_openflow_if_dump,
    (PB_DS_DUMP_FUNC)pb_ds_dhclient_if_dump,
    (PB_DS_DUMP_FUNC)pb_ds_pvlan_community_dump,
    (PB_DS_DUMP_FUNC)pb_ds_circuit_id_dump,
    (PB_DS_DUMP_FUNC)pb_ds_flush_fdb_dump,
    (PB_DS_DUMP_FUNC)pb_ds_lldp_neighbour_dump,
    (PB_DS_DUMP_FUNC)pb_ds_mrouter_port_dump,
    (PB_DS_DUMP_FUNC)pb_ds_query_dump,
};

PB_DS_FREE_UNPACKED_FUNC g_pb_free_unpacked_ds_func[DS_MAX] =
{
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_brgif__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_aclqos_if__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_lag__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_lacp__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_pmap_class__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_mac_ace__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_ip_ace__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_connected__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_ospf_auth__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_storm_control__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_openflow_if__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_dhclient_if__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_pvlan_community__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_circuit_id__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_flush_fdb__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_lldp_neighbour__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_mrouter_port__free_unpacked,
    (PB_DS_FREE_UNPACKED_FUNC)cdb__ds_query__free_unpacked,
};

int32
pb_ds_pack(uint32 ds_id, void *p_tbl, void *p_ds, void *p_ds2, uint8 *buf, uint32 buf_len)
{
    if (ds_id >= DS_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_pack_ds_func[ds_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    return g_pb_pack_ds_func[ds_id](p_tbl, p_ds, p_ds2, buf, buf_len);
}

void*
pb_ds_unpack(uint32 ds_id, ProtobufCAllocator *allocator, uint32 len, uint8 *data)
{
    if (ds_id >= DS_MAX)
    {
        return NULL;
    }

    if (NULL == g_pb_unpack_ds_func[ds_id])
    {
        return NULL;
    }

    return g_pb_unpack_ds_func[ds_id](allocator, len, data);
}

int32
pb_ds_dump(uint32 ds_id, void *object, char *out)
{
    if (ds_id >= DS_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_dump_ds_func[ds_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    return g_pb_dump_ds_func[ds_id](object, out);
}

int32
pb_ds_free_unpacked(uint32 ds_id, void *object, ProtobufCAllocator *allocator)
{
    if (ds_id >= DS_MAX)
    {
        return PM_E_INVALID_PARAM;
    }

    if (NULL == g_pb_free_unpacked_ds_func[ds_id])
    {
        return PM_E_NOT_SUPPORT;
    }

    g_pb_free_unpacked_ds_func[ds_id](object, allocator);

    return PM_E_NONE;
}



#ifndef __TBL_AUTHD_DEBUG_H__
#define __TBL_AUTHD_DEBUG_H__

int32
tbl_authd_debug_set_authd_debug_field_sync(tbl_authd_debug_t *p_authd_debug, tbl_authd_debug_field_id_t field_id, uint32 sync);

int32
tbl_authd_debug_set_authd_debug_field(tbl_authd_debug_t *p_authd_debug, tbl_authd_debug_field_id_t field_id);

tbl_authd_debug_t*
tbl_authd_debug_get_authd_debug();

int32
tbl_authd_debug_dump_one(tbl_authd_debug_t *p_authd_debug, tbl_iter_args_t *pargs);

int32
tbl_authd_debug_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_authd_debug_t*
tbl_authd_debug_init_authd_debug();

#endif /* !__TBL_AUTHD_DEBUG_H__ */



#ifndef __TBL_MANAGE_IF_DEFINE_H__
#define __TBL_MANAGE_IF_DEFINE_H__

/* TBL_MANAGE_IF field defines */
typedef enum
{
    TBL_MANAGE_IF_FLD_ADDR                 = 0 ,  /* RW */
    TBL_MANAGE_IF_FLD_GATEWAY              = 1 ,  /* RW */
    TBL_MANAGE_IF_FLD_MAX                  = 2 
} tbl_manage_if_field_id_t;

/* TBL_MANAGE_IF defines */
typedef struct
{
    prefix_ipv4_t        addr;
    addr_ipv4_t          gateway;
} tbl_manage_if_t;

#endif /* !__TBL_MANAGE_IF_DEFINE_H__ */


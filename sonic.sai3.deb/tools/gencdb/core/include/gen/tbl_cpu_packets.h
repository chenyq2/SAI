
#ifndef __TBL_CPU_PACKETS_H__
#define __TBL_CPU_PACKETS_H__

int32
tbl_cpu_packets_set_cpu_packets_field_sync(tbl_cpu_packets_t *p_cpu_packets, tbl_cpu_packets_field_id_t field_id, uint32 sync);

int32
tbl_cpu_packets_set_cpu_packets_field(tbl_cpu_packets_t *p_cpu_packets, tbl_cpu_packets_field_id_t field_id);

tbl_cpu_packets_t*
tbl_cpu_packets_get_cpu_packets();

int32
tbl_cpu_packets_dump_one(tbl_cpu_packets_t *p_cpu_packets, tbl_iter_args_t *pargs);

int32
tbl_cpu_packets_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_cpu_packets_t*
tbl_cpu_packets_init_cpu_packets();

#endif /* !__TBL_CPU_PACKETS_H__ */


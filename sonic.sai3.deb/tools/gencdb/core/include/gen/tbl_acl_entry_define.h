
#ifndef __TBL_ACL_ENTRY_DEFINE_H__
#define __TBL_ACL_ENTRY_DEFINE_H__

/* TBL_ACL_ENTRY field defines */
typedef enum
{
    TBL_ACL_ENTRY_FLD_KEY                  = 0 ,  /* READ */
    TBL_ACL_ENTRY_FLD_TBLID                = 1 ,  /* RW */
    TBL_ACL_ENTRY_FLD_ENTRY_PRIORITY       = 2 ,  /* RW */
    TBL_ACL_ENTRY_FLD_TIME_RANGE           = 3 ,  /* RW */
    TBL_ACL_ENTRY_FLD_KEY_FLAGS            = 4 ,  /* RW */
    TBL_ACL_ENTRY_FLD_INVALID              = 5 ,  /* RW */
    TBL_ACL_ENTRY_FLD_IS_COPP              = 6 ,  /* RW */
    TBL_ACL_ENTRY_FLD_IN_PORT              = 7 ,  /* RW */
    TBL_ACL_ENTRY_FLD_OUT_PORT             = 8 ,  /* RW */
    TBL_ACL_ENTRY_FLD_ETHER_TYPE           = 9 ,  /* RW */
    TBL_ACL_ENTRY_FLD_ETHER_TYPE_MASK      = 10,  /* RW */
    TBL_ACL_ENTRY_FLD_SRC_MAC              = 11,  /* RW */
    TBL_ACL_ENTRY_FLD_SRC_MAC_MASK         = 12,  /* RW */
    TBL_ACL_ENTRY_FLD_DST_MAC              = 13,  /* RW */
    TBL_ACL_ENTRY_FLD_DST_MAC_MASK         = 14,  /* RW */
    TBL_ACL_ENTRY_FLD_SVLAN                = 15,  /* RW */
    TBL_ACL_ENTRY_FLD_SVLAN_MASK           = 16,  /* RW */
    TBL_ACL_ENTRY_FLD_SVLAN_COS            = 17,  /* RW */
    TBL_ACL_ENTRY_FLD_SVLAN_COS_MASK       = 18,  /* RW */
    TBL_ACL_ENTRY_FLD_CVLAN                = 19,  /* RW */
    TBL_ACL_ENTRY_FLD_CVLAN_MASK           = 20,  /* RW */
    TBL_ACL_ENTRY_FLD_CVLAN_COS            = 21,  /* RW */
    TBL_ACL_ENTRY_FLD_CVLAN_COS_MASK       = 22,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_TYPE              = 23,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_TYPE_MASK         = 24,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_FLAGS             = 25,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_FLAGS_MASK        = 26,  /* RW */
    TBL_ACL_ENTRY_FLD_SRC_IP               = 27,  /* RW */
    TBL_ACL_ENTRY_FLD_SRC_IP_MASK          = 28,  /* RW */
    TBL_ACL_ENTRY_FLD_DST_IP               = 29,  /* RW */
    TBL_ACL_ENTRY_FLD_DST_IP_MASK          = 30,  /* RW */
    TBL_ACL_ENTRY_FLD_DSCP                 = 31,  /* RW */
    TBL_ACL_ENTRY_FLD_DSCP_MASK            = 32,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_PRECEDENCE        = 33,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_PRECEDENCE_MASK   = 34,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_PROTOCOL          = 35,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_PROTOCOL_MASK     = 36,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_SRC_PORT_TYPE     = 37,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_SRC_PORT          = 38,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_SRC_PORT_MASK     = 39,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_DST_PORT_TYPE     = 40,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_DST_PORT          = 41,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_DST_PORT_MASK     = 42,  /* RW */
    TBL_ACL_ENTRY_FLD_IP_FRAG              = 43,  /* RW */
    TBL_ACL_ENTRY_FLD_TCP_FLAGS            = 44,  /* RW */
    TBL_ACL_ENTRY_FLD_TCP_FLAGS_MASK       = 45,  /* RW */
    TBL_ACL_ENTRY_FLD_IGMP_TYPE            = 46,  /* RW */
    TBL_ACL_ENTRY_FLD_ICMP_TYPE            = 47,  /* RW */
    TBL_ACL_ENTRY_FLD_ICMP_CODE            = 48,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_VXLAN_VNI         = 49,  /* RW */
    TBL_ACL_ENTRY_FLD_L4_VXLAN_VNI_MASK    = 50,  /* RW */
    TBL_ACL_ENTRY_FLD_DENY                 = 51,  /* RW */
    TBL_ACL_ENTRY_FLD_STATS_EN             = 52,  /* RW */
    TBL_ACL_ENTRY_FLD_OPTIONS              = 53,  /* RW */
    TBL_ACL_ENTRY_FLD_ACTION_STRIP_HEADER  = 54,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_REDIRECT  = 55,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_MARK_VLAN = 56,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_UNTAG     = 57,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_TRUNCTION = 58,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_DEST_MAC_EN = 59,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_DEST_MAC = 60,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_SRC_MAC_EN = 61,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_SRC_MAC = 62,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_IPDA_EN = 63,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_IPDA = 64,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_IPSA_EN = 65,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_ACTION_EDIT_IPSA = 66,  /* RW */
    TBL_ACL_ENTRY_FLD_TAP_GROUP_OID        = 67,  /* RW */
    TBL_ACL_ENTRY_FLD_MAX                  = 68
} tbl_acl_entry_field_id_t;

/* TBL_ACL_ENTRY defines */
typedef struct
{
    uint64               aclid;
} tbl_acl_entry_key_t;

typedef struct
{
    tbl_acl_entry_key_t  key;
    uint32               tblid;
    uint32               entry_priority;
    char                 time_range[TIME_RANGE_SIZE+1];
    uint32               key_flags;
    uint32               invalid;
    uint32               is_copp;
    uint64               in_port;
    uint64               out_port;
    uint32               ether_type;
    uint32               ether_type_mask;
    mac_addr_t           src_mac;
    mac_addr_t           src_mac_mask;
    mac_addr_t           dst_mac;
    mac_addr_t           dst_mac_mask;
    uint32               svlan;
    uint32               svlan_mask;
    uint32               svlan_cos;
    uint32               svlan_cos_mask;
    uint32               cvlan;
    uint32               cvlan_mask;
    uint32               cvlan_cos;
    uint32               cvlan_cos_mask;
    uint32               ip_type;
    uint32               ip_type_mask;
    uint32               ip_flags;
    uint32               ip_flags_mask;
    addr_ipv4_t          src_ip;
    addr_ipv4_t          src_ip_mask;
    addr_ipv4_t          dst_ip;
    addr_ipv4_t          dst_ip_mask;
    uint32               dscp;
    uint32               dscp_mask;
    uint32               ip_precedence;
    uint32               ip_precedence_mask;
    uint32               ip_protocol;
    uint32               ip_protocol_mask;
    uint32               l4_src_port_type;
    uint32               l4_src_port;
    uint32               l4_src_port_mask;
    uint32               l4_dst_port_type;
    uint32               l4_dst_port;
    uint32               l4_dst_port_mask;
    uint32               ip_frag;
    uint32               tcp_flags;
    uint32               tcp_flags_mask;
    uint32               igmp_type;
    uint32               icmp_type;
    uint32               icmp_code;
    uint32               l4_vxlan_vni;
    uint32               l4_vxlan_vni_mask;
    uint32               deny;
    uint32               stats_en;
    uint32               options;
    uint32               action_strip_header;
    uint32               tap_action_redirect;
    uint32               tap_action_mark_vlan;
    uint32               tap_action_untag;
    uint32               tap_action_trunction;
    uint32               tap_action_edit_dest_mac_en;
    mac_addr_t           tap_action_edit_dest_mac;
    uint32               tap_action_edit_src_mac_en;
    mac_addr_t           tap_action_edit_src_mac;
    uint32               tap_action_edit_ipda_en;
    addr_t               tap_action_edit_ipda; /* ip address v4/v6 */
    uint32               tap_action_edit_ipsa_en;
    addr_t               tap_action_edit_ipsa; /* ip address v4/v6 */
    uint64               tap_group_oid;
} tbl_acl_entry_t;

typedef struct
{
    ctclib_hash_t        *acl_entry_hash;
    ctclib_slist_t       *acl_entry_list;
} tbl_acl_entry_master_t;

#endif /* !__TBL_ACL_ENTRY_DEFINE_H__ */


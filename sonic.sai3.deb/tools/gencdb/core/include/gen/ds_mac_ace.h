
#ifndef __DS_MAC_ACE_H__
#define __DS_MAC_ACE_H__

int32
ds_mac_ace_add_mac_ace_sync(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace, uint32 sync);

int32
ds_mac_ace_del_mac_ace_sync(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace, uint32 sync);

int32
ds_mac_ace_set_mac_ace_field_sync(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace, ds_mac_ace_field_id_t field_id, uint32 sync);

int32
ds_mac_ace_add_mac_ace(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace);

int32
ds_mac_ace_del_mac_ace(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace);

int32
ds_mac_ace_set_mac_ace_field(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace, ds_mac_ace_field_id_t field_id);

ds_mac_ace_t*
ds_mac_ace_get_mac_ace(tbl_acl_t *p_acl, ds_mac_ace_t *p_mac_ace);

int32
ds_mac_ace_dump_one(ds_mac_ace_t *p_mac_ace, tbl_iter_args_t *pargs);

#endif /* !__DS_MAC_ACE_H__ */



#ifndef __TBL_MEM_SUMMARY_H__
#define __TBL_MEM_SUMMARY_H__

int32
tbl_mem_summary_set_mem_summary_field_sync(tbl_mem_summary_t *p_mem_info, tbl_mem_summary_field_id_t field_id, uint32 sync);

int32
tbl_mem_summary_set_mem_summary_field(tbl_mem_summary_t *p_mem_info, tbl_mem_summary_field_id_t field_id);

tbl_mem_summary_t*
tbl_mem_summary_get_mem_summary();

int32
tbl_mem_summary_dump_one(tbl_mem_summary_t *p_mem_info, tbl_iter_args_t *pargs);

int32
tbl_mem_summary_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_mem_summary_t*
tbl_mem_summary_init_mem_summary();

#endif /* !__TBL_MEM_SUMMARY_H__ */


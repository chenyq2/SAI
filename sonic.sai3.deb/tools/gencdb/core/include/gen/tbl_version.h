
#ifndef __TBL_VERSION_H__
#define __TBL_VERSION_H__

int32
tbl_version_set_version_field_sync(tbl_version_t *p_ver, tbl_version_field_id_t field_id, uint32 sync);

int32
tbl_version_set_version_field(tbl_version_t *p_ver, tbl_version_field_id_t field_id);

tbl_version_t*
tbl_version_get_version();

int32
tbl_version_dump_one(tbl_version_t *p_ver, tbl_iter_args_t *pargs);

int32
tbl_version_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_version_t*
tbl_version_init_version();

#endif /* !__TBL_VERSION_H__ */


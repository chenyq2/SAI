
#ifndef __TBL_INTERFACE_DEFINE_H__
#define __TBL_INTERFACE_DEFINE_H__

#include "gen/ds_circuit_id_define.h"
#include "gen/ds_brgif_define.h"
#include "gen/ds_lag_define.h"
#include "gen/ds_lacp_define.h"
#include "gen/ds_storm_control_define.h"
#include "gen/ds_aclqos_if_define.h"
#include "gen/ds_openflow_if_define.h"
#include "gen/ds_dhclient_if_define.h"

/* TBL_INTERFACE field defines */
typedef enum
{
    TBL_INTERFACE_FLD_KEY                  = 0 ,  /* READ */
    TBL_INTERFACE_FLD_IFINDEX              = 1 ,  /* READ */
    TBL_INTERFACE_FLD_PORTID               = 2 ,  /* READ */
    TBL_INTERFACE_FLD_HOSTIFID             = 3 ,  /* READ */
    TBL_INTERFACE_FLD_DESC                 = 4 ,  /* RW */
    TBL_INTERFACE_FLD_SPEED                = 5 ,  /* RW */
    TBL_INTERFACE_FLD_DUPLEX               = 6 ,  /* RW */
    TBL_INTERFACE_FLD_UNIDIR               = 7 ,  /* RW */
    TBL_INTERFACE_FLD_FLOWCONTROL_SEND     = 8 ,  /* RW */
    TBL_INTERFACE_FLD_FLOWCONTROL_RECEIVE  = 9 ,  /* RW */
    TBL_INTERFACE_FLD_FLOWCONTROL_OPER_SEND = 10,  /* RW */
    TBL_INTERFACE_FLD_FLOWCONTROL_OPER_RECEIVE = 11,  /* RW */
    TBL_INTERFACE_FLD_FEC                  = 12,  /* RW */
    TBL_INTERFACE_FLD_PFC_ADMIN            = 13,  /* RW */
    TBL_INTERFACE_FLD_PFC_OPER             = 14,  /* RW */
    TBL_INTERFACE_FLD_PFC_PRIORITY         = 15,  /* RW */
    TBL_INTERFACE_FLD_JUMBOFRAME_EN        = 16,  /* RW */
    TBL_INTERFACE_FLD_ISOLATE_GROUP_ID     = 17,  /* RW */
    TBL_INTERFACE_FLD_DHCP_SNOOPING_TRUST  = 18,  /* RW */
    TBL_INTERFACE_FLD_PHY_STATUS           = 19,  /* RW */
    TBL_INTERFACE_FLD_PHY_LOOPBACK_MODE    = 20,  /* RW */
    TBL_INTERFACE_FLD_INTERNAL_LP_IFINDEX  = 21,  /* RW */
    TBL_INTERFACE_FLD_PVLAN_TYPE           = 22,  /* RW */
    TBL_INTERFACE_FLD_PRIVATE_VLAN         = 23,  /* RW */
    TBL_INTERFACE_FLD_COMMUNITY_VLAN       = 24,  /* RW */
    TBL_INTERFACE_FLD_NTP_DISABLE          = 25,  /* RW */
    TBL_INTERFACE_FLD_NTP_BROADCAST_CLIENT = 26,  /* RW */
    TBL_INTERFACE_FLD_PVLAN_GROUP_ID       = 27,  /* RW */
    TBL_INTERFACE_FLD_SUPPORT_SPEED        = 28,  /* READ */
    TBL_INTERFACE_FLD_MODE                 = 29,  /* RW */
    TBL_INTERFACE_FLD_VLAN_TYPE            = 30,  /* RW */
    TBL_INTERFACE_FLD_UP                   = 31,  /* RW */
    TBL_INTERFACE_FLD_RUNNING              = 32,  /* READ */
    TBL_INTERFACE_FLD_MTU                  = 33,  /* RW */
    TBL_INTERFACE_FLD_OPER_SPEED           = 34,  /* READ */
    TBL_INTERFACE_FLD_OPER_DUPLEX          = 35,  /* READ */
    TBL_INTERFACE_FLD_OPER_UNIDIR          = 36,  /* RW */
    TBL_INTERFACE_FLD_OPER_FEC             = 37,  /* RW */
    TBL_INTERFACE_FLD_OPER_LOOPBACK        = 38,  /* RW */
    TBL_INTERFACE_FLD_BANDWIDTH            = 39,  /* RW */
    TBL_INTERFACE_FLD_TAP_USED             = 40,  /* RW */
    TBL_INTERFACE_FLD_TAP_INGRESS_ENABLE   = 41,  /* RW */
    TBL_INTERFACE_FLD_TAP                  = 42,  /* RW */
    TBL_INTERFACE_FLD_TAP_MARK_VLAN        = 43,  /* RW */
    TBL_INTERFACE_FLD_MIRROR_ENABLE        = 44,  /* RW */
    TBL_INTERFACE_FLD_MIRROR_IGS_ID        = 45,  /* RW */
    TBL_INTERFACE_FLD_MIRROR_EGS_ID        = 46,  /* RW */
    TBL_INTERFACE_FLD_MIRROR_DEST_ID       = 47,  /* RW */
    TBL_INTERFACE_FLD_ADMIN_UP             = 48,  /* RW */
    TBL_INTERFACE_FLD_IP_SOURCE_EN         = 49,  /* RW */
    TBL_INTERFACE_FLD_IP_SOURCE_TYPE       = 50,  /* RW */
    TBL_INTERFACE_FLD_IP_SOURCE_ITEM_NUMBER = 51,  /* RW */
    TBL_INTERFACE_FLD_UNICAST_RPF_EN       = 52,  /* RW */
    TBL_INTERFACE_FLD_OPER_BANDWIDTH       = 53,  /* READ */
    TBL_INTERFACE_FLD_ERRDISABLE_REASON    = 54,  /* RW */
    TBL_INTERFACE_FLD_FDB_LOOP_OCCUR       = 55,  /* RW */
    TBL_INTERFACE_FLD_LINK_FLAP_CNT        = 56,  /* RW */
    TBL_INTERFACE_FLD_STATIC_SECURITY_NUM  = 57,  /* RW */
    TBL_INTERFACE_FLD_ERRDISABLE_TIMER     = 58,  /* READ */
    TBL_INTERFACE_FLD_SFLOW_FLOW_EN        = 59,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_FLOW_INGRESS   = 60,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_FLOW_EGRESS    = 61,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_COUNTER_EN     = 62,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_RATE           = 63,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_SEQUENCE       = 64,  /* RW */
    TBL_INTERFACE_FLD_SFLOW_SAMPLE_POOL    = 65,  /* RW */
    TBL_INTERFACE_FLD_MAC_ADDR             = 66,  /* READ */
    TBL_INTERFACE_FLD_HW_MAC_ADDR          = 67,  /* READ */
    TBL_INTERFACE_FLD_HW_TYPE              = 68,  /* READ */
    TBL_INTERFACE_FLD_PHY_TYPE             = 69,  /* READ */
    TBL_INTERFACE_FLD_MEDIA                = 70,  /* RW */
    TBL_INTERFACE_FLD_PHYPORT_COMBO        = 71,  /* READ */
    TBL_INTERFACE_FLD_PHYPORT_LOOPBACK     = 72,  /* RW */
    TBL_INTERFACE_FLD_PHYPORT_EEE          = 73,  /* READ */
    TBL_INTERFACE_FLD_PHYPORT_POE          = 74,  /* READ */
    TBL_INTERFACE_FLD_PHYPORT_MASTER       = 75,  /* READ */
    TBL_INTERFACE_FLD_PHYPORT_SLAVE        = 76,  /* READ */
    TBL_INTERFACE_FLD_PHYPORT_UNIDIR       = 77,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_100M         = 78,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_1G           = 79,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_10G          = 80,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_40G          = 81,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_100G         = 82,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_2_5G         = 83,  /* READ */
    TBL_INTERFACE_FLD_SUPPORT_5G           = 84,  /* READ */
    TBL_INTERFACE_FLD_CIRCUIT_ID           = 85,  /* SUB */
    TBL_INTERFACE_FLD_IGS_ACL              = 86,  /* RW */
    TBL_INTERFACE_FLD_EGS_ACL              = 87,  /* RW */
    TBL_INTERFACE_FLD_IGS_POLICY_MAP       = 88,  /* RW */
    TBL_INTERFACE_FLD_EGS_POLICY_MAP       = 89,  /* RW */
    TBL_INTERFACE_FLD_BRGIF                = 90,  /* SUB */
    TBL_INTERFACE_FLD_LAG                  = 91,  /* SUB */
    TBL_INTERFACE_FLD_LACP                 = 92,  /* SUB */
    TBL_INTERFACE_FLD_STORM_CONTROL        = 93,  /* SUB */
    TBL_INTERFACE_FLD_ACLQOS_IF            = 94,  /* SUB */
    TBL_INTERFACE_FLD_OPENFLOW_IF          = 95,  /* SUB */
    TBL_INTERFACE_FLD_DHCLIENT_IF          = 96,  /* SUB */
    TBL_INTERFACE_FLD_CRC_ERROR_CHECK_EN   = 97,  /* RW */
    TBL_INTERFACE_FLD_MLAG_ID              = 98,  /* READ */
    TBL_INTERFACE_FLD_ERPS_ENABLE          = 99,  /* RW */
    TBL_INTERFACE_FLD_ERPS_PDU_ACTION      = 100,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_ENABLE         = 101,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_UNAUTHORIZED   = 102,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_DIR_IN         = 103,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_DIR_OUT        = 104,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_MODE_MAC       = 105,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_GUEST_VLAN     = 106,  /* RW */
    TBL_INTERFACE_FLD_VLANCLASS_GROUP_ID   = 107,  /* RW */
    TBL_INTERFACE_FLD_VLANCLASS_ACTIVE_TYPE = 108,  /* RW */
    TBL_INTERFACE_FLD_VLANCLASS_DEFAULT_ACTION = 109,  /* RW */
    TBL_INTERFACE_FLD_DOT1X_CFG_GUEST_VLAN = 110,  /* RW */
    TBL_INTERFACE_FLD_EGS_ACL_EN           = 111,  /* RW */
    TBL_INTERFACE_FLD_TAP_GROUP_IGS_REF_CNT = 112,  /* RW */
    TBL_INTERFACE_FLD_TAP_GROUP_EGS_REF_CNT = 113,  /* RW */
    TBL_INTERFACE_FLD_ARPINSP_TRUST_ENABLE = 114,  /* RW */
    TBL_INTERFACE_FLD_ARP_NUMBERLIMIT_ENABLE = 115,  /* RW */
    TBL_INTERFACE_FLD_ARP_NUMBERLIMIT_NUMBER = 116,  /* RW */
    TBL_INTERFACE_FLD_ARP_NUMBERLIMIT_VIOLATE = 117,  /* RW */
    TBL_INTERFACE_FLD_ARP_NUMBERLIMIT_OCCUR = 118,  /* RW */
    TBL_INTERFACE_FLD_ARP_RATE_LIMIT_ERRDISABLE_OCCUR = 119,  /* RW */
    TBL_INTERFACE_FLD_INBAND_SNAT_TYPE     = 120,  /* RW */
    TBL_INTERFACE_FLD_MAX                  = 121
} tbl_interface_field_id_t;

/* TBL_INTERFACE defines */
typedef struct
{
    char                 name[IFNAME_SIZE];
} tbl_interface_key_t;

typedef struct
{
    tbl_interface_key_t  key;
    uint32               ifindex;             /* ifindex assign in user-space(PMs, Fea) to indicate an interface */
    uint64               portid;              /* port id for ASIC mapping */
    uint64               hostifid;            /* hostif id for SAI */
    char                 desc[DESC_SIZE+1];
    uint8                speed;
    uint8                duplex;
    uint8                unidir;
    uint8                flowcontrol;         /* bitmap of GLB_IF_FLOW_CONTROL_ */
    uint8                fec;
    uint8                pfc_admin;
    uint8                pfc_oper;
    uint8                pfc_priority;
    uint8                jumboframe_en;
    uint8                isolate_group_id;
    uint8                dhcp_snooping_trust; /* dhcp snooping trust interface or not for L2 */
    uint8                phy_status;          /* physical port status, glb_port_oper_status_t*/
    uint8                phy_loopback_mode;   /* physical port loopback mode, glb_lb_phy_t, valid when phyport_flag is GLB_PHYPORT_FLAG_LOOPBACK */
    uint32               internal_lp_ifindex; /*  this is parameters only use when phy_loopback_mode is internal mode */
    uint32               pvlan_type;          /* glb_if_pvlan_type_t */
    vid_t                private_vlan;
    vid_t                community_vlan;
    uint32               ntp_disable;
    uint32               ntp_broadcast_client;
    uint8                pvlan_group_id;
    uint8                support_speed;       /* bitmap of GLB_SUPPORT_SPEED_ */
    uint8                mode;                /* glb_if_mode_t */
    uint8                vlan_type;           /* glb_vlan_port_type_t */
    uint32               flags;
    uint32               mtu;                 /* MTU */
    uint8                oper_speed;
    uint8                oper_duplex;
    uint8                oper_unidir;
    uint8                oper_fec;
    uint8                oper_loopback;
    uint32               bandwidth;           /* bandwidth */
    uint32               tap_used;
    uint32               tap_ingress_enable;  /* tap group ingress bind to this interface */
    char                 tap[TAP_NAME_SIZE];  /* tap group name who used this ingress */
    uint32               tap_mark_vlan;       /* tap group mark source vlan */
    uint32               mirror_enable;       /* mirror source or destination enable */
    uint8                mirror_igs_id;       /* mirror ingress session id */
    uint8                mirror_egs_id;       /* mirror egress session id */
    uint8                mirror_dest_id;      /* mirror dest session id */
    uint8                admin_up;            /* admin_up is used for running-config and snmp get, same to up without errdisable */
    uint32               ip_source_en;        /* ip source guard enable */
    uint32               ip_source_type;      /* ip source guard type */
    uint32               ip_source_item_number; /* ip source guard num */
    uint32               unicast_rpf_en;
    uint32               oper_bandwidth;      /* operate bandwidth */
    uint32               errdisable_reason;   /* port Error disable reason*/
    uint32               fdb_loop_occur;      /* occur FDB loop, to trigger errdisable */
    uint32               link_flap_cnt;       /* link flap number*/
    uint32               static_security_num; /* static port-security mac num*/
    ctc_task_t           *errdisable_timer;
    uint32               sflow_flow_en;       /* sflow enable flow */
    uint32               sflow_flow_ingress;  /* sflow flow ingress */
    uint32               sflow_flow_egress;   /* sflow flow egress */
    uint32               sflow_counter_en;    /* sflow enable counter */
    uint32               sflow_rate;          /* sflow flow rate*/
    uint32               sflow_sequence;      /* sflow flow sequence, incremented with each flow sample */
    uint32               sflow_sample_pool;   /* sflow total number of packets that could have been sampled */
    mac_addr_t           mac_addr;            /* l2: hw_mac_addr, l3: route_mac */
    mac_addr_t           hw_mac_addr;         /* l2 mac addr */
    uint32               hw_type;             /* glb_if_type_t */
    uint32               phy_type;            /* glb_phy_type_t */
    uint32               media;               /* configured media for combo port, glb_port_media_t */
    uint8                phyport_flag;        /* bitmap of GLB_PHYPORT_FLAG_ */
    uint8                support_speed_flag;  /* bitmap of GLB_SUPPORT_SPEED_ */
    cdb_reference_list_t circuit_id;          /* circuit id hash for dhcp snooping */
    char                 igs_acl[ACL_NAME_FULL_NAME_SIZE+1]; /* ingress ACL name*/
    char                 egs_acl[ACL_NAME_FULL_NAME_SIZE+1]; /* egress ACL name*/
    char                 igs_policy_map[PMAP_NAME_SIZE+1]; /* ingress ACL name*/
    char                 egs_policy_map[PMAP_NAME_SIZE+1]; /* egress ACL name*/
    ds_brgif_t           *brgif;              /* bridge interface info */
    ds_lag_t             *lag;                /* LAG info */
    ds_lacp_t            *lacp;               /* LACP link info */
    ds_storm_control_t   *storm_control;      /* storm control information */
    ds_aclqos_if_t       *aclqos_if;          /* acl&qos interface configurateion info */
    ds_openflow_if_t     *openflow_if;        /* openflow interface configurateion info */
    ds_dhclient_if_t     *dhclient_if;        /* dhclient interface configurateion info */
    void                 *mstp_port;          /* refer to tbl_mstp_port_t */
    uint32               crc_error_check_en;  /* crc error check enable */
    uint32               mlag_id;             /* MLAG ID */
    uint32               erps_enable;
    uint32               erps_pdu_action;
    uint32               dot1x_enable;
    uint32               dot1x_flag;
    uint32               dot1x_guest_vlan;
    uint32               vlanclass_group_id;
    uint32               vlanclass_active_type;
    uint32               vlanclass_default_action;
    uint32               dot1x_cfg_guest_vlan; /* configurable guest vlan  */
    uint8                egs_acl_en;          /* set port egress acl enable or disable */
    uint32               tap_group_igs_ref_cnt; /* tap group ingress configured count  */
    uint32               tap_group_egs_ref_cnt; /* tap group egress configured count  */
    uint32               arpinsp_trust_enable; /*arp inspection enable/disable on port*/
    uint32               arp_numberlimit_enable; /*arp number limit enable/disable*/
    uint32               arp_numberlimit_number; /*arp number limit number*/
    uint32               arp_numberlimit_violate; /*arp number limit violate: protect, restrict, errdisable*/
    uint32               arp_numberlimit_occur; /* arp number limit occur, to trigger errdisable */
    uint32               arp_rate_limit_errdisable_occur; /* arp rate limit occur, to trigger errdisable */
    uint32               inband_snat_type;    /* refer to inband_snat_type_t  */
} tbl_interface_t;

typedef struct
{
    ctclib_hash_t        *if_hash;
    ctclib_slist_t       *if_list;
} tbl_interface_master_t;

#endif /* !__TBL_INTERFACE_DEFINE_H__ */


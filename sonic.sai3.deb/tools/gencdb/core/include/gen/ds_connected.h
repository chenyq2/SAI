
#ifndef __DS_CONNECTED_H__
#define __DS_CONNECTED_H__

int32
ds_connected_add_connected_sync(tbl_route_if_t *p_rtif, ds_connected_t *p_connect, uint32 sync);

int32
ds_connected_del_connected_sync(tbl_route_if_t *p_rtif, ds_connected_t *p_connect, uint32 sync);

int32
ds_connected_set_connected_field_sync(tbl_route_if_t *p_rtif, ds_connected_t *p_connect, ds_connected_field_id_t field_id, uint32 sync);

int32
ds_connected_add_connected(tbl_route_if_t *p_rtif, ds_connected_t *p_connect);

int32
ds_connected_del_connected(tbl_route_if_t *p_rtif, ds_connected_t *p_connect);

int32
ds_connected_set_connected_field(tbl_route_if_t *p_rtif, ds_connected_t *p_connect, ds_connected_field_id_t field_id);

ds_connected_t*
ds_connected_get_connected(tbl_route_if_t *p_rtif, ds_connected_t *p_connect);

int32
ds_connected_dump_one(ds_connected_t *p_connect, tbl_iter_args_t *pargs);

#endif /* !__DS_CONNECTED_H__ */


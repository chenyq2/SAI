
#ifndef __TBL_LLDP_GLOBAL_H__
#define __TBL_LLDP_GLOBAL_H__

int32
tbl_lldp_global_set_lldp_global_field_sync(tbl_lldp_global_t *p_lldp_glb, tbl_lldp_global_field_id_t field_id, uint32 sync);

int32
tbl_lldp_global_set_lldp_global_field(tbl_lldp_global_t *p_lldp_glb, tbl_lldp_global_field_id_t field_id);

tbl_lldp_global_t*
tbl_lldp_global_get_lldp_global();

int32
tbl_lldp_global_dump_one(tbl_lldp_global_t *p_lldp_glb, tbl_iter_args_t *pargs);

int32
tbl_lldp_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_lldp_global_t*
tbl_lldp_global_init_lldp_global();

#endif /* !__TBL_LLDP_GLOBAL_H__ */


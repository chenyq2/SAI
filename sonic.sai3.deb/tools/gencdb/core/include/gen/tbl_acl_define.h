
#ifndef __TBL_ACL_DEFINE_H__
#define __TBL_ACL_DEFINE_H__

#include "gen/ds_mac_ace_define.h"
#include "gen/ds_ip_ace_define.h"

/* TBL_ACL field defines */
typedef enum
{
    TBL_ACL_FLD_KEY                  = 0 ,  /* RW */
    TBL_ACL_FLD_REMARK               = 1 ,  /* RW */
    TBL_ACL_FLD_ACE_NUM              = 2 ,  /* READ */
    TBL_ACL_FLD_AFI                  = 3 ,  /* READ */
    TBL_ACL_FLD_MAC_ACE_LIST         = 4 ,  /* SUB */
    TBL_ACL_FLD_IP_ACE_LIST          = 5 ,  /* SUB */
    TBL_ACL_FLD_MAX                  = 6 
} tbl_acl_field_id_t;

/* TBL_ACL defines */
typedef struct
{
    char                 name[ACL_NAME_FULL_NAME_SIZE+1];
} tbl_acl_key_t;

typedef struct
{
    tbl_acl_key_t        key;
    char                 remark[ACL_REMARK_SIZE+1];
    uint32               ace_num;
    uint8                afi;
    cdb_reference_list_t mac_ace_list;        /* mac ace list */
    cdb_reference_list_t ip_ace_list;         /* ip ace list */
} tbl_acl_t;

typedef struct
{
    ctclib_hash_t        *acl_hash;
    ctclib_slist_t       *acl_list;
} tbl_acl_master_t;

#endif /* !__TBL_ACL_DEFINE_H__ */


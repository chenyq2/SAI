
#ifndef __TBL_ROUTE_GLOBAL_DEFINE_H__
#define __TBL_ROUTE_GLOBAL_DEFINE_H__

/* TBL_ROUTE_GLOBAL field defines */
typedef enum
{
    TBL_ROUTE_GLOBAL_FLD_GRATUITOUS_ARP_LEARN_EN = 0 ,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ARP_PKT_RX_COUNT     = 1 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARP_PKT_TX_COUNT     = 2 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARP_PKT_DISCARD_COUNT = 3 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARP_COUNT            = 4 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_MULTIPATH_NUM        = 5 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_MAX_STATIC           = 6 ,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ICMP_ERROR_RATELIMIT = 7 ,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_CURRENT_STATIC_ROUTES = 8 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_CURRENT_ECMP_ROUTES  = 9 ,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_CURRENT_REMOTE_ROUTES = 10,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_CURRENT_HOST_ROUTES  = 11,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_LOCAL         = 12,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_STATIC        = 13,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_CONNECTED     = 14,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_RIP           = 15,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_OSPF          = 16,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ACTIVE_BGP           = 17,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARPINSP_LOGBUF_ENTRYNUM = 18,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ARPINSP_LOGBUF_CURNUM = 19,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ARPINSP_LOGBUF_LOGNUM = 20,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ARPINSP_LOGBUF_LOGSEC = 21,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_ARPINSP_VALIDATE_FLAG = 22,  /* RW */
    TBL_ROUTE_GLOBAL_FLD_FIB_FULL             = 23,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARP_AGING_TIMER      = 24,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_ARPRATELIMIT_TIMER   = 25,  /* READ */
    TBL_ROUTE_GLOBAL_FLD_MAX                  = 26
} tbl_route_global_field_id_t;

/* TBL_ROUTE_GLOBAL defines */
typedef struct
{
    uint32               gratuitous_arp_learn_en;
    uint32               arp_pkt_rx_count;
    uint32               arp_pkt_tx_count;
    uint32               arp_pkt_discard_count;
    uint32               arp_count;
    uint32               multipath_num;
    uint32               max_static;
    uint32               icmp_error_ratelimit;
    uint32               current_static_routes;
    uint32               current_ecmp_routes;
    uint32               current_remote_routes;
    uint32               current_host_routes;
    uint32               active_local;
    uint32               active_static;
    uint32               active_connected;
    uint32               active_rip;
    uint32               active_ospf;
    uint32               active_bgp;
    uint32               arpinsp_logbuf_entrynum;
    uint32               arpinsp_logbuf_curnum;
    uint32               arpinsp_logbuf_lognum;
    uint32               arpinsp_logbuf_logsec;
    uint32               arpinsp_validate_flag;
    uint32               fib_full;
    ctc_task_t           *arp_aging_timer;
    ctc_task_t           *arpratelimit_timer;
} tbl_route_global_t;

#endif /* !__TBL_ROUTE_GLOBAL_DEFINE_H__ */


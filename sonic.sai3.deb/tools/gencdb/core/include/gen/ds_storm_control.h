
#ifndef __DS_STORM_CONTROL_H__
#define __DS_STORM_CONTROL_H__

int32
ds_storm_control_add_storm_control_sync(tbl_interface_t *p_if, ds_storm_control_t *p_storm_control, uint32 sync);

int32
ds_storm_control_del_storm_control_sync(tbl_interface_t *p_if, uint32 sync);

int32
ds_storm_control_set_storm_control_field_sync(tbl_interface_t *p_if, ds_storm_control_t *p_storm_control, ds_storm_control_field_id_t field_id, uint32 sync);

int32
ds_storm_control_add_storm_control(tbl_interface_t *p_if, ds_storm_control_t *p_storm_control);

int32
ds_storm_control_del_storm_control(tbl_interface_t *p_if);

int32
ds_storm_control_set_storm_control_field(tbl_interface_t *p_if, ds_storm_control_t *p_storm_control, ds_storm_control_field_id_t field_id);

ds_storm_control_t*
ds_storm_control_get_storm_control(tbl_interface_t *p_if);

int32
ds_storm_control_dump_one(ds_storm_control_t *p_storm_control, tbl_iter_args_t *pargs);

#endif /* !__DS_STORM_CONTROL_H__ */



#ifndef __TBL_OPENFLOW_H__
#define __TBL_OPENFLOW_H__

int32
tbl_openflow_set_openflow_field_sync(tbl_openflow_t *p_openflow, tbl_openflow_field_id_t field_id, uint32 sync);

int32
tbl_openflow_set_openflow_field(tbl_openflow_t *p_openflow, tbl_openflow_field_id_t field_id);

tbl_openflow_t*
tbl_openflow_get_openflow();

int32
tbl_openflow_dump_one(tbl_openflow_t *p_openflow, tbl_iter_args_t *pargs);

int32
tbl_openflow_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_openflow_t*
tbl_openflow_init_openflow();

#endif /* !__TBL_OPENFLOW_H__ */



#ifndef __TBL_DOT1X_GLOBAL_H__
#define __TBL_DOT1X_GLOBAL_H__

int32
tbl_dot1x_global_set_dot1x_global_field_sync(tbl_dot1x_global_t *p_dot1x_global, tbl_dot1x_global_field_id_t field_id, uint32 sync);

int32
tbl_dot1x_global_set_dot1x_global_field(tbl_dot1x_global_t *p_dot1x_global, tbl_dot1x_global_field_id_t field_id);

tbl_dot1x_global_t*
tbl_dot1x_global_get_dot1x_global();

int32
tbl_dot1x_global_dump_one(tbl_dot1x_global_t *p_dot1x_global, tbl_iter_args_t *pargs);

int32
tbl_dot1x_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_dot1x_global_t*
tbl_dot1x_global_init_dot1x_global();

#endif /* !__TBL_DOT1X_GLOBAL_H__ */


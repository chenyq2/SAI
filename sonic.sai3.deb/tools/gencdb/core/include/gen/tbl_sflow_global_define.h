
#ifndef __TBL_SFLOW_GLOBAL_DEFINE_H__
#define __TBL_SFLOW_GLOBAL_DEFINE_H__

/* TBL_SFLOW_GLOBAL field defines */
typedef enum
{
    TBL_SFLOW_GLOBAL_FLD_ENABLE               = 0 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_AGENT                = 1 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_COUNTER_INTERVAL     = 2 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_COUNTER_PORT_NUM     = 3 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_COUNTER_TIMER        = 4 ,  /* READ */
    TBL_SFLOW_GLOBAL_FLD_COUNTER_NEXT_PORT    = 5 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_SFLOW_ALL            = 6 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_SFLOW_COUNTER        = 7 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_SFLOW_SAMPLE         = 8 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_SFLOW_PACKET         = 9 ,  /* RW */
    TBL_SFLOW_GLOBAL_FLD_MAX                  = 10
} tbl_sflow_global_field_id_t;

/* TBL_SFLOW_GLOBAL defines */
typedef struct
{
    uint32               enable;              /* global sflow enable */
    addr_t               agent;               /* agent ip address */
    uint32               counter_interval;    /* sflow counter polling interval*/
    uint32               counter_port_num;    /* sflow counter sampling enabled port num*/
    ctc_task_t           *counter_timer;      /* sflow counter timer */
    uint32               counter_next_port;   /* get next port stats when sflow_counter_timer*/
    uint32               sflow;               /* bitmap of SFLOW_FLAG_ */
} tbl_sflow_global_t;

#endif /* !__TBL_SFLOW_GLOBAL_DEFINE_H__ */


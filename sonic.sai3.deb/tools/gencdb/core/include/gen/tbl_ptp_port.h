
#ifndef __TBL_PTP_PORT_H__
#define __TBL_PTP_PORT_H__

int32
tbl_ptp_port_add_ptp_port_sync(tbl_ptp_port_t *p_port, uint32 sync);

int32
tbl_ptp_port_del_ptp_port_sync(tbl_ptp_port_key_t *p_port_key, uint32 sync);

int32
tbl_ptp_port_set_ptp_port_field_sync(tbl_ptp_port_t *p_port, tbl_ptp_port_field_id_t field_id, uint32 sync);

int32
tbl_ptp_port_add_ptp_port(tbl_ptp_port_t *p_port);

int32
tbl_ptp_port_del_ptp_port(tbl_ptp_port_key_t *p_port_key);

int32
tbl_ptp_port_set_ptp_port_field(tbl_ptp_port_t *p_port, tbl_ptp_port_field_id_t field_id);

tbl_ptp_port_t*
tbl_ptp_port_get_ptp_port(tbl_ptp_port_key_t *p_port_key);

char*
tbl_ptp_port_key_val2str(tbl_ptp_port_t *p_port, char *str, uint32 str_len);

int32
tbl_ptp_port_dump_one(tbl_ptp_port_t *p_port, tbl_iter_args_t *pargs);

int32
tbl_ptp_port_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_ptp_port_master_t*
tbl_ptp_port_get_master();

tbl_ptp_port_master_t*
tbl_ptp_port_init_ptp_port();

#endif /* !__TBL_PTP_PORT_H__ */



#ifndef __TBL_PTP_FOREIGN_DEFINE_H__
#define __TBL_PTP_FOREIGN_DEFINE_H__

/* TBL_PTP_FOREIGN field defines */
typedef enum
{
    TBL_PTP_FOREIGN_FLD_KEY                  = 0 ,  /* READ */
    TBL_PTP_FOREIGN_FLD_MAX                  = 1 
} tbl_ptp_foreign_field_id_t;

/* TBL_PTP_FOREIGN defines */
typedef glb_ptp_port_id_t tbl_ptp_foreign_key_t;

typedef struct
{
    tbl_ptp_foreign_key_t key;
} tbl_ptp_foreign_t;

typedef struct
{
    ctclib_hash_t        *port_hash;
    ctclib_slist_t       *port_list;
} tbl_ptp_foreign_master_t;

#endif /* !__TBL_PTP_FOREIGN_DEFINE_H__ */


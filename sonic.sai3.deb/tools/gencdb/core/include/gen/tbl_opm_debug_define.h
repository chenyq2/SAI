
#ifndef __TBL_OPM_DEBUG_DEFINE_H__
#define __TBL_OPM_DEBUG_DEFINE_H__

/* TBL_OPM_DEBUG field defines */
typedef enum
{
    TBL_OPM_DEBUG_FLD_ERPS_ALL             = 0 ,  /* RW */
    TBL_OPM_DEBUG_FLD_ERPS_PACKET          = 1 ,  /* RW */
    TBL_OPM_DEBUG_FLD_ERPS_TIMER           = 2 ,  /* RW */
    TBL_OPM_DEBUG_FLD_ERPS_PROTOCOL        = 3 ,  /* RW */
    TBL_OPM_DEBUG_FLD_ERPS_EVENT           = 4 ,  /* RW */
    TBL_OPM_DEBUG_FLD_MAX                  = 5 
} tbl_opm_debug_field_id_t;

/* TBL_OPM_DEBUG defines */
typedef struct
{
    uint32               erps;                /* bitmap of OPMDBG_FLAG_ERPS_ */
} tbl_opm_debug_t;

#endif /* !__TBL_OPM_DEBUG_DEFINE_H__ */



#ifndef __TBL_MLAG_PEER_H__
#define __TBL_MLAG_PEER_H__

int32
tbl_mlag_peer_set_mlag_peer_field_sync(tbl_mlag_peer_t *p_peer, tbl_mlag_peer_field_id_t field_id, uint32 sync);

int32
tbl_mlag_peer_set_mlag_peer_field(tbl_mlag_peer_t *p_peer, tbl_mlag_peer_field_id_t field_id);

tbl_mlag_peer_t*
tbl_mlag_peer_get_mlag_peer();

int32
tbl_mlag_peer_dump_one(tbl_mlag_peer_t *p_peer, tbl_iter_args_t *pargs);

int32
tbl_mlag_peer_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_mlag_peer_t*
tbl_mlag_peer_init_mlag_peer();

#endif /* !__TBL_MLAG_PEER_H__ */


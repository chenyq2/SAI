
#ifndef __TBL_ACLQOS_IF_DEFINE_H__
#define __TBL_ACLQOS_IF_DEFINE_H__

/* TBL_ACLQOS_IF field defines */
typedef enum
{
    TBL_ACLQOS_IF_FLD_KEY                  = 0 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_DOMAIN         = 1 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_PORT_SHAPE_PROFILE = 2 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_INPUT_POLICER  = 3 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_OUTPUT_POLICER = 4 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_QUEUE_SHAPE_PROFILE = 5 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_QUEUE_DROP_PROFILE = 6 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_QUEUE_DROP_MODE = 7 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_REPLACE_DSCP   = 8 ,  /* READ */
    TBL_ACLQOS_IF_FLD_FLAGS_REPLACE_COS    = 9 ,  /* READ */
    TBL_ACLQOS_IF_FLD_DOMAIN               = 10,  /* RW */
    TBL_ACLQOS_IF_FLD_PORT_SHAPE_PROFILE   = 11,  /* RW */
    TBL_ACLQOS_IF_FLD_INPUT_POLICY_MAP     = 12,  /* RW */
    TBL_ACLQOS_IF_FLD_OUTPUT_POLICY_MAP    = 13,  /* RW */
    TBL_ACLQOS_IF_FLD_INPUT_POLICER        = 14,  /* RW */
    TBL_ACLQOS_IF_FLD_OUTPUT_POLICER       = 15,  /* RW */
    TBL_ACLQOS_IF_FLD_QUEUE_SHAPE_PROFILE  = 16,  /* RW */
    TBL_ACLQOS_IF_FLD_QUEUE_DROP_PROFILE   = 17,  /* RW */
    TBL_ACLQOS_IF_FLD_QUEUE_DROP_MODE      = 18,  /* RW */
    TBL_ACLQOS_IF_FLD_REPLACE_DSCP         = 19,  /* RW */
    TBL_ACLQOS_IF_FLD_REPLACE_COS          = 20,  /* RW */
    TBL_ACLQOS_IF_FLD_MAX                  = 21
} tbl_aclqos_if_field_id_t;

/* TBL_ACLQOS_IF defines */
typedef struct
{
    char                 name[IFNAME_SIZE];
} tbl_aclqos_if_key_t;

typedef struct
{
    tbl_aclqos_if_key_t  key;
    uint32               flags;               /* GLB_DROP_PROFILE_FLAGS_GREEN_MAX_THRD */
    uint32               domain;              /* qos domain, default: 0 */
    char                 port_shape_profile[QOS_NAME_SIZE];
    char                 input_policy_map[PMAP_NAME_SIZE]; /* attached police-map nmae */
    char                 output_policy_map[PMAP_NAME_SIZE]; /* attached police-map nmae */
    char                 input_policer[POLICER_NAME_SIZE]; /* policer name */
    char                 output_policer[POLICER_NAME_SIZE]; /* policer name */
    qos_name_t           queue_shape_profile[GLB_QOS_PORT_QUEUE_NUM]; /* queue shape name */
    qos_name_t           queue_drop_profile[GLB_QOS_PORT_QUEUE_NUM]; /* queue drop name */
    uint32               queue_drop_mode[GLB_QOS_PORT_QUEUE_NUM]; /* queue drop mode: glb_qos_queue_drop_mode_t */
    uint32               replace_dscp;        /* repalce dscp*/
    uint32               replace_cos;         /* repalce dscp*/
} tbl_aclqos_if_t;

typedef struct
{
    ctclib_hash_t        *if_hash;
    ctclib_slist_t       *if_list;
} tbl_aclqos_if_master_t;

#endif /* !__TBL_ACLQOS_IF_DEFINE_H__ */



#ifndef __TBL_SWITCH_DEBUG_H__
#define __TBL_SWITCH_DEBUG_H__

int32
tbl_switch_debug_set_switch_debug_field_sync(tbl_switch_debug_t *p_swthdbg, tbl_switch_debug_field_id_t field_id, uint32 sync);

int32
tbl_switch_debug_set_switch_debug_field(tbl_switch_debug_t *p_swthdbg, tbl_switch_debug_field_id_t field_id);

tbl_switch_debug_t*
tbl_switch_debug_get_switch_debug();

int32
tbl_switch_debug_dump_one(tbl_switch_debug_t *p_swthdbg, tbl_iter_args_t *pargs);

int32
tbl_switch_debug_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_switch_debug_t*
tbl_switch_debug_init_switch_debug();

#endif /* !__TBL_SWITCH_DEBUG_H__ */


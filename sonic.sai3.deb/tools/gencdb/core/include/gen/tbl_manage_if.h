
#ifndef __TBL_MANAGE_IF_H__
#define __TBL_MANAGE_IF_H__

int32
tbl_manage_if_set_manage_if_field_sync(tbl_manage_if_t *p_mng_if, tbl_manage_if_field_id_t field_id, uint32 sync);

int32
tbl_manage_if_set_manage_if_field(tbl_manage_if_t *p_mng_if, tbl_manage_if_field_id_t field_id);

tbl_manage_if_t*
tbl_manage_if_get_manage_if();

int32
tbl_manage_if_dump_one(tbl_manage_if_t *p_mng_if, tbl_iter_args_t *pargs);

int32
tbl_manage_if_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_manage_if_t*
tbl_manage_if_init_manage_if();

#endif /* !__TBL_MANAGE_IF_H__ */



#ifndef __TBL_QOS_GLOBAL_DEFINE_H__
#define __TBL_QOS_GLOBAL_DEFINE_H__

/* TBL_QOS_GLOBAL field defines */
typedef enum
{
    TBL_QOS_GLOBAL_FLD_QOS_ENABLE           = 0 ,  /* RW */
    TBL_QOS_GLOBAL_FLD_PHB_ENABLE           = 1 ,  /* RW */
    TBL_QOS_GLOBAL_FLD_PORT_POLICER_FIRST_ENABLE = 2 ,  /* RW */
    TBL_QOS_GLOBAL_FLD_POLICER_STATS_ENABLE = 3 ,  /* RW */
    TBL_QOS_GLOBAL_FLD_CUR_CPU_RATE         = 4 ,  /* RW */
    TBL_QOS_GLOBAL_FLD_DEF_CPU_RATE         = 5 ,  /* READ */
    TBL_QOS_GLOBAL_FLD_MAX                  = 6 
} tbl_qos_global_field_id_t;

/* TBL_QOS_GLOBAL defines */
typedef struct
{
    uint8                qos_enable;
    uint8                phb_enable;
    uint8                port_policer_first_enable;
    uint8                policer_stats_enable;
    uint32               cur_cpu_rate;        /* total cpu rate*/
    uint32               def_cpu_rate;        /* total cpu rate*/
} tbl_qos_global_t;

#endif /* !__TBL_QOS_GLOBAL_DEFINE_H__ */


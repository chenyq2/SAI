
#ifndef __TBL_NTP_IF_H__
#define __TBL_NTP_IF_H__

int32
tbl_ntp_if_set_ntp_if_field_sync(tbl_ntp_if_t *p_ntp_if, tbl_ntp_if_field_id_t field_id, uint32 sync);

int32
tbl_ntp_if_set_ntp_if_field(tbl_ntp_if_t *p_ntp_if, tbl_ntp_if_field_id_t field_id);

tbl_ntp_if_t*
tbl_ntp_if_get_ntp_if();

int32
tbl_ntp_if_dump_one(tbl_ntp_if_t *p_ntp_if, tbl_iter_args_t *pargs);

int32
tbl_ntp_if_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_ntp_if_t*
tbl_ntp_if_init_ntp_if();

#endif /* !__TBL_NTP_IF_H__ */


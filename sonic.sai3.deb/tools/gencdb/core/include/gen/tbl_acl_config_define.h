
#ifndef __TBL_ACL_CONFIG_DEFINE_H__
#define __TBL_ACL_CONFIG_DEFINE_H__

/* TBL_ACL_CONFIG field defines */
typedef enum
{
    TBL_ACL_CONFIG_FLD_KEY                  = 0 ,  /* READ */
    TBL_ACL_CONFIG_FLD_ACE_REF              = 1 ,  /* RW */
    TBL_ACL_CONFIG_FLD_INTF_REF_IN          = 2 ,  /* RW */
    TBL_ACL_CONFIG_FLD_INTF_REF_OUT         = 3 ,  /* RW */
    TBL_ACL_CONFIG_FLD_L4_PORT_REF          = 4 ,  /* RW */
    TBL_ACL_CONFIG_FLD_TCP_FLAGS_REF        = 5 ,  /* RW */
    TBL_ACL_CONFIG_FLD_REMARK               = 6 ,  /* RW */
    TBL_ACL_CONFIG_FLD_SEQ_REF              = 7 ,  /* RW */
    TBL_ACL_CONFIG_FLD_ETHER_REF            = 8 ,  /* RW */
    TBL_ACL_CONFIG_FLD_TAP_REF              = 9 ,  /* RW */
    TBL_ACL_CONFIG_FLD_TYPE_IDENTIFYING     = 10,  /* RW */
    TBL_ACL_CONFIG_FLD_ACE_TRUNCATION_REF_CNT = 11,  /* RW */
    TBL_ACL_CONFIG_FLD_MAX                  = 12
} tbl_acl_config_field_id_t;

/* TBL_ACL_CONFIG defines */
typedef struct
{
    char                 name[ACL_NAME_FULL_NAME_SIZE+1];
} tbl_acl_config_key_t;

typedef struct
{
    tbl_acl_config_key_t key;
    uint32               ace_ref;
    uint32               intf_ref_in;
    uint32               intf_ref_out;
    uint32               l4_port_ref;
    uint32               tcp_flags_ref;
    char                 remark[ACL_REMARK_SIZE+1];
    uint32               seq_ref;
    uint32               ether_ref;
    uint32               tap_ref;             /* tap ingress group flow used count */
    uint32               type_identifying;    /* identifying how  to use this acl flow */
    uint32               ace_truncation_ref_cnt;
} tbl_acl_config_t;

typedef struct
{
    ctclib_hash_t        *acl_config_hash;
    ctclib_slist_t       *acl_config_list;
} tbl_acl_config_master_t;

#endif /* !__TBL_ACL_CONFIG_DEFINE_H__ */


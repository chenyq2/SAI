
#ifndef __TBL_PTP_PORT_DEFINE_H__
#define __TBL_PTP_PORT_DEFINE_H__

/* TBL_PTP_PORT field defines */
typedef enum
{
    TBL_PTP_PORT_FLD_KEY                  = 0 ,  /* READ */
    TBL_PTP_PORT_FLD_IFINDEX              = 1 ,  /* READ */
    TBL_PTP_PORT_FLD_ENABLE               = 2 ,  /* RW */
    TBL_PTP_PORT_FLD_MAX                  = 3 
} tbl_ptp_port_field_id_t;

/* TBL_PTP_PORT defines */
typedef struct
{
    char                 name[IFNAME_SIZE];
} tbl_ptp_port_key_t;

typedef struct
{
    tbl_ptp_port_key_t   key;
    uint32               ifindex;
    uint32               enable;
} tbl_ptp_port_t;

typedef struct
{
    ctclib_hash_t        *port_hash;
    ctclib_slist_t       *port_list;
} tbl_ptp_port_master_t;

#endif /* !__TBL_PTP_PORT_DEFINE_H__ */



#ifndef __TBL_BOOTIMAGE_H__
#define __TBL_BOOTIMAGE_H__

int32
tbl_bootimage_set_bootimage_field_sync(tbl_bootimage_t *p_boot, tbl_bootimage_field_id_t field_id, uint32 sync);

int32
tbl_bootimage_set_bootimage_field(tbl_bootimage_t *p_boot, tbl_bootimage_field_id_t field_id);

tbl_bootimage_t*
tbl_bootimage_get_bootimage();

int32
tbl_bootimage_dump_one(tbl_bootimage_t *p_boot, tbl_iter_args_t *pargs);

int32
tbl_bootimage_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_bootimage_t*
tbl_bootimage_init_bootimage();

#endif /* !__TBL_BOOTIMAGE_H__ */



#ifndef __TBL_SYS_GLOBAL_H__
#define __TBL_SYS_GLOBAL_H__

int32
tbl_sys_global_set_sys_global_field_sync(tbl_sys_global_t *p_sys_glb, tbl_sys_global_field_id_t field_id, uint32 sync);

int32
tbl_sys_global_set_sys_global_field(tbl_sys_global_t *p_sys_glb, tbl_sys_global_field_id_t field_id);

tbl_sys_global_t*
tbl_sys_global_get_sys_global();

int32
tbl_sys_global_dump_one(tbl_sys_global_t *p_sys_glb, tbl_iter_args_t *pargs);

int32
tbl_sys_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_sys_global_t*
tbl_sys_global_init_sys_global();

#endif /* !__TBL_SYS_GLOBAL_H__ */



#ifndef __TBL_NTP_SYNCSTATUS_H__
#define __TBL_NTP_SYNCSTATUS_H__

int32
tbl_ntp_syncstatus_set_ntp_syncstatus_field_sync(tbl_ntp_syncstatus_t *p_ntp_syncstatus, tbl_ntp_syncstatus_field_id_t field_id, uint32 sync);

int32
tbl_ntp_syncstatus_set_ntp_syncstatus_field(tbl_ntp_syncstatus_t *p_ntp_syncstatus, tbl_ntp_syncstatus_field_id_t field_id);

tbl_ntp_syncstatus_t*
tbl_ntp_syncstatus_get_ntp_syncstatus();

int32
tbl_ntp_syncstatus_dump_one(tbl_ntp_syncstatus_t *p_ntp_syncstatus, tbl_iter_args_t *pargs);

int32
tbl_ntp_syncstatus_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_ntp_syncstatus_t*
tbl_ntp_syncstatus_init_ntp_syncstatus();

#endif /* !__TBL_NTP_SYNCSTATUS_H__ */


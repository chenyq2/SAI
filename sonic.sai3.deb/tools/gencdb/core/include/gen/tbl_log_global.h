
#ifndef __TBL_LOG_GLOBAL_H__
#define __TBL_LOG_GLOBAL_H__

int32
tbl_log_global_set_log_global_field_sync(tbl_log_global_t *p_log_glb, tbl_log_global_field_id_t field_id, uint32 sync);

int32
tbl_log_global_set_log_global_field(tbl_log_global_t *p_log_glb, tbl_log_global_field_id_t field_id);

tbl_log_global_t*
tbl_log_global_get_log_global();

int32
tbl_log_global_dump_one(tbl_log_global_t *p_log_glb, tbl_iter_args_t *pargs);

int32
tbl_log_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_log_global_t*
tbl_log_global_init_log_global();

#endif /* !__TBL_LOG_GLOBAL_H__ */


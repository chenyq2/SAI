
#ifndef __TBL_CHSM_DEBUG_H__
#define __TBL_CHSM_DEBUG_H__

int32
tbl_chsm_debug_set_chsm_debug_field_sync(tbl_chsm_debug_t *p_chsmdbg, tbl_chsm_debug_field_id_t field_id, uint32 sync);

int32
tbl_chsm_debug_set_chsm_debug_field(tbl_chsm_debug_t *p_chsmdbg, tbl_chsm_debug_field_id_t field_id);

tbl_chsm_debug_t*
tbl_chsm_debug_get_chsm_debug();

int32
tbl_chsm_debug_dump_one(tbl_chsm_debug_t *p_chsmdbg, tbl_iter_args_t *pargs);

int32
tbl_chsm_debug_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_chsm_debug_t*
tbl_chsm_debug_init_chsm_debug();

#endif /* !__TBL_CHSM_DEBUG_H__ */


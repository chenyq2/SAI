
#ifndef __TBL_ARPINSP_H__
#define __TBL_ARPINSP_H__

int32
tbl_arpinsp_add_arpinsp_sync(tbl_arpinsp_t *p_arpinsp, uint32 sync);

int32
tbl_arpinsp_del_arpinsp_sync(tbl_arpinsp_key_t *p_arpinsp_key, uint32 sync);

int32
tbl_arpinsp_set_arpinsp_field_sync(tbl_arpinsp_t *p_arpinsp, tbl_arpinsp_field_id_t field_id, uint32 sync);

int32
tbl_arpinsp_add_arpinsp(tbl_arpinsp_t *p_arpinsp);

int32
tbl_arpinsp_del_arpinsp(tbl_arpinsp_key_t *p_arpinsp_key);

int32
tbl_arpinsp_set_arpinsp_field(tbl_arpinsp_t *p_arpinsp, tbl_arpinsp_field_id_t field_id);

tbl_arpinsp_t*
tbl_arpinsp_get_arpinsp(tbl_arpinsp_key_t *p_arpinsp_key);

char*
tbl_arpinsp_key_val2str(tbl_arpinsp_t *p_arpinsp, char *str, uint32 str_len);

int32
tbl_arpinsp_dump_one(tbl_arpinsp_t *p_arpinsp, tbl_iter_args_t *pargs);

int32
tbl_arpinsp_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_arpinsp_master_t*
tbl_arpinsp_get_master();

tbl_arpinsp_master_t*
tbl_arpinsp_init_arpinsp();

#endif /* !__TBL_ARPINSP_H__ */


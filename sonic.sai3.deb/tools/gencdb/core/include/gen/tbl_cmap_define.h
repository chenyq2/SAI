
#ifndef __TBL_CMAP_DEFINE_H__
#define __TBL_CMAP_DEFINE_H__

/* TBL_CMAP field defines */
typedef enum
{
    TBL_CMAP_FLD_KEY                  = 0 ,  /* RW */
    TBL_CMAP_FLD_ANY_OR_ALL           = 1 ,  /* RW */
    TBL_CMAP_FLD_MATCH_ALL_ACE_NUM    = 2 ,  /* READ */
    TBL_CMAP_FLD_ACL_COUNT            = 3 ,  /* READ */
    TBL_CMAP_FLD_MATCH_TYPE           = 4 ,  /* READ */
    TBL_CMAP_FLD_ACL_LIST             = 5 ,  /* RW */
    TBL_CMAP_FLD_MAX                  = 6 
} tbl_cmap_field_id_t;

/* TBL_CMAP defines */
typedef struct
{
    char                 name[CMAP_NAME_SIZE+1];
} tbl_cmap_key_t;

typedef struct
{
    tbl_cmap_key_t       key;
    uint8                any_or_all;
    uint16               match_all_ace_num;
    uint16               acl_count;
    uint8                match_type;
    cdb_reference_list_t acl_list;            /* access list in cmap */
} tbl_cmap_t;

typedef struct
{
    ctclib_hash_t        *cmap_hash;
    ctclib_slist_t       *cmap_list;
    uint16               count;               /* use hash count */
} tbl_cmap_master_t;

#endif /* !__TBL_CMAP_DEFINE_H__ */


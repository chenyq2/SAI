
#ifndef __CDB_TBL_INFO_PRIV_H__
#define __CDB_TBL_INFO_PRIV_H__

static cdb_tbl_info_t g_cdb_tbl_info[TBL_MAX] =
{
    {
        sizeof(tbl_interface_key_t),
        sizeof(tbl_interface_t),
        sizeof(tbl_interface_fields)/sizeof(cdb_field_t),
        tbl_interface_fields,
        {
            tbl_interface_iterate,
            (TBL_DUMP_FUNC)tbl_interface_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_interface_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_route_if_key_t),
        sizeof(tbl_route_if_t),
        sizeof(tbl_route_if_fields)/sizeof(cdb_field_t),
        tbl_route_if_fields,
        {
            tbl_route_if_iterate,
            (TBL_DUMP_FUNC)tbl_route_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_route_if_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_kernel_if_key_t),
        sizeof(tbl_kernel_if_t),
        sizeof(tbl_kernel_if_fields)/sizeof(cdb_field_t),
        tbl_kernel_if_fields,
        {
            tbl_kernel_if_iterate,
            (TBL_DUMP_FUNC)tbl_kernel_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_kernel_if_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_port_if_key_t),
        sizeof(tbl_fea_port_if_t),
        sizeof(tbl_fea_port_if_fields)/sizeof(cdb_field_t),
        tbl_fea_port_if_fields,
        {
            tbl_fea_port_if_iterate,
            (TBL_DUMP_FUNC)tbl_fea_port_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_port_if_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_vlan_key_t),
        sizeof(tbl_vlan_t),
        sizeof(tbl_vlan_fields)/sizeof(cdb_field_t),
        tbl_vlan_fields,
        {
            tbl_vlan_iterate,
            (TBL_DUMP_FUNC)tbl_vlan_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_vlan_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_pvlan_key_t),
        sizeof(tbl_pvlan_t),
        sizeof(tbl_pvlan_fields)/sizeof(cdb_field_t),
        tbl_pvlan_fields,
        {
            tbl_pvlan_iterate,
            (TBL_DUMP_FUNC)tbl_pvlan_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_pvlan_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fdb_key_t),
        sizeof(tbl_fdb_t),
        sizeof(tbl_fdb_fields)/sizeof(cdb_field_t),
        tbl_fdb_fields,
        {
            tbl_fdb_iterate,
            (TBL_DUMP_FUNC)tbl_fdb_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fdb_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_mcfdb_key_t),
        sizeof(tbl_mcfdb_t),
        sizeof(tbl_mcfdb_fields)/sizeof(cdb_field_t),
        tbl_mcfdb_fields,
        {
            tbl_mcfdb_iterate,
            (TBL_DUMP_FUNC)tbl_mcfdb_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mcfdb_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_macfilter_key_t),
        sizeof(tbl_macfilter_t),
        sizeof(tbl_macfilter_fields)/sizeof(cdb_field_t),
        tbl_macfilter_fields,
        {
            tbl_macfilter_iterate,
            (TBL_DUMP_FUNC)tbl_macfilter_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_macfilter_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_psfdb_key_t),
        sizeof(tbl_psfdb_t),
        sizeof(tbl_psfdb_fields)/sizeof(cdb_field_t),
        tbl_psfdb_fields,
        {
            tbl_psfdb_iterate,
            (TBL_DUMP_FUNC)tbl_psfdb_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_psfdb_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ipsg_s_ip_key_t),
        sizeof(tbl_ipsg_s_ip_t),
        sizeof(tbl_ipsg_s_ip_fields)/sizeof(cdb_field_t),
        tbl_ipsg_s_ip_fields,
        {
            tbl_ipsg_s_ip_iterate,
            (TBL_DUMP_FUNC)tbl_ipsg_s_ip_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ipsg_s_ip_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ipsg_s_mac_key_t),
        sizeof(tbl_ipsg_s_mac_t),
        sizeof(tbl_ipsg_s_mac_fields)/sizeof(cdb_field_t),
        tbl_ipsg_s_mac_fields,
        {
            tbl_ipsg_s_mac_iterate,
            (TBL_DUMP_FUNC)tbl_ipsg_s_mac_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ipsg_s_mac_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ipsg_fib_key_t),
        sizeof(tbl_ipsg_fib_t),
        sizeof(tbl_ipsg_fib_fields)/sizeof(cdb_field_t),
        tbl_ipsg_fib_fields,
        {
            tbl_ipsg_fib_iterate,
            (TBL_DUMP_FUNC)tbl_ipsg_fib_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ipsg_fib_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_brg_global_t),
        sizeof(tbl_brg_global_fields)/sizeof(cdb_field_t),
        tbl_brg_global_fields,
        {
            tbl_brg_global_iterate,
            (TBL_DUMP_FUNC)tbl_brg_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_mstp_port_key_t),
        sizeof(tbl_mstp_port_t),
        sizeof(tbl_mstp_port_fields)/sizeof(cdb_field_t),
        tbl_mstp_port_fields,
        {
            tbl_mstp_port_iterate,
            (TBL_DUMP_FUNC)tbl_mstp_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mstp_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_msti_port_key_t),
        sizeof(tbl_msti_port_t),
        sizeof(tbl_msti_port_fields)/sizeof(cdb_field_t),
        tbl_msti_port_fields,
        {
            tbl_msti_port_iterate,
            (TBL_DUMP_FUNC)tbl_msti_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_msti_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_mstp_instance_key_t),
        sizeof(tbl_mstp_instance_t),
        sizeof(tbl_mstp_instance_fields)/sizeof(cdb_field_t),
        tbl_mstp_instance_fields,
        {
            tbl_mstp_instance_iterate,
            (TBL_DUMP_FUNC)tbl_mstp_instance_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mstp_instance_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_mstp_global_t),
        sizeof(tbl_mstp_global_fields)/sizeof(cdb_field_t),
        tbl_mstp_global_fields,
        {
            tbl_mstp_global_iterate,
            (TBL_DUMP_FUNC)tbl_mstp_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_lldp_global_t),
        sizeof(tbl_lldp_global_fields)/sizeof(cdb_field_t),
        tbl_lldp_global_fields,
        {
            tbl_lldp_global_iterate,
            (TBL_DUMP_FUNC)tbl_lldp_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_lldp_if_key_t),
        sizeof(tbl_lldp_if_t),
        sizeof(tbl_lldp_if_fields)/sizeof(cdb_field_t),
        tbl_lldp_if_fields,
        {
            tbl_lldp_if_iterate,
            (TBL_DUMP_FUNC)tbl_lldp_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_lldp_if_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_mlag_t),
        sizeof(tbl_mlag_fields)/sizeof(cdb_field_t),
        tbl_mlag_fields,
        {
            tbl_mlag_iterate,
            (TBL_DUMP_FUNC)tbl_mlag_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_mlag_peer_t),
        sizeof(tbl_mlag_peer_fields)/sizeof(cdb_field_t),
        tbl_mlag_peer_fields,
        {
            tbl_mlag_peer_iterate,
            (TBL_DUMP_FUNC)tbl_mlag_peer_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_mlag_port_key_t),
        sizeof(tbl_mlag_port_t),
        sizeof(tbl_mlag_port_fields)/sizeof(cdb_field_t),
        tbl_mlag_port_fields,
        {
            tbl_mlag_port_iterate,
            (TBL_DUMP_FUNC)tbl_mlag_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mlag_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_isolation_key_t),
        sizeof(tbl_isolation_t),
        sizeof(tbl_isolation_fields)/sizeof(cdb_field_t),
        tbl_isolation_fields,
        {
            tbl_isolation_iterate,
            (TBL_DUMP_FUNC)tbl_isolation_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_isolation_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_route_global_t),
        sizeof(tbl_route_global_fields)/sizeof(cdb_field_t),
        tbl_route_global_fields,
        {
            tbl_route_global_iterate,
            (TBL_DUMP_FUNC)tbl_route_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_ospf_key_t),
        sizeof(tbl_ospf_t),
        sizeof(tbl_ospf_fields)/sizeof(cdb_field_t),
        tbl_ospf_fields,
        {
            tbl_ospf_iterate,
            (TBL_DUMP_FUNC)tbl_ospf_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ospf_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ospf_network_key_t),
        sizeof(tbl_ospf_network_t),
        sizeof(tbl_ospf_network_fields)/sizeof(cdb_field_t),
        tbl_ospf_network_fields,
        {
            tbl_ospf_network_iterate,
            (TBL_DUMP_FUNC)tbl_ospf_network_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ospf_network_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ospf_area_auth_key_t),
        sizeof(tbl_ospf_area_auth_t),
        sizeof(tbl_ospf_area_auth_fields)/sizeof(cdb_field_t),
        tbl_ospf_area_auth_fields,
        {
            tbl_ospf_area_auth_iterate,
            (TBL_DUMP_FUNC)tbl_ospf_area_auth_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ospf_area_auth_key_val2str,
            NULL
        }
    },
    {
        sizeof(nexthop_key_t),
        sizeof(tbl_iproute_node_t),
        sizeof(tbl_iproute_node_fields)/sizeof(cdb_field_t),
        tbl_iproute_node_fields,
        {
            tbl_iproute_node_iterate,
            (TBL_DUMP_FUNC)tbl_iproute_node_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_iproute_node_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_static_route_cfg_key_t),
        sizeof(tbl_static_route_cfg_t),
        sizeof(tbl_static_route_cfg_fields)/sizeof(cdb_field_t),
        tbl_static_route_cfg_fields,
        {
            tbl_static_route_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_static_route_cfg_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_static_route_cfg_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_static_rt_cnt_key_t),
        sizeof(tbl_static_rt_cnt_t),
        sizeof(tbl_static_rt_cnt_fields)/sizeof(cdb_field_t),
        tbl_static_rt_cnt_fields,
        {
            tbl_static_rt_cnt_iterate,
            (TBL_DUMP_FUNC)tbl_static_rt_cnt_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_static_rt_cnt_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_arp_fib_key_t),
        sizeof(tbl_arp_fib_t),
        sizeof(tbl_arp_fib_fields)/sizeof(cdb_field_t),
        tbl_arp_fib_fields,
        {
            tbl_arp_fib_iterate,
            (TBL_DUMP_FUNC)tbl_arp_fib_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_arp_fib_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_arp_key_t),
        sizeof(tbl_arp_t),
        sizeof(tbl_arp_fields)/sizeof(cdb_field_t),
        tbl_arp_fields,
        {
            tbl_arp_iterate,
            (TBL_DUMP_FUNC)tbl_arp_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_arp_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_nexthop_key_t),
        sizeof(tbl_nexthop_t),
        sizeof(tbl_nexthop_fields)/sizeof(cdb_field_t),
        tbl_nexthop_fields,
        {
            tbl_nexthop_iterate,
            (TBL_DUMP_FUNC)tbl_nexthop_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_nexthop_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_nexthop_group_key_t),
        sizeof(tbl_nexthop_group_t),
        sizeof(tbl_nexthop_group_fields)/sizeof(cdb_field_t),
        tbl_nexthop_group_fields,
        {
            tbl_nexthop_group_iterate,
            (TBL_DUMP_FUNC)tbl_nexthop_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_nexthop_group_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_nexthop_key_t),
        sizeof(tbl_fea_nexthop_t),
        sizeof(tbl_fea_nexthop_fields)/sizeof(cdb_field_t),
        tbl_fea_nexthop_fields,
        {
            tbl_fea_nexthop_iterate,
            (TBL_DUMP_FUNC)tbl_fea_nexthop_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_nexthop_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_sys_global_t),
        sizeof(tbl_sys_global_fields)/sizeof(cdb_field_t),
        tbl_sys_global_fields,
        {
            tbl_sys_global_iterate,
            (TBL_DUMP_FUNC)tbl_sys_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_lag_global_t),
        sizeof(tbl_lag_global_fields)/sizeof(cdb_field_t),
        tbl_lag_global_fields,
        {
            tbl_lag_global_iterate,
            (TBL_DUMP_FUNC)tbl_lag_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_mem_summary_t),
        sizeof(tbl_mem_summary_fields)/sizeof(cdb_field_t),
        tbl_mem_summary_fields,
        {
            tbl_mem_summary_iterate,
            (TBL_DUMP_FUNC)tbl_mem_summary_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_chsm_debug_t),
        sizeof(tbl_chsm_debug_fields)/sizeof(cdb_field_t),
        tbl_chsm_debug_fields,
        {
            tbl_chsm_debug_iterate,
            (TBL_DUMP_FUNC)tbl_chsm_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_switch_debug_t),
        sizeof(tbl_switch_debug_fields)/sizeof(cdb_field_t),
        tbl_switch_debug_fields,
        {
            tbl_switch_debug_iterate,
            (TBL_DUMP_FUNC)tbl_switch_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_route_debug_t),
        sizeof(tbl_route_debug_fields)/sizeof(cdb_field_t),
        tbl_route_debug_fields,
        {
            tbl_route_debug_iterate,
            (TBL_DUMP_FUNC)tbl_route_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_quagga_debug_t),
        sizeof(tbl_quagga_debug_fields)/sizeof(cdb_field_t),
        tbl_quagga_debug_fields,
        {
            tbl_quagga_debug_iterate,
            (TBL_DUMP_FUNC)tbl_quagga_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_lsrv_debug_t),
        sizeof(tbl_lsrv_debug_fields)/sizeof(cdb_field_t),
        tbl_lsrv_debug_fields,
        {
            tbl_lsrv_debug_iterate,
            (TBL_DUMP_FUNC)tbl_lsrv_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_hsrv_debug_t),
        sizeof(tbl_hsrv_debug_fields)/sizeof(cdb_field_t),
        tbl_hsrv_debug_fields,
        {
            tbl_hsrv_debug_iterate,
            (TBL_DUMP_FUNC)tbl_hsrv_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_rif_key_t),
        sizeof(tbl_rif_t),
        sizeof(tbl_rif_fields)/sizeof(cdb_field_t),
        tbl_rif_fields,
        {
            tbl_rif_iterate,
            (TBL_DUMP_FUNC)tbl_rif_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_rif_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_lag_key_t),
        sizeof(tbl_fea_lag_t),
        sizeof(tbl_fea_lag_fields)/sizeof(cdb_field_t),
        tbl_fea_lag_fields,
        {
            tbl_fea_lag_iterate,
            (TBL_DUMP_FUNC)tbl_fea_lag_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_lag_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_fea_global_t),
        sizeof(tbl_fea_global_fields)/sizeof(cdb_field_t),
        tbl_fea_global_fields,
        {
            tbl_fea_global_iterate,
            (TBL_DUMP_FUNC)tbl_fea_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_fea_acl_table_key_t),
        sizeof(tbl_fea_acl_table_t),
        sizeof(tbl_fea_acl_table_fields)/sizeof(cdb_field_t),
        tbl_fea_acl_table_fields,
        {
            tbl_fea_acl_table_iterate,
            (TBL_DUMP_FUNC)tbl_fea_acl_table_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_acl_table_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_acl_key_t),
        sizeof(tbl_fea_acl_t),
        sizeof(tbl_fea_acl_fields)/sizeof(cdb_field_t),
        tbl_fea_acl_fields,
        {
            tbl_fea_acl_iterate,
            (TBL_DUMP_FUNC)tbl_fea_acl_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_acl_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_fdb_key_t),
        sizeof(tbl_fea_fdb_t),
        sizeof(tbl_fea_fdb_fields)/sizeof(cdb_field_t),
        tbl_fea_fdb_fields,
        {
            tbl_fea_fdb_iterate,
            (TBL_DUMP_FUNC)tbl_fea_fdb_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_fdb_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_brg_if_key_t),
        sizeof(tbl_fea_brg_if_t),
        sizeof(tbl_fea_brg_if_fields)/sizeof(cdb_field_t),
        tbl_fea_brg_if_fields,
        {
            tbl_fea_brg_if_iterate,
            (TBL_DUMP_FUNC)tbl_fea_brg_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_brg_if_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_worm_filter_key_t),
        sizeof(tbl_acl_worm_filter_t),
        sizeof(tbl_acl_worm_filter_fields)/sizeof(cdb_field_t),
        tbl_acl_worm_filter_fields,
        {
            tbl_acl_worm_filter_iterate,
            (TBL_DUMP_FUNC)tbl_acl_worm_filter_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_worm_filter_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_config_key_t),
        sizeof(tbl_acl_config_t),
        sizeof(tbl_acl_config_fields)/sizeof(cdb_field_t),
        tbl_acl_config_fields,
        {
            tbl_acl_config_iterate,
            (TBL_DUMP_FUNC)tbl_acl_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ace_config_key_t),
        sizeof(tbl_ace_config_t),
        sizeof(tbl_ace_config_fields)/sizeof(cdb_field_t),
        tbl_ace_config_fields,
        {
            tbl_ace_config_iterate,
            (TBL_DUMP_FUNC)tbl_ace_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ace_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_entry_key_t),
        sizeof(tbl_acl_entry_t),
        sizeof(tbl_acl_entry_fields)/sizeof(cdb_field_t),
        tbl_acl_entry_fields,
        {
            tbl_acl_entry_iterate,
            (TBL_DUMP_FUNC)tbl_acl_entry_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_entry_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_entry_action_key_t),
        sizeof(tbl_acl_entry_action_t),
        sizeof(tbl_acl_entry_action_fields)/sizeof(cdb_field_t),
        tbl_acl_entry_action_fields,
        {
            tbl_acl_entry_action_iterate,
            (TBL_DUMP_FUNC)tbl_acl_entry_action_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_entry_action_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_nexthop_group_key_t),
        sizeof(tbl_acl_nexthop_group_t),
        sizeof(tbl_acl_nexthop_group_fields)/sizeof(cdb_field_t),
        tbl_acl_nexthop_group_fields,
        {
            tbl_acl_nexthop_group_iterate,
            (TBL_DUMP_FUNC)tbl_acl_nexthop_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_nexthop_group_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_nexthop_key_t),
        sizeof(tbl_acl_nexthop_t),
        sizeof(tbl_acl_nexthop_fields)/sizeof(cdb_field_t),
        tbl_acl_nexthop_fields,
        {
            tbl_acl_nexthop_iterate,
            (TBL_DUMP_FUNC)tbl_acl_nexthop_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_nexthop_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_pmap_key_t),
        sizeof(tbl_pmap_t),
        sizeof(tbl_pmap_fields)/sizeof(cdb_field_t),
        tbl_pmap_fields,
        {
            tbl_pmap_iterate,
            (TBL_DUMP_FUNC)tbl_pmap_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_pmap_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_cmap_key_t),
        sizeof(tbl_cmap_t),
        sizeof(tbl_cmap_fields)/sizeof(cdb_field_t),
        tbl_cmap_fields,
        {
            tbl_cmap_iterate,
            (TBL_DUMP_FUNC)tbl_cmap_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cmap_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_key_t),
        sizeof(tbl_acl_t),
        sizeof(tbl_acl_fields)/sizeof(cdb_field_t),
        tbl_acl_fields,
        {
            tbl_acl_iterate,
            (TBL_DUMP_FUNC)tbl_acl_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_time_range_key_t),
        sizeof(tbl_time_range_t),
        sizeof(tbl_time_range_fields)/sizeof(cdb_field_t),
        tbl_time_range_fields,
        {
            tbl_time_range_iterate,
            (TBL_DUMP_FUNC)tbl_time_range_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_time_range_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_ssh_cfg_t),
        sizeof(tbl_ssh_cfg_fields)/sizeof(cdb_field_t),
        tbl_ssh_cfg_fields,
        {
            tbl_ssh_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_ssh_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_snmp_cfg_t),
        sizeof(tbl_snmp_cfg_fields)/sizeof(cdb_field_t),
        tbl_snmp_cfg_fields,
        {
            tbl_snmp_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_snmp_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_snmp_view_key_t),
        sizeof(tbl_snmp_view_t),
        sizeof(tbl_snmp_view_fields)/sizeof(cdb_field_t),
        tbl_snmp_view_fields,
        {
            tbl_snmp_view_iterate,
            (TBL_DUMP_FUNC)tbl_snmp_view_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_snmp_view_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_snmp_community_key_t),
        sizeof(tbl_snmp_community_t),
        sizeof(tbl_snmp_community_fields)/sizeof(cdb_field_t),
        tbl_snmp_community_fields,
        {
            tbl_snmp_community_iterate,
            (TBL_DUMP_FUNC)tbl_snmp_community_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_snmp_community_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_snmp_trap_key_t),
        sizeof(tbl_snmp_trap_t),
        sizeof(tbl_snmp_trap_fields)/sizeof(cdb_field_t),
        tbl_snmp_trap_fields,
        {
            tbl_snmp_trap_iterate,
            (TBL_DUMP_FUNC)tbl_snmp_trap_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_snmp_trap_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_snmp_inform_key_t),
        sizeof(tbl_snmp_inform_t),
        sizeof(tbl_snmp_inform_fields)/sizeof(cdb_field_t),
        tbl_snmp_inform_fields,
        {
            tbl_snmp_inform_iterate,
            (TBL_DUMP_FUNC)tbl_snmp_inform_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_snmp_inform_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_syslog_cfg_t),
        sizeof(tbl_syslog_cfg_fields)/sizeof(cdb_field_t),
        tbl_syslog_cfg_fields,
        {
            tbl_syslog_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_syslog_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_ntp_server_key_t),
        sizeof(tbl_ntp_server_t),
        sizeof(tbl_ntp_server_fields)/sizeof(cdb_field_t),
        tbl_ntp_server_fields,
        {
            tbl_ntp_server_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_server_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ntp_server_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ntp_ace_key_t),
        sizeof(tbl_ntp_ace_t),
        sizeof(tbl_ntp_ace_fields)/sizeof(cdb_field_t),
        tbl_ntp_ace_fields,
        {
            tbl_ntp_ace_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_ace_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ntp_ace_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ntp_key_key_t),
        sizeof(tbl_ntp_key_t),
        sizeof(tbl_ntp_key_fields)/sizeof(cdb_field_t),
        tbl_ntp_key_fields,
        {
            tbl_ntp_key_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_key_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ntp_key_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_ntp_cfg_t),
        sizeof(tbl_ntp_cfg_fields)/sizeof(cdb_field_t),
        tbl_ntp_cfg_fields,
        {
            tbl_ntp_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_ntp_if_t),
        sizeof(tbl_ntp_if_fields)/sizeof(cdb_field_t),
        tbl_ntp_if_fields,
        {
            tbl_ntp_if_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_if_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_ntp_syncstatus_t),
        sizeof(tbl_ntp_syncstatus_fields)/sizeof(cdb_field_t),
        tbl_ntp_syncstatus_fields,
        {
            tbl_ntp_syncstatus_iterate,
            (TBL_DUMP_FUNC)tbl_ntp_syncstatus_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_static_dns_key_t),
        sizeof(tbl_static_dns_t),
        sizeof(tbl_static_dns_fields)/sizeof(cdb_field_t),
        tbl_static_dns_fields,
        {
            tbl_static_dns_iterate,
            (TBL_DUMP_FUNC)tbl_static_dns_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_static_dns_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_dynamic_dns_domain_key_t),
        sizeof(tbl_dynamic_dns_domain_t),
        sizeof(tbl_dynamic_dns_domain_fields)/sizeof(cdb_field_t),
        tbl_dynamic_dns_domain_fields,
        {
            tbl_dynamic_dns_domain_iterate,
            (TBL_DUMP_FUNC)tbl_dynamic_dns_domain_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dynamic_dns_domain_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_dynamic_dns_server_key_t),
        sizeof(tbl_dynamic_dns_server_t),
        sizeof(tbl_dynamic_dns_server_fields)/sizeof(cdb_field_t),
        tbl_dynamic_dns_server_fields,
        {
            tbl_dynamic_dns_server_iterate,
            (TBL_DUMP_FUNC)tbl_dynamic_dns_server_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dynamic_dns_server_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_qos_domain_key_t),
        sizeof(tbl_qos_domain_t),
        sizeof(tbl_qos_domain_fields)/sizeof(cdb_field_t),
        tbl_qos_domain_fields,
        {
            tbl_qos_domain_iterate,
            (TBL_DUMP_FUNC)tbl_qos_domain_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_qos_domain_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_qos_policer_profile_key_t),
        sizeof(tbl_qos_policer_profile_t),
        sizeof(tbl_qos_policer_profile_fields)/sizeof(cdb_field_t),
        tbl_qos_policer_profile_fields,
        {
            tbl_qos_policer_profile_iterate,
            (TBL_DUMP_FUNC)tbl_qos_policer_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_qos_policer_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_qos_drop_profile_key_t),
        sizeof(tbl_qos_drop_profile_t),
        sizeof(tbl_qos_drop_profile_fields)/sizeof(cdb_field_t),
        tbl_qos_drop_profile_fields,
        {
            tbl_qos_drop_profile_iterate,
            (TBL_DUMP_FUNC)tbl_qos_drop_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_qos_drop_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_qos_queue_shape_profile_key_t),
        sizeof(tbl_qos_queue_shape_profile_t),
        sizeof(tbl_qos_queue_shape_profile_fields)/sizeof(cdb_field_t),
        tbl_qos_queue_shape_profile_fields,
        {
            tbl_qos_queue_shape_profile_iterate,
            (TBL_DUMP_FUNC)tbl_qos_queue_shape_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_qos_queue_shape_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_qos_port_shape_profile_key_t),
        sizeof(tbl_qos_port_shape_profile_t),
        sizeof(tbl_qos_port_shape_profile_fields)/sizeof(cdb_field_t),
        tbl_qos_port_shape_profile_fields,
        {
            tbl_qos_port_shape_profile_iterate,
            (TBL_DUMP_FUNC)tbl_qos_port_shape_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_qos_port_shape_profile_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_qos_global_t),
        sizeof(tbl_qos_global_fields)/sizeof(cdb_field_t),
        tbl_qos_global_fields,
        {
            tbl_qos_global_iterate,
            (TBL_DUMP_FUNC)tbl_qos_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_mirror_key_t),
        sizeof(tbl_mirror_t),
        sizeof(tbl_mirror_fields)/sizeof(cdb_field_t),
        tbl_mirror_fields,
        {
            tbl_mirror_iterate,
            (TBL_DUMP_FUNC)tbl_mirror_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mirror_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_mirror_mac_escape_key_t),
        sizeof(tbl_mirror_mac_escape_t),
        sizeof(tbl_mirror_mac_escape_fields)/sizeof(cdb_field_t),
        tbl_mirror_mac_escape_fields,
        {
            tbl_mirror_mac_escape_iterate,
            (TBL_DUMP_FUNC)tbl_mirror_mac_escape_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_mirror_mac_escape_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_tap_group_ingress_key_t),
        sizeof(tbl_tap_group_ingress_t),
        sizeof(tbl_tap_group_ingress_fields)/sizeof(cdb_field_t),
        tbl_tap_group_ingress_fields,
        {
            tbl_tap_group_ingress_iterate,
            (TBL_DUMP_FUNC)tbl_tap_group_ingress_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_tap_group_ingress_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_tap_group_ingress_flow_key_t),
        sizeof(tbl_tap_group_ingress_flow_t),
        sizeof(tbl_tap_group_ingress_flow_fields)/sizeof(cdb_field_t),
        tbl_tap_group_ingress_flow_fields,
        {
            tbl_tap_group_ingress_flow_iterate,
            (TBL_DUMP_FUNC)tbl_tap_group_ingress_flow_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_tap_group_ingress_flow_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_tap_group_egress_key_t),
        sizeof(tbl_tap_group_egress_t),
        sizeof(tbl_tap_group_egress_fields)/sizeof(cdb_field_t),
        tbl_tap_group_egress_fields,
        {
            tbl_tap_group_egress_iterate,
            (TBL_DUMP_FUNC)tbl_tap_group_egress_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_tap_group_egress_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_tap_group_key_t),
        sizeof(tbl_tap_group_t),
        sizeof(tbl_tap_group_fields)/sizeof(cdb_field_t),
        tbl_tap_group_fields,
        {
            tbl_tap_group_iterate,
            (TBL_DUMP_FUNC)tbl_tap_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_tap_group_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_user_key_t),
        sizeof(tbl_user_t),
        sizeof(tbl_user_fields)/sizeof(cdb_field_t),
        tbl_user_fields,
        {
            tbl_user_iterate,
            (TBL_DUMP_FUNC)tbl_user_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_user_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_vty_key_t),
        sizeof(tbl_vty_t),
        sizeof(tbl_vty_fields)/sizeof(cdb_field_t),
        tbl_vty_fields,
        {
            tbl_vty_iterate,
            (TBL_DUMP_FUNC)tbl_vty_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_vty_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_console_t),
        sizeof(tbl_console_fields)/sizeof(cdb_field_t),
        tbl_console_fields,
        {
            tbl_console_iterate,
            (TBL_DUMP_FUNC)tbl_console_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_authen_key_t),
        sizeof(tbl_authen_t),
        sizeof(tbl_authen_fields)/sizeof(cdb_field_t),
        tbl_authen_fields,
        {
            tbl_authen_iterate,
            (TBL_DUMP_FUNC)tbl_authen_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_authen_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_login_key_t),
        sizeof(tbl_login_t),
        sizeof(tbl_login_fields)/sizeof(cdb_field_t),
        tbl_login_fields,
        {
            tbl_login_iterate,
            (TBL_DUMP_FUNC)tbl_login_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_login_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_rsa_key_t),
        sizeof(tbl_rsa_t),
        sizeof(tbl_rsa_fields)/sizeof(cdb_field_t),
        tbl_rsa_fields,
        {
            tbl_rsa_iterate,
            (TBL_DUMP_FUNC)tbl_rsa_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_rsa_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_openflow_t),
        sizeof(tbl_openflow_fields)/sizeof(cdb_field_t),
        tbl_openflow_fields,
        {
            tbl_openflow_iterate,
            (TBL_DUMP_FUNC)tbl_openflow_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_cpu_traffic_key_t),
        sizeof(tbl_cpu_traffic_t),
        sizeof(tbl_cpu_traffic_fields)/sizeof(cdb_field_t),
        tbl_cpu_traffic_fields,
        {
            tbl_cpu_traffic_iterate,
            (TBL_DUMP_FUNC)tbl_cpu_traffic_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cpu_traffic_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_cpu_traffic_group_key_t),
        sizeof(tbl_cpu_traffic_group_t),
        sizeof(tbl_cpu_traffic_group_fields)/sizeof(cdb_field_t),
        tbl_cpu_traffic_group_fields,
        {
            tbl_cpu_traffic_group_iterate,
            (TBL_DUMP_FUNC)tbl_cpu_traffic_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cpu_traffic_group_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_cpu_utilization_key_t),
        sizeof(tbl_cpu_utilization_t),
        sizeof(tbl_cpu_utilization_fields)/sizeof(cdb_field_t),
        tbl_cpu_utilization_fields,
        {
            tbl_cpu_utilization_iterate,
            (TBL_DUMP_FUNC)tbl_cpu_utilization_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cpu_utilization_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_cpu_limit_key_t),
        sizeof(tbl_cpu_limit_t),
        sizeof(tbl_cpu_limit_fields)/sizeof(cdb_field_t),
        tbl_cpu_limit_fields,
        {
            tbl_cpu_limit_iterate,
            (TBL_DUMP_FUNC)tbl_cpu_limit_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cpu_limit_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_dhcrelay_t),
        sizeof(tbl_dhcrelay_fields)/sizeof(cdb_field_t),
        tbl_dhcrelay_fields,
        {
            tbl_dhcrelay_iterate,
            (TBL_DUMP_FUNC)tbl_dhcrelay_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_dhcsrvgrp_key_t),
        sizeof(tbl_dhcsrvgrp_t),
        sizeof(tbl_dhcsrvgrp_fields)/sizeof(cdb_field_t),
        tbl_dhcsrvgrp_fields,
        {
            tbl_dhcsrvgrp_iterate,
            (TBL_DUMP_FUNC)tbl_dhcsrvgrp_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dhcsrvgrp_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_dhcp_debug_t),
        sizeof(tbl_dhcp_debug_fields)/sizeof(cdb_field_t),
        tbl_dhcp_debug_fields,
        {
            tbl_dhcp_debug_iterate,
            (TBL_DUMP_FUNC)tbl_dhcp_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_dhclient_t),
        sizeof(tbl_dhclient_fields)/sizeof(cdb_field_t),
        tbl_dhclient_fields,
        {
            tbl_dhclient_iterate,
            (TBL_DUMP_FUNC)tbl_dhclient_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_dhcsnooping_t),
        sizeof(tbl_dhcsnooping_fields)/sizeof(cdb_field_t),
        tbl_dhcsnooping_fields,
        {
            tbl_dhcsnooping_iterate,
            (TBL_DUMP_FUNC)tbl_dhcsnooping_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_dhcbinding_key_t),
        sizeof(tbl_dhcbinding_t),
        sizeof(tbl_dhcbinding_fields)/sizeof(cdb_field_t),
        tbl_dhcbinding_fields,
        {
            tbl_dhcbinding_iterate,
            (TBL_DUMP_FUNC)tbl_dhcbinding_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dhcbinding_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_iptables_prevent_t),
        sizeof(tbl_iptables_prevent_fields)/sizeof(cdb_field_t),
        tbl_iptables_prevent_fields,
        {
            tbl_iptables_prevent_iterate,
            (TBL_DUMP_FUNC)tbl_iptables_prevent_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_errdisable_key_t),
        sizeof(tbl_errdisable_t),
        sizeof(tbl_errdisable_fields)/sizeof(cdb_field_t),
        tbl_errdisable_fields,
        {
            tbl_errdisable_iterate,
            (TBL_DUMP_FUNC)tbl_errdisable_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_errdisable_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ns_port_forwarding_key_t),
        sizeof(tbl_ns_port_forwarding_t),
        sizeof(tbl_ns_port_forwarding_fields)/sizeof(cdb_field_t),
        tbl_ns_port_forwarding_fields,
        {
            tbl_ns_port_forwarding_iterate,
            (TBL_DUMP_FUNC)tbl_ns_port_forwarding_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ns_port_forwarding_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_log_global_t),
        sizeof(tbl_log_global_fields)/sizeof(cdb_field_t),
        tbl_log_global_fields,
        {
            tbl_log_global_iterate,
            (TBL_DUMP_FUNC)tbl_log_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_log_key_t),
        sizeof(tbl_log_t),
        sizeof(tbl_log_fields)/sizeof(cdb_field_t),
        tbl_log_fields,
        {
            tbl_log_iterate,
            (TBL_DUMP_FUNC)tbl_log_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_log_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_sys_load_t),
        sizeof(tbl_sys_load_fields)/sizeof(cdb_field_t),
        tbl_sys_load_fields,
        {
            tbl_sys_load_iterate,
            (TBL_DUMP_FUNC)tbl_sys_load_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_cem_key_t),
        sizeof(tbl_cem_t),
        sizeof(tbl_cem_fields)/sizeof(cdb_field_t),
        tbl_cem_fields,
        {
            tbl_cem_iterate,
            (TBL_DUMP_FUNC)tbl_cem_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_cem_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_clock_t),
        sizeof(tbl_clock_fields)/sizeof(cdb_field_t),
        tbl_clock_fields,
        {
            tbl_clock_iterate,
            (TBL_DUMP_FUNC)tbl_clock_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_port_stats_key_t),
        sizeof(tbl_port_stats_t),
        sizeof(tbl_port_stats_fields)/sizeof(cdb_field_t),
        tbl_port_stats_fields,
        {
            tbl_port_stats_iterate,
            (TBL_DUMP_FUNC)tbl_port_stats_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_port_stats_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_port_stats_rate_key_t),
        sizeof(tbl_port_stats_rate_t),
        sizeof(tbl_port_stats_rate_fields)/sizeof(cdb_field_t),
        tbl_port_stats_rate_fields,
        {
            tbl_port_stats_rate_iterate,
            (TBL_DUMP_FUNC)tbl_port_stats_rate_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_port_stats_rate_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_aclqos_if_key_t),
        sizeof(tbl_aclqos_if_t),
        sizeof(tbl_aclqos_if_fields)/sizeof(cdb_field_t),
        tbl_aclqos_if_fields,
        {
            tbl_aclqos_if_iterate,
            (TBL_DUMP_FUNC)tbl_aclqos_if_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_aclqos_if_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_l2_action_t),
        sizeof(tbl_l2_action_fields)/sizeof(cdb_field_t),
        tbl_l2_action_fields,
        {
            tbl_l2_action_iterate,
            (TBL_DUMP_FUNC)tbl_l2_action_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_fea_qos_drop_profile_key_t),
        sizeof(tbl_fea_qos_drop_profile_t),
        sizeof(tbl_fea_qos_drop_profile_fields)/sizeof(cdb_field_t),
        tbl_fea_qos_drop_profile_fields,
        {
            tbl_fea_qos_drop_profile_iterate,
            (TBL_DUMP_FUNC)tbl_fea_qos_drop_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_qos_drop_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_qos_domain_key_t),
        sizeof(tbl_fea_qos_domain_t),
        sizeof(tbl_fea_qos_domain_fields)/sizeof(cdb_field_t),
        tbl_fea_qos_domain_fields,
        {
            tbl_fea_qos_domain_iterate,
            (TBL_DUMP_FUNC)tbl_fea_qos_domain_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_qos_domain_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_qos_queue_shape_profile_key_t),
        sizeof(tbl_fea_qos_queue_shape_profile_t),
        sizeof(tbl_fea_qos_queue_shape_profile_fields)/sizeof(cdb_field_t),
        tbl_fea_qos_queue_shape_profile_fields,
        {
            tbl_fea_qos_queue_shape_profile_iterate,
            (TBL_DUMP_FUNC)tbl_fea_qos_queue_shape_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_qos_queue_shape_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_qos_port_shape_profile_key_t),
        sizeof(tbl_fea_qos_port_shape_profile_t),
        sizeof(tbl_fea_qos_port_shape_profile_fields)/sizeof(cdb_field_t),
        tbl_fea_qos_port_shape_profile_fields,
        {
            tbl_fea_qos_port_shape_profile_iterate,
            (TBL_DUMP_FUNC)tbl_fea_qos_port_shape_profile_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_qos_port_shape_profile_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_port_policer_apply_key_t),
        sizeof(tbl_fea_port_policer_apply_t),
        sizeof(tbl_fea_port_policer_apply_fields)/sizeof(cdb_field_t),
        tbl_fea_port_policer_apply_fields,
        {
            tbl_fea_port_policer_apply_iterate,
            (TBL_DUMP_FUNC)tbl_fea_port_policer_apply_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_port_policer_apply_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_aclqos_if_stats_key_t),
        sizeof(tbl_aclqos_if_stats_t),
        sizeof(tbl_aclqos_if_stats_fields)/sizeof(cdb_field_t),
        tbl_aclqos_if_stats_fields,
        {
            tbl_aclqos_if_stats_iterate,
            (TBL_DUMP_FUNC)tbl_aclqos_if_stats_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_aclqos_if_stats_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_version_t),
        sizeof(tbl_version_fields)/sizeof(cdb_field_t),
        tbl_version_fields,
        {
            tbl_version_iterate,
            (TBL_DUMP_FUNC)tbl_version_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_manage_if_t),
        sizeof(tbl_manage_if_fields)/sizeof(cdb_field_t),
        tbl_manage_if_fields,
        {
            tbl_manage_if_iterate,
            (TBL_DUMP_FUNC)tbl_manage_if_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_bootimage_t),
        sizeof(tbl_bootimage_fields)/sizeof(cdb_field_t),
        tbl_bootimage_fields,
        {
            tbl_bootimage_iterate,
            (TBL_DUMP_FUNC)tbl_bootimage_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_chassis_t),
        sizeof(tbl_chassis_fields)/sizeof(cdb_field_t),
        tbl_chassis_fields,
        {
            tbl_chassis_iterate,
            (TBL_DUMP_FUNC)tbl_chassis_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_ifname_info_key_t),
        sizeof(tbl_ifname_info_t),
        sizeof(tbl_ifname_info_fields)/sizeof(cdb_field_t),
        tbl_ifname_info_fields,
        {
            tbl_ifname_info_iterate,
            (TBL_DUMP_FUNC)tbl_ifname_info_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ifname_info_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_card_key_t),
        sizeof(tbl_card_t),
        sizeof(tbl_card_fields)/sizeof(cdb_field_t),
        tbl_card_fields,
        {
            tbl_card_iterate,
            (TBL_DUMP_FUNC)tbl_card_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_card_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_port_key_t),
        sizeof(tbl_port_t),
        sizeof(tbl_port_fields)/sizeof(cdb_field_t),
        tbl_port_fields,
        {
            tbl_port_iterate,
            (TBL_DUMP_FUNC)tbl_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fiber_key_t),
        sizeof(tbl_fiber_t),
        sizeof(tbl_fiber_fields)/sizeof(cdb_field_t),
        tbl_fiber_fields,
        {
            tbl_fiber_iterate,
            (TBL_DUMP_FUNC)tbl_fiber_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fiber_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_sys_spec_key_t),
        sizeof(tbl_sys_spec_t),
        sizeof(tbl_sys_spec_fields)/sizeof(cdb_field_t),
        tbl_sys_spec_fields,
        {
            tbl_sys_spec_iterate,
            (TBL_DUMP_FUNC)tbl_sys_spec_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_sys_spec_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fan_key_t),
        sizeof(tbl_fan_t),
        sizeof(tbl_fan_fields)/sizeof(cdb_field_t),
        tbl_fan_fields,
        {
            tbl_fan_iterate,
            (TBL_DUMP_FUNC)tbl_fan_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fan_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_psu_key_t),
        sizeof(tbl_psu_t),
        sizeof(tbl_psu_fields)/sizeof(cdb_field_t),
        tbl_psu_fields,
        {
            tbl_psu_iterate,
            (TBL_DUMP_FUNC)tbl_psu_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_psu_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_led_key_t),
        sizeof(tbl_led_t),
        sizeof(tbl_led_fields)/sizeof(cdb_field_t),
        tbl_led_fields,
        {
            tbl_led_iterate,
            (TBL_DUMP_FUNC)tbl_led_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_led_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_sensor_key_t),
        sizeof(tbl_sensor_t),
        sizeof(tbl_sensor_fields)/sizeof(cdb_field_t),
        tbl_sensor_fields,
        {
            tbl_sensor_iterate,
            (TBL_DUMP_FUNC)tbl_sensor_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_sensor_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_reboot_info_key_t),
        sizeof(tbl_reboot_info_t),
        sizeof(tbl_reboot_info_fields)/sizeof(cdb_field_t),
        tbl_reboot_info_fields,
        {
            tbl_reboot_info_iterate,
            (TBL_DUMP_FUNC)tbl_reboot_info_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_reboot_info_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_errdisable_flap_key_t),
        sizeof(tbl_errdisable_flap_t),
        sizeof(tbl_errdisable_flap_fields)/sizeof(cdb_field_t),
        tbl_errdisable_flap_fields,
        {
            tbl_errdisable_flap_iterate,
            (TBL_DUMP_FUNC)tbl_errdisable_flap_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_errdisable_flap_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_opm_global_t),
        sizeof(tbl_opm_global_fields)/sizeof(cdb_field_t),
        tbl_opm_global_fields,
        {
            tbl_opm_global_iterate,
            (TBL_DUMP_FUNC)tbl_opm_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_erps_ring_key_t),
        sizeof(tbl_erps_ring_t),
        sizeof(tbl_erps_ring_fields)/sizeof(cdb_field_t),
        tbl_erps_ring_fields,
        {
            tbl_erps_ring_iterate,
            (TBL_DUMP_FUNC)tbl_erps_ring_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_erps_ring_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_erps_domain_key_t),
        sizeof(tbl_erps_domain_t),
        sizeof(tbl_erps_domain_fields)/sizeof(cdb_field_t),
        tbl_erps_domain_fields,
        {
            tbl_erps_domain_iterate,
            (TBL_DUMP_FUNC)tbl_erps_domain_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_erps_domain_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_opm_debug_t),
        sizeof(tbl_opm_debug_fields)/sizeof(cdb_field_t),
        tbl_opm_debug_fields,
        {
            tbl_opm_debug_iterate,
            (TBL_DUMP_FUNC)tbl_opm_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_policy_map_config_key_t),
        sizeof(tbl_policy_map_config_t),
        sizeof(tbl_policy_map_config_fields)/sizeof(cdb_field_t),
        tbl_policy_map_config_fields,
        {
            tbl_policy_map_config_iterate,
            (TBL_DUMP_FUNC)tbl_policy_map_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_policy_map_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_class_map_config_key_t),
        sizeof(tbl_class_map_config_t),
        sizeof(tbl_class_map_config_fields)/sizeof(cdb_field_t),
        tbl_class_map_config_fields,
        {
            tbl_class_map_config_iterate,
            (TBL_DUMP_FUNC)tbl_class_map_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_class_map_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_class_in_policy_config_key_t),
        sizeof(tbl_class_in_policy_config_t),
        sizeof(tbl_class_in_policy_config_fields)/sizeof(cdb_field_t),
        tbl_class_in_policy_config_fields,
        {
            tbl_class_in_policy_config_iterate,
            (TBL_DUMP_FUNC)tbl_class_in_policy_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_class_in_policy_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_in_class_config_key_t),
        sizeof(tbl_acl_in_class_config_t),
        sizeof(tbl_acl_in_class_config_fields)/sizeof(cdb_field_t),
        tbl_acl_in_class_config_fields,
        {
            tbl_acl_in_class_config_iterate,
            (TBL_DUMP_FUNC)tbl_acl_in_class_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_in_class_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_class_map_action_config_key_t),
        sizeof(tbl_class_map_action_config_t),
        sizeof(tbl_class_map_action_config_fields)/sizeof(cdb_field_t),
        tbl_class_map_action_config_fields,
        {
            tbl_class_map_action_config_iterate,
            (TBL_DUMP_FUNC)tbl_class_map_action_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_class_map_action_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_fea_acl_policy_action_key_t),
        sizeof(tbl_fea_acl_policy_action_t),
        sizeof(tbl_fea_acl_policy_action_fields)/sizeof(cdb_field_t),
        tbl_fea_acl_policy_action_fields,
        {
            tbl_fea_acl_policy_action_iterate,
            (TBL_DUMP_FUNC)tbl_fea_acl_policy_action_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_fea_acl_policy_action_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_igsp_global_t),
        sizeof(tbl_igsp_global_fields)/sizeof(cdb_field_t),
        tbl_igsp_global_fields,
        {
            tbl_igsp_global_iterate,
            (TBL_DUMP_FUNC)tbl_igsp_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_igsp_intf_key_t),
        sizeof(tbl_igsp_intf_t),
        sizeof(tbl_igsp_intf_fields)/sizeof(cdb_field_t),
        tbl_igsp_intf_fields,
        {
            tbl_igsp_intf_iterate,
            (TBL_DUMP_FUNC)tbl_igsp_intf_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_igsp_intf_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_igsp_group_key_t),
        sizeof(tbl_igsp_group_t),
        sizeof(tbl_igsp_group_fields)/sizeof(cdb_field_t),
        tbl_igsp_group_fields,
        {
            tbl_igsp_group_iterate,
            (TBL_DUMP_FUNC)tbl_igsp_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_igsp_group_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_auth_cfg_t),
        sizeof(tbl_auth_cfg_fields)/sizeof(cdb_field_t),
        tbl_auth_cfg_fields,
        {
            tbl_auth_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_auth_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_auth_server_key_t),
        sizeof(tbl_auth_server_t),
        sizeof(tbl_auth_server_fields)/sizeof(cdb_field_t),
        tbl_auth_server_fields,
        {
            tbl_auth_server_iterate,
            (TBL_DUMP_FUNC)tbl_auth_server_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_auth_server_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_auth_session_key_t),
        sizeof(tbl_auth_session_t),
        sizeof(tbl_auth_session_fields)/sizeof(cdb_field_t),
        tbl_auth_session_fields,
        {
            tbl_auth_session_iterate,
            (TBL_DUMP_FUNC)tbl_auth_session_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_auth_session_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_authd_debug_t),
        sizeof(tbl_authd_debug_fields)/sizeof(cdb_field_t),
        tbl_authd_debug_fields,
        {
            tbl_authd_debug_iterate,
            (TBL_DUMP_FUNC)tbl_authd_debug_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_dot1x_global_t),
        sizeof(tbl_dot1x_global_fields)/sizeof(cdb_field_t),
        tbl_dot1x_global_fields,
        {
            tbl_dot1x_global_iterate,
            (TBL_DUMP_FUNC)tbl_dot1x_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_dot1x_port_key_t),
        sizeof(tbl_dot1x_port_t),
        sizeof(tbl_dot1x_port_fields)/sizeof(cdb_field_t),
        tbl_dot1x_port_fields,
        {
            tbl_dot1x_port_iterate,
            (TBL_DUMP_FUNC)tbl_dot1x_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dot1x_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_dot1x_radius_key_t),
        sizeof(tbl_dot1x_radius_t),
        sizeof(tbl_dot1x_radius_fields)/sizeof(cdb_field_t),
        tbl_dot1x_radius_fields,
        {
            tbl_dot1x_radius_iterate,
            (TBL_DUMP_FUNC)tbl_dot1x_radius_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dot1x_radius_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_dot1x_mac_key_t),
        sizeof(tbl_dot1x_mac_t),
        sizeof(tbl_dot1x_mac_fields)/sizeof(cdb_field_t),
        tbl_dot1x_mac_fields,
        {
            tbl_dot1x_mac_iterate,
            (TBL_DUMP_FUNC)tbl_dot1x_mac_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_dot1x_mac_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_enable_key_t),
        sizeof(tbl_enable_t),
        sizeof(tbl_enable_fields)/sizeof(cdb_field_t),
        tbl_enable_fields,
        {
            tbl_enable_iterate,
            (TBL_DUMP_FUNC)tbl_enable_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_enable_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_chip_t),
        sizeof(tbl_chip_fields)/sizeof(cdb_field_t),
        tbl_chip_fields,
        {
            tbl_chip_iterate,
            (TBL_DUMP_FUNC)tbl_chip_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_clear_acl_policy_t),
        sizeof(tbl_clear_acl_policy_fields)/sizeof(cdb_field_t),
        tbl_clear_acl_policy_fields,
        {
            tbl_clear_acl_policy_iterate,
            (TBL_DUMP_FUNC)tbl_clear_acl_policy_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_author_key_t),
        sizeof(tbl_author_t),
        sizeof(tbl_author_fields)/sizeof(cdb_field_t),
        tbl_author_fields,
        {
            tbl_author_iterate,
            (TBL_DUMP_FUNC)tbl_author_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_author_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_account_key_t),
        sizeof(tbl_account_t),
        sizeof(tbl_account_fields)/sizeof(cdb_field_t),
        tbl_account_fields,
        {
            tbl_account_iterate,
            (TBL_DUMP_FUNC)tbl_account_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_account_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_accountcmd_key_t),
        sizeof(tbl_accountcmd_t),
        sizeof(tbl_accountcmd_fields)/sizeof(cdb_field_t),
        tbl_accountcmd_fields,
        {
            tbl_accountcmd_iterate,
            (TBL_DUMP_FUNC)tbl_accountcmd_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_accountcmd_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_vlanclass_rule_key_t),
        sizeof(tbl_vlanclass_rule_t),
        sizeof(tbl_vlanclass_rule_fields)/sizeof(cdb_field_t),
        tbl_vlanclass_rule_fields,
        {
            tbl_vlanclass_rule_iterate,
            (TBL_DUMP_FUNC)tbl_vlanclass_rule_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_vlanclass_rule_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_vlanclass_group_key_t),
        sizeof(tbl_vlanclass_group_t),
        sizeof(tbl_vlanclass_group_fields)/sizeof(cdb_field_t),
        tbl_vlanclass_group_fields,
        {
            tbl_vlanclass_group_iterate,
            (TBL_DUMP_FUNC)tbl_vlanclass_group_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_vlanclass_group_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_acl_l4_port_range_key_t),
        sizeof(tbl_acl_l4_port_range_t),
        sizeof(tbl_acl_l4_port_range_fields)/sizeof(cdb_field_t),
        tbl_acl_l4_port_range_fields,
        {
            tbl_acl_l4_port_range_iterate,
            (TBL_DUMP_FUNC)tbl_acl_l4_port_range_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_acl_l4_port_range_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_fea_pcap_t),
        sizeof(tbl_fea_pcap_fields)/sizeof(cdb_field_t),
        tbl_fea_pcap_fields,
        {
            tbl_fea_pcap_iterate,
            (TBL_DUMP_FUNC)tbl_fea_pcap_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_controller_key_t),
        sizeof(tbl_controller_t),
        sizeof(tbl_controller_fields)/sizeof(cdb_field_t),
        tbl_controller_fields,
        {
            tbl_controller_iterate,
            (TBL_DUMP_FUNC)tbl_controller_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_controller_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_cpu_packets_t),
        sizeof(tbl_cpu_packets_fields)/sizeof(cdb_field_t),
        tbl_cpu_packets_fields,
        {
            tbl_cpu_packets_iterate,
            (TBL_DUMP_FUNC)tbl_cpu_packets_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_ns_route_key_t),
        sizeof(tbl_ns_route_t),
        sizeof(tbl_ns_route_fields)/sizeof(cdb_field_t),
        tbl_ns_route_fields,
        {
            tbl_ns_route_iterate,
            (TBL_DUMP_FUNC)tbl_ns_route_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ns_route_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ns_route_ip_key_t),
        sizeof(tbl_ns_route_ip_t),
        sizeof(tbl_ns_route_ip_fields)/sizeof(cdb_field_t),
        tbl_ns_route_ip_fields,
        {
            tbl_ns_route_ip_iterate,
            (TBL_DUMP_FUNC)tbl_ns_route_ip_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ns_route_ip_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_openflow_interface_key_t),
        sizeof(tbl_openflow_interface_t),
        sizeof(tbl_openflow_interface_fields)/sizeof(cdb_field_t),
        tbl_openflow_interface_fields,
        {
            tbl_openflow_interface_iterate,
            (TBL_DUMP_FUNC)tbl_openflow_interface_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_openflow_interface_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_openflow_manager_key_t),
        sizeof(tbl_openflow_manager_t),
        sizeof(tbl_openflow_manager_fields)/sizeof(cdb_field_t),
        tbl_openflow_manager_fields,
        {
            tbl_openflow_manager_iterate,
            (TBL_DUMP_FUNC)tbl_openflow_manager_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_openflow_manager_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_ptp_global_t),
        sizeof(tbl_ptp_global_fields)/sizeof(cdb_field_t),
        tbl_ptp_global_fields,
        {
            tbl_ptp_global_iterate,
            (TBL_DUMP_FUNC)tbl_ptp_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_ptp_port_key_t),
        sizeof(tbl_ptp_port_t),
        sizeof(tbl_ptp_port_fields)/sizeof(cdb_field_t),
        tbl_ptp_port_fields,
        {
            tbl_ptp_port_iterate,
            (TBL_DUMP_FUNC)tbl_ptp_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ptp_port_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_ptp_foreign_key_t),
        sizeof(tbl_ptp_foreign_t),
        sizeof(tbl_ptp_foreign_fields)/sizeof(cdb_field_t),
        tbl_ptp_foreign_fields,
        {
            tbl_ptp_foreign_iterate,
            (TBL_DUMP_FUNC)tbl_ptp_foreign_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_ptp_foreign_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_fea_time_t),
        sizeof(tbl_fea_time_fields)/sizeof(cdb_field_t),
        tbl_fea_time_fields,
        {
            tbl_fea_time_iterate,
            (TBL_DUMP_FUNC)tbl_fea_time_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_bhm_global_t),
        sizeof(tbl_bhm_global_fields)/sizeof(cdb_field_t),
        tbl_bhm_global_fields,
        {
            tbl_bhm_global_iterate,
            (TBL_DUMP_FUNC)tbl_bhm_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_bhm_module_key_t),
        sizeof(tbl_bhm_module_t),
        sizeof(tbl_bhm_module_fields)/sizeof(cdb_field_t),
        tbl_bhm_module_fields,
        {
            tbl_bhm_module_iterate,
            (TBL_DUMP_FUNC)tbl_bhm_module_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_bhm_module_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_openflow_tunnel_interface_key_t),
        sizeof(tbl_openflow_tunnel_interface_t),
        sizeof(tbl_openflow_tunnel_interface_fields)/sizeof(cdb_field_t),
        tbl_openflow_tunnel_interface_fields,
        {
            tbl_openflow_tunnel_interface_iterate,
            (TBL_DUMP_FUNC)tbl_openflow_tunnel_interface_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_openflow_tunnel_interface_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_openflow_tunnel_local_ip_cnt_key_t),
        sizeof(tbl_openflow_tunnel_local_ip_cnt_t),
        sizeof(tbl_openflow_tunnel_local_ip_cnt_fields)/sizeof(cdb_field_t),
        tbl_openflow_tunnel_local_ip_cnt_fields,
        {
            tbl_openflow_tunnel_local_ip_cnt_iterate,
            (TBL_DUMP_FUNC)tbl_openflow_tunnel_local_ip_cnt_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_openflow_tunnel_local_ip_cnt_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_inband_snat_key_t),
        sizeof(tbl_inband_snat_t),
        sizeof(tbl_inband_snat_fields)/sizeof(cdb_field_t),
        tbl_inband_snat_fields,
        {
            tbl_inband_snat_iterate,
            (TBL_DUMP_FUNC)tbl_inband_snat_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_inband_snat_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_arpinsp_key_t),
        sizeof(tbl_arpinsp_t),
        sizeof(tbl_arpinsp_fields)/sizeof(cdb_field_t),
        tbl_arpinsp_fields,
        {
            tbl_arpinsp_iterate,
            (TBL_DUMP_FUNC)tbl_arpinsp_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_arpinsp_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_arpacl_config_key_t),
        sizeof(tbl_arpacl_config_t),
        sizeof(tbl_arpacl_config_fields)/sizeof(cdb_field_t),
        tbl_arpacl_config_fields,
        {
            tbl_arpacl_config_iterate,
            (TBL_DUMP_FUNC)tbl_arpacl_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_arpacl_config_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_arpace_config_key_t),
        sizeof(tbl_arpace_config_t),
        sizeof(tbl_arpace_config_fields)/sizeof(cdb_field_t),
        tbl_arpace_config_fields,
        {
            tbl_arpace_config_iterate,
            (TBL_DUMP_FUNC)tbl_arpace_config_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_arpace_config_key_val2str,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_copp_cfg_t),
        sizeof(tbl_copp_cfg_fields)/sizeof(cdb_field_t),
        tbl_copp_cfg_fields,
        {
            tbl_copp_cfg_iterate,
            (TBL_DUMP_FUNC)tbl_copp_cfg_dump_one,
            NULL,
            NULL
        }
    },
    {
        0,
        sizeof(tbl_sflow_global_t),
        sizeof(tbl_sflow_global_fields)/sizeof(cdb_field_t),
        tbl_sflow_global_fields,
        {
            tbl_sflow_global_iterate,
            (TBL_DUMP_FUNC)tbl_sflow_global_dump_one,
            NULL,
            NULL
        }
    },
    {
        sizeof(tbl_sflow_collector_key_t),
        sizeof(tbl_sflow_collector_t),
        sizeof(tbl_sflow_collector_fields)/sizeof(cdb_field_t),
        tbl_sflow_collector_fields,
        {
            tbl_sflow_collector_iterate,
            (TBL_DUMP_FUNC)tbl_sflow_collector_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_sflow_collector_key_val2str,
            NULL
        }
    },
    {
        sizeof(tbl_sflow_counter_port_key_t),
        sizeof(tbl_sflow_counter_port_t),
        sizeof(tbl_sflow_counter_port_fields)/sizeof(cdb_field_t),
        tbl_sflow_counter_port_fields,
        {
            tbl_sflow_counter_port_iterate,
            (TBL_DUMP_FUNC)tbl_sflow_counter_port_dump_one,
            (TBL_KEY_V2S_FUNC)tbl_sflow_counter_port_key_val2str,
            NULL
        }
    },
};

int32
cdb_tbl_pm_init(uint32 pm_id)
{
    cdb_node_t *p_tbl = NULL;
    uint32 i = 0;

    for (i = 0; i < TBL_MAX; i++)
    {
        p_tbl = cdb_get_tbl(i);

        if (0)
        {
        }
        else if (TBL_INTERFACE == i)
        {
            tbl_interface_init_interface();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ROUTE_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_AUTHD == pm_id) || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_DHCRELAY == pm_id) || (PM_ID_DHCLIENT == pm_id))
            {
                tbl_route_if_init_route_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_KERNEL_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_kernel_if_init_kernel_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_PORT_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_port_if_init_fea_port_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_VLAN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_ROUTED == pm_id) || (PM_ID_OPM == pm_id) || (PM_ID_AUTHD == pm_id) || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_DHCRELAY == pm_id))
            {
                tbl_vlan_init_vlan();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PVLAN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_pvlan_init_pvlan();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FDB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_fdb_init_fdb();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MCFDB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mcfdb_init_mcfdb();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MACFILTER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_ROUTED == pm_id))
            {
                tbl_macfilter_init_macfilter();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PSFDB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_psfdb_init_psfdb();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IPSG_S_IP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_ipsg_s_ip_init_ipsg_s_ip();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IPSG_S_MAC == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_DHCSNOOPING == pm_id))
            {
                tbl_ipsg_s_mac_init_ipsg_s_mac();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IPSG_FIB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_DHCRELAY == pm_id))
            {
                tbl_ipsg_fib_init_ipsg_fib();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_BRG_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_brg_global_init_brg_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MSTP_PORT == i)
        {
            tbl_mstp_port_init_mstp_port();
            p_tbl->inited = TRUE;
        }
        else if (TBL_MSTI_PORT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_msti_port_init_msti_port();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MSTP_INSTANCE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_OPM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_mstp_instance_init_mstp_instance();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MSTP_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_OPM == pm_id))
            {
                tbl_mstp_global_init_mstp_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LLDP_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_lldp_global_init_lldp_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LLDP_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_lldp_if_init_lldp_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MLAG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mlag_init_mlag();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MLAG_PEER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mlag_peer_init_mlag_peer();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MLAG_PORT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mlag_port_init_mlag_port();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ISOLATION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_isolation_init_isolation();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ROUTE_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_route_global_init_route_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_OSPF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_ospf_init_ospf();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_OSPF_NETWORK == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_ospf_network_init_ospf_network();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_OSPF_AREA_AUTH == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_ospf_area_auth_init_ospf_area_auth();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IPROUTE_NODE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_iproute_node_init_iproute_node();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_STATIC_ROUTE_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_static_route_cfg_init_static_route_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_STATIC_RT_CNT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_static_rt_cnt_init_static_rt_cnt();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ARP_FIB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_arp_fib_init_arp_fib();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ARP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_arp_init_arp();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NEXTHOP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_nexthop_init_nexthop();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NEXTHOP_GROUP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_nexthop_group_init_nexthop_group();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_NEXTHOP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_nexthop_init_fea_nexthop();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SYS_GLOBAL == i)
        {
            tbl_sys_global_init_sys_global();
            p_tbl->inited = TRUE;
        }
        else if (TBL_LAG_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_lag_global_init_lag_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MEM_SUMMARY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mem_summary_init_mem_summary();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CHSM_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id))
            {
                tbl_chsm_debug_init_chsm_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SWITCH_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_switch_debug_init_switch_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ROUTE_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_route_debug_init_route_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QUAGGA_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_quagga_debug_init_quagga_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LSRV_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_lsrv_debug_init_lsrv_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_HSRV_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_hsrv_debug_init_hsrv_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_RIF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_rif_init_rif();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_LAG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_lag_init_fea_lag();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_global_init_fea_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_ACL_TABLE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_acl_table_init_fea_acl_table();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_ACL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_fea_acl_init_fea_acl();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_FDB == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_fdb_init_fea_fdb();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_BRG_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_brg_if_init_fea_brg_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_WORM_FILTER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_acl_worm_filter_init_acl_worm_filter();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_config_init_acl_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACE_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_ace_config_init_ace_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_ENTRY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_entry_init_acl_entry();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_ENTRY_ACTION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_entry_action_init_acl_entry_action();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_NEXTHOP_GROUP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_nexthop_group_init_acl_nexthop_group();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_NEXTHOP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_nexthop_init_acl_nexthop();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PMAP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_pmap_init_pmap();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CMAP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_cmap_init_cmap();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_init_acl();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_TIME_RANGE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_time_range_init_time_range();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SSH_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ssh_cfg_init_ssh_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SNMP_CFG == i)
        {
            tbl_snmp_cfg_init_snmp_cfg();
            p_tbl->inited = TRUE;
        }
        else if (TBL_SNMP_VIEW == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_snmp_view_init_snmp_view();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SNMP_COMMUNITY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_snmp_community_init_snmp_community();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SNMP_TRAP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_snmp_trap_init_snmp_trap();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SNMP_INFORM == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_snmp_inform_init_snmp_inform();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SYSLOG_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_ROUTED == pm_id))
            {
                tbl_syslog_cfg_init_syslog_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_SERVER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_server_init_ntp_server();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_ACE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_ace_init_ntp_ace();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_KEY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_key_init_ntp_key();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_cfg_init_ntp_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_if_init_ntp_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NTP_SYNCSTATUS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_ntp_syncstatus_init_ntp_syncstatus();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_STATIC_DNS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_static_dns_init_static_dns();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DYNAMIC_DNS_DOMAIN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_dynamic_dns_domain_init_dynamic_dns_domain();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DYNAMIC_DNS_SERVER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_dynamic_dns_server_init_dynamic_dns_server();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_DOMAIN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_domain_init_qos_domain();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_POLICER_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_policer_profile_init_qos_policer_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_DROP_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_drop_profile_init_qos_drop_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_QUEUE_SHAPE_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_queue_shape_profile_init_qos_queue_shape_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_PORT_SHAPE_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_port_shape_profile_init_qos_port_shape_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_QOS_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_qos_global_init_qos_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MIRROR == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_ROUTED == pm_id))
            {
                tbl_mirror_init_mirror();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_MIRROR_MAC_ESCAPE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_mirror_mac_escape_init_mirror_mac_escape();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_TAP_GROUP_INGRESS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_tap_group_ingress_init_tap_group_ingress();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_TAP_GROUP_INGRESS_FLOW == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_tap_group_ingress_flow_init_tap_group_ingress_flow();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_TAP_GROUP_EGRESS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_tap_group_egress_init_tap_group_egress();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_TAP_GROUP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_tap_group_init_tap_group();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_USER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_user_init_user();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_VTY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_AUTHD == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_vty_init_vty();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CONSOLE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_console_init_console();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTHEN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_authen_init_authen();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LOGIN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_AUTHD == pm_id))
            {
                tbl_login_init_login();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_RSA == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_rsa_init_rsa();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_OPENFLOW == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_OPENFLOW == pm_id))
            {
                tbl_openflow_init_openflow();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CPU_TRAFFIC == i)
        {
            tbl_cpu_traffic_init_cpu_traffic();
            p_tbl->inited = TRUE;
        }
        else if (TBL_CPU_TRAFFIC_GROUP == i)
        {
            tbl_cpu_traffic_group_init_cpu_traffic_group();
            p_tbl->inited = TRUE;
        }
        else if (TBL_CPU_UTILIZATION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_cpu_utilization_init_cpu_utilization();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CPU_LIMIT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_cpu_limit_init_cpu_limit();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCRELAY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCRELAY == pm_id))
            {
                tbl_dhcrelay_init_dhcrelay();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCSRVGRP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCRELAY == pm_id))
            {
                tbl_dhcsrvgrp_init_dhcsrvgrp();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCP_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCRELAY == pm_id) || (PM_ID_DHCLIENT == pm_id) || (PM_ID_DHCSNOOPING == pm_id))
            {
                tbl_dhcp_debug_init_dhcp_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCLIENT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCLIENT == pm_id))
            {
                tbl_dhclient_init_dhclient();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCSNOOPING == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_ROUTED == pm_id))
            {
                tbl_dhcsnooping_init_dhcsnooping();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DHCBINDING == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_ROUTED == pm_id))
            {
                tbl_dhcbinding_init_dhcbinding();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IPTABLES_PREVENT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_iptables_prevent_init_iptables_prevent();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ERRDISABLE == i)
        {
            tbl_errdisable_init_errdisable();
            p_tbl->inited = TRUE;
        }
        else if (TBL_NS_PORT_FORWARDING == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_ns_port_forwarding_init_ns_port_forwarding();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LOG_GLOBAL == i)
        {
            tbl_log_global_init_log_global();
            p_tbl->inited = TRUE;
        }
        else if (TBL_LOG == i)
        {
            tbl_log_init_log();
            p_tbl->inited = TRUE;
        }
        else if (TBL_SYS_LOAD == i)
        {
            tbl_sys_load_init_sys_load();
            p_tbl->inited = TRUE;
        }
        else if (TBL_CEM == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_cem_init_cem();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CLOCK == i)
        {
            tbl_clock_init_clock();
            p_tbl->inited = TRUE;
        }
        else if (TBL_PORT_STATS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_OPENFLOW == pm_id))
            {
                tbl_port_stats_init_port_stats();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PORT_STATS_RATE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_port_stats_rate_init_port_stats_rate();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACLQOS_IF == i)
        {
            tbl_aclqos_if_init_aclqos_if();
            p_tbl->inited = TRUE;
        }
        else if (TBL_L2_ACTION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_OPM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_l2_action_init_l2_action();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_QOS_DROP_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_qos_drop_profile_init_fea_qos_drop_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_QOS_DOMAIN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_qos_domain_init_fea_qos_domain();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_QOS_QUEUE_SHAPE_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_fea_qos_queue_shape_profile_init_fea_qos_queue_shape_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_QOS_PORT_SHAPE_PROFILE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_fea_qos_port_shape_profile_init_fea_qos_port_shape_profile();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_PORT_POLICER_APPLY == i)
        {
            tbl_fea_port_policer_apply_init_fea_port_policer_apply();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ACLQOS_IF_STATS == i)
        {
            tbl_aclqos_if_stats_init_aclqos_if_stats();
            p_tbl->inited = TRUE;
        }
        else if (TBL_VERSION == i)
        {
            tbl_version_init_version();
            p_tbl->inited = TRUE;
        }
        else if (TBL_MANAGE_IF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_manage_if_init_manage_if();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_BOOTIMAGE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_bootimage_init_bootimage();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CHASSIS == i)
        {
            tbl_chassis_init_chassis();
            p_tbl->inited = TRUE;
        }
        else if (TBL_IFNAME_INFO == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_ifname_info_init_ifname_info();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CARD == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_OPENFLOW == pm_id))
            {
                tbl_card_init_card();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PORT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_port_init_port();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FIBER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_fiber_init_fiber();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SYS_SPEC == i)
        {
            tbl_sys_spec_init_sys_spec();
            p_tbl->inited = TRUE;
        }
        else if (TBL_FAN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_fan_init_fan();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PSU == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_psu_init_psu();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_LED == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_led_init_led();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SENSOR == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_sensor_init_sensor();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_REBOOT_INFO == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_CHSM == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_reboot_info_init_reboot_info();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ERRDISABLE_FLAP == i)
        {
            tbl_errdisable_flap_init_errdisable_flap();
            p_tbl->inited = TRUE;
        }
        else if (TBL_OPM_GLOBAL == i)
        {
            tbl_opm_global_init_opm_global();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ERPS_RING == i)
        {
            tbl_erps_ring_init_erps_ring();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ERPS_DOMAIN == i)
        {
            tbl_erps_domain_init_erps_domain();
            p_tbl->inited = TRUE;
        }
        else if (TBL_OPM_DEBUG == i)
        {
            tbl_opm_debug_init_opm_debug();
            p_tbl->inited = TRUE;
        }
        else if (TBL_POLICY_MAP_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_policy_map_config_init_policy_map_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CLASS_MAP_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_class_map_config_init_class_map_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CLASS_IN_POLICY_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_class_in_policy_config_init_class_in_policy_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_IN_CLASS_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_in_class_config_init_acl_in_class_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CLASS_MAP_ACTION_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_class_map_action_config_init_class_map_action_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_ACL_POLICY_ACTION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_fea_acl_policy_action_init_fea_acl_policy_action();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IGSP_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_OPM == pm_id))
            {
                tbl_igsp_global_init_igsp_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IGSP_INTF == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_OPM == pm_id))
            {
                tbl_igsp_intf_init_igsp_intf();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_IGSP_GROUP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_igsp_group_init_igsp_group();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTH_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_AUTHD == pm_id))
            {
                tbl_auth_cfg_init_auth_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTH_SERVER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_AUTHD == pm_id))
            {
                tbl_auth_server_init_auth_server();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTH_SESSION == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_AUTHD == pm_id))
            {
                tbl_auth_session_init_auth_session();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTHD_DEBUG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_AUTHD == pm_id))
            {
                tbl_authd_debug_init_authd_debug();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_DOT1X_GLOBAL == i)
        {
            tbl_dot1x_global_init_dot1x_global();
            p_tbl->inited = TRUE;
        }
        else if (TBL_DOT1X_PORT == i)
        {
            tbl_dot1x_port_init_dot1x_port();
            p_tbl->inited = TRUE;
        }
        else if (TBL_DOT1X_RADIUS == i)
        {
            tbl_dot1x_radius_init_dot1x_radius();
            p_tbl->inited = TRUE;
        }
        else if (TBL_DOT1X_MAC == i)
        {
            tbl_dot1x_mac_init_dot1x_mac();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ENABLE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id))
            {
                tbl_enable_init_enable();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CHIP == i)
        {
            tbl_chip_init_chip();
            p_tbl->inited = TRUE;
        }
        else if (TBL_CLEAR_ACL_POLICY == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_clear_acl_policy_init_clear_acl_policy();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_AUTHOR == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_AUTHD == pm_id))
            {
                tbl_author_init_author();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACCOUNT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_AUTHD == pm_id))
            {
                tbl_account_init_account();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACCOUNTCMD == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_APPCFG == pm_id) || (PM_ID_AUTHD == pm_id))
            {
                tbl_accountcmd_init_accountcmd();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_VLANCLASS_RULE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_vlanclass_rule_init_vlanclass_rule();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_VLANCLASS_GROUP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_vlanclass_group_init_vlanclass_group();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ACL_L4_PORT_RANGE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_acl_l4_port_range_init_acl_l4_port_range();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_PCAP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_pcap_init_fea_pcap();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CONTROLLER == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_controller_init_controller();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_CPU_PACKETS == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_cpu_packets_init_cpu_packets();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_NS_ROUTE == i)
        {
            tbl_ns_route_init_ns_route();
            p_tbl->inited = TRUE;
        }
        else if (TBL_NS_ROUTE_IP == i)
        {
            tbl_ns_route_ip_init_ns_route_ip();
            p_tbl->inited = TRUE;
        }
        else if (TBL_OPENFLOW_INTERFACE == i)
        {
            tbl_openflow_interface_init_openflow_interface();
            p_tbl->inited = TRUE;
        }
        else if (TBL_OPENFLOW_MANAGER == i)
        {
            tbl_openflow_manager_init_openflow_manager();
            p_tbl->inited = TRUE;
        }
        else if (TBL_PTP_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_PTP == pm_id))
            {
                tbl_ptp_global_init_ptp_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PTP_PORT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_PTP == pm_id))
            {
                tbl_ptp_port_init_ptp_port();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_PTP_FOREIGN == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_PTP == pm_id))
            {
                tbl_ptp_foreign_init_ptp_foreign();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_FEA_TIME == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id))
            {
                tbl_fea_time_init_fea_time();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_BHM_GLOBAL == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_BHM == pm_id))
            {
                tbl_bhm_global_init_bhm_global();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_BHM_MODULE == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_BHM == pm_id))
            {
                tbl_bhm_module_init_bhm_module();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_OPENFLOW_TUNNEL_INTERFACE == i)
        {
            tbl_openflow_tunnel_interface_init_openflow_tunnel_interface();
            p_tbl->inited = TRUE;
        }
        else if (TBL_OPENFLOW_TUNNEL_LOCAL_IP_CNT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_openflow_tunnel_local_ip_cnt_init_openflow_tunnel_local_ip_cnt();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_INBAND_SNAT == i)
        {
            tbl_inband_snat_init_inband_snat();
            p_tbl->inited = TRUE;
        }
        else if (TBL_ARPINSP == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id) || (PM_ID_SWITCH == pm_id) || (PM_ID_DHCSNOOPING == pm_id) || (PM_ID_DHCRELAY == pm_id))
            {
                tbl_arpinsp_init_arpinsp();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ARPACL_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_arpacl_config_init_arpacl_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_ARPACE_CONFIG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_ROUTED == pm_id))
            {
                tbl_arpace_config_init_arpace_config();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_COPP_CFG == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id) || (PM_ID_FEA == pm_id))
            {
                tbl_copp_cfg_init_copp_cfg();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SFLOW_GLOBAL == i)
        {
            tbl_sflow_global_init_sflow_global();
            p_tbl->inited = TRUE;
        }
        else if (TBL_SFLOW_COLLECTOR == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_SWITCH == pm_id))
            {
                tbl_sflow_collector_init_sflow_collector();
                p_tbl->inited = TRUE;
            }
        }
        else if (TBL_SFLOW_COUNTER_PORT == i)
        {
            if (CHECK_FULL_CDB_PMS || (PM_ID_FEA == pm_id) || (PM_ID_SWITCH == pm_id))
            {
                tbl_sflow_counter_port_init_sflow_counter_port();
                p_tbl->inited = TRUE;
            }
        }
    }

    return PM_E_NONE;
}

#endif /* !__CDB_TBL_INFO_PRIV_H__ */



#ifndef __DS_PMAP_CLASS_H__
#define __DS_PMAP_CLASS_H__

int32
ds_pmap_class_add_pmap_class_sync(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class, uint32 sync);

int32
ds_pmap_class_del_pmap_class_sync(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class, uint32 sync);

int32
ds_pmap_class_set_pmap_class_field_sync(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class, ds_pmap_class_field_id_t field_id, uint32 sync);

int32
ds_pmap_class_add_pmap_class(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class);

int32
ds_pmap_class_del_pmap_class(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class);

int32
ds_pmap_class_set_pmap_class_field(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class, ds_pmap_class_field_id_t field_id);

ds_pmap_class_t*
ds_pmap_class_get_pmap_class(tbl_pmap_t *p_pmap, ds_pmap_class_t *p_pmap_class);

int32
ds_pmap_class_dump_one(ds_pmap_class_t *p_pmap_class, tbl_iter_args_t *pargs);

ds_pmap_class_t*
ds_pmap_class_get_pmap_class_by_name(tbl_pmap_t *p_pmap, char *name);

int32
ds_pmap_class_add_pmap_class_by_name(tbl_pmap_t *p_pmap, char* name);

int32
ds_pmap_class_del_pmap_class_by_name(tbl_pmap_t *p_pmap, char* name);

#endif /* !__DS_PMAP_CLASS_H__ */


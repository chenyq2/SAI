
#ifndef __TBL_ROUTE_DEBUG_DEFINE_H__
#define __TBL_ROUTE_DEBUG_DEFINE_H__

/* TBL_ROUTE_DEBUG field defines */
typedef enum
{
    TBL_ROUTE_DEBUG_FLD_ROUTE_EVENT          = 0 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARP_EVENT            = 1 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARP_PACKET           = 2 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARP_PROTOCOL         = 3 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARP_TIMER            = 4 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARPINSPECTION_EVENT  = 5 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARPINSPECTION_PACKET = 6 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARPINSPECTION_PROTOCOL = 7 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_ARPINSPECTION_TIMER  = 8 ,  /* RW */
    TBL_ROUTE_DEBUG_FLD_MAX                  = 9 
} tbl_route_debug_field_id_t;

/* TBL_ROUTE_DEBUG defines */
typedef struct
{
    uint32               route;               /* bitmap of RTDBG_FLAG_ROUTE_ */
    uint32               arp;                 /* bitmap of RTDBG_FLAG_ARP_ */
    uint32               arpinspection;       /* bitmap of RTDBG_FLAG_ARPINSPECTION_ */
} tbl_route_debug_t;

#endif /* !__TBL_ROUTE_DEBUG_DEFINE_H__ */


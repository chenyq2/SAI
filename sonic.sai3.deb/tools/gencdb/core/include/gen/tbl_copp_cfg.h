
#ifndef __TBL_COPP_CFG_H__
#define __TBL_COPP_CFG_H__

int32
tbl_copp_cfg_set_copp_cfg_field_sync(tbl_copp_cfg_t *p_copp_cfg, tbl_copp_cfg_field_id_t field_id, uint32 sync);

int32
tbl_copp_cfg_set_copp_cfg_field(tbl_copp_cfg_t *p_copp_cfg, tbl_copp_cfg_field_id_t field_id);

tbl_copp_cfg_t*
tbl_copp_cfg_get_copp_cfg();

int32
tbl_copp_cfg_dump_one(tbl_copp_cfg_t *p_copp_cfg, tbl_iter_args_t *pargs);

int32
tbl_copp_cfg_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_copp_cfg_t*
tbl_copp_cfg_init_copp_cfg();

#endif /* !__TBL_COPP_CFG_H__ */


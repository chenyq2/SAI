
#ifndef __TBL_ACE_CONFIG_DEFINE_H__
#define __TBL_ACE_CONFIG_DEFINE_H__

/* TBL_ACE_CONFIG field defines */
typedef enum
{
    TBL_ACE_CONFIG_FLD_KEY                  = 0 ,  /* READ */
    TBL_ACE_CONFIG_FLD_KEY_FLAGS            = 1 ,  /* RW */
    TBL_ACE_CONFIG_FLD_TIME_RANGE           = 2 ,  /* RW */
    TBL_ACE_CONFIG_FLD_APPLY_CNT            = 3 ,  /* READ */
    TBL_ACE_CONFIG_FLD_IN_PORT              = 4 ,  /* RW */
    TBL_ACE_CONFIG_FLD_OUT_PORT             = 5 ,  /* RW */
    TBL_ACE_CONFIG_FLD_ETHER_TYPE           = 6 ,  /* RW */
    TBL_ACE_CONFIG_FLD_ETHER_TYPE_MASK      = 7 ,  /* RW */
    TBL_ACE_CONFIG_FLD_SRC_MAC              = 8 ,  /* RW */
    TBL_ACE_CONFIG_FLD_SRC_MAC_MASK         = 9 ,  /* RW */
    TBL_ACE_CONFIG_FLD_DST_MAC              = 10,  /* RW */
    TBL_ACE_CONFIG_FLD_DST_MAC_MASK         = 11,  /* RW */
    TBL_ACE_CONFIG_FLD_SVLAN                = 12,  /* RW */
    TBL_ACE_CONFIG_FLD_SVLAN_MASK           = 13,  /* RW */
    TBL_ACE_CONFIG_FLD_SVLAN_COS            = 14,  /* RW */
    TBL_ACE_CONFIG_FLD_SVLAN_COS_MASK       = 15,  /* RW */
    TBL_ACE_CONFIG_FLD_CVLAN                = 16,  /* RW */
    TBL_ACE_CONFIG_FLD_CVLAN_MASK           = 17,  /* RW */
    TBL_ACE_CONFIG_FLD_CVLAN_COS            = 18,  /* RW */
    TBL_ACE_CONFIG_FLD_CVLAN_COS_MASK       = 19,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_TYPE              = 20,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_TYPE_MASK         = 21,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_FLAGS             = 22,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_FLAGS_MASK        = 23,  /* RW */
    TBL_ACE_CONFIG_FLD_SRC_IP               = 24,  /* RW */
    TBL_ACE_CONFIG_FLD_SRC_IP_MASK          = 25,  /* RW */
    TBL_ACE_CONFIG_FLD_DST_IP               = 26,  /* RW */
    TBL_ACE_CONFIG_FLD_DST_IP_MASK          = 27,  /* RW */
    TBL_ACE_CONFIG_FLD_DSCP                 = 28,  /* RW */
    TBL_ACE_CONFIG_FLD_DSCP_MASK            = 29,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_PRECEDENCE        = 30,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_PRECEDENCE_MASK   = 31,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_PROTOCOL          = 32,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_PROTOCOL_MASK     = 33,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_SRC_PORT_TYPE     = 34,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_SRC_PORT          = 35,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_SRC_PORT_MASK     = 36,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_DST_PORT_TYPE     = 37,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_DST_PORT          = 38,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_DST_PORT_MASK     = 39,  /* RW */
    TBL_ACE_CONFIG_FLD_IP_FRAG              = 40,  /* RW */
    TBL_ACE_CONFIG_FLD_TCP_FLAGS            = 41,  /* RW */
    TBL_ACE_CONFIG_FLD_TCP_FLAGS_MASK       = 42,  /* RW */
    TBL_ACE_CONFIG_FLD_IGMP_TYPE            = 43,  /* RW */
    TBL_ACE_CONFIG_FLD_ICMP_TYPE            = 44,  /* RW */
    TBL_ACE_CONFIG_FLD_ICMP_CODE            = 45,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_VXLAN_VNI         = 46,  /* RW */
    TBL_ACE_CONFIG_FLD_L4_VXLAN_VNI_MASK    = 47,  /* RW */
    TBL_ACE_CONFIG_FLD_DENY                 = 48,  /* RW */
    TBL_ACE_CONFIG_FLD_STATS_EN             = 49,  /* RW */
    TBL_ACE_CONFIG_FLD_OPTIONS              = 50,  /* RW */
    TBL_ACE_CONFIG_FLD_ACTION_STRIP_HEADER  = 51,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_REDIRECT  = 52,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_MARK_VLAN = 53,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_UNTAG     = 54,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_TRUNCTION = 55,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_DEST_MAC_EN = 56,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_DEST_MAC = 57,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_SRC_MAC_EN = 58,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_SRC_MAC = 59,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_IPDA_EN = 60,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_IPDA = 61,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_IPSA_EN = 62,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_ACTION_EDIT_IPSA = 63,  /* RW */
    TBL_ACE_CONFIG_FLD_TAP_SNMP_SET         = 64,  /* RW */
    TBL_ACE_CONFIG_FLD_MAX                  = 65
} tbl_ace_config_field_id_t;

/* TBL_ACE_CONFIG defines */
typedef ace_config_key_t tbl_ace_config_key_t;

typedef struct
{
    tbl_ace_config_key_t key;
    uint32               key_flags;
    char                 time_range[TIME_RANGE_SIZE+1];
    uint16               apply_cnt;           /* ace apply count: if not zero, time-range is started either*/
    uint32               in_port;
    uint32               out_port;
    uint32               ether_type;
    uint32               ether_type_mask;
    mac_addr_t           src_mac;
    mac_addr_t           src_mac_mask;
    mac_addr_t           dst_mac;
    mac_addr_t           dst_mac_mask;
    uint32               svlan;
    uint32               svlan_mask;
    uint32               svlan_cos;
    uint32               svlan_cos_mask;
    uint32               cvlan;
    uint32               cvlan_mask;
    uint32               cvlan_cos;
    uint32               cvlan_cos_mask;
    uint32               ip_type;
    uint32               ip_type_mask;
    uint32               ip_flags;
    uint32               ip_flags_mask;
    addr_ipv4_t          src_ip;
    addr_ipv4_t          src_ip_mask;
    addr_ipv4_t          dst_ip;
    addr_ipv4_t          dst_ip_mask;
    uint32               dscp;
    uint32               dscp_mask;
    uint32               ip_precedence;
    uint32               ip_precedence_mask;
    uint32               ip_protocol;
    uint32               ip_protocol_mask;
    uint32               l4_src_port_type;
    uint32               l4_src_port;
    uint32               l4_src_port_mask;
    uint32               l4_dst_port_type;
    uint32               l4_dst_port;
    uint32               l4_dst_port_mask;
    uint32               ip_frag;
    uint32               tcp_flags;
    uint32               tcp_flags_mask;
    uint32               igmp_type;
    uint32               icmp_type;
    uint32               icmp_code;
    uint32               l4_vxlan_vni;
    uint32               l4_vxlan_vni_mask;
    uint32               deny;
    uint32               stats_en;
    uint32               options;
    uint32               action_strip_header;
    uint32               tap_action_redirect;
    uint32               tap_action_mark_vlan;
    uint32               tap_action_untag;
    uint32               tap_action_trunction;
    uint32               tap_action_edit_dest_mac_en;
    mac_addr_t           tap_action_edit_dest_mac;
    uint32               tap_action_edit_src_mac_en;
    mac_addr_t           tap_action_edit_src_mac;
    uint32               tap_action_edit_ipda_en;
    addr_t               tap_action_edit_ipda; /* ip address v4/v6 */
    uint32               tap_action_edit_ipsa_en;
    addr_t               tap_action_edit_ipsa; /* ip address v4/v6 */
    uint32               tap_snmp_set;
} tbl_ace_config_t;

typedef struct
{
    ctclib_hash_t        *ace_config_hash;
    ctclib_slist_t       *ace_config_list;
} tbl_ace_config_master_t;

#endif /* !__TBL_ACE_CONFIG_DEFINE_H__ */


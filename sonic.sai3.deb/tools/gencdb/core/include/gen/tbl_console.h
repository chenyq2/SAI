
#ifndef __TBL_CONSOLE_H__
#define __TBL_CONSOLE_H__

int32
tbl_console_set_console_field_sync(tbl_console_t *p_console, tbl_console_field_id_t field_id, uint32 sync);

int32
tbl_console_set_console_field(tbl_console_t *p_console, tbl_console_field_id_t field_id);

tbl_console_t*
tbl_console_get_console();

int32
tbl_console_dump_one(tbl_console_t *p_console, tbl_iter_args_t *pargs);

int32
tbl_console_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_console_t*
tbl_console_init_console();

#endif /* !__TBL_CONSOLE_H__ */


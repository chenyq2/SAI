
#ifndef __TBL_ROUTE_IF_DEFINE_H__
#define __TBL_ROUTE_IF_DEFINE_H__

#include "gen/ds_connected_define.h"
#include "gen/ds_ospf_auth_define.h"

/* TBL_ROUTE_IF field defines */
typedef enum
{
    TBL_ROUTE_IF_FLD_KEY                  = 0 ,  /* READ */
    TBL_ROUTE_IF_FLD_MTU                  = 1 ,  /* RW */
    TBL_ROUTE_IF_FLD_MAC                  = 2 ,  /* RW */
    TBL_ROUTE_IF_FLD_IPV4_ENABLE          = 3 ,  /* RW */
    TBL_ROUTE_IF_FLD_IPV6_ENABLE          = 4 ,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_RETRANS_TIME     = 5 ,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_TIMEOUT          = 6 ,  /* RW */
    TBL_ROUTE_IF_FLD_IFINDEX              = 7 ,  /* READ */
    TBL_ROUTE_IF_FLD_KERNEL_IFINDEX       = 8 ,  /* READ */
    TBL_ROUTE_IF_FLD_ARP_RETRY_TIMEOUT    = 9 ,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_COST            = 10,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_MTU_IGNORE      = 11,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_TIMER_HELLO     = 12,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_TIMER_DEAD      = 13,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_AUTH_TYPE       = 14,  /* RW */
    TBL_ROUTE_IF_FLD_OSPF_AUTH_KEY        = 15,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_PROXY_EN         = 16,  /* RW */
    TBL_ROUTE_IF_FLD_LOCAL_ARP_PROXY_EN   = 17,  /* RW */
    TBL_ROUTE_IF_FLD_UNICAST_RPF_EN       = 18,  /* RW */
    TBL_ROUTE_IF_FLD_IP_UNREACHABLE_EN    = 19,  /* RW */
    TBL_ROUTE_IF_FLD_IP_REDIRECTS_EN      = 20,  /* RW */
    TBL_ROUTE_IF_FLD_DHCP_RELAY_OPTION_TRUST = 21,  /* RW */
    TBL_ROUTE_IF_FLD_DHCP_SERVER_GROUP    = 22,  /* RW */
    TBL_ROUTE_IF_FLD_DHCP_PDU_ENABLED     = 23,  /* READ */
    TBL_ROUTE_IF_FLD_DHCP_CLIENT_ENABLE   = 24,  /* RW */
    TBL_ROUTE_IF_FLD_DHCP_CLIENT_IPV4     = 25,  /* RW */
    TBL_ROUTE_IF_FLD_DHCP_CLIENT_IPV4_MASK = 26,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_CURR_DYNAMIC     = 27,  /* READ */
    TBL_ROUTE_IF_FLD_ARP_ATTACK_NUMBER    = 28,  /* READ */
    TBL_ROUTE_IF_FLD_ARP_RATE_LIMIT_EN    = 29,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_RATE_LIMIT_PKT_MAX = 30,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_RATE_LIMIT_VIOLATION = 31,  /* RW */
    TBL_ROUTE_IF_FLD_ARP_RATE_LIMIT_PKT_CURR = 32,  /* READ */
    TBL_ROUTE_IF_FLD_ARP_RATE_LIMIT_PORT_ABNORMAL_FLAG = 33,  /* RW */
    TBL_ROUTE_IF_FLD_IFC_IPV4             = 34,  /* SUB */
    TBL_ROUTE_IF_FLD_IFC_IPV6             = 35,  /* SUB */
    TBL_ROUTE_IF_FLD_OSPF_MD5_KEY         = 36,  /* SUB */
    TBL_ROUTE_IF_FLD_MAX                  = 37
} tbl_route_if_field_id_t;

/* TBL_ROUTE_IF defines */
typedef struct
{
    char                 name[IFNAME_SIZE];
} tbl_route_if_key_t;

typedef struct
{
    tbl_route_if_key_t   key;
    uint32               mtu;                 /* MTU same to interface */
    mac_addr_t           mac;                 /* route-mac address */
    uint32               ipv4_enable;         /* ipv4 enable */
    uint32               ipv6_enable;         /* ipv6 enable */
    uint32               arp_retrans_time;    /* retrans time */
    uint32               arp_timeout;         /* arp timeout */
    uint32               ifindex;
    uint32               kernel_ifindex;      /* ifindex assign in kernel to indicate an interface  */
    uint32               arp_retry_timeout;
    uint32               ospf_cost;
    uint32               ospf_mtu_ignore;
    uint32               ospf_timer_hello;
    uint32               ospf_timer_dead;
    uint32               ospf_auth_type;
    char                 ospf_auth_key[256];
    uint8                arp_proxy_en;
    uint8                local_arp_proxy_en;
    uint32               unicast_rpf_en;
    uint8                ip_unreachable_en;
    uint8                ip_redirects_en;
    uint8                dhcp_relay_option_trust; /* trust this interface */
    uint8                dhcp_server_group;   /* server group for dhcp relay <1-16> */
    uint8                dhcp_pdu_enabled;    /* DHCP PDU to CPU enbaled or not */
    uint8                dhcp_client_enable;  /* dhcp client enable */
    char                 dhcp_client_ipv4[GLB_IPV4_MAX_PREFIXLEN]; /* dhcp client ip */
    char                 dhcp_client_ipv4_mask[GLB_MAX_IPV4_MASK_LEN]; /* dhcp client mask */
    uint32               arp_curr_dynamic;    /* arp numberlimit current dynamic arp number */
    uint64               arp_attack_number;   /* arp numberlimit attack number */
    uint8                arp_rate_limit_en;   /* arp rate limit enable flag */
    uint32               arp_rate_limit_pkt_max; /* arp rate limit max pkt rcv in 30s */
    uint8                arp_rate_limit_violation; /* arp rate limit rcv pkts exceed max num , then follow this action to do :restrict, errdisable */
    uint32               arp_rate_limit_pkt_curr; /* arp rate limit current pkt number */
    uint8                arp_rate_limit_port_abnormal_flag; /* arp rate limit rcv pkts exceed max num */
    cdb_reference_list_t ifc_ipv4;
    cdb_reference_list_t ifc_ipv6;
    cdb_reference_list_t ospf_md5_key;
} tbl_route_if_t;

typedef struct
{
    ctclib_hash_t        *if_hash;
    ctclib_slist_t       *if_list;
} tbl_route_if_master_t;

#endif /* !__TBL_ROUTE_IF_DEFINE_H__ */


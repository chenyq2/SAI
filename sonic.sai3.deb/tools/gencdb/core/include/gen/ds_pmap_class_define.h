
#ifndef __DS_PMAP_CLASS_DEFINE_H__
#define __DS_PMAP_CLASS_DEFINE_H__

/* DS_PMAP_CLASS field defines */
typedef enum
{
    DS_PMAP_CLASS_FLD_KEY                  = 0 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_PRIORITY       = 1 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_COLOR          = 2 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_TRUST          = 3 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_REDIRECT       = 4 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_TAP            = 5 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_MONITOR        = 6 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_STATS          = 7 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_DOMAIN         = 8 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_COS            = 9 ,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_DSCP           = 10,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_CTAG_COS       = 11,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_STAG_COS       = 12,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_POLICER        = 13,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_AGGREATE_POLICER = 14,  /* RW */
    DS_PMAP_CLASS_FLD_FLAGS_PHB            = 15,  /* RW */
    DS_PMAP_CLASS_FLD_TRUST                = 16,  /* RW */
    DS_PMAP_CLASS_FLD_PRIORITY             = 17,  /* RW */
    DS_PMAP_CLASS_FLD_COLOR                = 18,  /* RW */
    DS_PMAP_CLASS_FLD_DOMAIN               = 19,  /* RW */
    DS_PMAP_CLASS_FLD_DSCP                 = 20,  /* RW */
    DS_PMAP_CLASS_FLD_COS                  = 21,  /* RW */
    DS_PMAP_CLASS_FLD_MONITOR_SESSION      = 22,  /* RW */
    DS_PMAP_CLASS_FLD_PHB                  = 23,  /* RW */
    DS_PMAP_CLASS_FLD_REDIRECT_IFNAME      = 24,  /* RW */
    DS_PMAP_CLASS_FLD_TAPNAME              = 25,  /* RW */
    DS_PMAP_CLASS_FLD_TAPVLAN              = 26,  /* RW */
    DS_PMAP_CLASS_FLD_POLICER              = 27,  /* RW */
    DS_PMAP_CLASS_FLD_AGGREGATE_POLICER    = 28,  /* RW */
    DS_PMAP_CLASS_FLD_MAX                  = 29
} ds_pmap_class_field_id_t;

/* DS_PMAP_CLASS defines */
typedef struct
{
    char                 name[CMAP_NAME_SIZE];
} ds_pmap_class_key_t;

typedef struct
{
    ds_pmap_class_key_t  key;
    uint32               flags;
    uint8                trust;
    uint8                priority;
    uint8                color;
    uint8                domain;
    uint8                dscp;
    uint8                cos;
    uint8                monitor_session;
    uint8                phb;
    char                 redirect_ifname[IFNAME_SIZE]; /* modify ifindex to ifname for buildcfg */
    char                 tapname[TAP_NAME_SIZE];
    uint32               tapvlan;
    char                 policer[POLICER_NAME_SIZE]; /* */
    char                 aggregate_policer[POLICER_NAME_SIZE]; /* */
} ds_pmap_class_t;

#endif /* !__DS_PMAP_CLASS_DEFINE_H__ */



#ifndef __TBL_DHCSNOOPING_H__
#define __TBL_DHCSNOOPING_H__

int32
tbl_dhcsnooping_set_dhcsnooping_field_sync(tbl_dhcsnooping_t *p_dhcsnooping, tbl_dhcsnooping_field_id_t field_id, uint32 sync);

int32
tbl_dhcsnooping_set_dhcsnooping_field(tbl_dhcsnooping_t *p_dhcsnooping, tbl_dhcsnooping_field_id_t field_id);

tbl_dhcsnooping_t*
tbl_dhcsnooping_get_dhcsnooping();

int32
tbl_dhcsnooping_dump_one(tbl_dhcsnooping_t *p_dhcsnooping, tbl_iter_args_t *pargs);

int32
tbl_dhcsnooping_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_dhcsnooping_t*
tbl_dhcsnooping_init_dhcsnooping();

#endif /* !__TBL_DHCSNOOPING_H__ */


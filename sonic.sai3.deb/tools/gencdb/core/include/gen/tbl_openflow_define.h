
#ifndef __TBL_OPENFLOW_DEFINE_H__
#define __TBL_OPENFLOW_DEFINE_H__

/* TBL_OPENFLOW field defines */
typedef enum
{
    TBL_OPENFLOW_FLD_GROUP_HASH_KEY       = 0 ,  /* RW */
    TBL_OPENFLOW_FLD_BOND_HASH_KEY        = 1 ,  /* RW */
    TBL_OPENFLOW_FLD_BOND_HASH_USE        = 2 ,  /* RW */
    TBL_OPENFLOW_FLD_LACP_LOCAL_PROC      = 3 ,  /* RW */
    TBL_OPENFLOW_FLD_LOCAL_VTEP_IP        = 4 ,  /* RW */
    TBL_OPENFLOW_FLD_DECAP_MODE           = 5 ,  /* RW */
    TBL_OPENFLOW_FLD_FLOW_DROP_PKT_TO_INGRESS_PORT = 6 ,  /* RW */
    TBL_OPENFLOW_FLD_GROUP_DROP_PKT_TO_INGRESS_PORT = 7 ,  /* RW */
    TBL_OPENFLOW_FLD_UDF_PARSER           = 8 ,  /* RW */
    TBL_OPENFLOW_FLD_METER_IPG            = 9 ,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_EN            = 10,  /* RW */
    TBL_OPENFLOW_FLD_PTP_E2E_EN           = 11,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_STAG          = 12,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_ADDR          = 13,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_GW            = 14,  /* RW */
    TBL_OPENFLOW_FLD_MPLS_PARSER          = 15,  /* RW */
    TBL_OPENFLOW_FLD_STPID                = 16,  /* RW */
    TBL_OPENFLOW_FLD_CTPID                = 17,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_DOWNLINK_PORT_BMP = 18,  /* RW */
    TBL_OPENFLOW_FLD_INBAND_UPLINK_PORT_NAME = 19,  /* RW */
    TBL_OPENFLOW_FLD_FLOW_HASH_KEY        = 20,  /* RW */
    TBL_OPENFLOW_FLD_VXLAN_HASH_MERGE_EN  = 21,  /* RW */
    TBL_OPENFLOW_FLD_NVGRE_HASH_MERGE_EN  = 22,  /* RW */
    TBL_OPENFLOW_FLD_EFD_TCP_ONLY_ENABLE  = 23,  /* RW */
    TBL_OPENFLOW_FLD_EFD_GRANULARITY      = 24,  /* RW */
    TBL_OPENFLOW_FLD_EFD_DETECT_SPEED     = 25,  /* RW */
    TBL_OPENFLOW_FLD_EFD_DETECT_TIME_INTERVAL = 26,  /* RW */
    TBL_OPENFLOW_FLD_EFD_AGING_TIMER      = 27,  /* RW */
    TBL_OPENFLOW_FLD_EFD_FLOW_TRAFFIC_CLASS = 28,  /* RW */
    TBL_OPENFLOW_FLD_EFD_FLOW_COLOR       = 29,  /* RW */
    TBL_OPENFLOW_FLD_EFD_IPG_ENABLE       = 30,  /* RW */
    TBL_OPENFLOW_FLD_MAX                  = 31
} tbl_openflow_field_id_t;

/* TBL_OPENFLOW defines */
typedef struct
{
    uint32               group_hash_key;      /* group hash key */
    uint32               bond_hash_key;       /* bond hash key */
    uint32               bond_hash_use;       /* bond hash use */
    uint32               lacp_local_proc;     /* bond hash use */
    addr_ipv4_t          local_vtep_ip;       /* local vtep ip */
    char                 decap_mode[GLB_MAX_DESC_STR_LEN]; /* decapsulation mode */
    uint8                flow_drop_pkt_to_ingress_port; /* flow drop pkt to ingress port */
    uint8                group_drop_pkt_to_ingress_port; /* group drop pkt to ingress port */
    uint8                udf_parser;          /* udf parser */
    uint8                meter_ipg;           /* meter ipg */
    uint8                inband_en;           /* inband enable */
    uint8                ptp_e2e_en;          /* e2e enable */
    vid_t                inband_stag;         /* inband stag */
    prefix_ipv4_t        inband_addr;         /* inband ip address */
    addr_ipv4_t          inband_gw;           /* inband gw address */
    uint8                mpls_parser;         /* mpls parser */
    int32                stpid;               /*stpid*/
    int32                ctpid;               /*ctpid*/
    port_bmp_t           inband_downlink_port_bmp;
    char                 inband_uplink_port_name[IFNAME_SIZE];
    uint32               flow_hash_key;       /* flow hash key */
    uint8                vxlan_hash_merge_en; /* flow hash vxlan merge enable */
    uint8                nvgre_hash_merge_en; /* flow hash nvgre merge enable */
    uint8                efd_tcp_only_enable; /*efd tcp-only enable*/
    uint32               efd_granularity;     /*efd granularity*/
    uint32               efd_detect_speed;    /*efd detect speed*/
    uint32               efd_detect_time_interval; /*efd detect time-interval*/
    uint32               efd_aging_timer;     /*efd aging-timer*/
    uint32               efd_flow_traffic_class; /*efd_flow_traffic_class*/
    uint32               efd_flow_color;      /*efd_flow_color*/
    uint8                efd_ipg_enable;      /*efd ipg enable*/
} tbl_openflow_t;

#endif /* !__TBL_OPENFLOW_DEFINE_H__ */


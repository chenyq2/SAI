
#ifndef __TBL_IPTABLES_PREVENT_H__
#define __TBL_IPTABLES_PREVENT_H__

int32
tbl_iptables_prevent_set_iptables_prevent_field_sync(tbl_iptables_prevent_t *p_iptables_prevent, tbl_iptables_prevent_field_id_t field_id, uint32 sync);

int32
tbl_iptables_prevent_set_iptables_prevent_field(tbl_iptables_prevent_t *p_iptables_prevent, tbl_iptables_prevent_field_id_t field_id);

tbl_iptables_prevent_t*
tbl_iptables_prevent_get_iptables_prevent();

int32
tbl_iptables_prevent_dump_one(tbl_iptables_prevent_t *p_iptables_prevent, tbl_iter_args_t *pargs);

int32
tbl_iptables_prevent_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_iptables_prevent_t*
tbl_iptables_prevent_init_iptables_prevent();

#endif /* !__TBL_IPTABLES_PREVENT_H__ */


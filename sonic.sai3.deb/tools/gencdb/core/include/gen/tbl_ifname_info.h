
#ifndef __TBL_IFNAME_INFO_H__
#define __TBL_IFNAME_INFO_H__

int32
tbl_ifname_info_add_ifname_info_sync(tbl_ifname_info_t *p_ifname_info, uint32 sync);

int32
tbl_ifname_info_del_ifname_info_sync(tbl_ifname_info_key_t *p_ifname_info_key, uint32 sync);

int32
tbl_ifname_info_set_ifname_info_field_sync(tbl_ifname_info_t *p_ifname_info, tbl_ifname_info_field_id_t field_id, uint32 sync);

int32
tbl_ifname_info_add_ifname_info(tbl_ifname_info_t *p_ifname_info);

int32
tbl_ifname_info_del_ifname_info(tbl_ifname_info_key_t *p_ifname_info_key);

int32
tbl_ifname_info_set_ifname_info_field(tbl_ifname_info_t *p_ifname_info, tbl_ifname_info_field_id_t field_id);

tbl_ifname_info_t*
tbl_ifname_info_get_ifname_info(tbl_ifname_info_key_t *p_ifname_info_key);

char*
tbl_ifname_info_key_val2str(tbl_ifname_info_t *p_ifname_info, char *str, uint32 str_len);

int32
tbl_ifname_info_dump_one(tbl_ifname_info_t *p_ifname_info, tbl_iter_args_t *pargs);

int32
tbl_ifname_info_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_ifname_info_master_t*
tbl_ifname_info_get_master();

tbl_ifname_info_master_t*
tbl_ifname_info_init_ifname_info();

#endif /* !__TBL_IFNAME_INFO_H__ */


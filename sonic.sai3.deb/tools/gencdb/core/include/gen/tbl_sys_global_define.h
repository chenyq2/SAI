
#ifndef __TBL_SYS_GLOBAL_DEFINE_H__
#define __TBL_SYS_GLOBAL_DEFINE_H__

/* TBL_SYS_GLOBAL field defines */
typedef enum
{
    TBL_SYS_GLOBAL_FLD_HOSTNAME             = 0 ,  /* RW */
    TBL_SYS_GLOBAL_FLD_ROUTE_MAC            = 1 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_MAC_NUM              = 2 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_CURR_VLANIF_COUNT    = 3 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_INIT_DONE            = 4 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_STARTUP_DONE         = 5 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_MAX_FRAME_SIZE       = 6 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_JUMBO_FRAME_SIZE     = 7 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_REBOOT_TYPE          = 8 ,  /* READ */
    TBL_SYS_GLOBAL_FLD_IPG_SHAPING_ENABLE   = 9 ,  /* RW */
    TBL_SYS_GLOBAL_FLD_IPG_POLICING_ENABLE  = 10,  /* RW */
    TBL_SYS_GLOBAL_FLD_IPG_STORM_CONTROL_ENABLE = 11,  /* RW */
    TBL_SYS_GLOBAL_FLD_AAA_NEW_MODEL        = 12,  /* RW */
    TBL_SYS_GLOBAL_FLD_SERVICE_PASSWORD_ENCRYPTION = 13,  /* RW */
    TBL_SYS_GLOBAL_FLD_MAX_VTY              = 14,  /* RW */
    TBL_SYS_GLOBAL_FLD_AAA_PRIVILEGE1       = 15,  /* RW */
    TBL_SYS_GLOBAL_FLD_AAA_PRIVILEGE2       = 16,  /* RW */
    TBL_SYS_GLOBAL_FLD_AAA_PRIVILEGE3       = 17,  /* RW */
    TBL_SYS_GLOBAL_FLD_DHCP_SERVICE_ENABLE  = 18,  /* RW */
    TBL_SYS_GLOBAL_FLD_DHCP_RELAY_ENABLE    = 19,  /* RW */
    TBL_SYS_GLOBAL_FLD_DHCP_SNOOPING_ENABLE = 20,  /* RW */
    TBL_SYS_GLOBAL_FLD_HTTP_SERVICE_ENABLE  = 21,  /* RW */
    TBL_SYS_GLOBAL_FLD_HTTP_IMAGE_NAME      = 22,  /* RW */
    TBL_SYS_GLOBAL_FLD_ERRDISABLE_INTERVAL  = 23,  /* RW */
    TBL_SYS_GLOBAL_FLD_RPC_HTTP_PORT        = 24,  /* RW */
    TBL_SYS_GLOBAL_FLD_TRUNCTION_LENGTH     = 25,  /* RW */
    TBL_SYS_GLOBAL_FLD_TAP_TS_MACDA         = 26,  /* RW */
    TBL_SYS_GLOBAL_FLD_TAP_TS_MACSA         = 27,  /* RW */
    TBL_SYS_GLOBAL_FLD_ETHER_TYPE           = 28,  /* RW */
    TBL_SYS_GLOBAL_FLD_PTF_PORT             = 29,  /* RW */
    TBL_SYS_GLOBAL_FLD_TELNET_DISABLE       = 30,  /* RW */
    TBL_SYS_GLOBAL_FLD_HTTP_DISABLE         = 31,  /* RW */
    TBL_SYS_GLOBAL_FLD_HTTP_PORT            = 32,  /* RW */
    TBL_SYS_GLOBAL_FLD_CUT_THROUGH_ENABLE   = 33,  /* RW */
    TBL_SYS_GLOBAL_FLD_PROTECTED_VLAN_CNT   = 34,  /* RW */
    TBL_SYS_GLOBAL_FLD_MIB_PORT_STATS_READ_NUM = 35,  /* RW */
    TBL_SYS_GLOBAL_FLD_MIB_FLOW_STATS_READ_NUM = 36,  /* RW */
    TBL_SYS_GLOBAL_FLD_MEMORY_THRESHOLD1    = 37,  /* RW */
    TBL_SYS_GLOBAL_FLD_MEMORY_THRESHOLD2    = 38,  /* RW */
    TBL_SYS_GLOBAL_FLD_MEMORY_THRESHOLD3    = 39,  /* RW */
    TBL_SYS_GLOBAL_FLD_SYSTEM_MEMCHK_STATE  = 40,  /* RW */
    TBL_SYS_GLOBAL_FLD_MGMT_IF_RUNNING      = 41,  /* READ */
    TBL_SYS_GLOBAL_FLD_MGMT_IF_TIMER        = 42,  /* READ */
    TBL_SYS_GLOBAL_FLD_MAX                  = 43
} tbl_sys_global_field_id_t;

/* TBL_SYS_GLOBAL defines */
typedef struct
{
    char                 hostname[HOSTNAME_SIZE+1];
    mac_addr_t           route_mac;
    uint32               mac_num;
    int32                curr_vlanif_count;
    uint32               init_done;
    uint32               startup_done;
    uint32               max_frame_size;
    uint32               jumbo_frame_size;
    uint8                reboot_type;         /* glb_reboot_type_t, this boot reason */
    uint8                ipg_shaping_enable;
    uint8                ipg_policing_enable;
    uint8                ipg_storm_control_enable;
    uint8                aaa_new_model;       /* AAA new model or not, default not */
    uint8                service_password_encryption; /* encrypt password or not */
    uint8                max_vty;             /* MAX vty numbers */
    uint8                aaa_privilege1;
    uint8                aaa_privilege2;
    uint8                aaa_privilege3;
    uint8                dhcp_service_enable; /* enable DHCP service or not */
    uint8                dhcp_relay_enable;   /* enable DHCP relay or not */
    uint8                dhcp_snooping_enable; /* enable DHCP snooping or not */
    uint8                http_service_enable; /* TODO, enable RPC HTTP service */
    char                 http_image_name[HTTP_IMAGE_NAME_SIZE]; /* TODO, HTTP image file name */
    uint32               errdisable_interval; /* errdisable recovery interval*/
    uint32               rpc_http_port;       /* TODO, RPC http server port */
    uint32               trunction_length;    /* Truncation length */
    mac_addr_t           tap_ts_macda;        /* TAP Timestamp macda */
    mac_addr_t           tap_ts_macsa;        /* TAP Timestamp macsa */
    uint16               ether_type;          /* TAP Timestamp ethernet type */
    uint32               ptf_port;            /* PTF test TCP port, 0 means PTF disable */
    uint32               telnet_disable;      /* disable telnet service */
    uint32               http_disable;        /* disable http service */
    uint32               http_port;           /* modify http service port*/
    uint8                cut_through_enable;  /* Enable cut through or not */
    uint32               protected_vlan_cnt;  /*protected vlan count*/
    uint32               mib_port_stats_read_num; /* MIB port stats read number per round */
    uint32               mib_flow_stats_read_num; /* MIB flow stats read number per round */
    uint32               memory_threshold1;   /*memory threshold one*/
    uint32               memory_threshold2;   /*memory threshold two*/
    uint32               memory_threshold3;   /*memory threshold three*/
    uint32               system_memchk_state; /*syslimit_memchk_state_t*/
    uint32               mgmt_if_running;     /* mgmt if up/down state */
    ctc_task_t           *mgmt_if_timer;      /* monitor mgmt if up/down timer */
} tbl_sys_global_t;

#endif /* !__TBL_SYS_GLOBAL_DEFINE_H__ */


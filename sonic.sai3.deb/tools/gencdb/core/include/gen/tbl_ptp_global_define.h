
#ifndef __TBL_PTP_GLOBAL_DEFINE_H__
#define __TBL_PTP_GLOBAL_DEFINE_H__

/* TBL_PTP_GLOBAL field defines */
typedef enum
{
    TBL_PTP_GLOBAL_FLD_ENABLE               = 0 ,  /* RW */
    TBL_PTP_GLOBAL_FLD_MAX                  = 1 
} tbl_ptp_global_field_id_t;

/* TBL_PTP_GLOBAL defines */
typedef struct
{
    uint32               enable;
} tbl_ptp_global_t;

#endif /* !__TBL_PTP_GLOBAL_DEFINE_H__ */


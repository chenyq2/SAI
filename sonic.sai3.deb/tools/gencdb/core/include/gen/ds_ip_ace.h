
#ifndef __DS_IP_ACE_H__
#define __DS_IP_ACE_H__

int32
ds_ip_ace_add_ip_ace_sync(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace, uint32 sync);

int32
ds_ip_ace_del_ip_ace_sync(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace, uint32 sync);

int32
ds_ip_ace_set_ip_ace_field_sync(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace, ds_ip_ace_field_id_t field_id, uint32 sync);

int32
ds_ip_ace_add_ip_ace(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace);

int32
ds_ip_ace_del_ip_ace(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace);

int32
ds_ip_ace_set_ip_ace_field(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace, ds_ip_ace_field_id_t field_id);

ds_ip_ace_t*
ds_ip_ace_get_ip_ace(tbl_acl_t *p_acl, ds_ip_ace_t *p_ip_ace);

int32
ds_ip_ace_dump_one(ds_ip_ace_t *p_ip_ace, tbl_iter_args_t *pargs);

#endif /* !__DS_IP_ACE_H__ */


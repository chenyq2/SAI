
#ifndef __TBL_PMAP_DEFINE_H__
#define __TBL_PMAP_DEFINE_H__

#include "gen/ds_pmap_class_define.h"

/* TBL_PMAP field defines */
typedef enum
{
    TBL_PMAP_FLD_KEY                  = 0 ,  /* RW */
    TBL_PMAP_FLD_CMAP_CNT             = 1 ,  /* READ */
    TBL_PMAP_FLD_ATTACHED             = 2 ,  /* READ */
    TBL_PMAP_FLD_ATTACH_CNT           = 3 ,  /* READ */
    TBL_PMAP_FLD_PMAP_CLASS_LIST      = 4 ,  /* SUB */
    TBL_PMAP_FLD_MAX                  = 5 
} tbl_pmap_field_id_t;

/* TBL_PMAP defines */
typedef struct
{
    char                 name[PMAP_NAME_SIZE+1];
} tbl_pmap_key_t;

typedef struct
{
    tbl_pmap_key_t       key;
    uint8                cmap_cnt;
    uint8                attached;
    uint32               attach_cnt;          /* record number of interface which attched this pmap*/
    uint8                apply_dir;           /* for aggreate policer checking*/
    cdb_reference_list_t pmap_class_list;     /* class and action info, ds list is recommanded, now it is ds only */
} tbl_pmap_t;

typedef struct
{
    ctclib_hash_t        *pmap_hash;
    ctclib_slist_t       *pmap_list;
    uint16               count;               /* use hash count */
} tbl_pmap_master_t;

#endif /* !__TBL_PMAP_DEFINE_H__ */


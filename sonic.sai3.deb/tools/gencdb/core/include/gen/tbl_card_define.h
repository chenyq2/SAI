
#ifndef __TBL_CARD_DEFINE_H__
#define __TBL_CARD_DEFINE_H__

/* TBL_CARD field defines */
typedef enum
{
    TBL_CARD_FLD_KEY                  = 0 ,  /* READ */
    TBL_CARD_FLD_SLOT                 = 1 ,  /* READ */
    TBL_CARD_FLD_PRODUCT_NAME         = 2 ,  /* READ */
    TBL_CARD_FLD_HARDWARE_NAME        = 3 ,  /* READ */
    TBL_CARD_FLD_COMPANY_NAME         = 4 ,  /* READ */
    TBL_CARD_FLD_PACKAGE_NAME         = 5 ,  /* READ */
    TBL_CARD_FLD_ENTERPRISE_OID       = 6 ,  /* READ */
    TBL_CARD_FLD_HARDWARE_TYPE        = 7 ,  /* READ */
    TBL_CARD_FLD_SERIAL_NO            = 8 ,  /* READ */
    TBL_CARD_FLD_BOOTROM_VER          = 9 ,  /* READ */
    TBL_CARD_FLD_EPLD_VER             = 10,  /* RW */
    TBL_CARD_FLD_SW_VER               = 11,  /* READ */
    TBL_CARD_FLD_HARDWARE_VER         = 12,  /* READ */
    TBL_CARD_FLD_BOOTCMD              = 13,  /* RW */
    TBL_CARD_FLD_FLASH_SIZE           = 14,  /* READ */
    TBL_CARD_FLD_DRAM_SIZE            = 15,  /* READ */
    TBL_CARD_FLD_PORT_NUM             = 16,  /* READ */
    TBL_CARD_FLD_UPTIME_DAY           = 17,  /* READ */
    TBL_CARD_FLD_UPTIME_HOUR          = 18,  /* READ */
    TBL_CARD_FLD_UPTIME_MIN           = 19,  /* READ */
    TBL_CARD_FLD_ATTACH_TIME          = 20,  /* RW */
    TBL_CARD_FLD_ATTACH_COUNT         = 21,  /* RW */
    TBL_CARD_FLD_TMPR_LOW             = 22,  /* RW */
    TBL_CARD_FLD_TMPR_HIGH            = 23,  /* RW */
    TBL_CARD_FLD_TMPR_CRITICAL        = 24,  /* RW */
    TBL_CARD_FLD_STATUS               = 25,  /* RW */
    TBL_CARD_FLD_REBOOT               = 26,  /* READ */
    TBL_CARD_FLD_UPDATE_EPLD_NAME     = 27,  /* RW */
    TBL_CARD_FLD_UPDATE_BOOTROM_NAME  = 28,  /* RW */
    TBL_CARD_FLD_PLATFORM_TYPE        = 29,  /* RW */
    TBL_CARD_FLD_MAX                  = 30
} tbl_card_field_id_t;

/* TBL_CARD defines */
typedef struct
{
    uint32               id;
} tbl_card_key_t;

typedef struct
{
    tbl_card_key_t       key;
    uint32               slot;
    char                 product_name[GLB_NAME_INFO_STR_MAX];
    char                 hardware_name[GLB_NAME_INFO_STR_MAX];
    char                 company_name[GLB_NAME_INFO_STR_MAX];
    char                 package_name[GLB_NAME_INFO_STR_MAX];
    char                 enterprise_oid[GLB_NAME_INFO_STR_MAX];
    char                 hardware_type[GLB_NAME_INFO_STR_MAX];
    char                 serial_no[GLB_NAME_INFO_STR_MAX];
    char                 bootrom_ver[GLB_NAME_INFO_STR_MAX];
    char                 epld_ver[GLB_NAME_INFO_STR_MAX];
    char                 sw_ver[GLB_NAME_INFO_STR_MAX];
    char                 hardware_ver[GLB_NAME_INFO_STR_MAX];
    char                 bootcmd[GLB_NAME_INFO_STR_MAX];
    int32                flash_size;
    int32                dram_size;
    int32                port_num;
    int32                uptime_day;
    int32                uptime_hour;
    int32                uptime_min;
    sal_time_t           attach_time;
    uint32               attach_count;
    int32                tmpr_low;
    int32                tmpr_high;
    int32                tmpr_critical;
    uint32               status;              /*Card status, 1 means ready, 0 means not ready*/
    uint32               reboot;
    char                 update_epld_name[GLB_NAME_INFO_STR_MAX];
    char                 update_bootrom_name[GLB_NAME_INFO_STR_MAX];
    int32                platform_type;
} tbl_card_t;

typedef struct
{
    tbl_card_t           *card_array[GLB_SLOT_NUM_MAX];
} tbl_card_master_t;

#endif /* !__TBL_CARD_DEFINE_H__ */



#ifndef __TBL_SFLOW_GLOBAL_H__
#define __TBL_SFLOW_GLOBAL_H__

int32
tbl_sflow_global_set_sflow_global_field_sync(tbl_sflow_global_t *p_sflow_glb, tbl_sflow_global_field_id_t field_id, uint32 sync);

int32
tbl_sflow_global_set_sflow_global_field(tbl_sflow_global_t *p_sflow_glb, tbl_sflow_global_field_id_t field_id);

tbl_sflow_global_t*
tbl_sflow_global_get_sflow_global();

int32
tbl_sflow_global_dump_one(tbl_sflow_global_t *p_sflow_glb, tbl_iter_args_t *pargs);

int32
tbl_sflow_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_sflow_global_t*
tbl_sflow_global_init_sflow_global();

#endif /* !__TBL_SFLOW_GLOBAL_H__ */


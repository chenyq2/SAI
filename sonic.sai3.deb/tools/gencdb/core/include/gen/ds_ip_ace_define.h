
#ifndef __DS_IP_ACE_DEFINE_H__
#define __DS_IP_ACE_DEFINE_H__

/* DS_IP_ACE field defines */
typedef enum
{
    DS_IP_ACE_FLD_KEY                  = 0 ,  /* RW */
    DS_IP_ACE_FLD_TIME_RANGE           = 1 ,  /* RW */
    DS_IP_ACE_FLD_IP_SA                = 2 ,  /* RW */
    DS_IP_ACE_FLD_IP_SA_MASK           = 3 ,  /* RW */
    DS_IP_ACE_FLD_IP_DA                = 4 ,  /* RW */
    DS_IP_ACE_FLD_IP_DA_MASK           = 5 ,  /* RW */
    DS_IP_ACE_FLD_L4_PROTOCOL          = 6 ,  /* RW */
    DS_IP_ACE_FLD_L4_SRC_PORT          = 7 ,  /* RW */
    DS_IP_ACE_FLD_L4_DST_PORT          = 8 ,  /* RW */
    DS_IP_ACE_FLD_IP_FRAG              = 9 ,  /* RW */
    DS_IP_ACE_FLD_TCP_FLAG             = 10,  /* RW */
    DS_IP_ACE_FLD_IP_OPTIONS           = 11,  /* RW */
    DS_IP_ACE_FLD_DSCP                 = 12,  /* RW */
    DS_IP_ACE_FLD_PREC                 = 13,  /* RW */
    DS_IP_ACE_FLD_ICMP_CODE            = 14,  /* RW */
    DS_IP_ACE_FLD_ICMP_TYPE            = 15,  /* RW */
    DS_IP_ACE_FLD_IGMP_TYPE            = 16,  /* RW */
    DS_IP_ACE_FLD_APPLY_CNT            = 17,  /* READ */
    DS_IP_ACE_FLD_STATS                = 18,  /* READ */
    DS_IP_ACE_FLD_MAX                  = 19
} ds_ip_ace_field_id_t;

/* DS_IP_ACE defines */
typedef struct
{
    uint32               seqno;
} ds_ip_ace_key_t;

typedef struct
{
    ds_ip_ace_key_t      key;
    char                 time_range[TIME_RANGE_SIZE];
    addr_ipv4_t          ip_sa;
    addr_ipv4_t          ip_sa_mask;
    addr_ipv4_t          ip_da;
    addr_ipv4_t          ip_da_mask;
    uint8                l4_protocol;
    glb_flow_l4_port_t   l4_src_port;
    glb_flow_l4_port_t   l4_dst_port;
    uint8                ip_frag;
    glb_flow_tcp_flag_t  tcp_flag;
    uint8                ip_options;
    uint8                dscp;
    uint8                prec;
    uint8                icmp_code;
    uint8                icmp_type;
    uint8                igmp_type;
    uint16               apply_cnt;           /* ip ace apply count: if not zero, time-range is started either*/
    glb_stats_t          stats;
} ds_ip_ace_t;

#endif /* !__DS_IP_ACE_DEFINE_H__ */


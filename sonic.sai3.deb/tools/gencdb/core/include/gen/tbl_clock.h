
#ifndef __TBL_CLOCK_H__
#define __TBL_CLOCK_H__

int32
tbl_clock_set_clock_field_sync(tbl_clock_t *p_clk, tbl_clock_field_id_t field_id, uint32 sync);

int32
tbl_clock_set_clock_field(tbl_clock_t *p_clk, tbl_clock_field_id_t field_id);

tbl_clock_t*
tbl_clock_get_clock();

int32
tbl_clock_dump_one(tbl_clock_t *p_clk, tbl_iter_args_t *pargs);

int32
tbl_clock_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_clock_t*
tbl_clock_init_clock();

#endif /* !__TBL_CLOCK_H__ */


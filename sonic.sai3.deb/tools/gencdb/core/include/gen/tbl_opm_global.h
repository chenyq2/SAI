
#ifndef __TBL_OPM_GLOBAL_H__
#define __TBL_OPM_GLOBAL_H__

int32
tbl_opm_global_set_opm_global_field_sync(tbl_opm_global_t *p_opmglb, tbl_opm_global_field_id_t field_id, uint32 sync);

int32
tbl_opm_global_set_opm_global_field(tbl_opm_global_t *p_opmglb, tbl_opm_global_field_id_t field_id);

tbl_opm_global_t*
tbl_opm_global_get_opm_global();

int32
tbl_opm_global_dump_one(tbl_opm_global_t *p_opmglb, tbl_iter_args_t *pargs);

int32
tbl_opm_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_opm_global_t*
tbl_opm_global_init_opm_global();

#endif /* !__TBL_OPM_GLOBAL_H__ */


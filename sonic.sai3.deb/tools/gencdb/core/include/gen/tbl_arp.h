
#ifndef __TBL_ARP_H__
#define __TBL_ARP_H__

int32
tbl_arp_add_arp_sync(tbl_arp_t *p_arp, uint32 sync);

int32
tbl_arp_del_arp_sync(tbl_arp_key_t *p_arp_key, uint32 sync);

int32
tbl_arp_set_arp_field_sync(tbl_arp_t *p_arp, tbl_arp_field_id_t field_id, uint32 sync);

int32
tbl_arp_add_arp(tbl_arp_t *p_arp);

int32
tbl_arp_del_arp(tbl_arp_key_t *p_arp_key);

int32
tbl_arp_set_arp_field(tbl_arp_t *p_arp, tbl_arp_field_id_t field_id);

tbl_arp_t*
tbl_arp_get_arp(tbl_arp_key_t *p_arp_key);

char*
tbl_arp_key_val2str(tbl_arp_t *p_arp, char *str, uint32 str_len);

int32
tbl_arp_dump_one(tbl_arp_t *p_arp, tbl_iter_args_t *pargs);

int32
tbl_arp_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_arp_master_t*
tbl_arp_get_master();

tbl_arp_master_t*
tbl_arp_init_arp();

#endif /* !__TBL_ARP_H__ */


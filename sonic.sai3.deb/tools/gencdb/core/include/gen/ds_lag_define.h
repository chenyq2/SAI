
#ifndef __DS_LAG_DEFINE_H__
#define __DS_LAG_DEFINE_H__

/* DS_LAG field defines */
typedef enum
{
    DS_LAG_FLD_MODE                 = 0 ,  /* READ */
    DS_LAG_FLD_LAG_ID               = 1 ,  /* READ */
    DS_LAG_FLD_OPER_STATE           = 2 ,  /* READ */
    DS_LAG_FLD_BUNDLE_PORTS_COUNT   = 3 ,  /* READ */
    DS_LAG_FLD_LOAD_BALANCE_MODE    = 4 ,  /* RW */
    DS_LAG_FLD_MEMBER_PORTS         = 5 ,  /* READ */
    DS_LAG_FLD_MAX                  = 6 
} ds_lag_field_id_t;

/* DS_LAG defines */
typedef struct
{
    uint8                mode;                /* glb_agg_mode_t */
    uint8                lag_id;
    uint8                oper_state;
    int8                 bundle_ports_count;
    uint8                load_balance_mode;
    cdb_reference_list_t member_ports;        /* only for LAG group */
} ds_lag_t;

#endif /* !__DS_LAG_DEFINE_H__ */



#ifndef __TBL_LAG_GLOBAL_H__
#define __TBL_LAG_GLOBAL_H__

int32
tbl_lag_global_set_lag_global_field_sync(tbl_lag_global_t *p_lag_glb, tbl_lag_global_field_id_t field_id, uint32 sync);

int32
tbl_lag_global_set_lag_global_field(tbl_lag_global_t *p_lag_glb, tbl_lag_global_field_id_t field_id);

tbl_lag_global_t*
tbl_lag_global_get_lag_global();

int32
tbl_lag_global_dump_one(tbl_lag_global_t *p_lag_glb, tbl_iter_args_t *pargs);

int32
tbl_lag_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_lag_global_t*
tbl_lag_global_init_lag_global();

#endif /* !__TBL_LAG_GLOBAL_H__ */


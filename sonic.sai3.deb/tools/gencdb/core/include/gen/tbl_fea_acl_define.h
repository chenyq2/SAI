
#ifndef __TBL_FEA_ACL_DEFINE_H__
#define __TBL_FEA_ACL_DEFINE_H__

/* TBL_FEA_ACL field defines */
typedef enum
{
    TBL_FEA_ACL_FLD_KEY                  = 0 ,  /* READ */
    TBL_FEA_ACL_FLD_SAI_ACL_ID           = 1 ,  /* RW */
    TBL_FEA_ACL_FLD_COUNTER_ID           = 2 ,  /* RW */
    TBL_FEA_ACL_FLD_STATS_PACKET         = 3 ,  /* RW */
    TBL_FEA_ACL_FLD_STATS_BYTE           = 4 ,  /* RW */
    TBL_FEA_ACL_FLD_MAX                  = 5 
} tbl_fea_acl_field_id_t;

/* TBL_FEA_ACL defines */
typedef struct
{
    uint64               acl_id;
} tbl_fea_acl_key_t;

typedef struct
{
    tbl_fea_acl_key_t    key;
    uint64               sai_acl_id;
    uint64               counter_id;
    uint64               stats_packet;
    uint64               stats_byte;
} tbl_fea_acl_t;

typedef struct
{
    ctclib_hash_t        *fea_acl_hash;
} tbl_fea_acl_master_t;

#endif /* !__TBL_FEA_ACL_DEFINE_H__ */


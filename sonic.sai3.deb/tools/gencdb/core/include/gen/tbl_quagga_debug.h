
#ifndef __TBL_QUAGGA_DEBUG_H__
#define __TBL_QUAGGA_DEBUG_H__

int32
tbl_quagga_debug_set_quagga_debug_field_sync(tbl_quagga_debug_t *p_dbg, tbl_quagga_debug_field_id_t field_id, uint32 sync);

int32
tbl_quagga_debug_set_quagga_debug_field(tbl_quagga_debug_t *p_dbg, tbl_quagga_debug_field_id_t field_id);

tbl_quagga_debug_t*
tbl_quagga_debug_get_quagga_debug();

int32
tbl_quagga_debug_dump_one(tbl_quagga_debug_t *p_dbg, tbl_iter_args_t *pargs);

int32
tbl_quagga_debug_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_quagga_debug_t*
tbl_quagga_debug_init_quagga_debug();

#endif /* !__TBL_QUAGGA_DEBUG_H__ */


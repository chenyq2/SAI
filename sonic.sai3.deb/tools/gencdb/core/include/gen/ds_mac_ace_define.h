
#ifndef __DS_MAC_ACE_DEFINE_H__
#define __DS_MAC_ACE_DEFINE_H__

/* DS_MAC_ACE field defines */
typedef enum
{
    DS_MAC_ACE_FLD_KEY                  = 0 ,  /* RW */
    DS_MAC_ACE_FLD_TIME_RANGE           = 1 ,  /* RW */
    DS_MAC_ACE_FLD_MAC_SA               = 2 ,  /* RW */
    DS_MAC_ACE_FLD_MAC_SA_MASK          = 3 ,  /* RW */
    DS_MAC_ACE_FLD_MAC_DA               = 4 ,  /* RW */
    DS_MAC_ACE_FLD_MAC_DA_MASK          = 5 ,  /* RW */
    DS_MAC_ACE_FLD_VLAN                 = 6 ,  /* RW */
    DS_MAC_ACE_FLD_INNER_VLAN           = 7 ,  /* RW */
    DS_MAC_ACE_FLD_COS                  = 8 ,  /* RW */
    DS_MAC_ACE_FLD_INNER_COS            = 9 ,  /* RW */
    DS_MAC_ACE_FLD_ETHER_TYPE           = 10,  /* RW */
    DS_MAC_ACE_FLD_ETHER_TYPE_MASK      = 11,  /* RW */
    DS_MAC_ACE_FLD_ARP_OP_CODE          = 12,  /* RW */
    DS_MAC_ACE_FLD_APPLY_CNT            = 13,  /* READ */
    DS_MAC_ACE_FLD_SENDER_IP            = 14,  /* RW */
    DS_MAC_ACE_FLD_SENDER_IP_MASK       = 15,  /* RW */
    DS_MAC_ACE_FLD_TARGET_IP            = 16,  /* RW */
    DS_MAC_ACE_FLD_TARGET_IP_MASK       = 17,  /* RW */
    DS_MAC_ACE_FLD_STATS                = 18,  /* READ */
    DS_MAC_ACE_FLD_MAX                  = 19
} ds_mac_ace_field_id_t;

/* DS_MAC_ACE defines */
typedef struct
{
    uint32               seqno;
} ds_mac_ace_key_t;

typedef struct
{
    ds_mac_ace_key_t     key;
    char                 time_range[TIME_RANGE_SIZE];
    mac_addr_t           mac_sa;
    mac_addr_t           mac_sa_mask;
    mac_addr_t           mac_da;
    mac_addr_t           mac_da_mask;
    uint16               vlan;
    uint16               inner_vlan;
    uint8                cos;
    uint8                inner_cos;
    uint16               ether_type;
    uint16               ether_type_mask;
    uint16               arp_op_code;
    uint16               apply_cnt;           /* mac ace apply count: if not zero, time-range is started either*/
    addr_ipv4_t          sender_ip;
    addr_ipv4_t          sender_ip_mask;
    addr_ipv4_t          target_ip;
    addr_ipv4_t          target_ip_mask;
    glb_stats_t          stats;
} ds_mac_ace_t;

#endif /* !__DS_MAC_ACE_DEFINE_H__ */



#ifndef __DS_FLUSH_FDB_H__
#define __DS_FLUSH_FDB_H__

int32
ds_flush_fdb_add_flush_fdb_sync(tbl_l2_action_t *p_l2_act, ds_flush_fdb_t *p_flush_fdb, uint32 sync);

int32
ds_flush_fdb_del_flush_fdb_sync(tbl_l2_action_t *p_l2_act, uint32 sync);

int32
ds_flush_fdb_set_flush_fdb_field_sync(tbl_l2_action_t *p_l2_act, ds_flush_fdb_t *p_flush_fdb, ds_flush_fdb_field_id_t field_id, uint32 sync);

int32
ds_flush_fdb_add_flush_fdb(tbl_l2_action_t *p_l2_act, ds_flush_fdb_t *p_flush_fdb);

int32
ds_flush_fdb_del_flush_fdb(tbl_l2_action_t *p_l2_act);

int32
ds_flush_fdb_set_flush_fdb_field(tbl_l2_action_t *p_l2_act, ds_flush_fdb_t *p_flush_fdb, ds_flush_fdb_field_id_t field_id);

ds_flush_fdb_t*
ds_flush_fdb_get_flush_fdb(tbl_l2_action_t *p_l2_act);

int32
ds_flush_fdb_dump_one(ds_flush_fdb_t *p_flush_fdb, tbl_iter_args_t *pargs);

#endif /* !__DS_FLUSH_FDB_H__ */


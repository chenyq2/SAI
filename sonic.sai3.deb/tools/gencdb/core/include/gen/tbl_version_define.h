
#ifndef __TBL_VERSION_DEFINE_H__
#define __TBL_VERSION_DEFINE_H__

/* TBL_VERSION field defines */
typedef enum
{
    TBL_VERSION_FLD_VERSION              = 0 ,  /* READ */
    TBL_VERSION_FLD_COMPANY              = 1 ,  /* READ */
    TBL_VERSION_FLD_PACKAGE              = 2 ,  /* READ */
    TBL_VERSION_FLD_PRODUCT              = 3 ,  /* READ */
    TBL_VERSION_FLD_HW_TYPE              = 4 ,  /* READ */
    TBL_VERSION_FLD_MAX                  = 5 
} tbl_version_field_id_t;

/* TBL_VERSION defines */
typedef struct
{
    char                 version[SYS_INFO_SIZE];
    char                 company[SYS_INFO_SIZE];
    char                 package[SYS_INFO_SIZE];
    char                 product[SYS_INFO_SIZE];
    char                 hw_type[SYS_INFO_SIZE];
} tbl_version_t;

#endif /* !__TBL_VERSION_DEFINE_H__ */


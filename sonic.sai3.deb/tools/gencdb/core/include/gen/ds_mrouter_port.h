
#ifndef __DS_MROUTER_PORT_H__
#define __DS_MROUTER_PORT_H__

int32
ds_mrouter_port_add_mrouter_port_sync(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port, uint32 sync);

int32
ds_mrouter_port_del_mrouter_port_sync(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port, uint32 sync);

int32
ds_mrouter_port_set_mrouter_port_field_sync(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port, ds_mrouter_port_field_id_t field_id, uint32 sync);

int32
ds_mrouter_port_add_mrouter_port(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port);

int32
ds_mrouter_port_del_mrouter_port(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port);

int32
ds_mrouter_port_set_mrouter_port_field(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port, ds_mrouter_port_field_id_t field_id);

ds_mrouter_port_t*
ds_mrouter_port_get_mrouter_port(tbl_igsp_intf_t *p_if, ds_mrouter_port_t *p_mr_port);

int32
ds_mrouter_port_dump_one(ds_mrouter_port_t *p_mr_port, tbl_iter_args_t *pargs);

#endif /* !__DS_MROUTER_PORT_H__ */



#ifndef __TBL_BHM_GLOBAL_H__
#define __TBL_BHM_GLOBAL_H__

int32
tbl_bhm_global_set_bhm_global_field_sync(tbl_bhm_global_t *p_bhm_glb, tbl_bhm_global_field_id_t field_id, uint32 sync);

int32
tbl_bhm_global_set_bhm_global_field(tbl_bhm_global_t *p_bhm_glb, tbl_bhm_global_field_id_t field_id);

tbl_bhm_global_t*
tbl_bhm_global_get_bhm_global();

int32
tbl_bhm_global_dump_one(tbl_bhm_global_t *p_bhm_glb, tbl_iter_args_t *pargs);

int32
tbl_bhm_global_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_bhm_global_t*
tbl_bhm_global_init_bhm_global();

#endif /* !__TBL_BHM_GLOBAL_H__ */


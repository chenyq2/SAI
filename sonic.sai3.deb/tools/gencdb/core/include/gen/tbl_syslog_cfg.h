
#ifndef __TBL_SYSLOG_CFG_H__
#define __TBL_SYSLOG_CFG_H__

int32
tbl_syslog_cfg_set_syslog_cfg_field_sync(tbl_syslog_cfg_t *p_syslog_cfg, tbl_syslog_cfg_field_id_t field_id, uint32 sync);

int32
tbl_syslog_cfg_set_syslog_cfg_field(tbl_syslog_cfg_t *p_syslog_cfg, tbl_syslog_cfg_field_id_t field_id);

tbl_syslog_cfg_t*
tbl_syslog_cfg_get_syslog_cfg();

int32
tbl_syslog_cfg_dump_one(tbl_syslog_cfg_t *p_syslog_cfg, tbl_iter_args_t *pargs);

int32
tbl_syslog_cfg_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_syslog_cfg_t*
tbl_syslog_cfg_init_syslog_cfg();

#endif /* !__TBL_SYSLOG_CFG_H__ */



#ifndef __TBL_L2_ACTION_H__
#define __TBL_L2_ACTION_H__

#include "gen/ds_flush_fdb.h"

int32
tbl_l2_action_set_l2_action_field_sync(tbl_l2_action_t *p_l2_act, tbl_l2_action_field_id_t field_id, uint32 sync);

int32
tbl_l2_action_set_l2_action_field(tbl_l2_action_t *p_l2_act, tbl_l2_action_field_id_t field_id);

tbl_l2_action_t*
tbl_l2_action_get_l2_action();

int32
tbl_l2_action_dump_one(tbl_l2_action_t *p_l2_act, tbl_iter_args_t *pargs);

int32
tbl_l2_action_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_l2_action_t*
tbl_l2_action_init_l2_action();

#endif /* !__TBL_L2_ACTION_H__ */



#ifndef __TBL_ACL_H__
#define __TBL_ACL_H__

#include "gen/ds_mac_ace.h"
#include "gen/ds_ip_ace.h"

int32
tbl_acl_add_acl_sync(tbl_acl_t *p_acl, uint32 sync);

int32
tbl_acl_del_acl_sync(tbl_acl_key_t *p_acl_key, uint32 sync);

int32
tbl_acl_set_acl_field_sync(tbl_acl_t *p_acl, tbl_acl_field_id_t field_id, uint32 sync);

int32
tbl_acl_add_acl(tbl_acl_t *p_acl);

int32
tbl_acl_del_acl(tbl_acl_key_t *p_acl_key);

int32
tbl_acl_set_acl_field(tbl_acl_t *p_acl, tbl_acl_field_id_t field_id);

tbl_acl_t*
tbl_acl_get_acl(tbl_acl_key_t *p_acl_key);

char*
tbl_acl_key_val2str(tbl_acl_t *p_acl, char *str, uint32 str_len);

int32
tbl_acl_dump_one(tbl_acl_t *p_acl, tbl_iter_args_t *pargs);

int32
tbl_acl_iterate(TBL_ITER_CB_FUNC fn, tbl_iter_args_t *pargs);

tbl_acl_master_t*
tbl_acl_get_master();

tbl_acl_master_t*
tbl_acl_init_acl();

tbl_acl_t*
tbl_acl_get_acl_by_name(char *name);

#endif /* !__TBL_ACL_H__ */


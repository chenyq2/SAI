#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./pms-e300.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3

export LD_LIBRARY_PATH=/centec_switch/lib

echo "Centec Switch DUT Initialize..."
OSPDIR=/centec_switch
rm -fr /tmp/fea_done

#cp -fr $OSPDIR/etc/fea_cfg_metro_advanced /etc/fea_cfg
#cp -fr $OSPDIR/etc/ShowIpeDiscardType.txt /tmp/ShowIpeDiscardType.txt
#cp -fr $OSPDIR/etc/ShowEpeDiscardType.txt /tmp/ShowEpeDiscardType.txt

# initialize syslog-ng configuration file
#rm -fr /etc/syslog-ng.conf
#$OSPDIR/sbin/init-syslog-ng.sh

# initialize code file structure
mkdir -p /mnt/flash/cold
mkdir -p /mnt/flash/cold/bak
mkdir -p /mnt/flash/cold/cmd
mkdir -p /mnt/flash/cold/log
mkdir -p /mnt/flash/cold/running
mkdir -p /var/empty/sshd
mkdir -p /var/run
# initialize ntpd configuration file
mkdir -p /etc/ntp
cp -fr $OSPDIR/etc/ntp.conf /etc/ntp.conf
cp -fr $OSPDIR/etc/ntpkeys.conf /etc/ntp/keys
# starting ntpd
echo "Start ntpd..."
$OSPDIR/sbin/ntpd -c /etc/ntp.conf -p /var/run/ntpd.pid -g
# kill dropbear sshd
killall sshd

# prepare sshd configuration files
rm -fr /etc/ssh
mkdir -p /etc/ssh
chmod 755 /etc/ssh
cp -fr /centec_switch/etc/ssh/* /etc/ssh/
cp -fr /centec_switch/lib/security/pam_ctc.so /lib/security/
chmod 600 /etc/ssh/*
mkdir -p /etc/ssh/keys
chmod 700 /etc/ssh/keys
mkdir -p /var/empty
chmod 755 /var/empty
SSHD_USR=`cat /etc/passwd | grep sshd`
if [ "$SSHD_USR" == "" ]; then
    echo "sshd:*:74:74:Privilege-separated SSH:/var/empty:/sbin/nologin" >> /etc/passwd
fi


# initialize diag log structure
mkdir -p /mnt/flash/info

# initialize syslog-ng configuration file
rm -fr /etc/syslog-ng.conf
$OSPDIR/sbin/init-syslog-ng.sh

# starting up syslog-ng
echo "Start syslog-ng..."
$OSPDIR/sbin/syslog-ng -f /etc/syslog-ng.conf

echo "Insert kernel modules..."

# Init veth pair which is used for mgmt/default namespace port forwarding.
echo "Setup veth pair..."
source $OSPDIR/etc/init-veth.sh

echo "Start PMs ..."
#$OSPDIR/sbin/zebra &
$OSPDIR/sbin/ccs &
$OSPDIR/sbin/cds &
sleep 2
$OSPDIR/sbin/switch &
$OSPDIR/sbin/opm &
$OSPDIR/sbin/routed &
$OSPDIR/sbin/appcfg &
$OSPDIR/sbin/dhcrelay -4 -d >/dev/null
$OSPDIR/sbin/dhcsnooping -d >/dev/null
$OSPDIR/sbin/zebra -d
sleep 2
echo "Start chsm ..."
$OSPDIR/sbin/chsm &

echo "Waiting the fea initialize..."
$OSPDIR/sbin/fea & 
# waiting fea done
while true; do          
    if [ -f /tmp/fea_done ] ; then
        break;           
    fi                       
    echo -n "."          
    sleep 1;                
done

cdbctl update/cdb/sys/sys_global/init_done/1
echo "init done"
echo "Loading startup configuration file"
klish -q -s /mnt/flash/startup-config.conf

sleep 1
echo "Loading startup configuration done..."

MANG_VRF=64
#echo "Starting telnetd..."
/centec_switch/sbin/busybox telnetd -b :: -l /centec_switch/sbin/klish


exit 0

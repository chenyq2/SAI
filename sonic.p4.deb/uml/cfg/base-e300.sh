#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./base-e300.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3

# delete temp files
rm -fr /var/run/*_done
rm -fr /tmp/*
rm -fr /var/log/*log /var/log/*tmp /var/log/messages
rm -fr /var/run/*.pid
mkdir /tmp/cmd

#process hostname
hostname Centec
if [ -f /mnt/flash/startup-config.conf ]; then
    cat /mnt/flash/startup-config.conf | grep "^hostname" | sh
fi

# up interfaces
intnum=`cat $cfgfile | grep DUT_MAX_INTERFACES | awk '{print $3}'`
for ((i = 0; i <= $intnum; i++)) do
    ifconfig eth$i up >/dev/null 2>&1
    ip address flush dev eth$i scope link >/dev/null 2>&1
done

cpubase=`cat $cfgfile | grep CMODEL_CPU_PORT_BASE | awk '{print substr($3, 4, 3)}'`
cpucnt=`cat $cfgfile | grep CMODEL_CPU_PORT_CNT | awk '{print $3}'`
for ((i = 0; i < $cpucnt; i++)) do
    ifconfig eth$cpubase mtu 10000 >/dev/null 2>&1
    cpubase=`expr $cpubase + 1`
done

manint=`cat $cfgfile | grep MAN_INTERFACE_DUT | awk '{print $3}'`
ifconfig $manint up mtu 1600 >/dev/null 2>&1
ip address flush dev $manint scope link >/dev/null 2>&1
# process files
cp -rf /usr/share/zoneinfo/UTC /etc/localtime
rm -fr /etc/memory_profile
ln -s /centec_switch/etc/profile /etc/memory_profile

rm -fr /etc/pam.d/clish
rm -fr /etc/pam.d/sshd
ln -s /centec_switch/etc/pam_ctc_conf /etc/pam.d/clish
ln -s /centec_switch/etc/pam_ctc_conf /etc/pam.d/sshd
rm -fr /etc/nsswitch.conf
ln -s /centec_switch/etc/nss_ctc_conf /etc/nsswitch.conf
mkdir -p /mnt/flash/.ssh/
rm -fr /mnt/flash/.ssh/environment
echo "LD_LIBRARY_PATH=/centec_switch/lib" > /mnt/flash/.ssh/environment
echo "PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin:/usr/X11R6/bin:/centec_switch/sbin" >> /mnt/flash/.ssh/environment

touch /var/log/lastlog
touch /var/log/wtmp
        
cat > /tmp/oem_info <<EOF
company_full_name 2004-2014 Centec Networks Inc
package_name CentecOS
product_name V350
hardware_type 48T4X
snmp_enterprise_oid 27975
chassis_type PIZZA_BOX
4sfp_name NM-4SFP
2sfpp_name NM-2SFP+
4sfpp_name NM-4SFP+
EOF

MY_CD=`cat /root/.bash_profile | grep 'sbin' | grep 'cd'`
if [ "$MY_CD" == "" ]; then
    echo "cd $imagepath/sbin" >> /root/.bash_profile
fi

MY_GDB=`cat /root/.bash_profile | grep 'zz'`
if [ "$MY_GDB" == "" ]; then
    echo 'function zz_gdb' >> /root/.bash_profile
    echo '{' >> /root/.bash_profile
    echo '    gdb $1 `pgrep $1`' >> /root/.bash_profile
    echo '}' >> /root/.bash_profile
fi

MY_L=`cat /root/.bash_profile | grep 'alias' | grep 'ls -lhF'`
if [ "$MY_L" == "" ]; then
    echo "alias l='ls -lhF'" >> /root/.bash_profile
fi

MY_LA=`cat /root/.bash_profile | grep 'alias' | grep 'ls -alhF'`
if [ "$MY_LA" == "" ]; then
    echo "alias la='ls -alhF'" >> /root/.bash_profile
fi

MY_GREP=`cat /root/.bash_profile | grep 'alias' | grep 'grep --color=auto'`
if [ "$MY_GREP" == "" ]; then
    echo "alias grep='grep --color=auto'" >> /root/.bash_profile
fi

MY_CLS=`cat /root/.bash_profile | grep 'alias' | grep 'clear; history -c'`
if [ "$MY_CLS" == "" ]; then
    echo "alias cls='clear; history -c'" >> /root/.bash_profile
fi

MY_EXPR=`cat /root/.bash_profile | grep LD_LIBRARY_PATH`
if [ "$MY_EXPR" == "" ]; then
    echo "export LD_LIBRARY_PATH=/centec_switch/lib" >> /root/.bash_profile
fi

MY_HALT=`cat /root/.bash_profile | grep 'alias' | grep 'halt -f'`
if [ "$MY_HALT" == "" ]; then
    echo "alias bye='halt -f'" >> /root/.bash_profile
fi
# setting PATH
export PATH=$PATH:/centec_switch/sbin

cat > /tmp/oem_info <<EOF
company_full_name 2004-2013 Centec Networks Inc
package_name CentecOS
product_name V350
hardware_type 48T4XG
snmp_enterprise_oid 27975
chassis_type PIZZA_BOX
EOF

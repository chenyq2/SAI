# !/bin/bash

#
# this script executed in uml environment
#

if [ $# != 2 ]; then
    echo "Usage: ./sysctl.sh cfgfile dutname"
    exit 1;
fi

cfgfile=$1
dutname=$2
manint=`cat $cfgfile | grep MAN_INTERFACE_DUT | awk '{ print $3}'`
if [ $dutname = "CTP" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CTP | awk '{ print $3}'`
fi

if [ $dutname = "CLT" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_CLT | awk '{ print $3}'`
fi
    
if [ $dutname = "SRV" ]; then
    manint=`cat $cfgfile | grep MAN_INTERFACE_SRV | awk '{ print $3}'`
fi

if [ $dutname != "CTP" ] && [ $dutname != "CLT" ] && [ $dutname != "SRV" ]; then
    # for memory protect
    sysctl -w vm.overcommit_memory=2
    sysctl -w vm.overcommit_ratio=95
 
    #for icmp redirect, for bug 13190
    sysctl -w net.ipv4.conf.all.send_redirects=0
    
    # for ipv4/6 neigh
    sysctl -w net.ipv4.conf.default.force_igmp_version=2
    sysctl -w net.ipv4.conf.all.accept_source_route=1
    disable kernel ARP
    sysctl -w net.ipv4.neigh.default.ucast_solicit=0
    sysctl -w net.ipv4.neigh.default.mcast_solicit=0
    sysctl -w net.ipv4.neigh.default.app_solicit=1
    sysctl -w net.ipv4.neigh.default.retrans_time_ms=3000
    sysctl -w net.ipv6.neigh.default.ucast_solicit=0
    sysctl -w net.ipv6.neigh.default.mcast_solicit=0
    sysctl -w net.ipv6.neigh.default.app_solicit=1
    sysctl -w net.ipv6.conf.default.dad_transmits=0
    sysctl -w net.ipv6.conf.all.dad_transmits=0
    sysctl -w net.ipv6.conf.all.router_solicitation_delay=0
    sysctl -w net.ipv6.conf.default.router_solicitation_delay=0
    sysctl -w net.ipv6.neigh.default.retrans_time_ms=3000
    sysctl -w net.ipv6.neigh.default.gc_thresh1=256
    sysctl -w net.ipv6.neigh.default.gc_thresh2=1024
    sysctl -w net.ipv6.neigh.default.gc_thresh3=2048

    #enable 8192 entries for ARP
    sysctl -w net.ipv4.neigh.default.gc_thresh1=3072
    sysctl -w net.ipv4.neigh.default.gc_thresh2=12288
    sysctl -w net.ipv4.neigh.default.gc_thresh3=24576

    # Configure socket max memberships
    sysctl -w net.ipv4.igmp_max_memberships=1000 2>&1 > /dev/null
fi

# for syslog message lost :bug 18873, make burst message form 10 to 128
sysctl -w net.unix.max_dgram_qlen=128

# for coredump
sysctl -w kernel.core_pattern='/mnt/flash/%e.core'
sysctl -w net.core.rmem_max=8000000
sysctl -w net.core.rmem_default=1000000
sysctl -w net.core.wmem_max=8000000
sysctl -w net.core.wmem_default=1000000

exit 0

# !/bin/bash

if [ $# != 2 ]; then
    echo "Usage: ./prepare_dirs.sh prefix dutname"
    exit 1;
fi

prefix=$1
name=$2
dutname=`echo $name | dd conv=lcase 2>/dev/null`

hoststr=`hostname`
commdirs="infoexchange"

if [[ $dutname == e800* ]]; then
prefixdir=../../$prefix
else
prefixdir=../$prefix
fi


dirs="$commdirs"
echo "Prepare local dirs for $name ..."
dirs=$dirs" $dutname" 

for dir in $dirs; do
    echo "mkdir -p $prefixdir/$dir"
    mkdir -p $prefixdir/$dir
done

basedirs="cf flash"
for dir in $basedirs; do
    echo "mkdir -p $prefixdir/$dutname/$dir"
    mkdir -p $prefixdir/$dutname/$dir
done

echo "Prepare local dirs for $name Done!"
exit 0

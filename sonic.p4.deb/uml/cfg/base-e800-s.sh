#!/bin/bash

if [ $# != 3 ]; then
    echo "Usage: ./base-e800-s.sh cfgfile dutname imagepath"
    exit 1;
fi

cfgfile=$1
dutname=$2
imagepath=$3

# delete temp files
rm -fr /var/run/*_done
rm -fr /tmp/*
rm -fr /var/log/*log /var/log/*tmp /var/log/messages
rm -fr /var/run/*.pid
mkdir /tmp/cmd

#process hostname
hostname E800
if [ -f /mnt/flash/startup-config.conf ]; then
    cat /mnt/flash/startup-config.conf | grep "^hostname" | sh
fi

# up interfaces
intnum=`cat $cfgfile | grep DUT_MAX_INTERFACES | awk '{print $3}'`
for ((i = 0; i <= $intnum; i++)) do
    ifconfig eth$i up  >/dev/null 2>&1
    ip address flush dev eth$i scope link >/dev/null 2>&1
done

manint=`cat $cfgfile | grep MAN_INTERFACE_DUT | awk '{print $3}'`
ifconfig $manint up mtu 1600 >/dev/null 2>&1
ip address flush dev $manint scope link >/dev/null 2>&1
# process files
cp -rf /usr/share/zoneinfo/UTC /etc/localtime
rm -fr /etc/memory_profile
ln -s /centec_switch/etc/stm/profile/ma /etc/memory_profile

MYCD=`cat /root/.bash_profile | grep sbin | grep zebos | grep cd`
if [ "$MYCD" == "" ]; then
    echo "cd $imagepath/sbin" >> /root/.bash_profile
fi

# setting PATH
export PATH=$PATH:/centec_switch/sbin


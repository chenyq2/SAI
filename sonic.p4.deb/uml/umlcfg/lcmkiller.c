/*
 * lcmkiller.c  --
 *    This file contains code to hanlder the msg send by CTP used tcp port 9900.
 * Add this daemon in order to CTP control can emulation e800 linecard kick off on uml 
 * this only the temp soulation for write e800 testing srcipt on uml
 * data: 2009.05.12
 * Author: Yangsj
*/


#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <unistd.h>


#define MAX_BUF_SIZE 1024
#define LISTEN_PORT  9700
#define RESULT_BUF_SIZE 1024
#define RESET_LC_TIME  (20)



int Lk_Sock_Server ( const int port , int *fd) {
    struct sockaddr_in sin;
	int sock_fd;
	sock_fd = socket(AF_INET,SOCK_STREAM,0);
	if (sock_fd == -1) {
		perror("Create Socket FD Error!");
		exit(1);
	}

    bzero(&sin,sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = INADDR_ANY;
	sin.sin_port=htons(port);

	if ( bind(sock_fd,(struct sockaddr *)&sin,sizeof(sin)) == -1 ) {
		perror("Bind socket error!");
		exit(1);
	}

	if ( listen(sock_fd,10)==-1) {
	    perror("listen on port 9900 error!");
		exit(1);
	}
     *fd=sock_fd;
	 return 0;
}



int Lk_Eval_Bash (const char *path, char *result) {    
    FILE *stream;
    size_t size;
	char cmd[256];
	snprintf(cmd,256,"%s %s","/bin/bash",path);
	stream=popen(cmd,"r");
    if (stream) {
           size=fread(result, RESULT_BUF_SIZE, 1, stream);
  	       pclose(stream);
		   return 0;
	} else {
	    	perror("stream open failed!");
			return 1;
	}
	return 0;
}

int Lk_Stop_Lcm ( char *path , char *result ) {
     Lk_Eval_Bash(path, result);
	 return 0;
}


int Lk_Start_Lcm ( char *path , char *result ) {
     Lk_Eval_Bash(path, result);
	 return 0;
}


int Lk_Accept_Conn ( int fd, struct sockaddr_in *sin, int *address_size) {
    int conn_fd;
	struct sockaddr *s_addr;
	s_addr=(struct sockaddr *) sin;
	if ( (conn_fd = accept(fd,s_addr,address_size)) == -1 ) {
		perror("Accept connect error!");
        exit(1);
	} else {
		return conn_fd;
	}
}




int Lk_Recv_Data ( const int fd, char *dstdata,int len) {
	if ( recv(fd,dstdata,len,0) == -1 ) {
		perror("receive data error!");
		exit(1);
	}
	return 0;
}



int  main ( int argc, char **argv) {
    pid_t pid,sid;
    pid=fork();
    if (pid<0) 
      { 
	  perror("fork error!");
	  exit(1); 
      }
    if (pid>0) 
       exit(0);  
    
    //child 
    if((sid=setsid())<0) 
      { 
	  perror("setsid error"); 
	  exit(1); 
      }

    if ((chdir("/")) < 0) 
      {
	   perror("chdir error");
	   exit(1);
      }
     umask(0);
     close(STDIN_FILENO);
     close(STDOUT_FILENO);
     close(STDERR_FILENO); 
	int server_listen_fd;
	int conn_fd;
        char revbuf[MAX_BUF_SIZE];
	char result[RESULT_BUF_SIZE];
	memset(result,'\0',RESULT_BUF_SIZE);
	struct sockaddr_in pin;
	int add_size;
    memset(revbuf,'\0',MAX_BUF_SIZE);
    Lk_Sock_Server(LISTEN_PORT, &server_listen_fd);
    
	while (1) {
		conn_fd=Lk_Accept_Conn(server_listen_fd,&pin,&add_size);
		Lk_Recv_Data(conn_fd,revbuf,MAX_BUF_SIZE);
		printf("%s\n",revbuf);
                if ( strncmp("stop",revbuf,4)==0 ) {
		  system("pkill -x lcm");
		  printf("execute kill lcm process");
		} else if ( strncmp("start",revbuf,5)==0 ) {
		  system("lcm");
		  printf("execute start lcm process");
		} else if ( strncmp("reset",revbuf,5)==0 ) {
		  system("pkill -x lcm");
		  sleep(RESET_LC_TIME);
		  system("lcm");
		}
		close(conn_fd);
	}

    return 0;
}


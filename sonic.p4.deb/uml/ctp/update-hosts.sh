#!/bin/bash

# update /etc/hosts

if [ $# != 2 ]; then
    echo "Usage: ./update-hosts.sh cfgfile dutname"
    exit 1;
fi

cfgfile=$1
dutname=$2

if [ $dutname != "CTP" ]; then
    echo "WARNING: please only execute it in CTP"
    exit 0
fi

ip=""
get_ip_addr()
{
    _baseip=$1
    _idx=$2

    _prefix=`echo $_baseip | awk '{ split($0,a,"." ); print a[1]"."a[2]"."a[3] }'`
    _suffix=`echo $_baseip | awk '{ split($0,a,"." ); print a[4] }'`
    _idx=`expr $_idx + $_suffix`
    ip="$_prefix.$_idx"
}

hostsfile="/etc/hosts"

ctpip=`cat $cfgfile | grep CTP_M_ADDR | awk '{print $3}'`
e300baseip=`cat $cfgfile | grep E300_M_BASE_ADDR | awk '{print $3}'`
e800baseip=`cat $cfgfile | grep E800_M_BASE_ADDR | awk '{print $3}'`
e800icbaseip=`cat $cfgfile | grep E800_IC_BASE_ADDR | awk '{print $3}'`

# add default entry
echo "127.0.0.1 localhost" > $hostsfile

# add ctp entry
echo "$ctpip ctp" >> $hostsfile

# add e300 entries
for ((i = 0; i < 6; i++)) do
    get_ip_addr $e300baseip $i
    echo "$ip e300-dut`expr $i + 1`" >> $hostsfile
done

# add e800 entries
cnt=0
for ((j = 1; j < 3; j++)) do
    for ((i = 0; i < 2; i++)) do
        get_ip_addr $e800baseip $cnt
        echo "$ip e800-dut$j-s`expr $i + 1`" >> $hostsfile
        cnt=`expr $cnt + 1`
    done

    for ((i = 0; i < 12; i++)) do
        get_ip_addr $e800baseip $cnt
        echo "$ip e800-dut$j-l`expr $i + 1`" >> $hostsfile
        cnt=`expr $cnt + 1`
    done
    cnt=20
done

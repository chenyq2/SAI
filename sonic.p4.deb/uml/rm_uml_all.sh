#!/bin/bash
rm -vf ./linux
rm -vf ./root_fs
rm -vf `find . -name 'root_fs-cow'`
